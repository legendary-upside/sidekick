// Source always points at the dev app host; prod builds rewrite the host to
// apps.legendaryupside.com (see PROD_HOST_REWRITES in _build_extension.py).
const LEGUP_APP_URL = 'https://apps.legendaryupside.com';

document.addEventListener('DOMContentLoaded', () => {
    const auth_status = document.getElementById('auth_status');
    const port = chrome.runtime.connect({ name: 'popup' });

    const formatExposureLine = (exposure) => {
        const ud =
            exposure && exposure.ud_last_updated_ms != null
                ? new Date(exposure.ud_last_updated_ms).toLocaleString()
                : 'Never';
        const dk =
            exposure && exposure.dk_last_updated_ms != null
                ? new Date(exposure.dk_last_updated_ms).toLocaleString()
                : 'Never';
        return `<div><strong>Exposure:</strong> UD ${ud} | DK ${dk}</div>`;
    };

    const MEMBERSHIP_VALIDATION_WINDOW_MS = 48 * 60 * 60 * 1000;

    const parseSessionTimestamp = (raw) => {
        if (raw == null || raw === '') return null;
        if (typeof raw === 'number' && Number.isFinite(raw)) {
            return raw < 1e12 ? raw * 1000 : raw;
        }
        const parsed = Date.parse(String(raw));
        return Number.isNaN(parsed) ? null : parsed;
    };

    const membershipSessionExpiresAt = (data) => {
        const explicit = parseSessionTimestamp(data?.validation_expires_at);
        if (explicit != null) {
            return explicit;
        }
        const validated = parseSessionTimestamp(data?.validated_at ?? data?.last_validated);
        if (validated == null) {
            return null;
        }
        return validated + MEMBERSHIP_VALIDATION_WINDOW_MS;
    };

    const formatExpiration = (expiresAt) => {
        if (!expiresAt) return 'Not set';
        try {
            const expDate = new Date(expiresAt);
            if (isNaN(expDate.getTime())) return 'Invalid date';
            return expDate.toLocaleString();
        } catch (err) {
            return 'Invalid date';
        }
    };

    const formatSessionExpirationLine = (data) => {
        const tier = data?.tier != null ? String(data.tier).trim().toLowerCase() : '';
        if (tier === 'legup') {
            const expiresMs = membershipSessionExpiresAt(data);
            return {
                label: 'Membership session expires',
                value: expiresMs != null
                    ? new Date(expiresMs).toLocaleString()
                    : 'Not set'
            };
        }
        return {
            label: 'App JWT expires',
            value: formatExpiration(data.app_jwt_expires_at)
        };
    };

    const update_auth_status = (data, exposure) => {
        if (data) {
            const formatValue = (value) => {
                if (value === null || value === undefined) return 'Not set';
                return value;
            };

            const formatBoolean = (value) => {
                if (value === undefined || value === null) return 'Unknown';
                return value ? 'Yes' : 'No';
            };

            const manifest = chrome.runtime.getManifest();
            const version = manifest?.version || 'Unknown';
            
            const seasonStage = data.season_stage ? `${String(data.season_stage).charAt(0).toUpperCase()}${String(data.season_stage).slice(1)}` : data.season_stage;
            const exposureHtml = formatExposureLine(exposure);
            const sessionExpiration = formatSessionExpirationLine(data);
            auth_status.innerHTML = `
                <div><strong>Extension Version:</strong> ${version}</div>
                <div><strong>User ID:</strong> ${formatValue(data.user_uuid)}</div>
                <div><strong>Email:</strong> ${formatValue(data.email)}</div>
                <div><strong>Allow Rankings:</strong> ${formatBoolean(data.allow_rankings)}</div>
                <div><strong>Tier:</strong> ${formatValue(data.tier)}</div>
                <div><strong>Reason:</strong> ${formatValue(data.reason)}</div>
                <div><strong>Season Stage:</strong> ${formatValue(seasonStage)}</div>
                <div><strong>${sessionExpiration.label}:</strong> ${sessionExpiration.value}</div>
                <div><strong>Last Config Update:</strong> ${formatExpiration(data.last_config_update)}</div>
                ${exposureHtml}
            `;
        } else {
            auth_status.textContent = 'No session data available';
        }
    };

    // Get initial auth status via port
    const sendPortRequest = (action, data = {}) => {
        return new Promise((resolve, reject) => {
            const request_id = `req_${Date.now()}_${Math.random()}`;
            const timeout = setTimeout(() => {
                reject(new Error('Request timeout'));
            }, 5000);
            
            const messageHandler = (msg) => {
                if (msg?.request_id === request_id) {
                    clearTimeout(timeout);
                    port.onMessage.removeListener(messageHandler);
                    if (msg.status === 'ok' || msg.status === 'success') {
                        resolve(msg);
                    } else {
                        reject(new Error(msg.message || 'Request failed'));
                    }
                }
            };
            
            port.onMessage.addListener(messageHandler);
            port.postMessage({ action, request_id, ...data });
        });
    };

    const sidecarEnabledCheckbox = document.getElementById('sidecarEnabledCheckbox');
    const streamerOverlayEnabledCheckbox = document.getElementById('streamerOverlayEnabledCheckbox');

    const loadSidecarPreference = () => {
        if (!sidecarEnabledCheckbox) return;
        sendPortRequest('GET_SETTINGS', { scope: 'content_script', keys: 'user_settings' })
            .then((response) => {
                const enabled = response?.settings?.user_settings?.sidecar_enabled;
                sidecarEnabledCheckbox.checked = !!enabled;
            })
            .catch((err) => {
                console.error('[popup] Failed to load sidecar preference', err);
                sidecarEnabledCheckbox.checked = false;
            });
    };

    const persistSidecarPreference = (checked) => {
        return sendPortRequest('SET_SETTINGS', {
            scope: 'content_script',
            settings: { sidecar_enabled: !!checked }
        });
    };

    if (sidecarEnabledCheckbox) {
        loadSidecarPreference();
        sidecarEnabledCheckbox.addEventListener('change', () => {
            const checked = !!sidecarEnabledCheckbox.checked;
            sidecarEnabledCheckbox.disabled = true;
            persistSidecarPreference(checked)
                .catch((err) => {
                    console.error('[popup] Failed to update sidecar preference', err);
                    sidecarEnabledCheckbox.checked = !checked;
                })
                .finally(() => {
                    sidecarEnabledCheckbox.disabled = false;
                });
        });
    }

    const loadStreamerOverlayPreference = () => {
        if (!streamerOverlayEnabledCheckbox) return;
        sendPortRequest('GET_SETTINGS', { scope: 'content_script', keys: 'user_settings' })
            .then((response) => {
                const enabled = response?.settings?.user_settings?.streamer_overlay_enabled;
                streamerOverlayEnabledCheckbox.checked = !!enabled;
            })
            .catch((err) => {
                console.error('[popup] Failed to load streamer overlay preference', err);
                streamerOverlayEnabledCheckbox.checked = false;
            });
    };

    const persistStreamerOverlayPreference = (checked) => {
        return sendPortRequest('SET_SETTINGS', {
            scope: 'content_script',
            settings: { streamer_overlay_enabled: !!checked }
        });
    };

    if (streamerOverlayEnabledCheckbox) {
        loadStreamerOverlayPreference();
        streamerOverlayEnabledCheckbox.addEventListener('change', () => {
            const checked = !!streamerOverlayEnabledCheckbox.checked;
            streamerOverlayEnabledCheckbox.disabled = true;
            persistStreamerOverlayPreference(checked)
                .catch((err) => {
                    console.error('[popup] Failed to update streamer overlay preference', err);
                    streamerOverlayEnabledCheckbox.checked = !checked;
                })
                .finally(() => {
                    streamerOverlayEnabledCheckbox.disabled = false;
                });
        });
    }

    const loadSessionAndSettings = async () => {
        try {
            const [sessionResponse, settingsResponse, exposureResponse] = await Promise.all([
                sendPortRequest('GET_SESSION_DATA'),
                sendPortRequest('GET_SETTINGS', { scope: 'content_script', keys: 'static_settings' }),
                sendPortRequest('GET_EXPOSURE_STATUS').catch(() => null)
            ]);
            
            if (sessionResponse?.session_data) {
                const sessionData = sessionResponse.session_data;
                const seasonStage = settingsResponse?.settings?.static_settings?.season_stage || 'Not set';
                
                // Add season_stage to session data for display
                const displayData = {
                    ...sessionData,
                    season_stage: seasonStage
                };
                update_auth_status(displayData, exposureResponse?.exposure);
            }
        } catch (err) {
            console.error('[popup] Failed to load session or settings', err);
            // Fallback to just session data
            Promise.all([
                sendPortRequest('GET_SESSION_DATA'),
                sendPortRequest('GET_EXPOSURE_STATUS').catch(() => null)
            ])
                .then(([response, exposureRes]) => {
                    if (response) {
                        update_auth_status(response.session_data, exposureRes?.exposure);
                    }
                })
                .catch((err2) => {
                    console.error('[popup] get_session_data failed', err2);
                });
        }
    };
    
    loadSessionAndSettings();

    // Listen for auth status updates
    port.onMessage.addListener(async (request) => {
        if (request.action === 'CLOSE_POPUP_UI') {
            window.close();
            return;
        }
        if (request.action === 'UPDATE_SESSION_DATA') {
            // Also fetch settings to get season_stage
            try {
                const [settingsResponse, exposureResponse] = await Promise.all([
                    sendPortRequest('GET_SETTINGS', { scope: 'content_script', keys: 'static_settings' }),
                    sendPortRequest('GET_EXPOSURE_STATUS').catch(() => null)
                ]);
                const seasonStage = settingsResponse?.settings?.static_settings?.season_stage || 'Not set';
                const displayData = {
                    ...request.session_data,
                    season_stage: seasonStage
                };
                update_auth_status(displayData, exposureResponse?.exposure);
            } catch (err) {
                console.error('[popup] Failed to load settings for session update', err);
                // Fallback to just session data
                update_auth_status(request.session_data);
            }
        } else if (request.action === 'UPDATE_SETTINGS') {
            // When settings update, refresh the display to show updated season_stage
            try {
                const [sessionResponse, exposureResponse] = await Promise.all([
                    sendPortRequest('GET_SESSION_DATA'),
                    sendPortRequest('GET_EXPOSURE_STATUS').catch(() => null)
                ]);
                if (sessionResponse?.session_data) {
                    const seasonStage = request.settings?.static_settings?.season_stage || 'Not set';
                    const displayData = {
                        ...sessionResponse.session_data,
                        season_stage: seasonStage
                    };
                    update_auth_status(displayData, exposureResponse?.exposure);
                }
            } catch (err) {
                console.error('[popup] Failed to refresh display after settings update', err);
            }
        }
    });

    // Handle open test draft page button
    document.getElementById('openTestDraftPage').addEventListener('click', () => {
        chrome.tabs.create({ url: chrome.runtime.getURL('draft-test.html') });
    });

    // Handle open settings page button
    document.getElementById('openSidekickSettings').addEventListener('click', () => {
        chrome.tabs.create({ url: chrome.runtime.getURL('settings.html') });
    });

    // Handle open LegUp app button
    document.getElementById('openLegUpApp').addEventListener('click', () => {
        chrome.tabs.create({ url: LEGUP_APP_URL });
    });

    // Handle restart background script button
    document.getElementById('restartBackgroundScript').addEventListener('click', () => {
        sendPortRequest('RESTART_BACKGROUND_SCRIPT')
            .then((response) => {
            })
            .catch((err) => {
                console.error('[popup] Failed to restart background script:', err);
            });
    });

    // Handle logout and restart button
    document.getElementById('logoutAndRestart').addEventListener('click', () => {
        if (confirm('This will clear all extension storage and restart the background script. Continue?')) {
            sendPortRequest('LOGOUT_AND_RESTART')
                .then((response) => {
                })
                .catch((err) => {
                    console.error('[popup] Failed to logout and restart:', err);
                });
        }
    });
});
