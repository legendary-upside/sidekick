const BASE_BG = Object.freeze({
    env: 'prod', // 'prod' | 'dev' | 'local'
                // this should generally not be changed
                // value is automatically replaced by _build_extension.py during build process
                // only a value of 'dev' should be committed to the repo
    is_sideloaded: false,
    override_sideload_check: false,

    server_address_by_env: Object.freeze({
        // Prod builds rewrite the dev host to the prod one (PROD_HOST_REWRITES in
        // _build_extension.py), so shipped prod code never references the dev server.
        prod: 'apps.legendaryupside.com',
        dev: 'apps.legendaryupside.com',
        local: 'localhost:8080'
    }),

    api_base_path: '/api',
    draft_cleanup_days: 30,
    auth_poll_interval_ms: 5 * 60 * 1000
});

const PERSISTABLE_BG_KEYS = [];
const RUNTIME_BG = {
    is_sideloaded: BASE_BG.is_sideloaded
};

const CONFIG_ENDPOINT_PATH = '/config';
const CONFIG_DATASETS_ENDPOINT_PATH = '/config/datasets';
const USER_RANKINGS_ENDPOINT_PATH = '/user-rankings';
const INSTANCES_REGISTER_ENDPOINT_PATH = '/instances/register';

// Same string as manifest.json; use for every auth/config/rankings/register/session payload.
function get_extension_version() {
    try {
        return chrome.runtime.getManifest().version;
    } catch (err) {
        return 'unknown';
    }
}
const CONFIG_REFRESH_INTERVAL_MS = 15 * 60 * 1000;
const CONFIG_REFRESH_PLAYER_MAP_MISS_MIN_INTERVAL_MS = 3 * 60 * 1000; // Rate limit when content script used team-agnostic fallback
const CONFIG_RETRY_BASE_DELAY_MS = 2000;
const CONFIG_RETRY_MAX_DELAY_MS = 60 * 1000;
const IN_FLIGHT_POLL_INTERVAL_MS = 1000;
const IN_FLIGHT_POLL_INITIAL_DELAY_MS = 3000; // Wait before first poll
const IN_FLIGHT_POLL_MAX_COUNT = 12;
// HTTP timeouts for /rankings. The content script gives up and retries at 20s
// (RANKINGS_REQUEST_TIMEOUT_MS), so a queue slot must not sit on a hung request
// past that point — 3 hung slots starve the queue and every queued item ages out.
const RANKINGS_HTTP_TIMEOUT_MS = 20000;
const RANKINGS_POLL_HTTP_TIMEOUT_MS = 10000; // Poll POSTs are lean and run on a 1s cadence
// An inFlightRankingsRequests marker older than this is treated as orphaned (its
// request died without running the cleanup `finally`) and cleared instead of
// deduping the incoming request. Self-heal for any marker-leak path.
const IN_FLIGHT_MARKER_STALE_MS = 30000;
const QUEUE_LOG_INTERVAL_MS = 15000; // Periodic background queue visibility logging

// Tournament error / no-data cache TTL (background_draft_state.js)
const TOURNAMENT_ERROR_CACHE_TTL_MS = 1 * 1000;
const TOURNAMENT_NO_DATA_CACHE_TTL_MS = 1 * 60 * 1000;
// Sprint bestball backend uses quantile_bin_averages(..., n_bins=20), not 200.
const UNDERDOG_SPRINT_FINALS_EV_BINS = 20;
// Standard/playoff finals quantile bins when finals size >= this value.
// Overridable via remote config background_settings.underdog_finals_ev_bins.
const UNDERDOG_FINALS_EV_BINS_DEFAULT = 200;

/** Debounce window before POST /exposure/sync after local exposure persist (background_exposure.js). */
const EXPOSURE_SYNC_DEBOUNCE_MS = 10 * 1000;
/** Wire payload schema for POST /exposure/sync. */
const EXPOSURE_SYNC_SCHEMA_VERSION = 2;

// Same allowlist as backend ALLOWED_TRUSTED_DATA_UUIDS (/dkslates, /ud_tournament_slate_map).
const TRUSTED_DATA_UPLOAD_UUIDS = Object.freeze([
    "ae6c933b-bfbe-43a8-a452-f8571e782f8a",  // Phil
    "f7bac68c-e408-4e16-ad7e-7cbb78fb4a23",  // Luke
    "f21bb883-09f7-4930-9262-9428caa91f93",  // Kerrane
    "d139bab6-f3a7-4d00-bc57-95c06390505f",  // Shaidy
    "8326aca0-3e26-49d1-abdd-61e2a557c136",  // Sack
    "9be0259e-0b93-445d-b2ee-fb78ff4e7f1b",  // Daniel R
    "e4ac953e-e7ad-4d8b-aad6-3891d7ded565",  // Zach L
    "b16283c8-538f-4180-82dd-9d7f6833287d",  // CeeGee
    "407ce03a-5f6e-4243-9106-ae1221a91bcf",  // Steph
    "5b96c8d9-e38c-4015-8b1f-b000f53bc127",  // Gretch
    "c2aae676-e08c-46ce-8398-152178f23d0c",  // Bert Sure
    "05c9af64-7a0e-4697-9c15-f4442b75b49c"   // Kyle Dvo
]);
const udTournamentSlateMapInFlight = new Set();
const dkTournamentMapInFlight = new Set();

const OVERLAY_SITE_FALLBACK = Object.freeze({
    overlayState: { width: 288, height: 500, mini: false },
    ui: {
        selected_algo_type: 'sim',
        selected_ranking_set: 'legup'
    },
    draftSelections: {},
    streamerOverlayState: {}
});

const CONFIG_FALLBACK = Object.freeze({
    schema_version: 1,
    content_script_settings: {
        user_settings: {
            icon_size: '48',
            use_image_icons: false,
            enable_mouse_over_text: true,
            user_sound_enabled: false,
            use_cached_rankings: true,
            force_lite_mode: false,
            low_resources_mode: false,
            suppress_nonfatal_warning_notifications: false,
            sidecar_enabled: false,
            streamer_overlay_enabled: false,
            tag_icon_quarterback: true,
            tag_icon_teammate: true,
            tag_icon_exposure: false,
            /** 'default' | 'fees_only' | 'percent_only' — overlay exposure tag text when exposure is enabled */
            tag_icon_exposure_display: 'default',
            /** When true, exposure tag uses combined UD+DK totals (fees + pick_count, denom = ud_draft_count + dk_total_entries). */
            exposure_aggregate_across_sites: false,
            tag_icon_week_17: true,
            tag_icon_bye_overlap: true,
            tag_icon_combination_uniqueness: false,
            tag_icon_draft_availability: true,
            tag_icon_r1_active: true,
            tag_icon_conf_champ_opp: true,
            tag_icon_hide_inactive: false,
            tag_icon_compact: false,
            ghost_enable_button_container: true,
            ghost_enable_player_card: false,
            ghost_enable_draft_board: false,
            ud_xhr_replay_disabled: false,
            // Dev: legacy collision diagnostics ignore rules (test urgent bubble); persisted.
            ud_debug_ignore_legacy_collision_rules: false,
            // Underdog exposure aggregation (default: include all slates + older contests).
            // If ud_exposure_included_slates is undefined, treat as "all whitelisted slates".
            ud_exposure_included_slates: undefined,
            ud_exposure_include_older: true,
            /** When true, overlay aggregates exposure across all included slates. When false (default), overlay shows exposure for the current contest's slate only. */
            ud_exposure_aggregate_slates: false,
            dk_exposure_included_slates: undefined,
            dk_exposure_aggregate_slates: false,
            // NOTE: dev/debug toggle; controlled via remote config `static_settings`
            // and optionally overridable from the dev sidecar.
        },
        static_settings: {
            season_stage: 'regular',
            schedule_calcs_enabled: true,
            // Default off: rely on ribbon DOM / legacy map unless enabled.
            ud_intercept_extraction_enabled: false,
            // When true: on Underdog /active/{id} only, after URL draft id changes, skip one tick
            // (no extraction, no CHECK_CACHED). Ignored on /draft/, /completed/, etc. Remote or sidecar.
            ud_enable_nonop_tick_after_nav: false,
            underdog_slate_whitelist: {},
            // Display names for UD slate UUIDs (and legacy UUID-keyed DK slates stored under
            // ud_by_slate, e.g. older Pre-Draft Bestball). Decoupled from the active whitelist so
            // retired slate UUIDs can still be labeled without re-adding them as active slates.
            // Shape: { "<slate_uuid>": "<friendly label>" }. Populated via remote config.
            underdog_slate_friendly_labels: {},
            // DraftKings draft group whitelist used to pin "active" slates surfaced in the
            // overlay/settings UI. Shape mirrors underdog_slate_whitelist: { friendly_key: "<draftGroupId>" }.
            // Defaults to empty here; the real values come from remote config.
            draftkings_slate_whitelist: {},
            // DraftKings draft group display names, keyed by draftGroupId so legacy/retired
            // draft groups can be labeled without re-adding them to the whitelist.
            // Shape: { "<draftGroupId>": "<friendly label>" }. Defaults to empty; populated via remote config.
            draftkings_slate_friendly_labels: {},
            draftkings_tournament_whitelist: []
        },
        overlay: {
            underdog: OVERLAY_SITE_FALLBACK,
            draftkings: OVERLAY_SITE_FALLBACK
        }
    },
    background_settings: {
        draft_cleanup_days: BASE_BG.draft_cleanup_days,
        auth_poll_interval_ms: BASE_BG.auth_poll_interval_ms,
        user_rank_key: 'adp',
        // Max quantile bins for standard/playoff finals stage_loss_evs (sprint stays at 20).
        underdog_finals_ev_bins: UNDERDOG_FINALS_EV_BINS_DEFAULT
    },
    background_datasets: {
        merged_ud_bbm: null,
        merged_dk_bbm: null,
        bbm_teams: null,
        team_override: null,
        id_map: null,
        exposure_id_map: null
    },
    content_script_datasets: {
        player_map_ud: null,
        player_exposure: null,
        id_map: null,
        exposure_id_map: null
    },
    user_rankings_datasets: {}
});

const state = {
    popup_port: null,
    settings_ports: new Set(),
    auth_status_data: null,
    processing_message: false,
    message_queue: [],
    retry_count: 0,
    last_auth_message: null,
    last_auth_type: null,
    last_extension_icon_key: null,
    last_underdog_tournament_call: 0, // Timestamp of last Underdog tournament API call
    last_underdog_contest_styles_call: 0, // Timestamp of last Underdog contest_styles API call
    last_underdog_entry_styles_call: 0, // Timestamp of last Underdog entry_styles API call
    boot_id: null, // Unique ID for this background script instance (changes on restart)
    hello_seq: 0, // Sequence number for BG_HELLO messages
    last_player_map_miss_config_refresh: 0, // Timestamp of last config refresh triggered by player-map fallback
    queue_log_timer: null, // Interval handle for queue visibility logging
    queue_metrics: {
        last_log_ts: Date.now(),
        interval_requests: 0,
        interval_poll_requests: 0,
        interval_duplicates: 0,
        interval_enqueued: 0,
        interval_cache_checks: 0,
        interval_cache_enqueued: 0,
        interval_dropped: 0,
        total_requests: 0,
        total_poll_requests: 0,
        total_duplicates: 0,
        total_enqueued: 0,
        total_cache_checks: 0,
        total_cache_enqueued: 0,
        total_dropped: 0,
        total_stale_markers_cleared: 0
    },
};

const KEYS = {
    settings_background: 'settings:background',
    settings_content_script: 'settings:content_script',
    session_data: 'session:data',
    matchup_odds_fields: 'matchup:odds_fields',
    draft_prefix: 'draft:players:',
    draft_cleanup_marker: 'draft:players:__last_cleanup',
    remote_config_cache: 'config:remote_cache',
    remote_config_cache_ts: 'config:remote_cache_ts',
    /** `user_uuid` string used for the last successful `/config` fetch (empty string = anonymous). */
    remote_config_cache_user_uuid: 'config:remote_cache_user_uuid',
    /** Server fingerprints for lean config / datasets not-modified. */
    remote_config_etag: 'config:remote_etag',
    remote_datasets_etag: 'config:remote_datasets_etag',
    remote_user_rankings_etag: 'config:remote_user_rankings_etag',
    remote_user_exposure_etag: 'config:remote_user_exposure_etag',
    /**
     * `user_uuid` we have previously seen a non-empty custom rankings set for.
     * Distinguishes "this user has no custom rankings" from "we lost them locally",
     * so only the latter forces an uncached datasets pull.
     */
    user_rankings_seen_for_user_uuid: 'config:user_rankings_seen_for_user_uuid',
    /** Last `ETag` header from `/config/datasets` (datasets or combined); used as known_etag. */
    remote_datasets_response_etag: 'config:remote_datasets_response_etag',
    draft_states: 'draft:states',
    rankings_cache: 'rankings:cache',
    tournament_prefix: 'tournament:underdog:',
    tournament_dk_prefix: 'tournament:dk:',
    tournament_evs_prefix: 'tournament:evs:',
    tournament_draft_mapping: 'tournament:underdog:draft_mapping', // Maps draft_id -> tournament_id for Underdog
    // tournament_id -> marker once this install successfully POSTed /ud_tournament_slate_map
    ud_tournament_slate_map_submitted: 'ud:tournament_slate_map:submitted',
    // tournament_key -> marker once this install successfully POSTed /dk_tournament_map
    dk_tournament_map_submitted: 'dk:tournament_map:submitted',
    ud_draft_xhr_snapshots: 'ud:draft:xhr_snapshots', // draft_id -> { url, headers, captured_at_ms } for replay
    tournament_dk_draft_mapping: 'tournament:dk:draft_mapping', // Maps draft_id -> tournament_key for DraftKings
    tournament_error_cache: 'tournament:underdog:error_cache', // Cache for failed tournament API calls with TTL
    ud_tournament_marker_clear_gen: 'ud:tournament_marker_clear_gen', // Bumped when UD tournament 404 markers are cleared (install/update); BG_HELLO invalidates CS summary cache
    contest_styles_cache: 'tournament:underdog:contest_styles', // Cached contest_styles (shared across all tournaments)
    entry_styles_cache: 'tournament:underdog:entry_styles', // Cached entry_styles (shared across all tournaments)
    contest_dk_prefix: 'contest:dk:',
    contest_dk_draft_mapping: 'contest:dk:draft_mapping', // Maps draft_id -> contest_id for DraftKings
    active_polls: 'background:active_polls', // Persisted active polling timers
    background_startup_time: 'background:startup_time', // Track when background script started
    exposure_player_map: 'exposure:player_map', // Player exposure rows + per-site last update (local only)
    exposure_upload_state: 'exposure:upload_state', // Per-slate content hashes + last manifest for backend sync
    dk_exposure_contest_fee_cache: 'exposure:dk:contest_fee_cache', // { [contestKey]: { entryFee, name, tournamentKey, updated_at_ms } }
    streamer_mode_data: 'streamer:mode_data', // Shared streamer overlay payload (cross-tab)
    /** Logged-in DraftKings / Underdog display usernames (for multi-account tracking). */
    fantasy_site_usernames: 'fantasy:site_usernames',
    /** Stable per-install UUID; cleared on uninstall/reinstall (and full storage clear). */
    install_instance_id: 'install:instance_id',
    /** Server-minted secret from POST /instances/register; never log or postMessage. */
    install_instance_secret: 'install:instance_secret',
    /**
     * One-shot marker: client-auth / attestation storage reset for natural updates
     * from pre-2.2.50 (or early attestation) installs. Set on install and after the
     * update migration runs so it does not repeat every version bump.
     */
    client_auth_storage_reset_v1: 'migration:client_auth_storage_reset_v1'
};

const storage = {
    get(keys) {
        return new Promise(resolve => chrome.storage.local.get(keys, resolve));
    },
    set(obj) {
        return new Promise(resolve => chrome.storage.local.set(obj, resolve));
    },
    remove(keys) {
        return new Promise(resolve => chrome.storage.local.remove(keys, resolve));
    }
};

const contentPorts = new Map();
const inFlightRankingsRequests = new Map(); // Key: request_identifier, Value: Promise
const inFlightPollTimers = new Map(); // Key: request_identifier, Value: { timerId, port, requestData }
const pendingPortRequests = new Map(); // Key: request_id, Value: { resolve, reject, timeout }

// Request queue to limit concurrent rankings request processing
// Prevents multiple tabs from overwhelming the background script
const RANKINGS_QUEUE_MAX_PENDING = 20;
const CACHED_RANKINGS_QUEUE_MAX_PENDING = 40;
const RANKINGS_QUEUE_ITEM_TTL_MS = 25 * 1000;

const rankingsRequestQueue = {
    queue: [],
    processing: 0,
    maxConcurrent: 3, // Allow up to 3 concurrent rankings requests
    processNext: null,
    maxPending: RANKINGS_QUEUE_MAX_PENDING
};

// Queue for cached rankings lookups to prevent spam when many tabs poll simultaneously
const cachedRankingsRequestQueue = {
    queue: [],
    processing: 0,
    maxConcurrent: 5,
    processNext: null,
    maxPending: CACHED_RANKINGS_QUEUE_MAX_PENDING
};

// A dropped item never runs, so its owner must get a chance to clean up state it
// set optimistically (in-flight markers) and to tell the content script — otherwise
// the request identifier stays marked in-flight forever and every retry for it is
// silently swallowed by the duplicate filter.
function runQueueItemOnDrop(item, dropReason, logLabel) {
    if (!item || typeof item.onDrop !== 'function') return;
    try {
        item.onDrop(dropReason);
    } catch (err) {
    }
}

function enqueueBoundedQueue(queueState, item, logLabel) {
    if (!queueState || !item) return false;
    const maxPending = queueState.maxPending || 20;
    while (queueState.queue.length >= maxPending) {
        const dropped = queueState.queue.shift();
        if (BASE_BG.env !== 'prod') {
            const log_data = {
                request_identifier: dropped?.request_identifier || null,
                enqueued_at: dropped?.enqueued_at || null,
                queue_length: queueState.queue.length
            };
        }
        // Owners that need prod visibility (rankings requests) log from their own onDrop.
        runQueueItemOnDrop(dropped, 'queue_cap', logLabel);
    }
    queueState.queue.push(item);
    return true;
}

function shiftFreshQueueItem(queueState, ttlMs) {
    const limit = ttlMs == null ? RANKINGS_QUEUE_ITEM_TTL_MS : ttlMs;
    const now = Date.now();
    while (queueState.queue.length > 0) {
        const next = queueState.queue.shift();
        const enqueuedAt = next?.enqueued_at || 0;
        if (enqueuedAt && (now - enqueuedAt) > limit) {
            if (BASE_BG.env !== 'prod') {
                const log_data = {
                    request_identifier: next?.request_identifier || null,
                    age_ms: now - enqueuedAt,
                    ttl_ms: limit
                };
            }
            // Owners that need prod visibility (rankings requests) log from their own onDrop.
            runQueueItemOnDrop(next, 'stale_ttl', 'queue');
            continue;
        }
        return next;
    }
    return null;
}

function notifyRankingsRequestFailed(port, payload) {
    const data = payload && typeof payload === 'object' ? payload : {};
    const message = data.message || 'Rankings request failed. Refresh your session and try again.';
    const type = data.type || 'rankings_error';
    const request_identifier = data.request_identifier || null;
    const draft_id = data.draft_id || null;

    if (port) {
        try {
            port.postMessage({
                action: 'RANKINGS_REQUEST_FAILED',
                request_identifier,
                draft_id,
                message,
                type,
                reason: data.reason || null
            });
        } catch (err) {
        }
    }

    // Soft overlay notice (closable path via UPDATE_NOTIFICATION). Callers pass
    // broadcast: false for transient failures the client auto-recovers from
    // (queue drops, poll give-ups) so the user isn't spammed with notices.
    if (data.broadcast !== false && typeof broadcast_notification === 'function') {
        broadcast_notification(message, type);
    }
}

// Tell a tab that fresh results for one of its requests just landed in the local
// rankings cache, so it can pull them immediately (CHECK_CACHED_RANKINGS) instead
// of waiting for its next extraction tick. Delivery is best-effort: on a dead or
// mid-reconnect port the content script still recovers via its tick loop.
function notifyRankingsResultsReady(port, tabId, data) {
    const payload = data && typeof data === 'object' ? data : {};
    // Prefer the live port for the tab — the captured port may predate a reconnect.
    let targetPort = null;
    if (tabId != null && typeof contentPorts !== 'undefined' && contentPorts.get(tabId)) {
        targetPort = contentPorts.get(tabId);
    } else if (port) {
        targetPort = port;
    }
    if (!targetPort) {
        return false;
    }
    try {
        targetPort.postMessage({
            action: 'RANKINGS_RESULTS_READY',
            request_identifier: payload.request_identifier || null,
            draft_id: payload.draft_id || null,
            num_picks: typeof payload.num_picks === 'number' ? payload.num_picks : null
        });
        return true;
    } catch (err) {
        return false;
    }
}

function clearStaleRankingsWork(options = {}) {
    const reason = options.reason || 'unspecified';
    const droppedRankings = rankingsRequestQueue.queue.length;
    const droppedCached = cachedRankingsRequestQueue.queue.length;
    rankingsRequestQueue.queue = [];
    cachedRankingsRequestQueue.queue = [];

    const pollIds = [...inFlightPollTimers.keys()];
    for (const requestIdentifier of pollIds) {
        try {
            stopInFlightPolling(requestIdentifier);
        } catch (err) {
        }
    }

    const inFlightIds = [...inFlightRankingsRequests.keys()];
    inFlightRankingsRequests.clear();

    if (BASE_BG.env !== 'prod') {
        const log_data = {
            reason,
            dropped_rankings_queue: droppedRankings,
            dropped_cached_queue: droppedCached,
            stopped_polls: pollIds.length,
            cleared_in_flight: inFlightIds.length
        };
    }
}

const configState = {
    data: null,
    pending: null,
    refreshTimer: null,
    lastFetch: 0,
    /** Last successful remote config fetch assumed this `user_uuid` (including ''); null until first apply/fetch. */
    remote_config_fetched_for_user_uuid: null,
    /** { config, datasets, user_rankings, user_exposure, datasets_response } from last successful etag exchange. */
    etags: {
        config: '',
        datasets: '',
        user_rankings: '',
        user_exposure: '',
        datasets_response: '',
    },
};

const SUBSCRIPTION_TIER_SIDEKICK = 'sidekick';
const SUBSCRIPTION_TIER_LEGUP = 'legup';
const MEMBERSHIP_VALIDATION_WINDOW_MS = 48 * 60 * 60 * 1000;

function parse_session_timestamp(raw) {
    if (raw == null || raw === '') return null;
    if (typeof raw === 'number' && Number.isFinite(raw)) {
        return raw < 1e12 ? raw * 1000 : raw;
    }
    const parsed = Date.parse(String(raw));
    return Number.isNaN(parsed) ? null : parsed;
}

function membership_session_expires_at(session) {
    const s = session && typeof session === 'object' ? session : {};
    const explicit = parse_session_timestamp(s.validation_expires_at);
    if (explicit != null) {
        return explicit;
    }
    const validated = parse_session_timestamp(s.validated_at ?? s.last_validated);
    if (validated == null) {
        return null;
    }
    return validated + MEMBERSHIP_VALIDATION_WINDOW_MS;
}

const TIER_CAPABILITIES = Object.freeze({
    sidekick: Object.freeze({
        rankings: true,
        overlay_extraction: true
    }),
    legup: Object.freeze({
        rankings: false,
        overlay_extraction: true
    }),
    none: Object.freeze({
        rankings: false,
        overlay_extraction: false
    })
});

function normalize_tier(raw) {
    if (raw == null || raw === '') return null;
    const s = String(raw).trim().toLowerCase();
    if (s === SUBSCRIPTION_TIER_SIDEKICK || s.includes('sidekick')) return SUBSCRIPTION_TIER_SIDEKICK;
    if (s === SUBSCRIPTION_TIER_LEGUP || s === 'leg up') return SUBSCRIPTION_TIER_LEGUP;
    return null;
}

function session_access_level(session) {
    const s = session && typeof session === 'object' ? session : {};
    const tier = normalize_tier(s.tier);
    if (s.allow_rankings === true || tier === SUBSCRIPTION_TIER_SIDEKICK) {
        return SUBSCRIPTION_TIER_SIDEKICK;
    }
    if (tier === SUBSCRIPTION_TIER_LEGUP) {
        return SUBSCRIPTION_TIER_LEGUP;
    }
    return 'none';
}

function session_allows_sidekick_rankings(session) {
    return session?.allow_rankings === true;
}

// Machine-readable session.reason values set by the extension. Keep distinct so
// overlay copy / popup debug can tell 48h window expiry from app-JWT recovery misses.
const AUTH_REASON = Object.freeze({
    session_window_expired: 'auth:session_window_expired',
    app_jwt_expired: 'auth:app_jwt_expired',
    tokens_missing: 'auth:tokens_missing',
    refresh_failed: 'auth:refresh_failed',
    user_not_found: 'auth:user_not_found',
});

const AUTH_REASON_USER_MESSAGES = Object.freeze({
    [AUTH_REASON.session_window_expired]:
        "It's been a while since you went to legendaryupside.com. Click the button to refresh your session.",
    [AUTH_REASON.app_jwt_expired]:
        'Your Sidekick session timed out. Click the button to renew it at legendaryupside.com.',
    [AUTH_REASON.tokens_missing]:
        'Sidekick needs you to sign in at legendaryupside.com. Click the button to continue.',
    [AUTH_REASON.refresh_failed]:
        'Sidekick could not refresh your session. Click the button to try again, or restart the background script if this keeps happening.',
    [AUTH_REASON.user_not_found]:
        'Your Sidekick account was not found on the server. Click the button to sign in at legendaryupside.com.',
});

function auth_reason_user_message(reason) {
    const raw = reason == null ? '' : String(reason);
    if (!raw) {
        return '';
    }
    if (AUTH_REASON_USER_MESSAGES[raw]) {
        return AUTH_REASON_USER_MESSAGES[raw];
    }
    // Backend / legacy strings that previously all mapped to the 48h bubble.
    if (raw.includes('Validation time exceeded') || raw === 'Session expired; sign in at legendaryupside.com') {
        return AUTH_REASON_USER_MESSAGES[AUTH_REASON.session_window_expired];
    }
    if (raw.includes('Session not found on server')) {
        return AUTH_REASON_USER_MESSAGES[AUTH_REASON.user_not_found];
    }
    if (raw.includes('does not have the required subscription') || raw.includes('Sidekick subscription required')) {
        return "You do not have Sidekick access. Subscribe to the LegUp + Sidekick tier at <a href='https://www.legendaryupside.com/#/portal/account' target='_blank'>Legendary Upside</a> and then press the button to refresh your session.";
    }
    if (raw.includes('auth:app_jwt_expired') || /app jwt expired|app session expired/i.test(raw)) {
        return AUTH_REASON_USER_MESSAGES[AUTH_REASON.app_jwt_expired];
    }
    if (raw.includes('auth:refresh_failed') || /could not refresh|refresh failed/i.test(raw)) {
        return AUTH_REASON_USER_MESSAGES[AUTH_REASON.refresh_failed];
    }
    if (raw.includes('auth:tokens_missing') || raw.includes('sign in at legendaryupside.com')) {
        return AUTH_REASON_USER_MESSAGES[AUTH_REASON.tokens_missing];
    }
    if (raw.includes('legendaryupside.com') || raw.includes('Session expired')) {
        return AUTH_REASON_USER_MESSAGES[AUTH_REASON.session_window_expired];
    }
    return '';
}

function session_auth_refresh_needed(session) {
    const reason = session?.reason == null ? '' : String(session.reason);
    if (!reason) {
        return false;
    }
    if (reason.startsWith('auth:')) {
        return reason === AUTH_REASON.session_window_expired
            || reason === AUTH_REASON.app_jwt_expired
            || reason === AUTH_REASON.tokens_missing
            || reason === AUTH_REASON.refresh_failed
            || reason === AUTH_REASON.user_not_found;
    }
    return reason.includes('legendaryupside.com')
        || reason.includes('Session expired')
        || reason.includes('Validation time exceeded')
        || reason.includes('Session not found on server');
}

function compute_session_auth_notification(session) {
    const normalized = { ...(session || {}) };
    if (!Object.prototype.hasOwnProperty.call(normalized, 'user_uuid')) {
        normalized.user_uuid = null;
    }
    if (!Object.prototype.hasOwnProperty.call(normalized, 'allow_rankings')) {
        normalized.allow_rankings = null;
    }
    if (!Object.prototype.hasOwnProperty.call(normalized, 'reason')) {
        normalized.reason = null;
    }
    if (!Object.prototype.hasOwnProperty.call(normalized, 'tier')) {
        normalized.tier = null;
    }

    const accessLevel = session_access_level(normalized);
    let message = '';
    const type = 'auth_error';

    const sessionRefreshNeeded =
        normalized.user_uuid &&
        normalized.allow_rankings !== true &&
        session_auth_refresh_needed(normalized);

    if ((accessLevel === SUBSCRIPTION_TIER_SIDEKICK || accessLevel === SUBSCRIPTION_TIER_LEGUP) && !sessionRefreshNeeded) {
        return { message, type };
    }

    if (!normalized.allow_rankings) {
        message = auth_reason_user_message(normalized.reason);
        if (!message) {
            if (normalized.allow_rankings === null || normalized.allow_rankings === undefined) {
                message = 'Please sign in to Legendary Upside to use Sidekick. Press the button to sign in.';
            } else {
                message = 'Unknown issue. Please contact support.';
            }
        }
    }

    return { message, type };
}

const EXTENSION_ACTION_ICON_SIZE = 48;

const EXTENSION_ACTION_ICON_PATHS = Object.freeze({
    legup: 'assets/kickstand_favicon_145x150.png',
    underdog: 'assets/Sidekick_Favicon-Transparent.png',
    draftkings: 'assets/Sidekick_Favicon-DK.png',
    sidekick: 'assets/Sidekick_Favicon-Black2x-100.png'
});

function is_session_authenticated(session) {
    const uuid = session?.user_uuid;
    return typeof uuid === 'string' && uuid.length > 0;
}

function is_legup_lite_mode(session, user_settings) {
    if (!is_session_authenticated(session)) {
        return false;
    }
    if (user_settings?.force_lite_mode) {
        return true;
    }
    return session_access_level(session) === SUBSCRIPTION_TIER_LEGUP;
}

function extension_site_from_url(url) {
    if (!url) return null;
    if (/app\.(?:underdogfantasy|underdogsports)\.com/i.test(url)) {
        return 'underdog';
    }
    if (/draftkings\.com/i.test(url)) {
        return 'draftkings';
    }
    return null;
}

async function extension_action_icon_active_site() {
    const tabsApi = (typeof browser !== 'undefined' && browser.tabs)
        ? browser.tabs
        : (typeof chrome !== 'undefined' ? chrome.tabs : null);
    if (!tabsApi?.query) {
        return null;
    }
    try {
        const tabs = await tabsApi.query({ active: true, currentWindow: true });
        return extension_site_from_url(tabs?.[0]?.url || '');
    } catch (_) {
        return null;
    }
}

function extension_action_icon_key(session, userSettings, site) {
    if (is_legup_lite_mode(session, userSettings || {})) {
        return 'legup';
    }
    if (site === 'underdog') {
        return 'underdog';
    }
    if (site === 'draftkings') {
        return 'draftkings';
    }
    return 'sidekick';
}

function extension_action_icon_set_icon_path(relPath) {
    const normalized = String(relPath || '').replace(/^\//, '');
    return { [EXTENSION_ACTION_ICON_SIZE]: `/${normalized}` };
}

async function extension_action_icon_image_data_for_path(relPath, size) {
    const runtime = (typeof browser !== 'undefined' && browser.runtime)
        ? browser.runtime
        : (typeof chrome !== 'undefined' ? chrome.runtime : null);
    if (!runtime?.getURL) {
        throw new Error('runtime.getURL unavailable');
    }

    const url = runtime.getURL(String(relPath).replace(/^\//, ''));
    const response = await fetch(url);
    if (!response.ok) {
        throw new Error(`icon fetch failed (${response.status}) for ${url}`);
    }

    const blob = await response.blob();
    const bitmap = await createImageBitmap(blob);
    try {
        const canvas = new OffscreenCanvas(size, size);
        const ctx = canvas.getContext('2d', { willReadFrequently: true });
        ctx.drawImage(bitmap, 0, 0, size, size);
        return { [String(size)]: ctx.getImageData(0, 0, size, size) };
    } finally {
        if (typeof bitmap.close === 'function') {
            bitmap.close();
        }
    }
}

async function request_extension_action_icon_resync(session) {
    state.last_extension_icon_key = null;
    await sync_extension_action_icon(session);
}

async function sync_extension_action_icon(session) {
    const actionApi = (typeof browser !== 'undefined' && browser.action)
        ? browser.action
        : (typeof chrome !== 'undefined' ? chrome.action : null);
    if (!actionApi?.setIcon) {
        return;
    }

    let userSettings = {};
    if (typeof get_content_script_settings === 'function') {
        try {
            const cs = await get_content_script_settings(['user_settings']);
            userSettings = cs?.user_settings || {};
        } catch (_) {}
    }

    const site = await extension_action_icon_active_site();
    const iconKey = extension_action_icon_key(session, userSettings, site);
    const cacheKey = `${iconKey}:${site || 'none'}`;
    if (state.last_extension_icon_key === cacheKey) {
        return;
    }

    const relPath = EXTENSION_ACTION_ICON_PATHS[iconKey] || EXTENSION_ACTION_ICON_PATHS.sidekick;
    const pathDetails = extension_action_icon_set_icon_path(relPath);

    try {
        // MV3 service workers resolve relative paths from the worker file, not the
        // extension root. Leading-slash paths work in sideloaded builds but can fail
        // once packaged/signed, so prefer ImageData when OffscreenCanvas is available.
        if (typeof OffscreenCanvas !== 'undefined' && typeof createImageBitmap === 'function') {
            const imageData = await extension_action_icon_image_data_for_path(relPath, EXTENSION_ACTION_ICON_SIZE);
            await actionApi.setIcon({ imageData });
        } else {
            await actionApi.setIcon({ path: pathDetails });
        }
        state.last_extension_icon_key = cacheKey;
    } catch (imageDataErr) {
        try {
            await actionApi.setIcon({ path: pathDetails });
            state.last_extension_icon_key = cacheKey;
        } catch (pathErr) {
            console.error('[auth] sync_extension_action_icon failed', {
                iconKey,
                site,
                imageDataErr,
                pathErr
            });
        }
    }
}

// Underdog legacy ribbon key collisions: defines __LEGUP_UD_LEGACY_KEY_COLLISION__. Set UD_LEGACY_KEY_COLLISION_RULES_ENABLED false to disable at build time.
(function () {
    const UD_LEGACY_KEY_COLLISION_RULES_ENABLED = true;

    // Board order → suffixed keys (legacyKey-1, …). Brittle when ADPs are close — see docs/CONTENT_SCRIPT_DOCUMENTATION.md.
    const UD_LEGACY_KEY_COLLISION_RULES = [
        {
            legacyKey: 'B. Robinson_RB - ATL',
            orderedPlayerIds: [
                '2b0cbe83-48a2-41b0-b03f-42180cfc4b77', // Bijan Robinson
                '63374c3e-26cc-4d22-a77a-e29b8f5b2f4a' // Brian Robinson
            ]
        },
        {
            legacyKey: 'K. Allen_RB - FA',
            orderedPlayerIds: [
                'd016873c-23d2-4635-b85e-0c23dd393745', // Kaytron Allen
                '7ef90151-aca0-429e-afbb-3aec19c8d687' // Kazmeir Allen
            ]
        }
    ];

    const root = typeof globalThis !== 'undefined' ? globalThis : typeof window !== 'undefined' ? window : self;
    root.__LEGUP_UD_LEGACY_KEY_COLLISION__ = {
        enabled: UD_LEGACY_KEY_COLLISION_RULES_ENABLED,
        rules: UD_LEGACY_KEY_COLLISION_RULES
    };
})();

// DraftKings tournament parsing shared by the content script (draft-time
// tournament_info for rankings requests) and the background script
// (/dk_tournament_map submissions). Loaded into both contexts via
// manifest.json — keep this file dependency-free.

function parse_draft_kings_advancement(rounds = []) {
    if (!Array.isArray(rounds) || rounds.length === 0) return null;

    // Helper to grab a round by number; returns {} if not found
    const byNumber = n => rounds.find(r => r.roundNumber === n) || {};

    const r1 = byNumber(1);
    const r2 = byNumber(2);
    const r3 = byNumber(3);
    const r4 = byNumber(4);

    // All three early rounds must have an advancingEntryCount & contestSize
    if (
        [r1, r2, r3].some(
            r => typeof r.advancingEntryCount !== "number" || typeof r.contestSize !== "number"
        ) ||
        typeof r4.contestSize !== "number"
    ) {
        return null; // malformed data
    }

    const regular_season_num = r1.advancingEntryCount;
    const regular_season_denom = r1.contestSize;

    const w15_num = r2.advancingEntryCount;
    const w15_denom = r2.contestSize;

    const w16_num = r3.advancingEntryCount;
    const w16_denom = r3.contestSize;

    const finals_size = r4.contestSize;
    const w17_quantile = Math.min(0.95, (finals_size - 2) / finals_size);
    const raw_string = "Round Advancement: " + regular_season_num + "/" + regular_season_denom + " - " + w15_num + "/" + w15_denom + " - " + w16_num + "/" + w16_denom + " - " + finals_size + " Seat Final";
    return {
        regular_season_num,
        regular_season_denom,
        w15_num,
        w15_denom,
        w16_num,
        w16_denom,
        finals_size,
        w17_quantile,
        raw_string
    };
}

function parse_draft_kings_payouts(rounds = [], { includeZero = true } = {}) {
    if (!Array.isArray(rounds) || rounds.length === 0) return {};

    const toAmount = (v) => {
        if (typeof v === 'number') return v;
        if (typeof v !== 'string') return 0;
        const m = v.match(/[\d,]+(?:\.\d+)?/);
        return m ? parseFloat(m[0].replace(/,/g, '')) || 0 : 0;
    };

    const result = {};

    for (const r of rounds) {
        const roundNumber = r?.roundNumber;
        const contestSize = Number.isFinite(r?.contestSize) ? r.contestSize : 0;
        if (!Number.isFinite(roundNumber) || contestSize <= 0) {
            continue; // skip malformed rounds
        }

        // Initialize per-position cash array (1..contestSize), default 0
        const cashByPos = new Array(contestSize).fill(0);

        // Apply tiers; non-cash tiers (e.g., Ticket) yield amount=0
        for (const tier of (r.payoutSummary || [])) {
            const amount = toAmount(tier?.tierPayoutDescriptions?.Cash); // Tickets/missing => 0
            const min = Math.max(1, Number.isFinite(tier?.minPosition) ? tier.minPosition : 1);
            const maxRaw = Number.isFinite(tier?.maxPosition) ? tier.maxPosition : min;
            const max = Math.min(contestSize, Math.max(min, maxRaw));

            for (let pos = min; pos <= max; pos++) {
                // If overlapping tiers ever occur, keep the larger cash value
                cashByPos[pos - 1] = Math.max(cashByPos[pos - 1], amount);
            }
        }

        // Reduce to { amount: count }
        const map = {};
        for (const amt of cashByPos) {
            if (amt === 0 && !includeZero) continue;
            map[amt] = (map[amt] || 0) + 1;
        }

        result[roundNumber] = map;
    }

    return result;
}

function cloneDeep(value) {
    if (value === undefined || value === null) return value;
    return JSON.parse(JSON.stringify(value));
}

function deepEqual(a, b) {
    if (a === b) return true;
    return JSON.stringify(a) === JSON.stringify(b);
}

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function normalize_identifier(value) {
    if (value === undefined || value === null) return null;
    const normalized = String(value).trim();
    return normalized.length ? normalized : null;
}

function collect_player_identifiers(player) {
    if (!player || typeof player !== 'object') return [];
    const identifiers = [];

    const ud_identifier = normalize_identifier(player?.ud_id ?? player?.udId ?? player?.id);
    if (ud_identifier) identifiers.push(`ud:${ud_identifier}`);

    const dk_identifier = normalize_identifier(player?.dk_id ?? player?.dkId);
    if (dk_identifier) identifiers.push(`dk:${dk_identifier}`);

    return identifiers;
}






// Local exposure data: merged into content_script_datasets.player_exposure for all tabs.
// Persisted under KEYS.exposure_player_map.

const exposureState = {
    by_id: {},
    ud_by_slate: {},
    dk_by_slate: {},
    ud_last_updated_ms: null,
    ud_draft_count: null, // last-merged slate draft_count (denominator for percent synthesis)
    dk_total_entries: null, // denominator for DK percent synthesis (ownedEntries / totalEntries)
    dk_last_updated_ms: null,
    _hydrated: false
};

function normalizeUdExposureIncludedSlatesMap(raw) {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
        return {};
    }
    const out = {};
    for (const [k, v] of Object.entries(raw)) {
        const key = k != null ? String(k).trim() : '';
        if (!key) continue;
        out[key] = !!v;
    }
    return out;
}

function computeAggregatedUdExposureFromSlates(udBySlate, includedSlatesMap) {
    const bySlate = udBySlate && typeof udBySlate === 'object' ? udBySlate : {};
    const included = normalizeUdExposureIncludedSlatesMap(includedSlatesMap);
    const outById = {};
    let denom = 0;

    const slateIds = Object.keys(bySlate);
    for (let si = 0; si < slateIds.length; si++) {
        const slateId = slateIds[si];
        const ent = bySlate[slateId];
        if (!ent || typeof ent !== 'object') continue;
        const isIncluded = Object.prototype.hasOwnProperty.call(included, slateId) ? !!included[slateId] : true;
        if (!isIncluded) continue;

        const dc = Number(ent.draft_count);
        if (Number.isFinite(dc) && dc > 0) {
            denom += dc;
        }

        const byId = ent.by_id && typeof ent.by_id === 'object' ? ent.by_id : null;
        if (!byId) continue;

        for (const [id, row] of Object.entries(byId)) {
            if (!id) continue;
            const r = row && typeof row === 'object' ? row : null;
            if (!r) continue;
            const prev = outById[id] && typeof outById[id] === 'object' ? outById[id] : {};
            const next = { ...prev };

            const nf = Number(r.ud_entry_fees);
            if (Number.isFinite(nf)) {
                const pf = Number(prev.ud_entry_fees);
                next.ud_entry_fees = (Number.isFinite(pf) ? pf : 0) + nf;
            }

            const np = Number(r.ud_pick_count);
            if (Number.isFinite(np)) {
                const pp = Number(prev.ud_pick_count);
                next.ud_pick_count = (Number.isFinite(pp) ? pp : 0) + np;
            }

            // Keep display fields (prefer existing).
            if (!next.full_name && r.full_name) next.full_name = r.full_name;
            if (!next.position && r.position) next.position = r.position;
            if (!next.team && r.team) next.team = r.team;

            outById[id] = next;
        }
    }

    return { by_id: outById, draft_count: denom > 0 ? denom : null };
}

function computeAggregatedDkExposureFromSlates(dkBySlate, includedSlatesMap) {
    const bySlate = dkBySlate && typeof dkBySlate === 'object' ? dkBySlate : {};
    const included = normalizeUdExposureIncludedSlatesMap(includedSlatesMap);
    const outById = {};
    let denom = 0;

    for (const [slateId, ent] of Object.entries(bySlate)) {
        if (!ent || typeof ent !== 'object') continue;
        const isIncluded = Object.prototype.hasOwnProperty.call(included, slateId) ? !!included[slateId] : true;
        if (!isIncluded) continue;

        const te = Number(ent.total_entries);
        if (Number.isFinite(te) && te > 0) denom += te;

        const byId = ent.by_id && typeof ent.by_id === 'object' ? ent.by_id : null;
        if (!byId) continue;

        for (const [id, row] of Object.entries(byId)) {
            if (!id || !row || typeof row !== 'object') continue;
            const prev = outById[id] && typeof outById[id] === 'object' ? outById[id] : {};
            const next = { ...prev };

            const nf = Number(row.dk_entry_fees);
            if (Number.isFinite(nf)) {
                const pf = Number(prev.dk_entry_fees);
                next.dk_entry_fees = (Number.isFinite(pf) ? pf : 0) + nf;
            }
            const np = Number(row.dk_pick_count);
            if (Number.isFinite(np)) {
                const pp = Number(prev.dk_pick_count);
                next.dk_pick_count = (Number.isFinite(pp) ? pp : 0) + np;
            }
            if (!next.full_name && row.full_name) next.full_name = row.full_name;
            if (!next.position && row.position) next.position = row.position;
            if (!next.team && row.team) next.team = row.team;

            outById[id] = next;
        }
    }

    return { by_id: outById, total_entries: denom > 0 ? denom : null };
}

function stripUdExposureFields(byId) {
    const src = byId && typeof byId === 'object' ? byId : {};
    const out = {};
    for (const [id, row] of Object.entries(src)) {
        if (!row || typeof row !== 'object') {
            out[id] = row;
            continue;
        }
        const next = { ...row };
        // Remove UD exposure fields so recompute can re-apply cleanly.
        delete next.ud_entry_fees;
        delete next.ud_pick_count;
        delete next.ud_drafted_percent; // legacy compat field
        out[id] = next;
    }
    return out;
}

function stripDkExposureFields(byId) {
    const src = byId && typeof byId === 'object' ? byId : {};
    const out = {};
    for (const [id, row] of Object.entries(src)) {
        if (!row || typeof row !== 'object') {
            out[id] = row;
            continue;
        }
        const next = { ...row };
        delete next.dk_entry_fees;
        delete next.dk_pick_count;
        delete next.dk_drafted_percent; // legacy compat field
        out[id] = next;
    }
    return out;
}

async function ensureExposureUserSettingsForStoredSlates(udBySlate, dkBySlate) {
    if (typeof get_content_script_settings !== 'function' || typeof set_content_script_settings !== 'function') {
        return null;
    }
    const settings = await get_content_script_settings(['user_settings']);
    const us = settings && settings.user_settings && typeof settings.user_settings === 'object' ? settings.user_settings : {};

    const udExisting = normalizeUdExposureIncludedSlatesMap(us.ud_exposure_included_slates);
    const udNext = { ...udExisting };
    const udSlateIds = udBySlate && typeof udBySlate === 'object' ? Object.keys(udBySlate) : [];
    let changed = false;
    for (let i = 0; i < udSlateIds.length; i++) {
        const sid = udSlateIds[i];
        if (!sid) continue;
        if (!Object.prototype.hasOwnProperty.call(udNext, sid)) {
            udNext[sid] = true;
            changed = true;
        }
    }
    for (const k of Object.keys(udNext)) {
        if (udSlateIds.indexOf(k) === -1) {
            delete udNext[k];
            changed = true;
        }
    }

    const dkExisting = normalizeUdExposureIncludedSlatesMap(us.dk_exposure_included_slates);
    const dkNext = { ...dkExisting };
    const dkSlateIds = dkBySlate && typeof dkBySlate === 'object' ? Object.keys(dkBySlate) : [];
    for (let j = 0; j < dkSlateIds.length; j++) {
        const sid = dkSlateIds[j];
        if (!sid) continue;
        if (!Object.prototype.hasOwnProperty.call(dkNext, sid)) {
            dkNext[sid] = true;
            changed = true;
        }
    }
    for (const k2 of Object.keys(dkNext)) {
        if (dkSlateIds.indexOf(k2) === -1) {
            delete dkNext[k2];
            changed = true;
        }
    }

    const shouldEnableExposureIcon = us.tag_icon_exposure !== true;
    if (changed || shouldEnableExposureIcon) {
        const patch = {};
        if (changed) {
            patch.ud_exposure_included_slates = udNext;
            patch.dk_exposure_included_slates = dkNext;
        }
        if (shouldEnableExposureIcon) patch.tag_icon_exposure = true;
        const next = await set_content_script_settings(patch);
        notify_content_scripts('UPDATE_SETTINGS', { settings: next });
        notify_settings_pages('UPDATE_SETTINGS', { settings: next });
        return next && next.user_settings ? next.user_settings : us;
    }

    return us;
}

function defaultExposurePayload() {
    return {
        by_id: {},
        ud_by_slate: {},
        dk_by_slate: {},
        ud_last_updated_ms: null,
        ud_draft_count: null,
        dk_total_entries: null,
        dk_last_updated_ms: null
    };
}

function approximateUtf8Bytes(str) {
    if (typeof str !== 'string') return 0;
    if (typeof TextEncoder !== 'undefined') {
        return new TextEncoder().encode(str).length;
    }
    return str.length;
}

async function hydrateExposureFromStorage() {
    try {
        const res = await storage.get([KEYS.exposure_player_map]);
        const raw = res && res[KEYS.exposure_player_map];
        if (raw && typeof raw === 'object') {
            exposureState.by_id = raw.by_id && typeof raw.by_id === 'object' ? raw.by_id : {};
            exposureState.ud_by_slate =
                raw.ud_by_slate && typeof raw.ud_by_slate === 'object' ? raw.ud_by_slate : {};
            exposureState.dk_by_slate =
                raw.dk_by_slate && typeof raw.dk_by_slate === 'object' ? raw.dk_by_slate : {};
            exposureState.ud_last_updated_ms =
                typeof raw.ud_last_updated_ms === 'number' ? raw.ud_last_updated_ms : null;
            exposureState.ud_draft_count =
                typeof raw.ud_draft_count === 'number' ? raw.ud_draft_count : null;
            exposureState.dk_total_entries =
                typeof raw.dk_total_entries === 'number' ? raw.dk_total_entries : null;
            exposureState.dk_last_updated_ms =
                typeof raw.dk_last_updated_ms === 'number' ? raw.dk_last_updated_ms : null;
        } else {
            const empty = defaultExposurePayload();
            exposureState.by_id = empty.by_id;
            exposureState.ud_by_slate = empty.ud_by_slate;
            exposureState.dk_by_slate = empty.dk_by_slate;
            exposureState.ud_last_updated_ms = empty.ud_last_updated_ms;
            exposureState.ud_draft_count = empty.ud_draft_count;
            exposureState.dk_total_entries = empty.dk_total_entries;
            exposureState.dk_last_updated_ms = empty.dk_last_updated_ms;
        }
    } catch (err) {
        console.error('[exposure] hydrateExposureFromStorage failed', err);
        const empty = defaultExposurePayload();
        exposureState.by_id = empty.by_id;
        exposureState.ud_by_slate = empty.ud_by_slate;
        exposureState.dk_by_slate = empty.dk_by_slate;
        exposureState.ud_last_updated_ms = empty.ud_last_updated_ms;
        exposureState.ud_draft_count = empty.ud_draft_count;
        exposureState.dk_total_entries = empty.dk_total_entries;
        exposureState.dk_last_updated_ms = empty.dk_last_updated_ms;
    }
    exposureState._hydrated = true;
}

function mergePlayerExposureIntoContentScriptDatasets(datasets) {
    if (!datasets || typeof datasets !== 'object') return;
    const byId = exposureState.by_id && typeof exposureState.by_id === 'object' ? exposureState.by_id : {};
    const udBySlate = exposureState.ud_by_slate && typeof exposureState.ud_by_slate === 'object' ? exposureState.ud_by_slate : {};
    const dkBySlate = exposureState.dk_by_slate && typeof exposureState.dk_by_slate === 'object' ? exposureState.dk_by_slate : {};
    datasets.player_exposure = {
        by_id: cloneDeep(byId),
        ud_by_slate: cloneDeep(udBySlate),
        dk_by_slate: cloneDeep(dkBySlate),
        ud_last_updated_ms: exposureState.ud_last_updated_ms,
        ud_draft_count: exposureState.ud_draft_count,
        dk_total_entries: exposureState.dk_total_entries,
        dk_last_updated_ms: exposureState.dk_last_updated_ms
    };
}

function getExposureStatusForPopup() {
    const payload = {
        by_id: exposureState.by_id || {},
        ud_by_slate: exposureState.ud_by_slate || {},
        dk_by_slate: exposureState.dk_by_slate || {},
        ud_last_updated_ms: exposureState.ud_last_updated_ms,
        ud_draft_count: exposureState.ud_draft_count,
        dk_total_entries: exposureState.dk_total_entries,
        dk_last_updated_ms: exposureState.dk_last_updated_ms
    };
    const json = JSON.stringify(payload);
    return {
        ud_last_updated_ms: exposureState.ud_last_updated_ms,
        dk_last_updated_ms: exposureState.dk_last_updated_ms,
        approx_storage_bytes: approximateUtf8Bytes(json)
    };
}

// Full payload for extension settings page (split rankings / exposure panes).
function getExposureStorageForSettings() {
    const byId = exposureState.by_id && typeof exposureState.by_id === 'object' ? exposureState.by_id : {};
    const udBySlate = exposureState.ud_by_slate && typeof exposureState.ud_by_slate === 'object' ? exposureState.ud_by_slate : {};
    const dkBySlate = exposureState.dk_by_slate && typeof exposureState.dk_by_slate === 'object' ? exposureState.dk_by_slate : {};
    let infoById = null;
    try {
        if (typeof get_content_script_datasets === 'function') {
            const ds = get_content_script_datasets();
            infoById = ds?.player_map_ud?.player_info_by_id || null;
        }
    } catch (e) {
        infoById = null;
    }
    const outById = cloneDeep(byId);
    const outUdBySlate = cloneDeep(udBySlate);
    const outDkBySlate = cloneDeep(dkBySlate);
    if (infoById && typeof infoById === 'object') {
        const enrichRows = (rowsById) => {
            for (const [id, row] of Object.entries(rowsById || {})) {
                if (!row || typeof row !== 'object') continue;
                const info = infoById[id];
                if (!info || typeof info !== 'object') continue;
                if ((!row.full_name || !String(row.full_name).trim()) && info.full_name) {
                    row.full_name = String(info.full_name).trim();
                }
                if ((!row.position || !String(row.position).trim()) && info.position) {
                    row.position = String(info.position).trim();
                }
                if ((!row.team || !String(row.team).trim()) && info.team) {
                    row.team = String(info.team).trim();
                }
            }
        };
        const enrichSlates = (slates) => {
            for (const slateId of Object.keys(slates || {})) {
                const slate = slates[slateId];
                enrichRows(slate && typeof slate === 'object' ? slate.by_id : null);
            }
        };
        enrichRows(outById);
        enrichSlates(outUdBySlate);
        enrichSlates(outDkBySlate);
    }
    return {
        by_id: outById,
        ud_by_slate: outUdBySlate,
        dk_by_slate: outDkBySlate,
        ud_last_updated_ms: exposureState.ud_last_updated_ms,
        ud_draft_count: exposureState.ud_draft_count,
        dk_total_entries: exposureState.dk_total_entries,
        dk_last_updated_ms: exposureState.dk_last_updated_ms
    };
}

async function getExposureStorageForSettingsRequest() {
    if (!exposureState._hydrated) {
        await hydrateExposureFromStorage();
    }
    return getExposureStorageForSettings();
}

function normalizeUdSlateIdForExposure(slate_id) {
    const s = slate_id != null ? String(slate_id).trim() : '';
    return s ? s : 'legacy';
}

// Underdog exposure page: rows from intercepted GET .../ownership (appearance_id mapped to id).
// Now stored per-slate so settings page can switch views; `by_id` remains the last-merged slate for backward compatibility.
async function mergeUdExposureOwnershipRows(rows, options = {}) {
    if (!Array.isArray(rows) || !rows.length) {
        return { merged: false, reason: 'no_rows' };
    }
    if (!exposureState._hydrated) {
        await hydrateExposureFromStorage();
    }
    const slateId = normalizeUdSlateIdForExposure(options && options.slate_id);
    const draftCount = Number(options && options.draft_count);
    const normalizedDraftCount = Number.isFinite(draftCount) && draftCount > 0 ? draftCount : null;
    if (normalizedDraftCount == null) {
        throw new Error('[exposure][UD] missing required draft_count (denominator)');
    }
    const prevUdBySlate =
        exposureState.ud_by_slate && typeof exposureState.ud_by_slate === 'object'
            ? exposureState.ud_by_slate
            : {};
    const prevSlate = prevUdBySlate[slateId] && typeof prevUdBySlate[slateId] === 'object' ? prevUdBySlate[slateId] : {};
    const prevDraftCount = Number(prevSlate.draft_count);
    if (Number.isFinite(prevDraftCount) && prevDraftCount > 0 && normalizedDraftCount < prevDraftCount) {
        return {
            merged: false,
            reason: 'draft_count_shrink',
            slate_id: slateId,
            prev_draft_count: prevDraftCount,
            draft_count: normalizedDraftCount
        };
    }
    let maxIncomingPickCount = 0;
    for (let pi = 0; pi < rows.length; pi++) {
        const npick = Number(rows[pi] && rows[pi].ud_pick_count);
        if (Number.isFinite(npick) && npick > maxIncomingPickCount) {
            maxIncomingPickCount = npick;
        }
    }
    if (maxIncomingPickCount > normalizedDraftCount) {
        return {
            merged: false,
            reason: 'pick_count_exceeds_draft_count',
            slate_id: slateId,
            draft_count: normalizedDraftCount,
            max_pick_count: maxIncomingPickCount
        };
    }
    const now = Date.now();
    const prev = prevSlate.by_id && typeof prevSlate.by_id === 'object' ? prevSlate.by_id : {};
    const nextById = { ...prev };
    const optTournaments = options && Array.isArray(options.tournaments) ? options.tournaments : null;
    const nextTournaments = optTournaments != null
        ? optTournaments
        : (Array.isArray(prevSlate.tournaments) ? prevSlate.tournaments : null);
    for (let i = 0; i < rows.length; i++) {
        const r = rows[i];
        if (!r || typeof r !== 'object') {
            continue;
        }
        const id = r.id != null ? String(r.id).trim() : '';
        if (!id) {
            continue;
        }
        const existing = nextById[id] && typeof nextById[id] === 'object' ? { ...nextById[id] } : {};
        const nf = Number(r.ud_entry_fees);
        const npick = Number(r.ud_pick_count);
        const patch = {};
        if (Number.isFinite(nf)) {
            patch.ud_entry_fees = nf;
        }
        if (Number.isFinite(npick)) {
            patch.ud_pick_count = npick;
        } else {
            // Strict: no percent fallback.
            continue;
        }
        if (r.full_name != null && String(r.full_name).trim()) {
            patch.full_name = String(r.full_name).trim();
        }
        if (r.position != null && String(r.position).trim()) {
            patch.position = String(r.position).trim();
        }
        if (r.team != null && String(r.team).trim()) {
            patch.team = String(r.team).trim();
        }
        if (Object.keys(patch).length === 0) {
            continue;
        }
        nextById[id] = { ...existing, ...patch };
    }
    await persistExposurePayload({
        by_id: nextById, // will be replaced with aggregated UD view in persistExposurePayload()
        ud_by_slate: {
            ...prevUdBySlate,
            [slateId]: {
                by_id: nextById,
                ud_last_updated_ms: now,
                draft_count: normalizedDraftCount,
                tournaments: nextTournaments
            }
        },
        ud_last_updated_ms: now,
        ud_draft_count: normalizedDraftCount,
        dk_last_updated_ms: exposureState.dk_last_updated_ms,
        dk_by_slate:
            exposureState.dk_by_slate && typeof exposureState.dk_by_slate === 'object' ? exposureState.dk_by_slate : {}
    });
    return {
        merged: true,
        slate_id: slateId,
        draft_count: normalizedDraftCount,
        row_count: rows.length
    };
}

// DraftKings exposure: per draftGroupId from intercepted lineups (content script maps playerDkId to canonical id).
async function mergeDkExposureLineupsRows(slates) {
    if (!slates || typeof slates !== 'object' || Array.isArray(slates)) {
        return;
    }
    const slateKeys = Object.keys(slates);
    if (!slateKeys.length) {
        return;
    }
    if (!exposureState._hydrated) {
        await hydrateExposureFromStorage();
    }
    const now = Date.now();
    const prevDk =
        exposureState.dk_by_slate && typeof exposureState.dk_by_slate === 'object' ? exposureState.dk_by_slate : {};
    const nextDk = { ...prevDk };
    for (let i = 0; i < slateKeys.length; i++) {
        const dgId = slateKeys[i];
        const payload = slates[dgId];
        if (!payload || typeof payload !== 'object') continue;
        const rows = payload.rows;
        const totalEntries = Number(payload.total_entries);
        const labelRaw = payload.label != null ? String(payload.label).trim() : '';
        const label = labelRaw ? labelRaw : 'Draft Group ' + dgId;
        if (!Array.isArray(rows) || !rows.length) continue;
        if (!Number.isFinite(totalEntries) || totalEntries <= 0) continue;
        const byId = {};
        for (let ri = 0; ri < rows.length; ri++) {
            const r = rows[ri];
            if (!r || typeof r !== 'object') continue;
            const id = r.id != null ? String(r.id).trim() : '';
            if (!id) continue;
            byId[id] = { ...r };
        }
        if (!Object.keys(byId).length) continue;
        const prevSlate = prevDk[dgId] && typeof prevDk[dgId] === 'object' ? prevDk[dgId] : null;
        const rawLineups = Array.isArray(payload.lineups) && payload.lineups.length
            ? payload.lineups
            : (prevSlate && Array.isArray(prevSlate.raw_lineups) ? prevSlate.raw_lineups : []);
        const slateEntry = {
            by_id: byId,
            dk_last_updated_ms: now,
            total_entries: Math.round(totalEntries),
            label: label
        };
        if (rawLineups.length) {
            slateEntry.raw_lineups = rawLineups;
        }
        nextDk[dgId] = slateEntry;
    }
    await persistExposurePayload({
        dk_by_slate: nextDk,
        dk_last_updated_ms: now,
        ud_last_updated_ms: exposureState.ud_last_updated_ms
    });
    // Always re-submit DK lineups after a merge so a prior successful hash gate
    // (or a failed large upload) cannot block resync when revisiting /lineup.
    // Immediate flush so chunked enrich can overlap the next draftStatus wave
    // with an in-flight /exposure/sync.
    scheduleExposureSyncToBackend({ forceSites: ['draftkings'], immediate: true });
}

// Future: content script will send scraped rows; merges into by_id and sets site last_updated.
async function persistExposurePayload(next, options) {
    if (!next || typeof next !== 'object') return;
    const skipBackendSync = !!(options && options.skipBackendSync);

    const mergeByIdPatch = (base, patch) => {
        const out = base && typeof base === 'object' ? { ...base } : {};
        if (!patch || typeof patch !== 'object') {
            return out;
        }
        for (const [id, row] of Object.entries(patch)) {
            if (!id) continue;
            if (!row || typeof row !== 'object') continue;
            const prev = out[id] && typeof out[id] === 'object' ? out[id] : {};
            out[id] = { ...prev, ...row };
        }
        return out;
    };

    const merged = {
        ...defaultExposurePayload(),
        ...next,
        // IMPORTANT: treat by_id as a PATCH, not a replacement, so UD updates can't erase DK (and vice versa).
        by_id: mergeByIdPatch(exposureState.by_id || {}, next.by_id),
        ud_by_slate:
            next.ud_by_slate && typeof next.ud_by_slate === 'object'
                ? next.ud_by_slate
                : exposureState.ud_by_slate || {},
        dk_by_slate:
            next.dk_by_slate && typeof next.dk_by_slate === 'object'
                ? next.dk_by_slate
                : exposureState.dk_by_slate || {}
    };

    const us = await ensureExposureUserSettingsForStoredSlates(merged.ud_by_slate, merged.dk_by_slate);
    const udIncludedMap = us && typeof us === 'object' ? us.ud_exposure_included_slates : null;
    const dkIncludedMap = us && typeof us === 'object' ? us.dk_exposure_included_slates : null;

    const udAgg = computeAggregatedUdExposureFromSlates(merged.ud_by_slate, udIncludedMap);
    const udAggById = udAgg && udAgg.by_id && typeof udAgg.by_id === 'object' ? udAgg.by_id : {};
    const udDenom = udAgg && udAgg.draft_count != null ? udAgg.draft_count : null;

    const dkAgg = computeAggregatedDkExposureFromSlates(merged.dk_by_slate, dkIncludedMap);
    const dkAggById = dkAgg && dkAgg.by_id && typeof dkAgg.by_id === 'object' ? dkAgg.by_id : {};
    const dkDenom = dkAgg && dkAgg.total_entries != null ? dkAgg.total_entries : null;

    let nextById = stripUdExposureFields(merged.by_id || {});
    for (const [id, row] of Object.entries(udAggById)) {
        const existing = nextById[id] && typeof nextById[id] === 'object' ? { ...nextById[id] } : {};
        nextById[id] = { ...existing, ...row };
    }
    merged.ud_draft_count = udDenom;

    nextById = stripDkExposureFields(nextById);
    for (const [id, row] of Object.entries(dkAggById)) {
        const existing = nextById[id] && typeof nextById[id] === 'object' ? { ...nextById[id] } : {};
        nextById[id] = { ...existing, ...row };
    }
    merged.by_id = nextById;
    merged.dk_total_entries = dkDenom;

    exposureState.by_id = merged.by_id;
    exposureState.ud_by_slate = merged.ud_by_slate;
    exposureState.dk_by_slate = merged.dk_by_slate;
    exposureState.ud_last_updated_ms =
        merged.ud_last_updated_ms != null ? merged.ud_last_updated_ms : exposureState.ud_last_updated_ms;
    exposureState.ud_draft_count = merged.ud_draft_count != null ? merged.ud_draft_count : exposureState.ud_draft_count;
    exposureState.dk_total_entries =
        merged.dk_total_entries != null ? merged.dk_total_entries : exposureState.dk_total_entries;
    exposureState.dk_last_updated_ms =
        merged.dk_last_updated_ms != null ? merged.dk_last_updated_ms : exposureState.dk_last_updated_ms;
    await storage.set({
        [KEYS.exposure_player_map]: {
            by_id: exposureState.by_id,
            ud_by_slate: exposureState.ud_by_slate,
            dk_by_slate: exposureState.dk_by_slate,
            ud_last_updated_ms: exposureState.ud_last_updated_ms,
            ud_draft_count: exposureState.ud_draft_count,
            dk_total_entries: exposureState.dk_total_entries,
            dk_last_updated_ms: exposureState.dk_last_updated_ms
        }
    });
    notify_content_scripts('UPDATE_DATASETS', { datasets: get_content_script_datasets() });
    if (typeof notify_settings_pages === 'function') {
        notify_settings_pages('UPDATE_EXPOSURE', {});
    }
    if (!skipBackendSync) {
        scheduleExposureSyncToBackend();
    }
}

function convertWirePlayersToLocalById(players, site) {
    const pickKey = site === 'underdog' ? 'ud_pick_count' : 'dk_pick_count';
    const feeKey = site === 'underdog' ? 'ud_entry_fees' : 'dk_entry_fees';
    const byId = {};
    const list = Array.isArray(players) ? players : [];
    for (let i = 0; i < list.length; i++) {
        const p = list[i];
        if (!p || typeof p !== 'object') continue;
        const id = p.player_id != null ? String(p.player_id).trim() : '';
        if (!id) continue;
        const pickCount = Number(p.pick_count);
        if (!Number.isFinite(pickCount)) continue;
        const fees = Number(p.entry_fees);
        const row = {
            [pickKey]: Math.round(pickCount),
            [feeKey]: Number.isFinite(fees) ? fees : 0
        };
        if (p.full_name != null && String(p.full_name).trim()) {
            row.full_name = String(p.full_name).trim();
        }
        if (p.position != null && String(p.position).trim()) {
            row.position = String(p.position).trim();
        }
        if (p.team != null && String(p.team).trim()) {
            row.team = String(p.team).trim();
        }
        byId[id] = row;
    }
    return byId;
}

/**
 * Fill local exposure gaps from Layer A rollups returned by GET /config/datasets.
 * Never overwrites an existing local slate (fresh intercepts win). Skips backend
 * push; seeds upload_state from server_slate_hashes so incremental sync stays quiet.
 */
async function applyServerExposureRollups(payload) {
    if (!payload || typeof payload !== 'object') {
        return { applied: false, reason: 'no_payload' };
    }
    if (!exposureState._hydrated) {
        await hydrateExposureFromStorage();
    }

    const slates = Array.isArray(payload.slates) ? payload.slates : [];
    const serverHashes =
        payload.server_slate_hashes && typeof payload.server_slate_hashes === 'object'
            ? payload.server_slate_hashes
            : { underdog: {}, draftkings: {} };

    const prevUd =
        exposureState.ud_by_slate && typeof exposureState.ud_by_slate === 'object'
            ? exposureState.ud_by_slate
            : {};
    const prevDk =
        exposureState.dk_by_slate && typeof exposureState.dk_by_slate === 'object'
            ? exposureState.dk_by_slate
            : {};
    const nextUd = { ...prevUd };
    const nextDk = { ...prevDk };
    let appliedCount = 0;
    let udTouched = false;
    let dkTouched = false;
    let maxUdUpdated = exposureState.ud_last_updated_ms;
    let maxDkUpdated = exposureState.dk_last_updated_ms;

    for (let i = 0; i < slates.length; i++) {
        const slate = slates[i];
        if (!slate || typeof slate !== 'object') continue;
        const site = slate.site === 'draftkings' ? 'draftkings' : slate.site === 'underdog' ? 'underdog' : null;
        if (!site) continue;
        const slateId = slate.slate_id != null ? String(slate.slate_id).trim() : '';
        if (!slateId) continue;
        const denom = Number(slate.denominator);
        if (!Number.isFinite(denom) || denom <= 0) continue;
        const byId = convertWirePlayersToLocalById(slate.players, site);
        if (!Object.keys(byId).length) {
            if (BASE_BG.env !== 'prod') {
                const log_data = {
                    site,
                    slate_id: slateId,
                    player_count: Array.isArray(slate.players) ? slate.players.length : 0,
                };
            }
            continue;
        }
        const updatedAt =
            typeof slate.updated_at_ms === 'number' && Number.isFinite(slate.updated_at_ms)
                ? slate.updated_at_ms
                : Date.now();
        const serverHash =
            serverHashes[site] && typeof serverHashes[site] === 'object'
                ? serverHashes[site][slateId]
                : slate.content_hash;

        if (site === 'underdog') {
            if (nextUd[slateId] && typeof nextUd[slateId] === 'object') continue;
            nextUd[slateId] = {
                by_id: byId,
                draft_count: Math.round(denom),
                ud_last_updated_ms: updatedAt,
                tournaments: Array.isArray(slate.tournaments) ? slate.tournaments : null,
                server_content_hash: serverHash != null ? String(serverHash) : null
            };
            udTouched = true;
            appliedCount += 1;
            if (maxUdUpdated == null || updatedAt > maxUdUpdated) maxUdUpdated = updatedAt;
        } else {
            if (nextDk[slateId] && typeof nextDk[slateId] === 'object') continue;
            const labelRaw = slate.label != null ? String(slate.label).trim() : '';
            nextDk[slateId] = {
                by_id: byId,
                total_entries: Math.round(denom),
                dk_last_updated_ms: updatedAt,
                label: labelRaw || 'Draft Group ' + slateId,
                server_content_hash: serverHash != null ? String(serverHash) : null
            };
            dkTouched = true;
            appliedCount += 1;
            if (maxDkUpdated == null || updatedAt > maxDkUpdated) maxDkUpdated = updatedAt;
        }
    }

    if (!appliedCount) {
        await seedExposureUploadStateFromServerHashes(serverHashes, nextUd, nextDk);
        return { applied: false, reason: 'no_gaps', applied_count: 0 };
    }

    const persistNext = {
        ud_by_slate: nextUd,
        dk_by_slate: nextDk
    };
    if (udTouched) persistNext.ud_last_updated_ms = maxUdUpdated;
    if (dkTouched) persistNext.dk_last_updated_ms = maxDkUpdated;

    await persistExposurePayload(persistNext, { skipBackendSync: true });
    await seedExposureUploadStateFromServerHashes(serverHashes, nextUd, nextDk);

    if (BASE_BG.env !== 'prod') {
    }
    return { applied: true, applied_count: appliedCount };
}

async function seedExposureUploadStateFromServerHashes(serverHashes, udBySlate, dkBySlate) {
    const hashes = serverHashes && typeof serverHashes === 'object' ? serverHashes : {};
    const udHashes = hashes.underdog && typeof hashes.underdog === 'object' ? hashes.underdog : {};
    const dkHashes = hashes.draftkings && typeof hashes.draftkings === 'object' ? hashes.draftkings : {};
    const state = await loadExposureUploadState();
    const now = Date.now();
    let changed = false;

    const seedSite = (siteKey, localSlates, hashMap) => {
        if (!state.slates[siteKey]) state.slates[siteKey] = {};
        const local = localSlates && typeof localSlates === 'object' ? localSlates : {};
        const hashIds = Object.keys(hashMap || {});
        for (let i = 0; i < hashIds.length; i++) {
            const slateId = hashIds[i];
            const hash = hashMap[slateId];
            if (hash == null || !String(hash)) continue;
            const existing = state.slates[siteKey][slateId];
            if (existing && existing.hash) continue;
            // Only stamp upload hashes for slates we actually hold locally;
            // still union server ids into last_manifest below to avoid prune races.
            if (!local[slateId]) continue;
            state.slates[siteKey][slateId] = {
                hash: String(hash),
                uploaded_at_ms: now
            };
            changed = true;
        }
        const localIds = Object.keys(local);
        const serverIds = hashIds.filter((id) => hashMap[id] != null && String(hashMap[id]));
        const prevManifest = Array.isArray(state.last_manifest[siteKey])
            ? state.last_manifest[siteKey]
            : [];
        const nextManifest = [...new Set([...prevManifest, ...localIds, ...serverIds])].map(String).sort();
        if (JSON.stringify(nextManifest) !== JSON.stringify([...prevManifest].map(String).sort())) {
            state.last_manifest[siteKey] = nextManifest;
            changed = true;
        }
    };

    seedSite('underdog', udBySlate, udHashes);
    seedSite('draftkings', dkBySlate, dkHashes);

    if (changed) {
        state.last_error = null;
        await saveExposureUploadState(state);
    }
}

// --- Backend exposure sync (POST /exposure/sync) ---

let exposureSyncDebounceTimer = null;
let exposureSyncInFlight = false;
let exposureSyncPendingAfterFlight = false;
let exposureSyncForceSites = null;

function defaultExposureUploadState() {
    return {
        schema_version: EXPOSURE_SYNC_SCHEMA_VERSION,
        slates: { underdog: {}, draftkings: {} },
        last_manifest: { underdog: [], draftkings: [] },
        last_sync_ms: null,
        last_error: null
    };
}

async function loadExposureUploadState() {
    try {
        const res = await storage.get(KEYS.exposure_upload_state);
        const raw = res && res[KEYS.exposure_upload_state];
        if (!raw || typeof raw !== 'object') {
            return defaultExposureUploadState();
        }
        const slates = raw.slates && typeof raw.slates === 'object' ? raw.slates : {};
        const ud = slates.underdog && typeof slates.underdog === 'object' ? slates.underdog : {};
        const dk = slates.draftkings && typeof slates.draftkings === 'object' ? slates.draftkings : {};
        const lastManifest =
            raw.last_manifest && typeof raw.last_manifest === 'object'
                ? raw.last_manifest
                : { underdog: [], draftkings: [] };
        return {
            schema_version: EXPOSURE_SYNC_SCHEMA_VERSION,
            slates: { underdog: { ...ud }, draftkings: { ...dk } },
            last_manifest: {
                underdog: Array.isArray(lastManifest.underdog) ? [...lastManifest.underdog] : [],
                draftkings: Array.isArray(lastManifest.draftkings) ? [...lastManifest.draftkings] : []
            },
            last_sync_ms: typeof raw.last_sync_ms === 'number' ? raw.last_sync_ms : null,
            last_error: raw.last_error != null ? String(raw.last_error) : null
        };
    } catch (err) {
        return defaultExposureUploadState();
    }
}

async function saveExposureUploadState(state) {
    await storage.set({ [KEYS.exposure_upload_state]: state });
}

function fnv1aHashHex(str) {
    const s = typeof str === 'string' ? str : '';
    let h = 0x811c9dc5;
    for (let i = 0; i < s.length; i++) {
        h ^= s.charCodeAt(i);
        h = Math.imul(h, 0x01000193);
    }
    return (h >>> 0).toString(16);
}

function buildExposureWirePlayersFromById(byId, site) {
    const src = byId && typeof byId === 'object' ? byId : {};
    const pickKey = site === 'underdog' ? 'ud_pick_count' : 'dk_pick_count';
    const feeKey = site === 'underdog' ? 'ud_entry_fees' : 'dk_entry_fees';
    const out = [];
    for (const [playerId, row] of Object.entries(src)) {
        if (!playerId || !row || typeof row !== 'object') continue;
        const pickCount = Number(row[pickKey]);
        if (!Number.isFinite(pickCount)) continue;
        const fees = Number(row[feeKey]);
        const entry = {
            player_id: String(playerId),
            pick_count: Math.round(pickCount),
            entry_fees: Number.isFinite(fees) ? fees : 0
        };
        if (row.full_name != null && String(row.full_name).trim()) {
            entry.full_name = String(row.full_name).trim();
        }
        if (row.position != null && String(row.position).trim()) {
            entry.position = String(row.position).trim();
        }
        if (row.team != null && String(row.team).trim()) {
            entry.team = String(row.team).trim();
        }
        out.push(entry);
    }
    out.sort((a, b) => a.player_id.localeCompare(b.player_id));
    return out;
}

function buildDkContestsByKeyFromArray(contests) {
    if (!Array.isArray(contests)) {
        return contests && typeof contests === 'object' ? contests : {};
    }
    const out = {};
    for (let i = 0; i < contests.length; i++) {
        const c = contests[i];
        if (!c || typeof c !== 'object') continue;
        const ck = c.contest_key != null ? String(c.contest_key).trim() : '';
        if (ck) out[ck] = c;
    }
    return out;
}

function enrichDkLineupsWithContestDetails(lineups, contestsByKey) {
    if (!Array.isArray(lineups) || !lineups.length) {
        return [];
    }
    const contests = contestsByKey && typeof contestsByKey === 'object' ? contestsByKey : {};
    const out = [];
    for (let i = 0; i < lineups.length; i++) {
        const lu = lineups[i];
        if (!lu || typeof lu !== 'object') continue;
        let next;
        try {
            next = JSON.parse(JSON.stringify(lu));
        } catch (eClone) {
            next = { ...lu };
        }
        const entriesIn = Array.isArray(next.entries) ? next.entries : [];
        const entriesOut = [];
        let lineupName = next.name != null ? String(next.name).trim() : '';
        let lineupFee = next.entry_fee != null ? Number(next.entry_fee) : null;
        let lineupTournamentKey = next.tournament_key != null ? String(next.tournament_key).trim() : '';
        for (let ei = 0; ei < entriesIn.length; ei++) {
            const ent = entriesIn[ei];
            if (!ent || typeof ent !== 'object') continue;
            const ck = ent.contest_key != null ? String(ent.contest_key).trim() : '';
            const entryOut = { ...ent };
            if (ck && contests[ck] && typeof contests[ck] === 'object') {
                const c = contests[ck];
                const nameRaw = c.name != null ? String(c.name).trim() : '';
                if (nameRaw) entryOut.name = nameRaw;
                const fee = Number(c.entry_fee);
                if (Number.isFinite(fee) && fee >= 0) entryOut.entry_fee = fee;
                const tk = c.tournament_key != null ? String(c.tournament_key).trim() : '';
                if (tk) entryOut.tournament_key = tk;
            }
            if (!lineupName && entryOut.name) lineupName = entryOut.name;
            if (lineupFee == null && entryOut.entry_fee != null) lineupFee = entryOut.entry_fee;
            if (!lineupTournamentKey && entryOut.tournament_key) lineupTournamentKey = entryOut.tournament_key;
            entriesOut.push(entryOut);
        }
        next.entries = entriesOut;
        if (lineupName) next.name = lineupName;
        if (lineupFee != null) next.entry_fee = lineupFee;
        if (lineupTournamentKey) next.tournament_key = lineupTournamentKey;
        out.push(next);
    }
    return out;
}

function computeExposureSlateContentHash(denominator, players, slateMeta, lineups) {
    const parts = [String(denominator)];
    for (let i = 0; i < players.length; i++) {
        const p = players[i];
        parts.push(
            p.player_id,
            String(p.pick_count),
            String(p.entry_fees),
            p.full_name || '',
            p.position || '',
            p.team || ''
        );
    }
    if (Array.isArray(slateMeta) && slateMeta.length) {
        parts.push('__slate_meta__');
        try {
            parts.push(JSON.stringify(slateMeta));
        } catch (e) {}
    }
    if (Array.isArray(lineups) && lineups.length) {
        parts.push('__lineups__');
        try {
            parts.push(JSON.stringify(lineups));
        } catch (e) {}
    }
    return fnv1aHashHex(parts.join('|'));
}

function buildExposureWireSlateFromUd(slateId, ent) {
    if (!ent || typeof ent !== 'object') return null;
    const draftCount = Number(ent.draft_count);
    if (!Number.isFinite(draftCount) || draftCount <= 0) return null;
    const players = buildExposureWirePlayersFromById(ent.by_id, 'underdog');
    if (!players.length) return null;
    const updatedAt =
        typeof ent.ud_last_updated_ms === 'number' ? ent.ud_last_updated_ms : Date.now();
    const tournaments = Array.isArray(ent.tournaments) ? ent.tournaments : null;
    let contentHash = computeExposureSlateContentHash(draftCount, players, tournaments);
    if (
        ent.server_content_hash != null &&
        String(ent.server_content_hash).trim()
    ) {
        contentHash = String(ent.server_content_hash).trim();
    }
    return {
        site: 'underdog',
        slate_id: String(slateId),
        label: null,
        denominator: Math.round(draftCount),
        denominator_kind: 'drafts',
        updated_at_ms: updatedAt,
        content_hash: contentHash,
        tournaments: tournaments || [],
        players
    };
}

/**
 * Diagnose DK lineup identity keys before /exposure/sync.
 * Helps verify whether missing lineup_id / entry_key would collapse mass-entries
 * onto shared contest_key in the unified cache.
 */
function summarizeDkLineupIdentityKeys(lineups, slateId) {
    const rows = Array.isArray(lineups) ? lineups : [];
    const lineupIds = new Set();
    const entryKeys = new Set();
    const contestKeys = new Set();
    let missingLineupId = 0;
    let missingEntryKey = 0;
    let missingContestKey = 0;
    let missingSeat = 0;
    let missingDraftSize = 0;
    let emptyEntries = 0;
    let emptyPlayers = 0;
    const missingSamples = [];

    for (let i = 0; i < rows.length; i++) {
        const lu = rows[i];
        if (!lu || typeof lu !== 'object') continue;
        const lid = lu.lineup_id != null ? String(lu.lineup_id).trim() : '';
        if (lid) lineupIds.add(lid);
        else missingLineupId++;

        const entries = Array.isArray(lu.entries) ? lu.entries : [];
        if (!entries.length) emptyEntries++;
        let hasEntryKey = false;
        let hasContestKey = false;
        for (let ei = 0; ei < entries.length; ei++) {
            const ent = entries[ei];
            if (!ent || typeof ent !== 'object') continue;
            const ek = ent.entry_key != null ? String(ent.entry_key).trim() : '';
            const ck = ent.contest_key != null ? String(ent.contest_key).trim() : '';
            if (ek) {
                hasEntryKey = true;
                entryKeys.add(ek);
            }
            if (ck) {
                hasContestKey = true;
                contestKeys.add(ck);
            }
        }
        if (!hasEntryKey) missingEntryKey++;
        if (!hasContestKey) missingContestKey++;

        if (lu.seat_number == null) missingSeat++;
        if (lu.draft_size == null) missingDraftSize++;
        const players = Array.isArray(lu.drafted_players) ? lu.drafted_players : [];
        if (!players.length) emptyPlayers++;

        if (
            missingSamples.length < 8 &&
            (!lid || !hasEntryKey || !hasContestKey || lu.seat_number == null || lu.draft_size == null)
        ) {
            const first = entries[0] && typeof entries[0] === 'object' ? entries[0] : {};
            missingSamples.push({
                i,
                lineup_id: lid || null,
                entry_key: first.entry_key != null ? String(first.entry_key) : null,
                contest_key: first.contest_key != null ? String(first.contest_key) : null,
                seat_number: lu.seat_number != null ? lu.seat_number : null,
                draft_size: lu.draft_size != null ? lu.draft_size : null,
                entry_count: entries.length,
                player_count: players.length,
                top_keys: Object.keys(lu).slice(0, 20)
            });
        }
    }

    return {
        slate_id: slateId != null ? String(slateId) : null,
        lineup_count: rows.length,
        unique_lineup_ids: lineupIds.size,
        unique_entry_keys: entryKeys.size,
        unique_contest_keys: contestKeys.size,
        // If contest_keys << lineups and entry_keys ≈ lineups, contest_key collision is likely.
        // If entry_keys << lineups, entry_key is also collapsing / missing.
        missing_lineup_id: missingLineupId,
        missing_entry_key: missingEntryKey,
        missing_contest_key: missingContestKey,
        missing_seat_number: missingSeat,
        missing_draft_size: missingDraftSize,
        empty_entries: emptyEntries,
        empty_drafted_players: emptyPlayers,
        missing_samples: missingSamples
    };
}

function logDkLineupIdentityKeysForSync(slates) {
    const list = Array.isArray(slates) ? slates : [];
    for (let i = 0; i < list.length; i++) {
        const slate = list[i];
        if (!slate || slate.site !== 'draftkings') continue;
        const summary = summarizeDkLineupIdentityKeys(slate.lineups, slate.slate_id);
        const collapsedByContest =
            summary.lineup_count > 0 &&
            summary.unique_contest_keys > 0 &&
            summary.unique_contest_keys < summary.lineup_count;
        const collapsedByEntry =
            summary.lineup_count > 0 &&
            summary.unique_entry_keys > 0 &&
            summary.unique_entry_keys < summary.lineup_count;
        const hasGaps =
            summary.missing_lineup_id ||
            summary.missing_entry_key ||
            summary.missing_contest_key ||
            summary.missing_seat_number ||
            summary.missing_draft_size ||
            collapsedByContest ||
            collapsedByEntry;
        const payload = {
            ...summary,
            would_collapse_on_contest_key: collapsedByContest,
            would_collapse_on_entry_key: collapsedByEntry
        };
        if (hasGaps) {
        } else {
        }
    }
}

function buildExposureWireSlateFromDk(slateId, ent) {
    if (!ent || typeof ent !== 'object') return null;
    const totalEntries = Number(ent.total_entries);
    if (!Number.isFinite(totalEntries) || totalEntries <= 0) return null;
    const players = buildExposureWirePlayersFromById(ent.by_id, 'draftkings');
    if (!players.length) return null;
    const updatedAt =
        typeof ent.dk_last_updated_ms === 'number' ? ent.dk_last_updated_ms : Date.now();
    const labelRaw = ent.label != null ? String(ent.label).trim() : '';
    // Rollup-only wire: raw DK lineups are shaped client-side and POSTed to
    // /exposure/processed-lineups (not stored as Layer A exposure_dk_lineups).
    let contentHash = computeExposureSlateContentHash(totalEntries, players, null, []);
    if (
        ent.server_content_hash != null &&
        String(ent.server_content_hash).trim() &&
        !(Array.isArray(ent.raw_lineups) && ent.raw_lineups.length)
    ) {
        contentHash = String(ent.server_content_hash).trim();
    }
    return {
        site: 'draftkings',
        slate_id: String(slateId),
        label: labelRaw || null,
        denominator: Math.round(totalEntries),
        denominator_kind: 'entries',
        updated_at_ms: updatedAt,
        content_hash: contentHash,
        contests: [],
        players,
        lineups: []
    };
}

function buildExposureSyncManifestAndSlates(uploadState) {
    const udBySlate =
        exposureState.ud_by_slate && typeof exposureState.ud_by_slate === 'object'
            ? exposureState.ud_by_slate
            : {};
    const dkBySlate =
        exposureState.dk_by_slate && typeof exposureState.dk_by_slate === 'object'
            ? exposureState.dk_by_slate
            : {};
    const manifest = { underdog: [], draftkings: [] };
    const slates = [];

    for (const slateId of Object.keys(udBySlate)) {
        const wire = buildExposureWireSlateFromUd(slateId, udBySlate[slateId]);
        if (!wire) continue;
        manifest.underdog.push(wire.slate_id);
        slates.push(wire);
    }
    for (const slateId of Object.keys(dkBySlate)) {
        const wire = buildExposureWireSlateFromDk(slateId, dkBySlate[slateId]);
        if (!wire) continue;
        manifest.draftkings.push(wire.slate_id);
        slates.push(wire);
    }

    // Keep known server slate ids in the manifest even when not hydrated locally yet,
    // so incremental sync cannot prune rollups still waiting on applyServerExposureRollups.
    const last =
        uploadState && uploadState.last_manifest && typeof uploadState.last_manifest === 'object'
            ? uploadState.last_manifest
            : {};
    for (const siteKey of ['underdog', 'draftkings']) {
        const extra = Array.isArray(last[siteKey]) ? last[siteKey] : [];
        for (let i = 0; i < extra.length; i++) {
            const sid = extra[i] != null ? String(extra[i]).trim() : '';
            if (!sid) continue;
            if (manifest[siteKey].indexOf(sid) === -1) {
                manifest[siteKey].push(sid);
            }
        }
        manifest[siteKey].sort();
    }
    return { manifest, slates };
}

function exposureManifestsEqual(a, b) {
    const sites = ['underdog', 'draftkings'];
    for (let i = 0; i < sites.length; i++) {
        const site = sites[i];
        const aa = [...((a && a[site]) || [])].map(String).sort();
        const bb = [...((b && b[site]) || [])].map(String).sort();
        if (aa.length !== bb.length) return false;
        for (let j = 0; j < aa.length; j++) {
            if (aa[j] !== bb[j]) return false;
        }
    }
    return true;
}

function collectExposureSlatesNeedingUpload(allSlates, uploadState, forceSites) {
    const stored = uploadState && uploadState.slates ? uploadState.slates : { underdog: {}, draftkings: {} };
    const force = new Set((forceSites || []).map(String));
    const changed = [];
    for (let i = 0; i < allSlates.length; i++) {
        const slate = allSlates[i];
        const siteKey = slate.site === 'draftkings' ? 'draftkings' : 'underdog';
        const siteSlates = stored[siteKey] && typeof stored[siteKey] === 'object' ? stored[siteKey] : {};
        const prev = siteSlates[slate.slate_id];
        const prevHash = prev && typeof prev === 'object' ? prev.hash : null;
        const forced = force.has(siteKey);
        if (forced || prevHash !== slate.content_hash) {
            if (forced) {
                changed.push({ ...slate, force_apply: true });
            } else {
                changed.push(slate);
            }
        }
    }
    return changed;
}

function _noteExposureSyncForceSites(forceSites) {
    if (!Array.isArray(forceSites) || !forceSites.length) return;
    if (!exposureSyncForceSites) exposureSyncForceSites = new Set();
    for (let i = 0; i < forceSites.length; i++) {
        const site = forceSites[i] != null ? String(forceSites[i]) : '';
        if (site === 'draftkings' || site === 'underdog') {
            exposureSyncForceSites.add(site);
        }
    }
}

function scheduleExposureSyncToBackend(options) {
    _noteExposureSyncForceSites(options && options.forceSites);
    const immediate = !!(options && options.immediate);
    if (exposureSyncDebounceTimer) {
        clearTimeout(exposureSyncDebounceTimer);
        exposureSyncDebounceTimer = null;
    }
    const delay = immediate ? 0 : EXPOSURE_SYNC_DEBOUNCE_MS;
    exposureSyncDebounceTimer = setTimeout(() => {
        exposureSyncDebounceTimer = null;
        runExposureSyncToBackend().catch((err) => {
        });
    }, delay);
}

async function runExposureSyncToBackend() {
    if (exposureSyncInFlight) {
        exposureSyncPendingAfterFlight = true;
        return;
    }
    exposureSyncInFlight = true;
    const forceSites = exposureSyncForceSites ? Array.from(exposureSyncForceSites) : [];
    exposureSyncForceSites = null;
    try {
        await syncExposureToBackend({ forceSites });
    } finally {
        exposureSyncInFlight = false;
        if (exposureSyncPendingAfterFlight) {
            exposureSyncPendingAfterFlight = false;
            scheduleExposureSyncToBackend();
        }
    }
}

async function syncExposureToBackend(options) {
    if (typeof get_session_data !== 'function' || typeof make_http_request !== 'function') {
        return;
    }
    const session = await refresh_session_if_needed();
    if (!session?.user_uuid) {
        return;
    }

    const forceSites = options && Array.isArray(options.forceSites) ? options.forceSites : [];
    const uploadState = await loadExposureUploadState();
    const { manifest, slates: allSlates } = buildExposureSyncManifestAndSlates(uploadState);
    // Never publish when we have nothing local — an empty manifest prunes every
    // server slate and races with reinstall hydrate.
    if (!allSlates.length) {
        if (BASE_BG.env !== 'prod') {
        }
        return;
    }
    const changedSlates = collectExposureSlatesNeedingUpload(allSlates, uploadState, forceSites);
    const manifestChanged = !exposureManifestsEqual(manifest, uploadState.last_manifest);

    if (!changedSlates.length && !manifestChanged) {
        return;
    }

    const headers = {};
    if (session.app_jwt) {
        headers.Authorization = `Bearer ${session.app_jwt}`;
    }

    let clientVersion = 'unknown';
    try {
        clientVersion = get_extension_version();
    } catch (eVer) {}

    const body = {
        user_uuid: session.user_uuid,
        schema_version: EXPOSURE_SYNC_SCHEMA_VERSION,
        client_version: clientVersion,
        extension_version: clientVersion,
        full_replace: false,
        slates: changedSlates,
        manifest
    };

    // Always log DK identity-key coverage on upload (prod included) so we can
    // diagnose homepage lineup undercount vs toast N/M without a special build.
    logDkLineupIdentityKeysForSync(changedSlates);
    try {
        const approxBytes = new TextEncoder().encode(JSON.stringify(body)).length;
        const uploadLogData = {
            changed_slate_count: changedSlates.length,
            force_sites: forceSites,
            manifest_changed: manifestChanged,
            underdog_slates: manifest.underdog.length,
            draftkings_slates: manifest.draftkings.length,
            approx_bytes: approxBytes
        };
        if (approxBytes > 3 * 1024 * 1024) {
        } else if (BASE_BG.env !== 'prod') {
        }
    } catch (eSize) {
        if (BASE_BG.env !== 'prod') {
            const log_data = {
                changed_slate_count: changedSlates.length,
                force_sites: forceSites
            };
        }
    }

    try {
        const response = await make_http_request_with_auth_retry('/exposure/sync', {
            method: 'POST',
            body,
            headers
        });

        const now = Date.now();
        const nextState = await loadExposureUploadState();
        const serverHashes =
            response &&
            response.server_slate_hashes &&
            typeof response.server_slate_hashes === 'object'
                ? response.server_slate_hashes
                : null;

        for (let i = 0; i < allSlates.length; i++) {
            const slate = allSlates[i];
            const siteKey = slate.site === 'draftkings' ? 'draftkings' : 'underdog';
            if (!nextState.slates[siteKey]) nextState.slates[siteKey] = {};
            const serverHash =
                serverHashes &&
                serverHashes[siteKey] &&
                typeof serverHashes[siteKey] === 'object'
                    ? serverHashes[siteKey][slate.slate_id]
                    : null;
            nextState.slates[siteKey][slate.slate_id] = {
                // Preserve per-slate fields owned by the processed-lineups
                // delta upload (lineup_ids ledger) — this block only owns the
                // rollup hash.
                ...(nextState.slates[siteKey][slate.slate_id] || {}),
                hash: serverHash != null ? String(serverHash) : slate.content_hash,
                uploaded_at_ms: now
            };
        }

        // Drop upload tracking for slates no longer in local storage.
        for (const siteKey of ['underdog', 'draftkings']) {
            const keep = new Set((manifest[siteKey] || []).map(String));
            const siteSlates = nextState.slates[siteKey] || {};
            for (const sid of Object.keys(siteSlates)) {
                if (!keep.has(sid)) {
                    delete siteSlates[sid];
                }
            }
            nextState.slates[siteKey] = siteSlates;
        }

        nextState.last_manifest = {
            underdog: [...manifest.underdog],
            draftkings: [...manifest.draftkings]
        };
        nextState.last_sync_ms = now;
        nextState.last_error = null;
        await saveExposureUploadState(nextState);

        if (BASE_BG.env !== 'prod') {
            const log_data = {
                applied: response && response.applied,
                skipped_unchanged: response && response.skipped_unchanged,
                pruned: response && response.pruned
            };
        }

        // Upload shaped DK unified lineups for homepage (separate from rollup sync).
        try {
            await uploadProcessedDkLineupsForChangedSlates(session, headers, changedSlates);
        } catch (errProcessed) {
        }
    } catch (err) {
        const message = (err?.responseBody && (err.responseBody.detail ?? err.responseBody.message)) ?? err?.message ?? 'Upload failed';
        const failState = await loadExposureUploadState();
        failState.last_error = message;
        await saveExposureUploadState(failState);
        throw err;
    }
}

function resolveDkCanonicalFromMaps(playerDkId, exposureMap, idMap) {
    const key = playerDkId != null ? String(playerDkId).trim() : '';
    if (!key) return null;
    const exp = exposureMap || {};
    const ids = idMap || {};
    const dkNative = exp[key];
    if (dkNative != null && String(dkNative).trim()) {
        const nativeKey = String(dkNative).trim();
        const hop2 = ids[nativeKey];
        if (hop2) return String(hop2);
        // Legacy exposure_id_map values are already Underdog UUIDs.
        if (nativeKey.length >= 32 && nativeKey.indexOf('-') >= 0) return nativeKey;
    }
    if (ids[key]) return String(ids[key]);
    return null;
}

function dkLineupEntryKeys(raw) {
    const entries = raw && Array.isArray(raw.entries) ? raw.entries : [];
    const keys = [];
    for (let i = 0; i < entries.length; i++) {
        const ek = entries[i] && entries[i].entry_key != null ? String(entries[i].entry_key).trim() : '';
        if (ek) keys.push(ek);
    }
    return keys;
}

// Canonical id order mirrors the server's _dk_lineup_id (schema v8): a single
// entry_key wins over DK's own lineup.id, because entry_key is the one id
// knowable both at draft time (userContestId) and on the exposure path — the
// bridge that lets future draft-time capture land on the same unified doc.
function dkProcessedLineupId(raw) {
    if (!raw || typeof raw !== 'object') return null;
    const entryKeys = dkLineupEntryKeys(raw);
    if (entryKeys.length === 1) return entryKeys[0];
    if (raw.lineup_id != null && String(raw.lineup_id).trim()) return String(raw.lineup_id).trim();
    if (entryKeys.length > 1) return [...new Set(entryKeys)].sort().join('|');
    const entries = Array.isArray(raw.entries) ? raw.entries : [];
    const ckFromEntries =
        entries[0] && entries[0].contest_key != null ? String(entries[0].contest_key).trim() : '';
    const ck =
        (raw.tournament_key != null ? String(raw.tournament_key).trim() : '') || ckFromEntries;
    const dg = raw.draft_group_id != null ? String(raw.draft_group_id).trim() : '';
    const seat = Number(raw.seat_number);
    const created = raw.create_date != null ? String(raw.create_date).trim() : '';
    // Last-resort unique key when DK omits lineup/entry ids (avoid contest-only collapse).
    if (dg && ck && Number.isFinite(seat) && seat >= 1) {
        return dg + ':' + ck + ':seat' + Math.round(seat) + (created ? ':' + created : '');
    }
    if (ck && dg) return dg + ':' + ck;
    return ck || dg || null;
}

function shapeDkRawLineupsToProcessed(slateId, rawLineups, exposureMap, idMap, playerInfoById) {
    const legacyContestsByKey = {};
    const enriched = enrichDkLineupsWithContestDetails(rawLineups, legacyContestsByKey);
    const out = [];
    for (let i = 0; i < enriched.length; i++) {
        const raw = enriched[i];
        if (!raw || typeof raw !== 'object') continue;
        const draftSize = Number(raw.draft_size);
        const seatNumber = Number(raw.seat_number);
        if (!Number.isFinite(draftSize) || draftSize < 1) continue;
        if (!Number.isFinite(seatNumber) || seatNumber < 1) continue;
        const lineupId = dkProcessedLineupId(raw);
        if (!lineupId) continue;
        const picks = [];
        const drafted = Array.isArray(raw.drafted_players) ? raw.drafted_players : [];
        for (let pi = 0; pi < drafted.length; pi++) {
            const dp = drafted[pi];
            if (!dp || typeof dp !== 'object') continue;
            const dkId = dp.player_dk_id != null ? String(dp.player_dk_id).trim() : '';
            if (!dkId) continue;
            const playerId = resolveDkCanonicalFromMaps(dkId, exposureMap, idMap);
            const info = playerId && playerInfoById ? playerInfoById[playerId] : null;
            const selectionTime = dp.selection_time != null ? String(dp.selection_time).trim() : '';
            const siteAdpRaw = Number(dp.adp);
            picks.push({
                pick_number: Number.isFinite(Number(dp.pick_number)) ? Number(dp.pick_number) : null,
                player_id: playerId,
                site_player_id: dkId,
                full_name: (info && info.full_name) || dp.full_name || null,
                position: (info && info.position) || dp.position || dp.pos || null,
                team: (info && info.team) || dp.team || null,
                // Real per-pick selection time when DK gave us one; the lineup-level
                // create_date is the fallback every DK pick used to carry.
                picked_at: selectionTime || raw.create_date || raw.contest_start_date || null,
                selection_time: selectionTime || null,
                // dp.adp is DK's averageDraftPosition for this contest's own draft
                // group and becomes the server's draft_adp. Distinct from current_adp
                // below, which is the live merged-dataset ADP for the player.
                site_adp: Number.isFinite(siteAdpRaw) && siteAdpRaw > 0 ? siteAdpRaw : null,
                current_adp: info && info.adp != null ? Number(info.adp) : null,
            });
        }
        const draftedAt = raw.create_date || raw.contest_start_date || null;
        const entryKeys = dkLineupEntryKeys(raw);
        const dkNativeLineupId =
            raw.lineup_id != null && String(raw.lineup_id).trim()
                ? String(raw.lineup_id).trim()
                : null;
        out.push({
            site: 'draftkings',
            lineup_id: lineupId,
            draft_id: lineupId,
            slate_id: String(slateId),
            contest_key: raw.tournament_key != null ? String(raw.tournament_key) : null,
            contest_name: raw.name != null ? String(raw.name) : null,
            contest_kind: 'tournament',
            entry_fee: raw.entry_fee != null ? Number(raw.entry_fee) : null,
            draft_size: Math.round(draftSize),
            seat_number: Math.round(seatNumber),
            contest_entries: Math.max(1, Math.round(Number(raw.contest_entries) || 1)),
            drafted_at: draftedAt,
            contest_start_date:
                raw.contest_start_date != null ? String(raw.contest_start_date) : null,
            historical_adp_key: 'dk_bbm',
            // Identity bridge fields (schema v8): the server stores these and
            // maintains alias docs so lookups by any of them resolve here.
            entry_key: entryKeys.length === 1 ? entryKeys[0] : null,
            site_entry_ids: entryKeys.length ? [...new Set(entryKeys)].sort() : null,
            dk_lineup_id: dkNativeLineupId,
            picks,
        });
    }
    return out;
}

async function uploadProcessedDkLineupsForChangedSlates(session, headers, changedSlates) {
    if (!session?.user_uuid || typeof make_http_request_with_auth_retry !== 'function') return;
    const dkChanged = (changedSlates || []).filter((s) => s && s.site === 'draftkings');
    if (!dkChanged.length) return;

    let homeDs = null;
    if (typeof build_home_exposure_datasets === 'function') {
        homeDs = build_home_exposure_datasets();
    }
    const exposureMap = (homeDs && homeDs.exposure_id_map) || {};
    const idMap = (homeDs && homeDs.id_map) || {};
    const playerInfoById = (homeDs && homeDs.player_info_by_id) || {};

    const dkBySlate =
        exposureState.dk_by_slate && typeof exposureState.dk_by_slate === 'object'
            ? exposureState.dk_by_slate
            : {};

    for (let i = 0; i < dkChanged.length; i++) {
        const slate = dkChanged[i];
        const slateId = slate.slate_id != null ? String(slate.slate_id) : '';
        if (!slateId) continue;
        const ent = dkBySlate[slateId];
        const raw = ent && Array.isArray(ent.raw_lineups) ? ent.raw_lineups : [];
        if (!raw.length) continue;
        const processed = shapeDkRawLineupsToProcessed(
            slateId,
            raw,
            exposureMap,
            idMap,
            playerInfoById
        );
        if (!processed.length) continue;

        // Manifest-first: completed lineups are immutable, so ask the server
        // which of this slate's lineups it already has and send only the
        // delta. DK's own lineup.id rides along as an alt id so the alias map
        // can resolve either handle to the same doc.
        let toUpload = processed;
        try {
            const manifest = await make_http_request_with_auth_retry(
                '/exposure/lineups/manifest',
                {
                    method: 'POST',
                    headers: headers || {},
                    body: {
                        user_uuid: session.user_uuid,
                        site: 'draftkings',
                        source: 'extension_exposure',
                        candidates: processed.map((lu) => ({
                            lineup_id: lu.lineup_id,
                            alt_ids: lu.dk_lineup_id ? [lu.dk_lineup_id] : [],
                        })),
                    },
                }
            );
            const wanted = new Set([
                ...(manifest?.missing || []),
                ...(manifest?.incomplete || []),
                ...(manifest?.enrichable || []),
            ]);
            toUpload = processed.filter((lu) => wanted.has(lu.lineup_id));
        } catch (errManifest) {
            // Manifest unavailable: upload everything (idempotent upserts).
        }

        // Uploads are additive. Deletion happens only for lineups this
        // extension previously uploaded for the slate that have since
        // disappeared locally (slate shrank) — tracked in the upload ledger.
        const uploadState = await loadExposureUploadState();
        const slateLedger =
            (uploadState.slates.draftkings && uploadState.slates.draftkings[slateId]) || {};
        const previousIds = Array.isArray(slateLedger.lineup_ids) ? slateLedger.lineup_ids : [];
        const currentIds = processed.map((lu) => lu.lineup_id);
        const currentIdSet = new Set(currentIds);
        const pruneIds = previousIds.filter((id) => !currentIdSet.has(id));

        if (toUpload.length || pruneIds.length) {
            await make_http_request_with_auth_retry('/exposure/processed-lineups', {
                method: 'POST',
                headers: headers || {},
                body: {
                    user_uuid: session.user_uuid,
                    site: 'draftkings',
                    lineups: toUpload,
                    prune_lineup_ids: pruneIds.length ? pruneIds : undefined,
                },
            });
        }

        const nextState = await loadExposureUploadState();
        if (!nextState.slates.draftkings) nextState.slates.draftkings = {};
        nextState.slates.draftkings[slateId] = {
            ...(nextState.slates.draftkings[slateId] || {}),
            lineup_ids: currentIds,
        };
        await saveExposureUploadState(nextState);

        if (BASE_BG.env !== 'prod') {
            const log_data = {
                slate_id: slateId,
                lineup_count: processed.length,
                uploaded: toUpload.length,
                skipped_synced: processed.length - toUpload.length,
                pruned: pruneIds.length,
            };
        }
    }
}

async function recomputeExposureAggregationFromCurrentSettings() {
    if (!exposureState._hydrated) {
        await hydrateExposureFromStorage();
    }
    if (typeof get_content_script_settings !== 'function') {
        return;
    }
    const settings = await get_content_script_settings(['user_settings']);
    const us = settings && settings.user_settings && typeof settings.user_settings === 'object' ? settings.user_settings : {};
    const udIncludedMap = us.ud_exposure_included_slates;
    const dkIncludedMap = us.dk_exposure_included_slates;
    const udAgg = computeAggregatedUdExposureFromSlates(exposureState.ud_by_slate, udIncludedMap);
    const udAggById = udAgg && udAgg.by_id && typeof udAgg.by_id === 'object' ? udAgg.by_id : {};
    const udDenom = udAgg && udAgg.draft_count != null ? udAgg.draft_count : null;

    const dkAgg = computeAggregatedDkExposureFromSlates(exposureState.dk_by_slate, dkIncludedMap);
    const dkAggById = dkAgg && dkAgg.by_id && typeof dkAgg.by_id === 'object' ? dkAgg.by_id : {};
    const dkDenom = dkAgg && dkAgg.total_entries != null ? dkAgg.total_entries : null;

    let nextById = stripUdExposureFields(exposureState.by_id || {});
    for (const [id, row] of Object.entries(udAggById)) {
        const existing = nextById[id] && typeof nextById[id] === 'object' ? { ...nextById[id] } : {};
        nextById[id] = { ...existing, ...row };
    }
    nextById = stripDkExposureFields(nextById);
    for (const [id, row] of Object.entries(dkAggById)) {
        const existing = nextById[id] && typeof nextById[id] === 'object' ? { ...nextById[id] } : {};
        nextById[id] = { ...existing, ...row };
    }
    exposureState.by_id = nextById;
    exposureState.ud_draft_count = udDenom;
    exposureState.dk_total_entries = dkDenom;
    await storage.set({
        [KEYS.exposure_player_map]: {
            by_id: exposureState.by_id,
            ud_by_slate: exposureState.ud_by_slate,
            dk_by_slate: exposureState.dk_by_slate,
            ud_last_updated_ms: exposureState.ud_last_updated_ms,
            ud_draft_count: exposureState.ud_draft_count,
            dk_total_entries: exposureState.dk_total_entries,
            dk_last_updated_ms: exposureState.dk_last_updated_ms
        }
    });
    notify_content_scripts('UPDATE_DATASETS', { datasets: get_content_script_datasets() });
    if (typeof notify_settings_pages === 'function') {
        notify_settings_pages('UPDATE_EXPOSURE', {});
    }
}

// --- DraftKings exposure: legacy contest fee cache cleanup ---
// Entry fees now come from the /mycontests scrape in content_script_draft_kings.js, so nothing
// writes this cache any more. The clear below runs on install/update to purge stale entries.

// Removes the retired DK contest fee/name cache written by the old per-contest fee resolver.
async function clearDkExposureContestFeeCache() {
    try {
        await storage.remove(KEYS.dk_exposure_contest_fee_cache);
    } catch (err) {
    }
}

// Draft state debouncing functions
async function get_draft_states() {
    const res = await storage.get(KEYS.draft_states);
    return (res && res[KEYS.draft_states]) || {};
}

async function set_draft_states(states) {
    await storage.set({ [KEYS.draft_states]: states });
}

async function get_rankings_cache() {
    const res = await storage.get(KEYS.rankings_cache);
    return (res && res[KEYS.rankings_cache]) || {};
}

async function set_rankings_cache(cache) {
    await storage.set({ [KEYS.rankings_cache]: cache });
}

// Serializes every read-modify-write of the rankings cache onto one promise chain.
// chrome.storage has no transactions: two concurrent writers that each read a full
// snapshot and write it back lose whichever entries the other cached in between.
// The rankings-request handler used to hold its snapshot across a queue wait plus a
// 20s HTTP call before writing it back, silently deleting other drafts' fresh
// results — the content script then found nothing until its 20s watchdog re-fetched.
let rankingsCacheUpdateChain = Promise.resolve();
function update_rankings_cache(mutate) {
    const run = rankingsCacheUpdateChain.then(async () => {
        const cache = await get_rankings_cache();
        mutate(cache);
        await set_rankings_cache(cache);
        return cache;
    });
    rankingsCacheUpdateChain = run.then(() => {}, () => {});
    return run;
}

// Store one freshly computed result row. The mutation runs against the snapshot
// read inside the serialized update, never against a snapshot the caller has been
// holding across awaits.
async function store_rankings_cache_entry(draft_id, request_identifier, cache_entry) {
    return update_rankings_cache((cache) => {
        cache[request_identifier] = cache_entry;
        cleanup_old_cache_entries_for_draft(cache, draft_id, request_identifier);
    });
}

// Pure mutation: prunes `cache` in place and does NOT persist. Callers that need
// the result saved go through update_rankings_cache/store_rankings_cache_entry.
function cleanup_old_cache_entries_for_draft(cache, draft_id, keep_request_identifier) {
    const now = Date.now();
    const timestamp_threshold = now - (60 * 60 * 1000); // 1 hour ago
    
    let per_draft_deleted = 0;
    let timestamp_deleted = 0;
    const entries_to_delete = new Set();

    // Step 1: Per-draft cleanup (keep only most recent for this draft_id).
    // "Most recent" means highest num_picks, not most recently written: a slow older
    // request can finish after a newer pick's results were cached, and keying the
    // cleanup on the old row must not clobber the newer row (it would blank the pick
    // the content script is actually waiting on). Rows ahead of the kept row are left
    // alone; the hourly TTL sweep below reaps them if they somehow go stale.
    if (draft_id && keep_request_identifier) {
        const keep_num_picks = cache[keep_request_identifier]?.num_picks;
        for (const [request_identifier, entry] of Object.entries(cache)) {
            if (request_identifier.startsWith(`${draft_id}-`) &&
                request_identifier !== keep_request_identifier) {
                const entry_num_picks = entry?.num_picks;
                const entry_is_newer =
                    typeof keep_num_picks === 'number' &&
                    typeof entry_num_picks === 'number' &&
                    entry_num_picks > keep_num_picks;
                if (entry_is_newer) {
                    continue;
                }
                entries_to_delete.add(request_identifier);
                per_draft_deleted++;
            }
        }
    }

    // Step 2: Timestamp-based cleanup (all entries older than 1 hour, across all drafts)
    // This runs regardless of whether we have a draft_id
    for (const [request_identifier, entry] of Object.entries(cache)) {
        // Skip the entry we're keeping for per-draft cleanup
        if (request_identifier === keep_request_identifier) {
            continue;
        }
        
        // Check if entry has a timestamp and is older than threshold
        const entry_timestamp = entry?.timestamp || 0;
        if (entry_timestamp > 0 && entry_timestamp < timestamp_threshold) {
            entries_to_delete.add(request_identifier);
            timestamp_deleted++;
        }
    }

    // Delete all entries marked for deletion
    for (const request_identifier of entries_to_delete) {
        delete cache[request_identifier];
    }

    const total_deleted = entries_to_delete.size;
    if (total_deleted > 0) {
    }

    return total_deleted > 0;
}

function cleanup_old_draft_state_entries(draft_states, draft_id, keep_request_identifier) {
    const now = Date.now();
    const timestamp_threshold = now - (60 * 60 * 1000); // 1 hour ago
    const MAX_DRAFT_STATE_ENTRIES = 50;
    let per_draft_deleted = 0;
    let timestamp_deleted = 0;
    let cap_deleted = 0;
    const entries_to_delete = new Set();

    if (!draft_states || typeof draft_states !== 'object') {
        return { changed: false, per_draft_deleted, timestamp_deleted, cap_deleted };
    }

    // Keep only the newest state for this draft id.
    if (draft_id && keep_request_identifier) {
        for (const [request_identifier, state] of Object.entries(draft_states)) {
            if (!state || state.draft?.draft_id !== draft_id) {
                continue;
            }
            if (request_identifier === keep_request_identifier) {
                continue;
            }
            entries_to_delete.add(request_identifier);
            per_draft_deleted++;
        }
    }

    // Remove very old states globally so stale sessions don't accumulate forever.
    for (const [request_identifier, state] of Object.entries(draft_states)) {
        if (request_identifier === keep_request_identifier) {
            continue;
        }
        const entry_timestamp = state?.last_update || 0;
        if (entry_timestamp > 0 && entry_timestamp < timestamp_threshold) {
            entries_to_delete.add(request_identifier);
            timestamp_deleted++;
        }
    }

    for (const request_identifier of entries_to_delete) {
        delete draft_states[request_identifier];
    }

    // Hard cap to protect against unexpectedly large stores.
    const remaining = Object.entries(draft_states);
    if (remaining.length > MAX_DRAFT_STATE_ENTRIES) {
        remaining.sort((a, b) => {
            const aTs = a?.[1]?.last_update || 0;
            const bTs = b?.[1]?.last_update || 0;
            return aTs - bTs;
        });
        const drop_count = remaining.length - MAX_DRAFT_STATE_ENTRIES;
        for (let i = 0; i < drop_count; i++) {
            const key = remaining[i][0];
            if (key === keep_request_identifier) {
                continue;
            }
            delete draft_states[key];
            cap_deleted++;
        }
    }

    const changed = (per_draft_deleted + timestamp_deleted + cap_deleted) > 0;
    if (changed) {
        const temp = {
            total_deleted: per_draft_deleted + timestamp_deleted + cap_deleted,
            per_draft_deleted: per_draft_deleted,
            timestamp_deleted: timestamp_deleted,
            cap_deleted: cap_deleted,
            keep_request_identifier: keep_request_identifier || null
        }
    }

    return { changed, per_draft_deleted, timestamp_deleted, cap_deleted };
}

async function get_tournament_error_cache(draft_id) {
    if (!draft_id) return null;
    
    const error_cache_res = await storage.get(KEYS.tournament_error_cache);
    const error_cache = (error_cache_res && error_cache_res[KEYS.tournament_error_cache]) || {};
    const cached = error_cache[draft_id];
    
    if (!cached) return null;
    
    // Check if error cache is still valid (within TTL)
    const now = Date.now();
    const age = now - cached.timestamp;
    if (age > TOURNAMENT_ERROR_CACHE_TTL_MS) {
        // Expired - remove it
        delete error_cache[draft_id];
        await storage.set({ [KEYS.tournament_error_cache]: error_cache });
        return null;
    }
    
    return cached;
}


async function set_tournament_error_cache(draft_id, error_type, error_message) {
    if (!draft_id) return;
    
    
    const error_cache_res = await storage.get(KEYS.tournament_error_cache);
    const error_cache = (error_cache_res && error_cache_res[KEYS.tournament_error_cache]) || {};
    
    error_cache[draft_id] = {
        timestamp: Date.now(),
        error_type: error_type,
        error_message: error_message
    };
    
    await storage.set({ [KEYS.tournament_error_cache]: error_cache });
}


async function clear_tournament_error_cache(draft_id) {
    if (!draft_id) return;
    
    const error_cache_res = await storage.get(KEYS.tournament_error_cache);
    const error_cache = (error_cache_res && error_cache_res[KEYS.tournament_error_cache]) || {};
    
    if (error_cache[draft_id]) {
        delete error_cache[draft_id];
        await storage.set({ [KEYS.tournament_error_cache]: error_cache });
    }
}


async function get_tournament_no_data_cache(draft_id) {
    if (!draft_id) return false;
    
    const no_tournament_key = `${KEYS.tournament_prefix}no_tournament:${draft_id}`;
    const no_tournament_res = await storage.get(no_tournament_key);
    if (!no_tournament_res || !no_tournament_res[no_tournament_key]) return false;
    
    const cached = no_tournament_res[no_tournament_key];
    const now = Date.now();
    const age = now - cached.timestamp;
    
    if (age > TOURNAMENT_NO_DATA_CACHE_TTL_MS) {
        // Expired - remove it
        await storage.remove(no_tournament_key);
        return false;
    }
    
    return true;
}


async function set_tournament_no_data_cache(draft_id) {
    if (!draft_id) return;
    
    const no_tournament_key = `${KEYS.tournament_prefix}no_tournament:${draft_id}`;
    const payload = {
        [no_tournament_key]: {
            no_tournament_data: true,
            timestamp: Date.now()
        }
    };
    await storage.set(payload);
}

/**
 * Drops every persisted Underdog tournament 404 marker (`tournament:underdog:no_tournament:{draft_id}`).
 * Used on extension install/update so stale markers do not block GET_TOURNAMENT_DATA after fixes
 * (e.g. Weekly Winners intercept path); uninstall/reinstall is no longer required.
 */
async function clear_all_underdog_tournament_no_data_markers() {
    const prefix = `${KEYS.tournament_prefix}no_tournament:`;
    try {
        const all = await storage.get(null);
        if (!all || typeof all !== 'object') {
            return;
        }
        const toRemove = [];
        const keys = Object.keys(all);
        for (let i = 0; i < keys.length; i++) {
            const k = keys[i];
            if (k.startsWith(prefix)) {
                toRemove.push(k);
            }
        }
        if (toRemove.length === 0) {
            return;
        }
        await storage.remove(toRemove);
    } catch (err) {
        console.error('[BG Tournament] clear_all_underdog_tournament_no_data_markers failed', err);
    }
}


async function get_tournament_id_for_draft(draft_id) {
    const mapping = await storage.get(KEYS.tournament_draft_mapping);
    return (mapping && mapping[KEYS.tournament_draft_mapping]?.[draft_id]) || null;
}


async function set_tournament_id_for_draft(draft_id, tournament_id) {
    const mapping_res = await storage.get(KEYS.tournament_draft_mapping);
    const mapping = (mapping_res && mapping_res[KEYS.tournament_draft_mapping]) || {};
    mapping[draft_id] = tournament_id;
    await storage.set({ [KEYS.tournament_draft_mapping]: mapping });
}


async function get_ud_draft_xhr_snapshot(draft_id) {
    if (!draft_id || typeof draft_id !== 'string') {
        return null;
    }
    const res = await storage.get(KEYS.ud_draft_xhr_snapshots);
    const map = (res && res[KEYS.ud_draft_xhr_snapshots]) || {};
    const snap = map[draft_id];
    if (!snap || typeof snap.url !== 'string') {
        return null;
    }
    return snap;
}

function filterUdReplayHeaders(headers) {
    if (!headers || typeof headers !== 'object' || Array.isArray(headers)) {
        return {};
    }
    // Keep only headers that are plausibly needed to replay GET /v2/drafts/{id}.
    // Everything else is either redundant or increases storage size.
    const allow = new Set(['authorization', 'x-csrf-token', 'x-xsrf-token']);
    const out = {};
    for (const k of Object.keys(headers)) {
        const lower = String(k).toLowerCase();
        if (!allow.has(lower)) {
            continue;
        }
        const v = headers[k];
        if (v == null) {
            continue;
        }
        const s = String(v);
        if (!s) {
            continue;
        }
        out[lower] = s;
    }
    return out;
}

function cleanupUdDraftXhrSnapshotsMap(map, { ttl_ms, max_entries } = {}) {
    const now = Date.now();
    const TTL_MS = Number.isFinite(ttl_ms) && ttl_ms > 0 ? ttl_ms : 60 * 60 * 1000; // 1 hour
    const MAX = Number.isFinite(max_entries) && max_entries > 0 ? max_entries : 25;

    if (!map || typeof map !== 'object') {
        return { map: {}, changed: true };
    }

    let changed = false;

    // TTL eviction
    for (const [draftId, snap] of Object.entries(map)) {
        const ts = snap && typeof snap === 'object' ? Number(snap.captured_at_ms) : 0;
        if (!Number.isFinite(ts) || ts <= 0) {
            continue;
        }
        if (now - ts > TTL_MS) {
            delete map[draftId];
            changed = true;
        }
    }

    // Max-size eviction (oldest first)
    const entries = Object.entries(map).map(([draftId, snap]) => {
        const ts = snap && typeof snap === 'object' ? Number(snap.captured_at_ms) : 0;
        return { draftId, ts: Number.isFinite(ts) ? ts : 0 };
    });
    if (entries.length > MAX) {
        entries.sort((a, b) => (a.ts || 0) - (b.ts || 0));
        const dropN = entries.length - MAX;
        for (let i = 0; i < dropN; i++) {
            const id = entries[i].draftId;
            delete map[id];
            changed = true;
        }
    }

    return { map, changed };
}


async function set_ud_draft_xhr_snapshot(draft_id, url, headers) {
    if (!draft_id || typeof draft_id !== 'string' || !url || typeof url !== 'string') {
        return;
    }
    const safeHeaders = filterUdReplayHeaders(headers);
    const res = await storage.get(KEYS.ud_draft_xhr_snapshots);
    const map = (res && res[KEYS.ud_draft_xhr_snapshots]) || {};
    cleanupUdDraftXhrSnapshotsMap(map);
    map[draft_id] = {
        url,
        headers: safeHeaders,
        captured_at_ms: Date.now()
    };
    cleanupUdDraftXhrSnapshotsMap(map);
    await storage.set({ [KEYS.ud_draft_xhr_snapshots]: map });
}


async function get_tournament_key_for_draft_dk(draft_id) {
    const mapping = await storage.get(KEYS.tournament_dk_draft_mapping);
    return (mapping && mapping[KEYS.tournament_dk_draft_mapping]?.[draft_id]) || null;
}


async function set_tournament_key_for_draft_dk(draft_id, tournament_key) {
    const mapping_res = await storage.get(KEYS.tournament_dk_draft_mapping);
    const mapping = (mapping_res && mapping_res[KEYS.tournament_dk_draft_mapping]) || {};
    mapping[draft_id] = tournament_key;
    await storage.set({ [KEYS.tournament_dk_draft_mapping]: mapping });
}


async function get_tournament_data_by_id(tournament_id) {
    if (!tournament_id) return null;
    const key = `${KEYS.tournament_prefix}${tournament_id}`;
    const res = await storage.get(key);
    return (res && res[key]) || null;
}


async function set_tournament_data_by_id(tournament_id, data) {
    if (!tournament_id) return;
    const key = `${KEYS.tournament_prefix}${tournament_id}`;
    await storage.set({ [key]: data });
}

function resolveUnderdogContestRounds(tournament_data) {
    if (!tournament_data) {
        return null;
    }
    const fromStyle = tournament_data.contest_style?.rounds;
    const styleRounds = typeof fromStyle === 'number' ? fromStyle : parseFloat(fromStyle);
    if (Number.isFinite(styleRounds) && styleRounds > 0) {
        return styleRounds;
    }
    const total = tournament_data.total_rounds;
    const totalRounds = typeof total === 'number' ? total : parseFloat(total);
    if (Number.isFinite(totalRounds) && totalRounds > 0) {
        return totalRounds;
    }
    return null;
}

/** Single-stage cumulative scoring (e.g. "The Frenchie Marathon"); no round-advancement denom. */
function isUnderdogMarathonTournament(tournament_data) {
    if (!tournament_data || tournament_data.no_tournament_data) {
        return false;
    }
    const parts = [
        tournament_data.title,
        tournament_data.rules_url,
        tournament_data.description,
        tournament_data.additional_info,
        tournament_data.contest_style?.name
    ];
    for (let i = 0; i < parts.length; i++) {
        const s = parts[i];
        if (typeof s === 'string' && /marathon/i.test(s)) {
            return true;
        }
    }
    return false;
}

/** Same fields as buildUnderdogTournamentSummary / content script extraction: draft table size + draft rounds. */
function underdogTournamentSizingComplete(tournament_data) {
    if (!tournament_data || tournament_data.no_tournament_data) {
        return false;
    }
    const r = resolveUnderdogContestRounds(tournament_data);
    if (!Number.isFinite(r) || r <= 0) {
        return false;
    }
    if (isUnderdogMarathonTournament(tournament_data)) {
        // Marathon: cumulative weeks 1–17, no advancement denom; draft table size comes from DOM ribbon.
        return true;
    }
    const denom = tournament_data.advancement_structure?.regular_season_denom;
    const d = typeof denom === 'number' ? denom : parseFloat(denom);
    return Number.isFinite(d) && d > 0;
}

/**
 * Breaks down exactly which sizing inputs are present/missing for a single tournament record.
 * Bespoke/new contests tend to fail on regular_season_denom (unrecognized additional_info format)
 * or on contest rounds (no contest_style.rounds / total_rounds), so log both halves explicitly.
 */
function describeUnderdogTournamentSizingFields(tournament_data) {
    const td = (tournament_data && typeof tournament_data === 'object') ? tournament_data : {};
    const denom_raw = td.advancement_structure?.regular_season_denom;
    const denom_parsed = typeof denom_raw === 'number' ? denom_raw : parseFloat(denom_raw);
    const resolved_rounds = resolveUnderdogContestRounds(td);
    const adv_raw_string = typeof td.advancement_structure?.raw_string === 'string' ? td.advancement_structure.raw_string : null;
    return {
        no_tournament_data: !!td.no_tournament_data,
        // draft-table size (regular season) inputs
        has_advancement_structure: !!td.advancement_structure,
        regular_season_denom_raw: denom_raw ?? null,
        regular_season_denom_parsed: Number.isFinite(denom_parsed) ? denom_parsed : null,
        denom_ok: Number.isFinite(denom_parsed) && denom_parsed > 0,
        // draft-rounds inputs
        contest_style_rounds: td.contest_style?.rounds ?? null,
        total_rounds: td.total_rounds ?? null,
        resolved_contest_rounds: resolved_rounds,
        rounds_ok: Number.isFinite(resolved_rounds) && resolved_rounds > 0,
        overall_complete: underdogTournamentSizingComplete(td),
        is_marathon: isUnderdogMarathonTournament(td),
        // context that helps identify a bespoke contest shape
        tournament_id: td.id ?? null,
        title: td.title ?? null,
        contest_style_id: td.contest_style_id ?? null,
        entry_style_id: td.entry_style_id ?? null,
        has_contest_style: !!td.contest_style,
        has_entry_style: !!td.entry_style,
        advancement_raw_string: adv_raw_string,
        additional_info: typeof td.additional_info === 'string' ? td.additional_info : null,
        top_keys: Object.keys(td)
    };
}

function logUnderdogTournamentSizingReject(context, draft_id, tournament_id, payload_bundle) {
    // Per-record breakdown so it is obvious which input (denom vs rounds) is missing for this contest.
    try {
        if (payload_bundle && typeof payload_bundle === 'object') {
            for (const [record_name, record_value] of Object.entries(payload_bundle)) {
                if (record_value && typeof record_value === 'object') {
                    if (BASE_BG.env !== 'prod') {
                        const sizingFields = describeUnderdogTournamentSizingFields(record_value);
                    }
                }
            }
        }
    } catch (describe_err) {
    }
}

async function purgeUnderdogTournamentCacheForTournamentId(tournament_id) {
    if (!tournament_id) return;
    const blob_key = `${KEYS.tournament_prefix}${tournament_id}`;
    await storage.remove([blob_key]);

    const mapping_res = await storage.get(KEYS.tournament_draft_mapping);
    const mapping = (mapping_res && mapping_res[KEYS.tournament_draft_mapping]) || {};
    let changed = false;
    for (const d of Object.keys(mapping)) {
        if (mapping[d] === tournament_id) {
            delete mapping[d];
            changed = true;
        }
    }
    if (changed) {
        await storage.set({ [KEYS.tournament_draft_mapping]: mapping });
    }
}


async function get_tournament_data_by_key_dk(tournament_key) {
    if (!tournament_key) return null;
    const key = `${KEYS.tournament_dk_prefix}${tournament_key}`;
    const res = await storage.get(key);
    return (res && res[key]) || null;
}


async function set_tournament_data_by_key_dk(tournament_key, data) {
    if (!tournament_key) return;
    const key = `${KEYS.tournament_dk_prefix}${tournament_key}`;
    await storage.set({ [key]: data });
}


async function get_tournament_data(draft_id) {
    if (!draft_id) {
        return null;
    }
    
    
    // Check error cache first - if we recently failed, don't try again
    const error_cache = await get_tournament_error_cache(draft_id);
    if (error_cache) {
        const age_seconds = Math.round((Date.now() - error_cache.timestamp) / 1000);
        return null;
    }
    
    // Check for cached "no tournament data" response (permanent 404)
    const has_no_data_cache = await get_tournament_no_data_cache(draft_id);
    if (has_no_data_cache) {
        return { no_tournament_data: true };
    }
    
    // Look up tournament_id from mapping
    const tournament_id = await get_tournament_id_for_draft(draft_id);
    if (!tournament_id) {
        return null;
    }
    
    
    // Fetch tournament data by tournament_id
    let tournament_data = await get_tournament_data_by_id(tournament_id);
    if (tournament_data) {
        // Check if cached data needs enrichment
        const needs_enrichment = (tournament_data.contest_style_id && !tournament_data.contest_style) || 
                                (tournament_data.entry_style_id && !tournament_data.entry_style);
        if (needs_enrichment) {
            const before_enrich = tournament_data;
            tournament_data = await enrich_tournament_data_with_styles(tournament_data);
            if (!underdogTournamentSizingComplete(tournament_data)) {
                logUnderdogTournamentSizingReject('get_tournament_data:after_enrich_incomplete', draft_id, tournament_id, {
                    cached_record_before_enrich: before_enrich,
                    cached_record_after_enrich: tournament_data
                });
                await purgeUnderdogTournamentCacheForTournamentId(tournament_id);
                return null;
            }
            await set_tournament_data_by_id(tournament_id, tournament_data);
        }
        if (!underdogTournamentSizingComplete(tournament_data)) {
            logUnderdogTournamentSizingReject('get_tournament_data:cached_blob_incomplete', draft_id, tournament_id, {
                cached_record: tournament_data
            });
            await purgeUnderdogTournamentCacheForTournamentId(tournament_id);
            return null;
        }
        const cacheHitDbg = { draft_id: draft_id, tournament_id: tournament_id, regular_season_denom: tournament_data.advancement_structure?.regular_season_denom ?? null, contest_rounds: tournament_data.contest_style?.rounds ?? null, has_contest_style_object: !!tournament_data.contest_style, additional_info_preview: typeof tournament_data.additional_info === 'string' ? tournament_data.additional_info.slice(0, 160) : null };
    } else {
    }
    return tournament_data;
}


async function set_tournament_data(draft_id, data) {
    if (!draft_id || !data) {
        return null;
    }
    
    
    // Clear any error cache since we successfully got data
    await clear_tournament_error_cache(draft_id);
    
    // Handle case where data has no_tournament_data flag (permanent 404 response)
    if (data.no_tournament_data) {
        // Cache "no tournament data" responses with longer TTL since it's a permanent state
        await set_tournament_no_data_cache(draft_id);
        return { no_tournament_data: true };
    }
    
    // Extract tournament_id from data (the flattened structure has 'id' at the top level)
    const tournament_id = data.id;
    if (!tournament_id) {
        return null;
    }
    
    
    // CRITICAL SAFETY CHECK: Check if we already have tournament data for this tournament_id
    // This prevents accidental overwrites and ensures Draft A's data is never lost
    let existing = await get_tournament_data_by_id(tournament_id);
    if (existing && !underdogTournamentSizingComplete(existing)) {
        logUnderdogTournamentSizingReject('set_tournament_data:purge_stale_existing', draft_id, tournament_id, {
            cached_record: existing,
            incoming_from_api: data
        });
        await purgeUnderdogTournamentCacheForTournamentId(tournament_id);
        existing = null;
    }
    if (existing) {
        // Tournament data already exists - check if it needs enrichment
        // If the new data has enrichment but existing doesn't, enrich and update cache
        const existing_needs_enrichment = (existing.contest_style_id && !existing.contest_style) || 
                                         (existing.entry_style_id && !existing.entry_style);
        const new_data_has_enrichment = (data.contest_style_id && data.contest_style) || 
                                       (data.entry_style_id && data.entry_style);
        
        if (existing_needs_enrichment && new_data_has_enrichment) {
            // Existing data is missing enrichment, but new data has it - merge enrichment into existing
            if (data.contest_style && !existing.contest_style) {
                existing.contest_style = data.contest_style;
            }
            if (data.entry_style && !existing.entry_style) {
                existing.entry_style = data.entry_style;
            }
            // Update cache with enriched data
            await set_tournament_data_by_id(tournament_id, existing);
        } else if (existing_needs_enrichment) {
            // Existing data needs enrichment, but new data doesn't have it - enrich existing data
            const enriched = await enrich_tournament_data_with_styles(existing);
            if (!underdogTournamentSizingComplete(enriched)) {
                logUnderdogTournamentSizingReject('set_tournament_data:enrich_existing_incomplete', draft_id, tournament_id, {
                    cached_record_before_enrich: existing,
                    after_enrich: enriched,
                    incoming_from_api: data
                });
                await purgeUnderdogTournamentCacheForTournamentId(tournament_id);
                return null;
            }
            await set_tournament_data_by_id(tournament_id, enriched);
            await set_tournament_id_for_draft(draft_id, tournament_id);
            const cacheEnrichedDbg = { draft_id: draft_id, tournament_id: tournament_id, regular_season_denom: enriched.advancement_structure?.regular_season_denom ?? null, contest_rounds: enriched.contest_style?.rounds ?? null };
            return enriched;
        }
        
        if (!underdogTournamentSizingComplete(existing)) {
            logUnderdogTournamentSizingReject('set_tournament_data:existing_incomplete_after_merge', draft_id, tournament_id, {
                cached_record: existing,
                incoming_from_api: data
            });
            await purgeUnderdogTournamentCacheForTournamentId(tournament_id);
        } else {
            // Tournament data already exists - just create the mapping and return existing data
            // This is the key safety feature: Draft B will use Draft A's cached data
            await set_tournament_id_for_draft(draft_id, tournament_id);
            const cacheReuseDbg = { draft_id: draft_id, tournament_id: tournament_id, regular_season_denom: existing.advancement_structure?.regular_season_denom ?? null, contest_rounds: existing.contest_style?.rounds ?? null };
            return existing;
        }
    }
    
    
    // Ensure data is fully enriched before caching
    // If data already has enrichment from fetch_underdog_tournament, use it as-is
    // Otherwise, enrich it now
    const data_to_cache = await enrich_tournament_data_with_styles(data);
    if (!underdogTournamentSizingComplete(data_to_cache)) {
        logUnderdogTournamentSizingReject('set_tournament_data:fresh_store_reject', draft_id, tournament_id, {
            incoming_flattened_before_enrich: data,
            after_enrich: data_to_cache
        });
        return null;
    }
    
    // Tournament data doesn't exist yet - store the enriched data
    await set_tournament_data_by_id(tournament_id, data_to_cache);
    
    // Store mapping from draft_id to tournament_id
    await set_tournament_id_for_draft(draft_id, tournament_id);
    
    const has_entry_style = !!data_to_cache.entry_style;
    const has_contest_style = !!data_to_cache.contest_style;
    const cachedNewDbg = { draft_id: draft_id, tournament_id: tournament_id, regular_season_denom: data_to_cache.advancement_structure?.regular_season_denom ?? null, contest_rounds: data_to_cache.contest_style?.rounds ?? null, contest_style_id: data_to_cache.contest_style_id ?? null, additional_info_preview: typeof data_to_cache.additional_info === 'string' ? data_to_cache.additional_info.slice(0, 200) : null };
    return data_to_cache;
}


async function get_tournament_data_dk(draft_id) {
    if (!draft_id) return null;
    
    // Look up tournament_key from mapping
    const tournament_key = await get_tournament_key_for_draft_dk(draft_id);
    if (!tournament_key) {
        return null;
    }
    
    // Fetch tournament data by tournament_key
    return await get_tournament_data_by_key_dk(tournament_key);
}


async function set_tournament_data_dk(draft_id, tournament_key, data) {
    if (!draft_id || !tournament_key || !data) return;
    
    // Store mapping from draft_id to tournament_key
    await set_tournament_key_for_draft_dk(draft_id, tournament_key);
    
    // Store tournament data by tournament_key (not draft_id)
    // Only store if we don't already have it (avoid overwriting with same data)
    const existing = await get_tournament_data_by_key_dk(tournament_key);
    if (!existing) {
        await set_tournament_data_by_key_dk(tournament_key, data);
    } else {
    }
}


async function fetch_draftkings_tournament(tournament_key) {
    const url = `https://api.draftkings.com/tournaments/v1/${tournament_key}?format=json`;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5000); // 5 second timeout
    
    const response = await fetch(url, {
        method: 'GET',
        mode: 'cors',
        headers: {
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.5'
        },
        signal: controller.signal
    });
    
    clearTimeout(timeout);
    
    if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    
    return await response.json();
}


async function get_contest_id_for_draft_dk(draft_id) {
    const mapping = await storage.get(KEYS.contest_dk_draft_mapping);
    return (mapping && mapping[KEYS.contest_dk_draft_mapping]?.[draft_id]) || null;
}


async function set_contest_id_for_draft_dk(draft_id, contest_id) {
    const mapping_res = await storage.get(KEYS.contest_dk_draft_mapping);
    const mapping = (mapping_res && mapping_res[KEYS.contest_dk_draft_mapping]) || {};
    mapping[draft_id] = contest_id;
    await storage.set({ [KEYS.contest_dk_draft_mapping]: mapping });
}


async function get_contest_data_by_id_dk(contest_id) {
    if (!contest_id) return null;
    const key = `${KEYS.contest_dk_prefix}${contest_id}`;
    const res = await storage.get(key);
    return (res && res[key]) || null;
}


async function set_contest_data_by_id_dk(contest_id, data) {
    if (!contest_id) return;
    const key = `${KEYS.contest_dk_prefix}${contest_id}`;
    await storage.set({ [key]: data });
}


async function get_contest_data_dk(draft_id) {
    if (!draft_id) return null;
    
    // Look up contest_id from mapping
    const contest_id = await get_contest_id_for_draft_dk(draft_id);
    if (!contest_id) {
        return null;
    }
    
    // Fetch contest data by contest_id
    return await get_contest_data_by_id_dk(contest_id);
}


async function set_contest_data_dk(draft_id, contest_id, data) {
    if (!draft_id || !contest_id || !data) return;
    
    // Store mapping from draft_id to contest_id
    await set_contest_id_for_draft_dk(draft_id, contest_id);
    
    // Store contest data by contest_id (not draft_id)
    // Only store if we don't already have it (avoid overwriting with same data)
    const existing = await get_contest_data_by_id_dk(contest_id);
    if (!existing) {
        await set_contest_data_by_id_dk(contest_id, data);
    } else {
    }
}


async function fetch_draftkings_contest(contest_id) {
    const url = `https://api.draftkings.com/contests/v1/contests/${contest_id}?format=json`;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5000); // 5 second timeout
    
    const response = await fetch(url, {
        method: 'GET',
        mode: 'cors',
        credentials: 'include',
        headers: {
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.5',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-site'
        },
        referrer: 'https://www.draftkings.com/',
        signal: controller.signal
    });
    
    clearTimeout(timeout);
    
    if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    
    return await response.json();
}

async function fetch_contest_styles() {
    // Check cache first - contest_styles are shared across all tournaments
    const cached = await storage.get(KEYS.contest_styles_cache);
    if (cached && cached[KEYS.contest_styles_cache]) {
        return cached[KEYS.contest_styles_cache];
    }
    
    try {
        // Rate limiting: enforce 500ms minimum between Underdog contest_styles API calls
        const now = Date.now();
        const time_since_last_call = now - state.last_underdog_contest_styles_call;
        const min_interval = 500; // 500ms minimum
        
        if (time_since_last_call < min_interval) {
            const wait_time = min_interval - time_since_last_call;
            // Try to return cached data if available (should have been checked above, but double-check)
            const cached_retry = await storage.get(KEYS.contest_styles_cache);
            if (cached_retry && cached_retry[KEYS.contest_styles_cache]) {
                return cached_retry[KEYS.contest_styles_cache];
            }
            // No cache available and rate limited - return empty array
            return [];
        }
        
        state.last_underdog_contest_styles_call = now;
        
        const url = 'https://stats.underdogfantasy.com/v1/contest_styles';
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 5000);
        
        const response = await fetch(url, {
            method: 'GET',
            signal: controller.signal
        });
        
        clearTimeout(timeout);
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        const data = await response.json();
        const contest_styles = data.contest_styles || [];
        
        // Cache the result for future use
        await storage.set({ [KEYS.contest_styles_cache]: contest_styles });
        
        return contest_styles;
    } catch (err) {
        console.error(`[BG Tournament] fetch_contest_styles: Error fetching:`, err);
        // Try to return cached data as fallback
        const cached_fallback = await storage.get(KEYS.contest_styles_cache);
        if (cached_fallback && cached_fallback[KEYS.contest_styles_cache]) {
            return cached_fallback[KEYS.contest_styles_cache];
        }
        return [];
    }
}

async function fetch_entry_styles() {
    // Check cache first - entry_styles are shared across all tournaments
    const cached = await storage.get(KEYS.entry_styles_cache);
    if (cached && cached[KEYS.entry_styles_cache]) {
        return cached[KEYS.entry_styles_cache];
    }
    
    try {
        // Rate limiting: enforce 500ms minimum between Underdog entry_styles API calls
        const now = Date.now();
        const time_since_last_call = now - state.last_underdog_entry_styles_call;
        const min_interval = 500; // 500ms minimum
        
        if (time_since_last_call < min_interval) {
            const wait_time = min_interval - time_since_last_call;
            // Try to return cached data if available (should have been checked above, but double-check)
            const cached_retry = await storage.get(KEYS.entry_styles_cache);
            if (cached_retry && cached_retry[KEYS.entry_styles_cache]) {
                return cached_retry[KEYS.entry_styles_cache];
            }
            // No cache available and rate limited - return empty array
            return [];
        }
        
        state.last_underdog_entry_styles_call = now;
        
        const url = 'https://stats.underdogfantasy.com/v2/entry_styles';
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 5000);
        
        const response = await fetch(url, {
            method: 'GET',
            signal: controller.signal
        });
        
        clearTimeout(timeout);
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        const data = await response.json();
        const entry_styles = data.entry_styles || [];
        
        // Cache the result for future use
        await storage.set({ [KEYS.entry_styles_cache]: entry_styles });
        
        return entry_styles;
    } catch (err) {
        console.error(`[BG Tournament] fetch_entry_styles: Error fetching:`, err);
        // Try to return cached data as fallback
        const cached_fallback = await storage.get(KEYS.entry_styles_cache);
        if (cached_fallback && cached_fallback[KEYS.entry_styles_cache]) {
            return cached_fallback[KEYS.entry_styles_cache];
        }
        return [];
    }
}

// Parses Underdog "Round Advancement: …" additional_info strings; see docs/BACKGROUND_ARCHITECTURE.md.
// Anchors after "Round Advancement:" and captures three fractions + finals integer; ignores trailing
// copy (e.g. "376 Seat Final", "376 Final", "376") so wording changes do not break parsing.
function parse_advancement_structure(text) {
    if (typeof text !== "string") return null;

    const TRIPLE_FRACTION_TAIL =
        /(\d+)\/(\d+)\s*-\s*(\d+)\/(\d+)\s*-\s*(\d+)\/(\d+)\s*-\s*(\d+)/i;

    const fromMarker = text.search(/Round Advancement/i);
    const hay = fromMarker >= 0 ? text.slice(fromMarker) : text;

    let match = hay.match(/^Round Advancement:\s*(\d+)\/(\d+)\s*-\s*(\d+)\/(\d+)\s*-\s*(\d+)\/(\d+)\s*-\s*(\d+)/i);
    if (!match) {
        match = hay.match(TRIPLE_FRACTION_TAIL);
    }
    if (!match) {
        match = text.match(TRIPLE_FRACTION_TAIL);
    }
    if (!match) {
        // Sprint: "Round Advancement: 2/12 - 3,756 Seat Final" (single fraction + finals, no W15/W16)
        const SPRINT_FINAL_TAIL =
            /Round Advancement:\s*(\d+)\/(\d+)\s*-\s*([\d,]+)\s*Seat\s*Final/i;
        let sprintMatch = hay.match(SPRINT_FINAL_TAIL);
        if (!sprintMatch) {
            sprintMatch = text.match(SPRINT_FINAL_TAIL);
        }
        if (sprintMatch) {
            const regular_season_num = Number(sprintMatch[1]);
            const regular_season_denom = Number(sprintMatch[2]);
            const finals_size = parseInt(String(sprintMatch[3]).replace(/,/g, ''), 10);
            if (
                Number.isFinite(regular_season_denom) &&
                regular_season_denom > 0 &&
                Number.isFinite(finals_size) &&
                finals_size > 0
            ) {
                const w17_quantile = Math.min(0.95, (finals_size - 2) / finals_size);
                return {
                    regular_season_num,
                    regular_season_denom,
                    w15_num: 1,
                    w15_denom: 1,
                    w16_num: 1,
                    w16_denom: 1,
                    finals_size,
                    w17_quantile,
                    raw_string: text,
                };
            }
        }

        const round_advancement_index = text.search(/Round Advancement/i);
        const advParseDbg = {
            text_length: text.length,
            found_round_advancement_marker: round_advancement_index >= 0,
            round_advancement_index,
            // What we sliced from the marker onward (what the regexes actually ran against).
            hay_from_marker: fromMarker >= 0 ? hay.slice(0, 400) : null,
            patterns_tried: [
                'anchored triple-fraction (^Round Advancement: a/b - c/d - e/f - g)',
                'triple-fraction tail (a/b - c/d - e/f - g anywhere)',
                'sprint final (Round Advancement: a/b - N Seat Final)'
            ],
            // Full raw string (not truncated) so a bespoke/new contest format is fully visible.
            full_additional_info: text
        };
        return {"raw_string": text};
    }

    // slice(1) grabs only the captures
    const [
        regular_season_num,
        regular_season_denom,
        w15_num,
        w15_denom,
        w16_num,
        w16_denom,
        finals_size,
    ] = match.slice(1).map(Number);

    const w17_quantile = Math.min(0.95, (finals_size - 2) / finals_size);

    return {
        regular_season_num,
        regular_season_denom,
        w15_num,
        w15_denom,
        w16_num,
        w16_denom,
        finals_size,
        w17_quantile,
        "raw_string": text,
    };
}


async function enrich_tournament_data_with_styles(tournament_data) {
    if (!tournament_data || tournament_data.no_tournament_data) {
        return tournament_data;
    }
    
    // Check if enrichment is needed
    const needs_contest_style = tournament_data.contest_style_id && !tournament_data.contest_style;
    const needs_entry_style = tournament_data.entry_style_id && !tournament_data.entry_style;
    
    if (!needs_contest_style && !needs_entry_style) {
        // Already fully enriched
        return tournament_data;
    }
    
    
    const fetch_promises = [];
    
    if (needs_contest_style) {
        fetch_promises.push(fetch_contest_styles());
    }
    if (needs_entry_style) {
        fetch_promises.push(fetch_entry_styles());
    }
    
    if (fetch_promises.length > 0) {
        // Use Promise.allSettled to prevent one failure from breaking the whole enrichment
        const results = await Promise.allSettled(fetch_promises);
        let result_index = 0;
        
        if (needs_contest_style) {
            const result = results[result_index++];
            if (result.status === 'fulfilled') {
                const contest_styles = result.value;
                const matching_contest_style = contest_styles.find(style => 
                    style.id === tournament_data.contest_style_id
                );
                
                if (matching_contest_style) {
                    tournament_data.contest_style = matching_contest_style;
                } else {
                }
            } else {
            }
        }
        
        if (needs_entry_style) {
            const result = results[result_index++];
            if (result.status === 'fulfilled') {
                const entry_styles = result.value;
                const matching_entry_style = entry_styles.find(style => 
                    style.id === tournament_data.entry_style_id
                );
                
                if (matching_entry_style) {
                    tournament_data.entry_style = matching_entry_style;
                } else {
                }
            } else {
            }
        }
    }
    
    return tournament_data;
}

async function fetch_underdog_tournament(draft_id) {
    // Rate limiting: enforce 500ms minimum between Underdog tournament API calls
    const now = Date.now();
    const time_since_last_call = now - state.last_underdog_tournament_call;
    const min_interval = 500; // 500ms minimum
    
    if (time_since_last_call < min_interval) {
        throw new Error('Rate limit: too soon since last tournament API call');
    }
    
    try {
        state.last_underdog_tournament_call = now;
        
        const url = `https://api.underdogfantasy.com/v1/drafts/${draft_id}/tournament`;
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 5000); // 5 second timeout
        
        const response = await fetch(url, {
            method: 'GET',
            signal: controller.signal
        });
        
        clearTimeout(timeout);
        
        if (response.status === 404) {
            // Return object indicating no tournament data for this draft
            return { no_tournament_data: true };
        }
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        const data = await response.json();
        
        // Fetch contest_styles and entry_styles in parallel
        if (data.tournament) {
            const fetch_promises = [];
            
            if (data.tournament.contest_style_id) {
                fetch_promises.push(fetch_contest_styles());
            }
            if (data.tournament.entry_style_id) {
                fetch_promises.push(fetch_entry_styles());
            }
            
            if (fetch_promises.length > 0) {
                // Use Promise.allSettled to prevent one failure from breaking the whole fetch
                // This ensures tournament data is returned even if contest_styles/entry_styles fail
                const results = await Promise.allSettled(fetch_promises);
                let result_index = 0;
                
                if (data.tournament.contest_style_id) {
                    const result = results[result_index++];
                    if (result.status === 'fulfilled') {
                        const contest_styles = result.value;
                        const matching_contest_style = contest_styles.find(style => 
                            style.id === data.tournament.contest_style_id
                        );
                        
                        if (matching_contest_style) {
                            data.tournament.contest_style = matching_contest_style;
                            // Full object + rounds: a bespoke contest may express rounds differently.
                            if (BASE_BG.env !== 'prod') {
                                const contestStyleLogData = {
                                    draft_id,
                                    contest_style_id: data.tournament.contest_style_id,
                                    rounds: matching_contest_style.rounds ?? null,
                                    contest_style_keys: Object.keys(matching_contest_style || {}),
                                    contest_style: matching_contest_style
                                };
                            }
                        } else {
                            // Log the available ids so we can see if this contest uses a style we don't recognize.
                            if (BASE_BG.env !== 'prod') {
                                const contestStyleNoMatchLogData = {
                                    draft_id,
                                    wanted_contest_style_id: data.tournament.contest_style_id,
                                    available_count: Array.isArray(contest_styles) ? contest_styles.length : 0,
                                    available: (Array.isArray(contest_styles) ? contest_styles : []).map(s => ({ id: s?.id ?? null, name: s?.name ?? null, rounds: s?.rounds ?? null }))
                                };
                            }
                        }
                    } else {
                    }
                }
                
                if (data.tournament.entry_style_id) {
                    const result = results[result_index++];
                    if (result.status === 'fulfilled') {
                        const entry_styles = result.value;
                        const matching_entry_style = entry_styles.find(style => 
                            style.id === data.tournament.entry_style_id
                        );
                        
                        if (matching_entry_style) {
                            data.tournament.entry_style = matching_entry_style;
                            if (BASE_BG.env !== 'prod') {
                                const entryStyleLogData = {
                                    draft_id,
                                    entry_style_id: data.tournament.entry_style_id,
                                    fee: matching_entry_style.fee ?? null,
                                    entry_style_keys: Object.keys(matching_entry_style || {}),
                                    entry_style: matching_entry_style
                                };
                            }
                        } else {
                            if (BASE_BG.env !== 'prod') {
                                const entryStyleNoMatchLogData = {
                                    draft_id,
                                    wanted_entry_style_id: data.tournament.entry_style_id,
                                    available_count: Array.isArray(entry_styles) ? entry_styles.length : 0,
                                    available: (Array.isArray(entry_styles) ? entry_styles : []).map(s => ({ id: s?.id ?? null, fee: s?.fee ?? null }))
                                };
                            }
                        }
                    } else {
                    }
                }
            }
            
            const additional_info = data.tournament.additional_info || "";
            const advancement_structure = parse_advancement_structure(additional_info) || null;
            const advancement_regex_matched =
                advancement_structure != null && advancement_structure.regular_season_denom != null;
            
            const flattened = {
                ...data.tournament,
                advancement_structure
            };
            
            const fetchSlateIds = Array.isArray(flattened.slates) ? flattened.slates.map((s) => s?.id).filter(Boolean) : (Array.isArray(flattened.states) ? flattened.states.map((s) => s?.id).filter(Boolean) : []);
            const fetchDbg = { draft_id: draft_id, tournament_id: flattened.id, title: flattened.title || null, additional_info_len: additional_info.length, additional_info_preview: additional_info.slice(0, 200), advancement_regex_matched: advancement_regex_matched, regular_season_denom: advancement_structure?.regular_season_denom ?? null, contest_style_id: data.tournament.contest_style_id ?? null, contest_style_rounds: data.tournament.contest_style?.rounds ?? null, slate_ids: fetchSlateIds };
            // Always log the top-level shape of the raw tournament object so a bespoke contest's
            // extra/renamed fields are visible even when sizing succeeds.
            if (BASE_BG.env !== 'prod') {
                const fetchTopLevelKeysLogData = {
                    draft_id,
                    tournament_id: flattened.id,
                    tournament_keys: Object.keys(data.tournament || {})
                };
            }
            if (!underdogTournamentSizingComplete(flattened)) {
                if (BASE_BG.env !== 'prod') {
                    const sizingFields = describeUnderdogTournamentSizingFields(flattened);
                }
            }
            return flattened;
        }
        
        const fetchMissingTournamentDbg = { draft_id: draft_id, top_keys: data && typeof data === 'object' ? Object.keys(data) : [], full_response: data };
        return data;
    } catch (err) {
        console.error(`[BG Tournament] fetch_underdog_tournament: FAILED for draft_id=${draft_id}:`, err);
        const error_message = err?.message || 'Unknown error';
        if (error_message.includes('aborted') || error_message.includes('timeout')) {
            console.error(`[BG Tournament] fetch_underdog_tournament: TIMEOUT for draft_id=${draft_id} after 5000ms`);
        } else if (error_message.includes('Rate limit')) {
            console.error(`[BG Tournament] fetch_underdog_tournament: RATE LIMIT ERROR for draft_id=${draft_id}`);
        }
        throw err;
    }
}


function is_sim_like_algo(algo_type) {
    if (!algo_type) return false;
    const normalized = algo_type.toLowerCase();
    return normalized === 'sim' || normalized === 'pure_sim' || normalized === 'dev_sim';
}


function extract_picks_from_response(response, algo_type) {
    if (!response) return null;

    if (is_sim_like_algo(algo_type)) {
        if (algo_type.toLowerCase() === 'pure_sim') {
            if (response.sim_picks) {
                return response.sim_picks;
            }
            return null;
        }
        if ((algo_type.toLowerCase() === 'sim' || algo_type.toLowerCase() === 'dev_sim') && response.blended_picks) {
            return response.blended_picks;
        }
        return null;
    } else if (response.classic_picks) {
        return response.classic_picks;
    }
    return null;
}

async function clear_draft_state_for_id(draft_id) {
    if (!draft_id) {
        return;
    }


    const draft_states = await get_draft_states();

    let states_changed = false;
    let states_cleared_count = 0;
    let cache_cleared_count = 0;

    // Clear all states and poll counts for this draft_id (may have multiple request_identifiers)

    for (const [request_identifier, state] of Object.entries(draft_states)) {
        if (state.draft?.draft_id === draft_id) {
            delete draft_states[request_identifier];
            states_changed = true;
            states_cleared_count++;
        }
    }

    if (states_changed) {
        await set_draft_states(draft_states);
    }

    // Rankings-cache rows go through the serialized updater so this clear can't
    // race a concurrent result store into losing either side's write.
    await update_rankings_cache((cache) => {
        for (const [key, value] of Object.entries(cache)) {
            // Check if request_identifier starts with draft_id
            if (key.startsWith(`${draft_id}-`)) {
                delete cache[key];
                cache_cleared_count++;
            }
        }
    });

    if (states_changed || cache_cleared_count > 0) {
    } else {
    }

    
    let in_flight_cleared = 0;
    for (const key of [...inFlightRankingsRequests.keys()]) {
        if (key.startsWith(`${draft_id}-`)) {
            inFlightRankingsRequests.delete(key);
            in_flight_cleared++;
        }
    }
    
    if (in_flight_cleared > 0) {
    }
    
}

/** Persist only fields needed for validate_draft_state_transition / cleanup — not full rankings payloads. */
function buildDraftStateSnapshotForStorage(draft_data) {
    const draft = draft_data && draft_data.draft;
    let slimDraft;
    if (draft && typeof draft === 'object') {
        const picks = Array.isArray(draft.picks)
            ? draft.picks.map((p) => ({
                  player_id: p.player_id,
                  position: p.position,
                  round: p.round,
                  pick_number: p.pick_number,
              }))
            : [];
        slimDraft = {
            draft_id: draft.draft_id,
            picks,
        };
    }
    return {
        request_identifier: draft_data.request_identifier,
        draft: slimDraft,
        last_update: Date.now(),
    };
}

function validate_draft_state_transition(lastState, newState) {
    if (!lastState || !newState) return true; // First time seeing this draft
    
    const lastPicks = lastState.draft?.picks || [];
    const newPicks = newState.draft?.picks || [];
    
    if (newPicks.length < lastPicks.length) {
        return false;
    }
    
    // Existing picks should not change fundamentally
    for (let i = 0; i < lastPicks.length; i++) {
        const lastPick = lastPicks[i];
        const newPick = newPicks[i];
        
        if (!lastPick || !newPick) continue;
        
        const player_id_changed = lastPick.player_id !== newPick.player_id;
        const position_changed = lastPick.position !== newPick.position;
        const round_changed = lastPick.round !== newPick.round;
        const pick_number_changed = lastPick.pick_number !== newPick.pick_number;
        
        if (player_id_changed || position_changed || round_changed || pick_number_changed) {
            console.error('[draft_validation] *** INVALID TRANSITION: Existing pick CHANGED ***', newState.draft?.draft_id, i, player_id_changed, position_changed, round_changed, pick_number_changed, lastPick.player_id, lastPick.position, lastPick.round, lastPick.pick_number, newPick.player_id, newPick.position, newPick.round, newPick.pick_number);
            return false;
        }
    }
    
    return true;
}


async function process_draft_state_debounce(draft_data) {
    const requestIdentifier = draft_data.request_identifier;
    if (!requestIdentifier) {
        return { shouldProcess: false, forceRepoll: false };
    }
    
    const draftId = draft_data.draft?.draft_id;
    
    // Load current state
    const draftStates = await get_draft_states();
    
    const lastState = draftStates[requestIdentifier];
    
    // Validate state transition against stored states
    let isValidTransition = true;
    
    if (draftId) {
        // First, validate against the stored state for this same request_identifier (if it exists)
        if (lastState) {
            isValidTransition = validate_draft_state_transition(lastState, draft_data);
            
            if (!isValidTransition) {
                console.error('[draft_debounce] Invalid state transition detected - draft went backward (same request_identifier)', requestIdentifier, draftId);
            }
        }
        
        // ALWAYS check against other request_identifiers for the same draft_id
        // This is critical for catching when picks are deleted (which changes request_identifier)
        if (isValidTransition) {
            let otherStateForDraft = null;
            for (const state_key in draftStates) {
                if (!Object.prototype.hasOwnProperty.call(draftStates, state_key)) {
                    continue;
                }
                const state = draftStates[state_key];
                if (!state || state.request_identifier === requestIdentifier) {
                    continue;
                }
                if (state.draft?.draft_id === draftId) {
                    otherStateForDraft = state;
                    break;
                }
            }
            if (otherStateForDraft) {
                const otherIsValid = validate_draft_state_transition(otherStateForDraft, draft_data);
                if (!otherIsValid) {
                    isValidTransition = false;
                }
            }
        }
    }

    // Store latest state and proceed immediately. If we detect an invalid transition,
    // clear cached state for the draft id and still proceed.
    if (!isValidTransition && draftId) {
        await clear_draft_state_for_id(draftId);
    }

    draftStates[requestIdentifier] = buildDraftStateSnapshotForStorage(draft_data);
    cleanup_old_draft_state_entries(draftStates, draftId, requestIdentifier);
    await set_draft_states(draftStates);

    return { shouldProcess: true, forceRepoll: false };
}

function extractUnderdogTournamentSlateIds(tournament_data) {
    if (!tournament_data || tournament_data.no_tournament_data) {
        return [];
    }
    const slates = tournament_data.slates || tournament_data.states || [];
    if (!Array.isArray(slates)) {
        return [];
    }
    const seen = new Set();
    const ids = [];
    for (let i = 0; i < slates.length; i++) {
        const sid = slates[i] && slates[i].id;
        if (typeof sid !== 'string') {
            continue;
        }
        const cleaned = sid.trim();
        if (!cleaned || seen.has(cleaned)) {
            continue;
        }
        seen.add(cleaned);
        ids.push(cleaned);
    }
    return ids;
}

// Bump when the POST body gains fields so installs that already submitted a
// tournament under an older shape re-submit it once with the new one.
const UD_TOURNAMENT_SLATE_MAP_PAYLOAD_VERSION = 2;

/**
 * Display metadata for the slate-map doc: parsed advancement structure plus
 * normalized payouts/entry fee. Advancement is stripped of EV-calculator merge
 * artifacts (stage_loss_evs, nested payout_structure) — the doc stores raw
 * tournament facts, not client-computed EVs.
 */
function buildUdTournamentSlateMapEnrichment(tournament_data) {
    let advancement_structure = null;
    const adv = tournament_data.advancement_structure;
    if (adv && typeof adv === 'object') {
        const {
            stage_loss_evs: _evs,
            payout_structure: _nested_payouts,
            entry_fee: _nested_fee,
            tournament_id: _tid,
            ...clean
        } = adv;
        if (Object.keys(clean).length) {
            advancement_structure = clean;
        }
    }

    let payout_structure = null;
    let entry_fee = null;
    if (typeof normalizeUnderdogPayoutsAndFee === 'function') {
        const normalized = normalizeUnderdogPayoutsAndFee(tournament_data);
        if (
            typeof hasUsableUnderdogPayoutStructure === 'function' &&
            hasUsableUnderdogPayoutStructure(normalized.payout_structure)
        ) {
            payout_structure = normalized.payout_structure;
        }
        const fee = Number(normalized.entry_fee);
        if (normalized.entry_fee != null && Number.isFinite(fee) && fee >= 0) {
            entry_fee = fee;
        }
    }

    return { advancement_structure, payout_structure, entry_fee };
}

/**
 * Fire-and-forget: trusted clients POST tournament_id -> slate_ids (plus
 * advancement/payout display metadata) once per install per payload version.
 * A submission without usable payouts stays re-submittable so a later hit
 * that has them upgrades the doc. Does not block GET_TOURNAMENT_DATA;
 * failures leave the id unmarked so a later hit can retry.
 */
async function maybe_submit_ud_tournament_slate_map(tournament_data) {
    try {
        if (!tournament_data || tournament_data.no_tournament_data) {
            return;
        }
        const tournament_id = tournament_data.id;
        if (!tournament_id || tournament_id === 'no_id' || typeof tournament_id !== 'string') {
            return;
        }
        const slate_ids = extractUnderdogTournamentSlateIds(tournament_data);
        if (!slate_ids.length) {
            return;
        }
        if (udTournamentSlateMapInFlight.has(tournament_id)) {
            return;
        }

        const { advancement_structure, payout_structure, entry_fee } =
            buildUdTournamentSlateMapEnrichment(tournament_data);
        const has_payouts = payout_structure != null;

        const submittedRes = await storage.get(KEYS.ud_tournament_slate_map_submitted);
        const submitted = (submittedRes && submittedRes[KEYS.ud_tournament_slate_map_submitted]) || {};
        const marker = submitted[tournament_id];
        // Legacy `true` markers predate enrichment -> re-submit once.
        const markerCurrent =
            marker &&
            typeof marker === 'object' &&
            marker.v >= UD_TOURNAMENT_SLATE_MAP_PAYLOAD_VERSION;
        if (markerCurrent && (marker.has_payouts || !has_payouts)) {
            return;
        }

        if (typeof refresh_session_if_needed !== 'function' || typeof make_http_request !== 'function') {
            return;
        }

        const session = await refresh_session_if_needed();
        if (!session?.user_uuid || !TRUSTED_DATA_UPLOAD_UUIDS.includes(session.user_uuid)) {
            return;
        }

        udTournamentSlateMapInFlight.add(tournament_id);
        try {
            const headers = {};
            if (session.app_jwt) {
                headers['Authorization'] = `Bearer ${session.app_jwt}`;
            }
            const body = {
                user_uuid: session.user_uuid,
                tournament_id,
                slate_ids
            };
            if (advancement_structure) {
                body.advancement_structure = advancement_structure;
            }
            if (payout_structure) {
                body.payout_structure = payout_structure;
            }
            if (entry_fee != null) {
                body.entry_fee = entry_fee;
            }
            await make_http_request('/ud_tournament_slate_map', {
                method: 'POST',
                body,
                headers
            });
            submitted[tournament_id] = {
                v: UD_TOURNAMENT_SLATE_MAP_PAYLOAD_VERSION,
                has_payouts
            };
            await storage.set({ [KEYS.ud_tournament_slate_map_submitted]: submitted });
            if (BASE_BG.env !== 'prod') {
                const log_data = {
                    tournament_id,
                    slate_ids,
                    has_advancement: !!advancement_structure,
                    has_payouts,
                    entry_fee
                };
            }
        } finally {
            udTournamentSlateMapInFlight.delete(tournament_id);
        }
    } catch (err) {
        if (tournament_data?.id) {
            udTournamentSlateMapInFlight.delete(tournament_data.id);
        }
    }
}

// Bump when the /dk_tournament_map POST body gains fields (same contract as
// UD_TOURNAMENT_SLATE_MAP_PAYLOAD_VERSION).
const DK_TOURNAMENT_MAP_PAYLOAD_VERSION = 1;

/**
 * Fire-and-forget: trusted clients POST DK tournament display metadata
 * (advancement/payouts/entry fee) keyed by tournament_key, parsed from the
 * raw tournaments/v1 response the content script hands us to cache
 * (SET_DK_TOURNAMENT_DATA). Once per install per payload version; a
 * submission without usable payouts stays re-submittable so a later hit that
 * has them upgrades the doc.
 */
async function maybe_submit_dk_tournament_map(tournament_key, tournament_data) {
    try {
        if (!tournament_key || typeof tournament_key !== 'string') {
            return;
        }
        const rounds = tournament_data?.tournamentDetail?.rounds;
        if (!Array.isArray(rounds) || !rounds.length) {
            return;
        }
        if (typeof parse_draft_kings_advancement !== 'function' || typeof parse_draft_kings_payouts !== 'function') {
            return;
        }
        if (dkTournamentMapInFlight.has(tournament_key)) {
            return;
        }

        const advancement_structure = parse_draft_kings_advancement(rounds) || null;
        // Zero-cash positions are noise for display (the EV calculator derives
        // its own zero tiers from the includeZero variant at rankings time).
        const payout_structure_raw = parse_draft_kings_payouts(rounds, { includeZero: false });
        const payout_structure =
            payout_structure_raw && Object.values(payout_structure_raw).some((tiers) => tiers && Object.keys(tiers).length)
                ? payout_structure_raw
                : null;
        const feeRaw = Number(tournament_data?.tournamentDetail?.entryFee);
        const entry_fee =
            tournament_data?.tournamentDetail?.entryFee != null && Number.isFinite(feeRaw) && feeRaw >= 0
                ? feeRaw
                : null;
        if (!advancement_structure && !payout_structure && entry_fee == null) {
            return;
        }
        const has_payouts = payout_structure != null;

        const submittedRes = await storage.get(KEYS.dk_tournament_map_submitted);
        const submitted = (submittedRes && submittedRes[KEYS.dk_tournament_map_submitted]) || {};
        const marker = submitted[tournament_key];
        const markerCurrent =
            marker &&
            typeof marker === 'object' &&
            marker.v >= DK_TOURNAMENT_MAP_PAYLOAD_VERSION;
        if (markerCurrent && (marker.has_payouts || !has_payouts)) {
            return;
        }

        if (typeof refresh_session_if_needed !== 'function' || typeof make_http_request !== 'function') {
            return;
        }

        const session = await refresh_session_if_needed();
        if (!session?.user_uuid || !TRUSTED_DATA_UPLOAD_UUIDS.includes(session.user_uuid)) {
            return;
        }

        dkTournamentMapInFlight.add(tournament_key);
        try {
            const headers = {};
            if (session.app_jwt) {
                headers['Authorization'] = `Bearer ${session.app_jwt}`;
            }
            const body = {
                user_uuid: session.user_uuid,
                tournament_key
            };
            if (advancement_structure) {
                body.advancement_structure = advancement_structure;
            }
            if (payout_structure) {
                body.payout_structure = payout_structure;
            }
            if (entry_fee != null) {
                body.entry_fee = entry_fee;
            }
            await make_http_request('/dk_tournament_map', {
                method: 'POST',
                body,
                headers
            });
            submitted[tournament_key] = {
                v: DK_TOURNAMENT_MAP_PAYLOAD_VERSION,
                has_payouts
            };
            await storage.set({ [KEYS.dk_tournament_map_submitted]: submitted });
            if (BASE_BG.env !== 'prod') {
                const log_data = {
                    tournament_key,
                    has_advancement: !!advancement_structure,
                    has_payouts,
                    entry_fee
                };
            }
        } finally {
            dkTournamentMapInFlight.delete(tournament_key);
        }
    } catch (err) {
        if (tournament_key) {
            dkTournamentMapInFlight.delete(tournament_key);
        }
    }
}

function format_type_skips_stage_loss_evs(format_type) {
    return format_type === 'eliminator' || format_type === 'marathon';
}

function strip_stage_loss_evs_from_advancement_structure(advancement_structure) {
    if (!advancement_structure || typeof advancement_structure !== 'object') {
        return advancement_structure;
    }
    if (!Object.prototype.hasOwnProperty.call(advancement_structure, 'stage_loss_evs')) {
        return advancement_structure;
    }
    const { stage_loss_evs: _removed, ...rest } = advancement_structure;
    return rest;
}

async function prepare_advancement_structure_for_rankings(advancement_structure, options) {
    const { tournament_info, draft_id, format_type, log_prefix } = options || {};
    const prefix = log_prefix || '[ev_calculator]';

    if (format_type_skips_stage_loss_evs(format_type)) {
        return strip_stage_loss_evs_from_advancement_structure(advancement_structure || null);
    }

    let advancement_structure_with_evs = advancement_structure || null;

    if (tournament_info && advancement_structure_with_evs) {
        advancement_structure_with_evs = {
            ...advancement_structure_with_evs,
            payout_structure: tournament_info.payout_structure,
            entry_fee: tournament_info.entry_fee,
            tournament_id: tournament_info.id
        };
    }

    if (advancement_structure_with_evs &&
        hasUsableUnderdogPayoutStructure(advancement_structure_with_evs.payout_structure) &&
        advancement_structure_with_evs.entry_fee &&
        !advancement_structure_with_evs.stage_loss_evs) {
        if (draft_id) {
            const stage_loss_evs = await get_or_calculate_tournament_evs(
                advancement_structure_with_evs,
                draft_id,
                format_type
            );

            if (stage_loss_evs) {
                advancement_structure_with_evs = {
                    ...advancement_structure_with_evs,
                    stage_loss_evs: stage_loss_evs
                };
            } else {
            }
        } else {
        }
    } else {
        const skip_reasons = [];
        if (!advancement_structure_with_evs) {
            skip_reasons.push('no_advancement_structure');
        } else {
            if (!advancement_structure_with_evs.payout_structure) {
                skip_reasons.push('no_payout_structure');
            }
            if (!advancement_structure_with_evs.entry_fee) {
                skip_reasons.push('no_entry_fee');
            }
            if (advancement_structure_with_evs.stage_loss_evs) {
                skip_reasons.push('already_has_stage_loss_evs');
            }
        }
    }

    if (format_type === 'sprint' && advancement_structure_with_evs) {
        advancement_structure_with_evs = {
            ...advancement_structure_with_evs,
            payout_structure: flattenUnderdogSprintPayoutStructureIfApplicable(
                advancement_structure_with_evs.payout_structure,
                format_type
            )
        };
    }

    return advancement_structure_with_evs;
}

function calc_stage_loss_evs(payout_structure, entry_fee, num_rounds = 4) {
    const stage_loss_evs = [];
    
    for (let round_num = 1; round_num < num_rounds; round_num++) {
        // Get the payout dict for this round as strings
        const payout_dict = payout_structure[String(round_num)] || {};
        
        // Filter out zero-payout entries
        const nonzero_items = [];
        for (const [prize, count] of Object.entries(payout_dict)) {
            const prizeFloat = parseFloat(prize);
            const countInt = parseInt(count, 10);
            if (prizeFloat > 0) {
                nonzero_items.push([prizeFloat, countInt]);
            }
        }
        
        if (nonzero_items.length === 0) {
            // No nonzero payouts (round 1), so EV = 0
            stage_loss_evs.push(0);
            continue;
        }
        
        // Compute weighted sum of payouts
        const total_winners = nonzero_items.reduce((sum, [, count]) => sum + count, 0);
        const weighted_sum = nonzero_items.reduce((sum, [prize, count]) => sum + (prize * count), 0);
        
        // EV for this stage (as described)
        const mean_prize = total_winners > 0 ? weighted_sum / total_winners : 0;
        const stage_ev = mean_prize / entry_fee;
        stage_loss_evs.push(stage_ev);
    }
    
    return stage_loss_evs;
}


function getUnderdogFinalsEvBins() {
    const remote = configState && configState.data && configState.data.background_settings
        ? configState.data.background_settings.underdog_finals_ev_bins
        : undefined;
    const fallback = CONFIG_FALLBACK && CONFIG_FALLBACK.background_settings
        ? CONFIG_FALLBACK.background_settings.underdog_finals_ev_bins
        : UNDERDOG_FINALS_EV_BINS_DEFAULT;
    const n = parseInt(remote != null ? remote : fallback, 10);
    if (!Number.isFinite(n) || n < 1) {
        return UNDERDOG_FINALS_EV_BINS_DEFAULT;
    }
    return n;
}

function quantile_bin_averages(data, n_bins = UNDERDOG_FINALS_EV_BINS_DEFAULT) {
    if (!Array.isArray(data) || data.length === 0) {
        return Array(n_bins).fill(NaN);
    }
    
    if (data.length <= n_bins) {
        // If we have fewer data points than bins, pad with the last value
        const result = [...data];
        while (result.length < n_bins) {
            result.push(data[data.length - 1]);
        }
        return result;
    }
    
    if (data.length === 1) {
        // Special case: only one data point
        const result = Array(n_bins).fill(data[0]);
        return result;
    }
    
    // Sort data for quantile calculation
    const sorted = [...data].sort((a, b) => a - b);
    
    // Create quantile boundaries
    const quantile_edges = [];
    for (let i = 0; i <= n_bins; i++) {
        quantile_edges.push(i / n_bins);
    }
    
    // Calculate value edges using linear interpolation
    const value_edges = [];
    for (const q of quantile_edges) {
        if (q === 0) {
            value_edges.push(sorted[0]);
        } else if (q === 1) {
            value_edges.push(sorted[sorted.length - 1]);
        } else {
            const index = q * (sorted.length - 1);
            const lower = Math.floor(index);
            const upper = Math.ceil(index);
            const fraction = index - lower;
            
            if (lower === upper) {
                value_edges.push(sorted[lower]);
            } else {
                value_edges.push(sorted[lower] * (1 - fraction) + sorted[upper] * fraction);
            }
        }
    }
    
    // Calculate average for each quantile bin
    const bin_averages = [];
    
    for (let i = 0; i < n_bins; i++) {
        const lower_edge = value_edges[i];
        const upper_edge = value_edges[i + 1];
        
        // Filter data points that fall in this bin
        let mask;
        if (i === n_bins - 1) {
            // Last bin includes the maximum value (inclusive on both ends)
            mask = data.filter(val => val >= lower_edge && val <= upper_edge);
        } else {
            // Other bins: inclusive on lower, exclusive on upper
            mask = data.filter(val => val >= lower_edge && val < upper_edge);
        }
        
        if (mask.length > 0) {
            const avg = mask.reduce((sum, val) => sum + val, 0) / mask.length;
            bin_averages.push(avg);
        } else {
            // Handle empty bins - use the midpoint of the bin edges
            const midpoint = (lower_edge + upper_edge) / 2;
            bin_averages.push(midpoint);
        }
    }
    
    return bin_averages;
}


function inferUnderdogEvNumRounds(payout_structure, format_type) {
    if (format_type === 'sprint') {
        return 2;
    }
    if (format_type) {
        // Standard / playoff: W1-14, W15, W16, W17 — always four stages even when
        // mid-tier payout dicts are empty (winner-take-all style).
        return 4;
    }
    if (!payout_structure || typeof payout_structure !== 'object') {
        return 4;
    }
    const hasFinals = Object.keys(payout_structure['4'] || {}).length > 0;
    const hasMidTiers =
        Object.keys(payout_structure['2'] || {}).length > 0 ||
        Object.keys(payout_structure['3'] || {}).length > 0;
    // format_type unknown: infer sprint when only the finals tier is populated.
    if (hasFinals && !hasMidTiers) {
        return 2;
    }
    return 4;
}

function isUnderdogSprintEvFormat(payout_structure, format_type) {
    if (format_type === 'sprint') {
        return true;
    }
    if (format_type) {
        return false;
    }
    return inferUnderdogEvNumRounds(payout_structure, null) === 2;
}

function inferUnderdogEvExpectedFinalsBinCount(payout_structure, finals_count, format_type) {
    if (isUnderdogSprintEvFormat(payout_structure, format_type)) {
        return UNDERDOG_SPRINT_FINALS_EV_BINS;
    }
    const maxBins = getUnderdogFinalsEvBins();
    if (finals_count > 0 && finals_count < maxBins) {
        return finals_count;
    }
    return maxBins;
}

// Backend sprint scorer expects a flat { prize: count } dict, not marathon tiers 1–4.
function flattenUnderdogSprintPayoutStructureIfApplicable(payout_structure, format_type) {
    if (format_type !== 'sprint' || !payout_structure || typeof payout_structure !== 'object') {
        return payout_structure;
    }
    const tier4 = payout_structure['4'];
    const tier2 = payout_structure['2'];
    const tier3 = payout_structure['3'];
    const hasMidTiers =
        (tier2 && typeof tier2 === 'object' && Object.keys(tier2).length > 0) ||
        (tier3 && typeof tier3 === 'object' && Object.keys(tier3).length > 0);
    if (!tier4 || typeof tier4 !== 'object' || !Object.keys(tier4).length || hasMidTiers) {
        return payout_structure;
    }
    return { ...tier4 };
}

// Total number of finalist seats, including seats that receive no payout.
// payout_structure['4'] only lists paid seats, so winner-take-all / partially
// paid finals need advancement_structure.finals_size to know how many losing
// finalist seats (payout 0) to include in the finals distribution.
function getUnderdogFinalsSeatCount(advancement_structure) {
    const payout_structure = advancement_structure && advancement_structure.payout_structure;
    const finals_payout_dict = (payout_structure && payout_structure['4']) || {};
    let paid_count = 0;
    for (const [, count] of Object.entries(finals_payout_dict)) {
        const countInt = parseInt(count, 10);
        if (Number.isFinite(countInt) && countInt > 0) {
            paid_count += countInt;
        }
    }
    const declared = advancement_structure && advancement_structure.finals_size;
    const declaredInt = parseInt(declared, 10);
    if (Number.isFinite(declaredInt) && declaredInt > 0 && declaredInt >= paid_count) {
        return declaredInt;
    }
    return paid_count;
}

function calculate_tournament_evs(advancement_structure, format_type = null) {
    if (!advancement_structure) {
        return null;
    }
    
    const payout_structure = advancement_structure.payout_structure;
    const entry_fee = advancement_structure.entry_fee;
    
    if (!payout_structure || typeof entry_fee !== 'number' || entry_fee <= 0) {
        return null;
    }
    
    // Get finals payout dict (round 4)
    const finals_payout_dict = payout_structure['4'] || {};
    
    // Flatten finals payouts into array
    const finals_payouts = [];
    for (const [prize, count] of Object.entries(finals_payout_dict)) {
        const prizeFloat = parseFloat(prize);
        const countInt = parseInt(count, 10);
        if (!Number.isFinite(countInt) || countInt <= 0 || Number.isNaN(prizeFloat)) {
            continue;
        }
        for (let i = 0; i < countInt; i++) {
            finals_payouts.push(prizeFloat);
        }
    }
    
    if (finals_payouts.length === 0) {
        return null;
    }
    
    // Include unpaid finalist seats (payout 0) so the finals distribution reflects
    // every seat, not just the paid ones. Without this, a winner-take-all final
    // (e.g. 1 paid seat of 47) would imply every finalist collects the top prize.
    const finals_seat_count = getUnderdogFinalsSeatCount(advancement_structure);
    while (finals_payouts.length < finals_seat_count) {
        finals_payouts.push(0);
    }
    
    // Normalize finals payouts by entry fee
    const normed_finals_payouts = finals_payouts.map(p => p / entry_fee);
    
    // Add small jitter to avoid duplicate values (helps with quantile binning)
    const normed_finals_payouts_jittered = normed_finals_payouts.map(p => 
        p + (Math.random() * 1e-10)
    );
    
    const expected_bin_count = inferUnderdogEvExpectedFinalsBinCount(
        payout_structure,
        normed_finals_payouts_jittered.length,
        format_type
    );
    const is_sprint = isUnderdogSprintEvFormat(payout_structure, format_type);

    let flattened_finals_payouts;
    if (expected_bin_count === normed_finals_payouts_jittered.length) {
        flattened_finals_payouts = normed_finals_payouts_jittered;
    } else {
        flattened_finals_payouts = quantile_bin_averages(normed_finals_payouts_jittered, expected_bin_count);
    }
    
    // Check for NaN values
    const nan_count = flattened_finals_payouts.filter(v => isNaN(v)).length;
    if (nan_count > 0) {
        return null;
    }
    
    const stage_loss_evs = calc_stage_loss_evs(
        payout_structure,
        entry_fee,
        inferUnderdogEvNumRounds(payout_structure, format_type)
    );
    
    // Append finals quantile EVs as the last element
    stage_loss_evs.push(flattened_finals_payouts);
    
    return stage_loss_evs;
}


async function get_or_calculate_tournament_evs(advancement_structure, draft_id, format_type = null) {
    if (!advancement_structure || !draft_id) {
        return null;
    }
    
    // Look up tournament_id from draft_id mapping
    let tournament_id = await get_tournament_id_for_draft(draft_id);
    
    // If no mapping exists, try to get tournament_id from advancement_structure
    if (!tournament_id && advancement_structure.tournament_id) {
        tournament_id = advancement_structure.tournament_id;
        // Create the mapping for future use
        await set_tournament_id_for_draft(draft_id, tournament_id);
    }
    
    if (!tournament_id) {
        return null;
    }
    
    // Calculate finals size to validate cache entries. Must match the seat count
    // used in calculate_tournament_evs (paid + unpaid finalist seats).
    const payout_structure = advancement_structure.payout_structure;
    const finals_size = getUnderdogFinalsSeatCount(advancement_structure);
    
    // Check cache first using tournament_id
    const cache_storage_key = `${KEYS.tournament_evs_prefix}${tournament_id}`;
    
    const cached = await storage.get(cache_storage_key);
    const cached_entry = (cached && cached[cache_storage_key]) || null;
    
    // Handle both old format (just array) and new format (object with evs and last_accessed)
    let cached_evs = null;
    if (cached_entry) {
        if (Array.isArray(cached_entry)) {
            // Old format - migrate to new format
            cached_evs = cached_entry;
        } else if (cached_entry.evs && Array.isArray(cached_entry.evs)) {
            // New format
            cached_evs = cached_entry.evs;
        }
    }
    
    if (cached_evs && cached_evs.length > 0) {
        const cached_finals_evs = cached_evs[cached_evs.length - 1];
        const cached_finals_length = Array.isArray(cached_finals_evs) ? cached_finals_evs.length : 0;
        
        const expected_finals_length = inferUnderdogEvExpectedFinalsBinCount(
            payout_structure,
            finals_size,
            format_type
        );
        let cache_valid = cached_finals_length === expected_finals_length;
        let invalidation_reason = null;
        if (!cache_valid) {
            invalidation_reason =
                `expected finals EV length ${expected_finals_length} (finals_size=${finals_size}, sprint=${isUnderdogSprintEvFormat(payout_structure, format_type)}) but cached length is ${cached_finals_length}`;
        }
        
        if (cache_valid) {
            // Update last_accessed timestamp
            const now = Date.now();
            await storage.set({ 
                [cache_storage_key]: {
                    evs: cached_evs,
                    last_accessed: now
                }
            });
            
            return cached_evs;
        } else {
            // Invalid cache - remove it and recalculate
            
            await storage.remove(cache_storage_key);
            cached_evs = null; // Force recalculation
        }
    }
    
    
    // Calculate EVs
    const stage_loss_evs = calculate_tournament_evs(advancement_structure, format_type);
    
    if (!stage_loss_evs) {
        return null;
    }
    
    // Cache the result with timestamp using tournament_id
    const now = Date.now();
    await storage.set({ 
        [cache_storage_key]: {
            evs: stage_loss_evs,
            last_accessed: now
        }
    });
    
    return stage_loss_evs;
}


async function cleanup_old_tournament_evs(max_age_ms = 7 * 24 * 60 * 60 * 1000) {
    const now = Date.now();
    const threshold = now - max_age_ms;
    
    try {
        // Get all storage keys
        const all_storage = await storage.get(null);
        const evs_keys = Object.keys(all_storage || {}).filter(key => 
            key.startsWith(KEYS.tournament_evs_prefix)
        );
        
        let cleaned_count = 0;
        const keys_to_remove = [];
        
        for (const key of evs_keys) {
            const entry = all_storage[key];
            let last_accessed = 0;
            
            // Handle both old format (just array) and new format (object with last_accessed)
            if (Array.isArray(entry)) {
                // Old format - no timestamp, consider it old
                last_accessed = 0;
            } else if (entry && typeof entry.last_accessed === 'number') {
                last_accessed = entry.last_accessed;
            } else {
                // Invalid format, mark for removal
                last_accessed = 0;
            }
            
            if (last_accessed < threshold) {
                keys_to_remove.push(key);
                cleaned_count++;
            }
        }
        
        if (keys_to_remove.length > 0) {
            await storage.remove(keys_to_remove);
        }
        
        return cleaned_count;
    } catch (err) {
        console.error('[ev_calculator] Error cleaning up tournament EV cache:', err);
        return 0;
    }
}


// Removes every cached tournament EV entry. Used on install/update to discard
// EVs computed by older (buggy) logic; they are recomputed lazily on next access.
async function clear_all_tournament_evs() {
    try {
        const all_storage = await storage.get(null);
        const evs_keys = Object.keys(all_storage || {}).filter(key =>
            key.startsWith(KEYS.tournament_evs_prefix)
        );

        if (evs_keys.length > 0) {
            await storage.remove(evs_keys);
        }

        return evs_keys.length;
    } catch (err) {
        console.error('[ev_calculator] Error clearing tournament EV cache:', err);
        return 0;
    }
}



function stopAllPollsForDraftId(draft_id, exclude_request_identifier) {
    if (!draft_id) {
        return;
    }
    
    for (const [request_identifier, pollData] of inFlightPollTimers.entries()) {
        // Skip the current request identifier
        if (request_identifier === exclude_request_identifier) {
            continue;
        }
        
        // Check if this poll is for the same draft_id
        const pollDraftId = pollData.draft_id || pollData.requestData?.draft_id;
        if (pollDraftId === draft_id) {
            stopInFlightPolling(request_identifier);
        }
    }
}


async function persist_active_poll(request_identifier, requestData) {
    try {
        const res = await storage.get(KEYS.active_polls);
        const activePolls = (res && res[KEYS.active_polls]) || {};
        activePolls[request_identifier] = {
            started_at: Date.now(),
            draft_id: requestData.draft_id || requestData.draft?.draft_id,
            algo_type: requestData.algo_type,
            ranking_set: requestData.ranking_set
        };
        await storage.set({ [KEYS.active_polls]: activePolls });
    } catch (err) {
        console.error('[background-http] Failed to persist active poll:', err);
    }
}

async function remove_active_poll(request_identifier) {
    try {
        const res = await storage.get(KEYS.active_polls);
        const activePolls = (res && res[KEYS.active_polls]) || {};
        if (activePolls[request_identifier]) {
            delete activePolls[request_identifier];
            await storage.set({ [KEYS.active_polls]: activePolls });
        }
    } catch (err) {
        console.error('[background-http] Failed to remove active poll:', err);
    }
}

// Server can return { status:"no_record", context:"poll_state_not_found", ... } when polling results
// before a state doc exists. If that happens, we stop polling and ask the content script to
// resubmit one fresh non-poll request with the full draft payload (once per window).
const POLL_NO_RECORD_REENQUEUE_WINDOW_MS = 60000;
const pollNoRecordAttemptsByKey = new Map(); // key -> { count, firstAtMs, lastAtMs }

// Slim down the rankings request payload to only the fields the polling loop and its
// legacy / re-enqueue fallbacks actually read. The original `request_data` includes the
// full draft (picks, current_roster), tournament payouts, and potentially custom rankings;
// retaining all of that for every in-flight poll across multiple drafts is the main
// contributor to client-side memory growth when the backend is slow.
function buildSlimPolledRequestData(requestData) {
    const rd = requestData || {};
    const draft = rd.draft || {};
    const tournament_info = rd.tournament_info || null;

    const slim_draft = {
        draft_id: draft.draft_id || rd.draft_id || null,
        site_name: draft.site_name || null
    };
    if (draft.id != null && draft.id !== slim_draft.draft_id) {
        slim_draft.id = draft.id;
    }

    let slim_tournament_info = null;
    if (tournament_info && typeof tournament_info === 'object') {
        slim_tournament_info = {
            id: tournament_info.id ?? null,
            payout_structure: tournament_info.payout_structure ?? null,
            entry_fee: tournament_info.entry_fee ?? null
        };
    }

    const format_type = rd.format_type || null;
    let advancement_structure = rd.advancement_structure || null;
    if (format_type_skips_stage_loss_evs(format_type)) {
        advancement_structure = strip_stage_loss_evs_from_advancement_structure(advancement_structure);
    }

    return {
        request_identifier: rd.request_identifier || null,
        draft_id: slim_draft.draft_id,
        algo_type: rd.algo_type || null,
        ranking_set: rd.ranking_set || null,
        format_type: format_type,
        user_uuid: rd.user_uuid || null,
        use_prod_url: Boolean(rd.use_prod_url),
        num_picks: rd.num_picks ?? draft.picks?.length ?? 0,
        advancement_structure: advancement_structure,
        tournament_info: slim_tournament_info,
        draft: slim_draft
    };
}

function buildLeanPollPayload(params) {
    const {
        extensionVersion,
        userUuid,
        requestIdentifier,
        algoType,
        draftId,
        siteName,
        rankingSet,
        formatType,
        customRankings,
        includeRankingSet,
        includeFormatType,
    } = params || {};

    const out = {
        poll: true,
        extension_version: extensionVersion || null,
        user_uuid: userUuid || null,
        request_identifier: requestIdentifier || null,
        algo_type: algoType || null,
        draft: { draft_id: draftId || null },
    };

    if (siteName != null) {
        out.draft.site_name = siteName;
    }

    if (includeRankingSet && rankingSet != null) {
        out.ranking_set = rankingSet;
    }
    if (includeFormatType && formatType != null) {
        out.format_type = formatType;
    }

    if (customRankings !== undefined) {
        out.custom_rankings = customRankings;
    }

    return out;
}

function pollNoRecordKey(draft_id, request_identifier) {
    const d = draft_id != null ? String(draft_id) : 'null';
    const r = request_identifier != null ? String(request_identifier) : 'null';
    return `${d}::${r}`;
}

// Drop entries whose last attempt is older than the re-enqueue window. The window guard is
// the only thing that gives entries meaning, so anything older is dead weight that would
// otherwise live forever (the request_identifier component changes per pick, so keys don't
// naturally repeat).
function pollNoRecordSweepExpired(nowMs) {
    for (const [key, raw] of pollNoRecordAttemptsByKey) {
        const lastAtMs = Number(raw?.lastAtMs) || 0;
        if (!lastAtMs || (nowMs - lastAtMs) > POLL_NO_RECORD_REENQUEUE_WINDOW_MS) {
            pollNoRecordAttemptsByKey.delete(key);
        }
    }
}

function pollNoRecordForgetForRequest(draft_id, request_identifier) {
    if (request_identifier == null) {
        return;
    }
    pollNoRecordAttemptsByKey.delete(pollNoRecordKey(draft_id, request_identifier));
    // We also delete the unknown-draft variant in case the entry was created before the
    // draft_id was resolved. Cheap and avoids stale keys.
    if (draft_id != null) {
        pollNoRecordAttemptsByKey.delete(pollNoRecordKey(null, request_identifier));
    }
}

function pollNoRecordReadAttemptState(key, nowMs) {
    const raw = pollNoRecordAttemptsByKey.get(key);
    if (!raw) {
        return { count: 0, firstAtMs: nowMs, lastAtMs: 0 };
    }
    if (raw.lastAtMs && (nowMs - raw.lastAtMs) > POLL_NO_RECORD_REENQUEUE_WINDOW_MS) {
        return { count: 0, firstAtMs: nowMs, lastAtMs: 0 };
    }
    return {
        count: Number(raw.count) || 0,
        firstAtMs: Number(raw.firstAtMs) || nowMs,
        lastAtMs: Number(raw.lastAtMs) || 0,
    };
}

function pollNoRecordAllowAndMark(draft_id, request_identifier, nowMs) {
    pollNoRecordSweepExpired(nowMs);
    const key = pollNoRecordKey(draft_id, request_identifier);
    const s = pollNoRecordReadAttemptState(key, nowMs);
    if ((s.count || 0) >= 1) {
        return { allowed: false, key, count: s.count || 0 };
    }
    const next = {
        count: (s.count || 0) + 1,
        firstAtMs: s.count ? s.firstAtMs : nowMs,
        lastAtMs: nowMs,
    };
    pollNoRecordAttemptsByKey.set(key, next);
    return { allowed: true, key, count: next.count };
}

function startInFlightPolling(request_identifier, port, incomingRequestData) {
    stopInFlightPolling(request_identifier);

    // Slim the retained payload up front so the polling state never holds onto the
    // full draft (picks/roster), playoff probabilities, or custom rankings. This is
    // the main contributor to client-side memory growth when the backend is slow and
    // multiple drafts are polling concurrently.
    const requestData = buildSlimPolledRequestData(incomingRequestData);

    // Get draft_id from requestData
    const draft_id = requestData.draft_id || requestData.draft?.draft_id;

    // Only one active poll loop per draft — cancel older polls for the same draft_id.
    // But never let a request for an OLDER draft state (a stale queued item surfacing
    // late) kill or replace the poll for a newer pick: that orphans the newer pick's
    // results and stalls the overlay until the content script's 20s timeout.
    if (draft_id) {
        const incomingNumPicks = typeof requestData.num_picks === 'number' ? requestData.num_picks : null;
        if (incomingNumPicks != null) {
            for (const [existing_rid, pollData] of inFlightPollTimers.entries()) {
                if (existing_rid === request_identifier) {
                    continue;
                }
                const pollDraftId = pollData.draft_id || pollData.requestData?.draft_id;
                const pollNumPicks = pollData.requestData?.num_picks;
                if (pollDraftId === draft_id && typeof pollNumPicks === 'number' && pollNumPicks > incomingNumPicks) {
                    if (BASE_BG.env !== 'prod') {
                        const log_data = {
                            stale_request: request_identifier,
                            stale_num_picks: incomingNumPicks,
                            newer_request: existing_rid,
                            newer_num_picks: pollNumPicks
                        };
                    }
                    return;
                }
            }
        }
        stopAllPollsForDraftId(draft_id, request_identifier);
    }
    
    // Store tabId when starting polling (port.sender might not be available in setInterval)
    const tabId = port.sender?.tab?.id;
    
    // Note: We allow polling to start even if port isn't in contentPorts yet (e.g., sendHello still in progress)
    // The polling function will check contentPorts.get(tabId) and stop if the port was removed
    // This handles the case where sendHello fails after polling starts
    
    // Persist active poll to storage for recovery
    persist_active_poll(request_identifier, requestData);
    
    // Extract polling logic into a reusable function
    const performPoll = async () => {
        // Check if this poll has already been stopped (prevents race conditions)
        if (!inFlightPollTimers.has(request_identifier)) {
            return;
        }
        
        // Get the current port for this tabId (handles port reconnections)
        // If tabId exists, use the current port from contentPorts; otherwise use the stored port
        // A missing port does NOT stop the poll: the port is routinely absent mid-reconnect
        // (contentPorts is only populated after BG_HELLO succeeds), and killing the poll here
        // stranded finished results in the DB with nothing left to fetch them — the overlay
        // then stalled until the content script's 20s watchdog. The poll's job is to land
        // results in the cache; notifications below are best-effort and null-port-safe, and
        // the max-poll cap bounds the lifetime of a poll whose tab really closed.
        const currentPort = (tabId ? contentPorts.get(tabId) : port) || null;

        // Check poll count and stop after 5 polls
        const pollData = inFlightPollTimers.get(request_identifier);
        if (pollData) {
            pollData.pollCount = (pollData.pollCount || 0) + 1;
            if (pollData.pollCount > IN_FLIGHT_POLL_MAX_COUNT) {
                stopInFlightPolling(request_identifier);
                // Don't give up silently: tell the content script so it clears its
                // loading state and re-requests on the next tick, instead of hanging
                // until its own 20s watchdog fires.
                if (currentPort && typeof notifyRankingsRequestFailed === 'function') {
                    notifyRankingsRequestFailed(currentPort, {
                        request_identifier,
                        draft_id: draft_id || null,
                        message: 'Rankings are taking longer than expected — retrying',
                        type: 'rankings_error',
                        reason: 'poll_gave_up',
                        broadcast: false
                    });
                }
                return;
            }
        }
        
        try {
            const session = await refresh_session_if_needed();
            if (!session_allows_sidekick_rankings(session)) {
                const env = (typeof BASE_BG !== 'undefined' && BASE_BG && BASE_BG.env) ? BASE_BG.env : 'prod';
                if (['dev', 'local'].includes(env)) {
                    const temp = {
                        request_identifier,
                        user_uuid: session?.user_uuid || null,
                        allow_rankings: session?.allow_rankings ?? null
                    };
                }
                stopInFlightPolling(request_identifier);
                if (typeof notifyRankingsRequestFailed === 'function') {
                    const gateReason = session?.reason || null;
                    const gateMessage = (typeof auth_reason_user_message === 'function'
                        ? auth_reason_user_message(gateReason)
                        : '')
                        || gateReason
                        || 'Sidekick access required for rankings. Refresh your session at legendaryupside.com.';
                    notifyRankingsRequestFailed(currentPort, {
                        request_identifier,
                        draft_id: draft_id || null,
                        message: gateMessage,
                        type: 'auth_error',
                        reason: 'sidekick_gate'
                    });
                } else if (typeof notify_auth_status === 'function') {
                    notify_auth_status(session || null);
                }
                return;
            }

            const useProdUrl = Boolean(requestData.use_prod_url);
            const extensionVersion = get_extension_version();
            const userUuid = requestData.user_uuid || session?.user_uuid || null;
            const draftId = requestData.draft?.draft_id || requestData.draft_id || requestData.draft?.id || null;
            const siteName = requestData.draft?.site_name || null;

            // Lean poll body: server short-circuits sim polls and does not enrich; avoid sending draft payloads.
            // Server currently requires ranking_set / format_type / site_name for poll validation.
            let customRankings = undefined;
            if (requestData.ranking_set === 'custom') {
                await ensure_config_ready();
                customRankings = custom_rankings_for_rankings_request(requestData);
            }

            const lean_poll_payload = buildLeanPollPayload({
                extensionVersion,
                userUuid,
                requestIdentifier: request_identifier,
                algoType: requestData.algo_type,
                draftId,
                siteName,
                rankingSet: requestData.ranking_set,
                formatType: requestData.format_type,
                customRankings,
                includeRankingSet: true,
                includeFormatType: true,
            });


            const response = await make_http_request_with_auth_retry('/rankings', {
                method: 'POST',
                body: lean_poll_payload,
                useProdUrl: useProdUrl,
                timeoutMs: RANKINGS_POLL_HTTP_TIMEOUT_MS
            });
            

            const needsClientResubmit =
                response
                && (response.status === 'reenqueue' || response.status === 'no_record')
                && response.context === 'poll_no_results';
            const shouldReenqueue =
                response
                && response.status === 'no_record'
                && response.context === 'poll_state_not_found';

            if (needsClientResubmit) {
                // State exists but job is orphaned — slim poll payload can't safely re-publish.
                // Stop polling and ask the content script to send one fresh non-poll request.
                if (BASE_BG.env !== 'prod') {
                    const log_data = {
                        draft_id: draft_id || null,
                        request_identifier,
                        server_status: response.status,
                    };
                }
                stopInFlightPolling(request_identifier);
                if (typeof notifyRankingsRequestFailed === 'function') {
                    notifyRankingsRequestFailed(currentPort, {
                        request_identifier,
                        draft_id: draft_id || null,
                        message: 'Rankings job stalled — retrying',
                        type: 'rankings_error',
                        reason: 'poll_no_results_resubmit'
                    });
                }
                return;
            }

            if (shouldReenqueue) {
                const pollDataForEvent = inFlightPollTimers.get(request_identifier);
                const elapsed_ms = pollDataForEvent?.startedAtMs ? (Date.now() - pollDataForEvent.startedAtMs) : null;
                const event_data = {
                    draft_id: draft_id || null,
                    request_identifier: request_identifier,
                    elapsed_ms: elapsed_ms,
                    pollCount: pollDataForEvent?.pollCount || 0,
                    server_status: response.status || null,
                    server_context: response.context || null,
                    server_message: response.message || null
                };

                // Stop polling but keep the no_record attempt state — the guard below
                // depends on it surviving this stop to prevent infinite resubmit loops.
                stopInFlightPolling(request_identifier, { keep_no_record_state: true });

                // Guard against infinite loops: allow this fallback only once per (draft_id, request_identifier) per window.
                const nowMs = Date.now();
                const guard = pollNoRecordAllowAndMark(draft_id || null, request_identifier, nowMs);
                if (!guard.allowed) {
                    const err_msg = 'Request could not be enqueued; please try again';
                    console.error('[background-http] no_record resubmit guard triggered; stopping', { key: guard.key, count: guard.count, draft_id: draft_id || null, request_identifier: request_identifier });
                    if (typeof broadcast_notification === 'function') {
                        broadcast_notification(err_msg, 'auth_error_update');
                    }
                    return;
                }

                // The retained poll payload is slim (draft_id + site_name only — no picks,
                // no roster), so re-publishing it here would enqueue a job computed from an
                // empty draft and cache wrong rankings under the current pick's identifier.
                // Ask the content script for one fresh non-poll request with the full draft
                // payload instead (same recovery as poll_no_results).
                if (typeof notifyRankingsRequestFailed === 'function') {
                    notifyRankingsRequestFailed(currentPort, {
                        request_identifier,
                        draft_id: draft_id || null,
                        message: 'Rankings job stalled — retrying',
                        type: 'rankings_error',
                        reason: 'poll_no_results_resubmit'
                    });
                }
                return;
            }
            
            if (response && response.status === 'in_flight') {
                return;
            }
            
            const finalPollData = inFlightPollTimers.get(request_identifier);
            const pollCount = finalPollData ? (finalPollData.pollCount || 0) : 0;
            stopInFlightPolling(request_identifier);
            
            let picks = extract_picks_from_response(response, requestData.algo_type);
            
            if (picks && Array.isArray(picks) && picks.length > 0) {
                // Remove from persisted storage since poll completed successfully
                remove_active_poll(request_identifier);
                const num_picks = requestData.num_picks ?? requestData.draft?.picks?.length ?? 0;
                const draft_id_for_cache = requestData.draft?.draft_id || draft_id || null;
                const cache_entry = {
                    picks: picks,
                    advancement_structure: response.advancement_structure || {},
                    request_identifier: request_identifier,
                    algo_type: requestData.algo_type,
                    timestamp: Date.now(),
                    num_picks: num_picks,
                    draft_id: draft_id_for_cache
                };

                // If this is a sim-like response with the new structure, store the full structure
                if (is_sim_like_algo(requestData.algo_type) &&
                    (response.classic_picks || response.sim_picks || response.blended_picks)) {
                    cache_entry.classic_picks = response.classic_picks;
                    cache_entry.sim_picks = response.sim_picks;
                    cache_entry.blended_picks = response.blended_picks;
                }

                // Serialized store (read-modify-write under the cache mutex) so a
                // concurrent slow request writing its own snapshot can't erase this row.
                await store_rankings_cache_entry(draft_id_for_cache, request_identifier, cache_entry);

                // Push a pull-trigger to the owning tab; without it the content script
                // only discovers the row on its next extraction tick.
                notifyRankingsResultsReady(currentPort, tabId, {
                    request_identifier,
                    draft_id: draft_id_for_cache,
                    num_picks: num_picks
                });
            }
        } catch (error) {
            const extensionUpdateMessage = typeof getExtensionUpdateMessage === 'function'
                ? getExtensionUpdateMessage(error)
                : null;
            if (extensionUpdateMessage && typeof broadcast_notification === 'function') {
                const notificationMessage = `Your extension is out of date. Click the refresh button to update it. ${extensionUpdateMessage}`;
                broadcast_notification(notificationMessage, 'auth_error_update');
            }
            console.error('[background-http] Error polling for in-flight results:', error);
            stopInFlightPolling(request_identifier);
            // Auth path already invalidates / notifies on hard failure; still clear CS loading.
            if (!extensionUpdateMessage && typeof notifyRankingsRequestFailed === 'function') {
                const detail = (typeof auth_error_detail === 'function' ? auth_error_detail(error) : '') || '';
                const isAuth = error?.status === 401 || /token_expired|session expired|auth:/i.test(detail);
                const authReason = (typeof auth_reason_app_jwt_expired === 'function'
                    ? auth_reason_app_jwt_expired()
                    : 'auth:app_jwt_expired');
                const authMessage = (typeof auth_reason_user_message === 'function'
                    ? auth_reason_user_message(authReason)
                    : null)
                    || (typeof ghost_jwt_expired_reason === 'function'
                        ? ghost_jwt_expired_reason()
                        : authReason);
                notifyRankingsRequestFailed(currentPort, {
                    request_identifier,
                    draft_id: draft_id || null,
                    message: isAuth
                        ? authMessage
                        : 'Rankings poll failed. Retrying on the next pick refresh.',
                    type: isAuth ? 'auth_error' : 'rankings_error',
                    reason: isAuth ? 'auth' : 'poll_error'
                });
            }
        }
    };
    
    // Wait initial delay before first poll, then poll at regular intervals
    const firstPollTimeoutId = setTimeout(() => {
        performPoll();
        // After first poll, set up interval for subsequent polls
        const intervalId = setInterval(performPoll, IN_FLIGHT_POLL_INTERVAL_MS);
        // Update the stored timer data to include the interval
        const pollData = inFlightPollTimers.get(request_identifier);
        if (pollData) {
            pollData.intervalId = intervalId;
        }
    }, IN_FLIGHT_POLL_INITIAL_DELAY_MS);
    
    inFlightPollTimers.set(request_identifier, { 
        timerId: firstPollTimeoutId, 
        intervalId: null, // Will be set after first poll
        port, 
        requestData, 
        tabId,
        draft_id: draft_id, // Store draft_id for easier lookup
        startedAtMs: Date.now(),
        pollCount: 0 // Track number of polls performed
    });
    // console.log('[background-http] Started polling timer for:', request_identifier, 'tabId:', tabId, 'draft_id:', draft_id);
}


function stopInFlightPolling(request_identifier, options = {}) {
    // The no_record handler stops polling and then consults/updates the no_record
    // attempt state to decide whether a resubmit is allowed. Forgetting that state
    // here would reset the once-per-window guard on every stop, allowing an
    // infinite resubmit loop against pathological server state.
    const keep_no_record_state = options.keep_no_record_state === true;
    const pollData = inFlightPollTimers.get(request_identifier);
    if (pollData) {
        // Clear the initial timeout (first poll)
        clearTimeout(pollData.timerId);
        // Clear the interval (subsequent polls) if it exists
        if (pollData.intervalId) {
            clearInterval(pollData.intervalId);
        }
        inFlightPollTimers.delete(request_identifier);
        // Remove from persisted storage
        remove_active_poll(request_identifier);
        // Drop any no_record bookkeeping for this request so the map can't accumulate
        // dead entries (request_identifier changes per pick so keys never repeat naturally).
        if (!keep_no_record_state) {
            pollNoRecordForgetForRequest(pollData.draft_id || null, request_identifier);
        }
        // console.log('[background-http] Stopped polling timer for:', request_identifier);
    } else if (!keep_no_record_state) {
        // Even when there's no timer entry (e.g. polling already stopped earlier), still clear
        // any stale no_record bookkeeping for this request_identifier.
        pollNoRecordForgetForRequest(null, request_identifier);
    }
}


async function cleanup_old_draft_states() {
    const draft_states = await get_draft_states();
    const now = Date.now();
    const cleanup_threshold = 7 * 24 * 60 * 60 * 1000; // 7 days
    
    let has_changes = false;
    
    for (const [request_identifier, state] of Object.entries(draft_states)) {
        const last_update = state.last_update || 0;
        if (now - last_update > cleanup_threshold) {
            delete draft_states[request_identifier];
            has_changes = true;
        }
    }
    
    if (has_changes) {
        await set_draft_states(draft_states);
    }
}

function is_app_jwt_valid(session) {
    const token = session?.app_jwt;
    const expiresAt = session?.app_jwt_expires_at;
    if (!token) return false;
    if (!expiresAt) return true;
    const expMs = Date.parse(expiresAt);
    if (Number.isNaN(expMs)) return true;
    return expMs - Date.now() > 60 * 1000;
}

function deepMergeOverlay(currentOverlay, patchOverlay) {
  const out = {};
  
  for (const key of Object.keys(currentOverlay || {})) {
    if (key !== 'underdog' && key !== 'draftkings') {
      const value = currentOverlay[key];
      // If it's a malformed site-like object, don't copy it (will be replaced by patch)
      if (!(value && typeof value === 'object' && value.overlayState !== undefined && value.ui !== undefined && value.draftSelections !== undefined)) {
        out[key] = value;
      }
    }
  }
  
  for (const key of Object.keys(patchOverlay || {})) {
    if (key === 'underdog' || key === 'draftkings') {
      const curSite = currentOverlay?.[key] || {};
      const pSite = patchOverlay[key] || {};
      if (pSite && typeof pSite === 'object' && (pSite.overlayState || pSite.ui || pSite.draftSelections || pSite.streamerOverlayState)) {
        out[key] = {
          overlayState: { ...(curSite.overlayState || {}), ...(pSite.overlayState || {}) },
          ui: { ...(curSite.ui || {}), ...(pSite.ui || {}) },
          draftSelections: { ...(curSite.draftSelections || {}), ...(pSite.draftSelections || {}) },
          streamerOverlayState: { ...(curSite.streamerOverlayState || {}), ...(pSite.streamerOverlayState || {}) }
        };
      }
    } else {
      out[key] = patchOverlay[key];
    }
  }
  
  for (const siteKey of ['underdog', 'draftkings']) {
    if (!(siteKey in patchOverlay) && siteKey in currentOverlay) {
      out[siteKey] = currentOverlay[siteKey];
    }
  }
  
  return out;
}

function normalize_content_script_defaults(source = {}) {
    const fallback = cloneDeep(CONFIG_FALLBACK.content_script_settings || {});
    const merged = { ...fallback, ...source };
    merged.overlay = deepMergeOverlay(cloneDeep(fallback.overlay || {}), source.overlay || {});
    
        // Special handling for whitelist-like keys: when remote config provides a value, preserve it as-is.
        // (We still fall back to CONFIG_FALLBACK when remote config omits the key.)
        if (source.static_settings && typeof source.static_settings === 'object') {
            const whitelistKeys = [
                'underdog_slate_whitelist',
                'underdog_slate_friendly_labels',
                'draftkings_slate_whitelist',
                'draftkings_slate_friendly_labels',
                'draftkings_tournament_whitelist',
                'season_stage',
                'ud_intercept_extraction_enabled'
            ];
            if (!merged.static_settings) {
                merged.static_settings = { ...fallback.static_settings };
            }
            
            for (const key of whitelistKeys) {
                if (source.static_settings[key] !== undefined) {
                    // Use remote config value directly (no coercion / no union merge).
                    merged.static_settings[key] = cloneDeep(source.static_settings[key]);
                }
            }
        
            // For other static_settings from remote config, merge normally
            for (const [key, value] of Object.entries(source.static_settings)) {
                if (!whitelistKeys.includes(key)) {
                    merged.static_settings[key] = value;
                }
            }
        }
    
    return merged;
}

function normalize_config(raw) {
    const safe = raw && typeof raw === 'object' ? raw : {};
    const fallbackBgDatasets = cloneDeep(CONFIG_FALLBACK.background_datasets || {});
    const incomingBgDatasets = safe.background_datasets && typeof safe.background_datasets === 'object' ? safe.background_datasets : {};
    const background_datasets = { ...fallbackBgDatasets };
    for (const [key, value] of Object.entries(incomingBgDatasets)) {
        background_datasets[key] = cloneDeep(value);
    }

    const fallbackCsDatasets = cloneDeep(CONFIG_FALLBACK.content_script_datasets || {});
    const incomingCsDatasets = safe.content_script_datasets && typeof safe.content_script_datasets === 'object' ? safe.content_script_datasets : {};
    const content_script_datasets = { ...fallbackCsDatasets };
    for (const [key, value] of Object.entries(incomingCsDatasets)) {
        content_script_datasets[key] = cloneDeep(value);
    }

    const fallbackUserRankingsDatasets = cloneDeep(CONFIG_FALLBACK.user_rankings_datasets || {});
    const incomingUserRankingsDatasets = safe.user_rankings_datasets && typeof safe.user_rankings_datasets === 'object' ? safe.user_rankings_datasets : {};
    const user_rankings_datasets = { ...fallbackUserRankingsDatasets };
    for (const [key, value] of Object.entries(incomingUserRankingsDatasets)) {
        user_rankings_datasets[key] = cloneDeep(value);
    }
    
    return {
        schema_version: safe.schema_version ?? CONFIG_FALLBACK.schema_version ?? null,
        content_script_settings: normalize_content_script_defaults(safe.content_script_settings || {}),
        background_settings: { ...CONFIG_FALLBACK.background_settings, ...(safe.background_settings || {}) },
        background_datasets,
        content_script_datasets,
        user_rankings_datasets,
    };
}

function get_config_defaults() {
    return configState.data || CONFIG_FALLBACK;
}

function get_default_content_script_settings() {
    const defaults = get_config_defaults().content_script_settings || CONFIG_FALLBACK.content_script_settings;
    return cloneDeep(defaults);
}

function get_default_background_settings() {
    const defaults = get_config_defaults().background_settings || CONFIG_FALLBACK.background_settings;
    return cloneDeep(defaults);
}

function get_datasets() {
    const defaults = get_config_defaults().background_datasets || CONFIG_FALLBACK.background_datasets || {};
    return cloneDeep(defaults);
}

function get_dataset(key) {
    const datasets = get_datasets();
    if (typeof key === 'undefined') return datasets;
    return cloneDeep(datasets[key]);
}

// Debug: every raw legacy key collision reports no rule (test urgent bubble); synced from user_settings.
var g_ud_debug_ignore_legacy_collision_rules = false;

function syncUdDebugLegacyCollisionRulesFromUserSettings(us) {
    g_ud_debug_ignore_legacy_collision_rules = !!(us && us.ud_debug_ignore_legacy_collision_rules);
}

function udLegacyLookupStorageKey(leg, player_id) {
    const cfg = typeof __LEGUP_UD_LEGACY_KEY_COLLISION__ !== 'undefined' ? __LEGUP_UD_LEGACY_KEY_COLLISION__ : null;
    if (!cfg || !cfg.enabled || !Array.isArray(cfg.rules)) {
        return leg;
    }
    for (let ri = 0; ri < cfg.rules.length; ri++) {
        const rule = cfg.rules[ri];
        if (!rule || rule.legacyKey !== leg || !Array.isArray(rule.orderedPlayerIds)) {
            continue;
        }
        const idx = rule.orderedPlayerIds.indexOf(player_id);
        if (idx >= 0) {
            return leg + '-' + (idx + 1);
        }
    }
    return leg;
}

function collectUdRawLegacyKeyCollisions(original_players) {
    const by_key = {};
    for (const [appearance_id, player_data] of Object.entries(original_players)) {
        if (!player_data || !player_data.id) {
            continue;
        }
        const raw = player_data.key;
        if (typeof raw !== 'string') {
            continue;
        }
        const leg = raw.trim();
        if (!leg) {
            continue;
        }
        if (!by_key[leg]) {
            by_key[leg] = [];
        }
        const full_name = typeof player_data.full_name === 'string' ? player_data.full_name : null;
        by_key[leg].push({ appearanceId: appearance_id, playerId: player_data.id, fullName: full_name });
    }
    const cfg = typeof __LEGUP_UD_LEGACY_KEY_COLLISION__ !== 'undefined' ? __LEGUP_UD_LEGACY_KEY_COLLISION__ : null;
    const rules = cfg && cfg.enabled && Array.isArray(cfg.rules) ? cfg.rules : [];
    const out = [];
    for (const leg of Object.keys(by_key)) {
        const rows = by_key[leg];
        const id_set = {};
        for (let i = 0; i < rows.length; i++) {
            id_set[rows[i].playerId] = true;
        }
        const distinct = Object.keys(id_set);
        if (distinct.length < 2) {
            continue;
        }
        let has_collision_rule = false;
        if (!g_ud_debug_ignore_legacy_collision_rules) {
            for (let ri = 0; ri < rules.length; ri++) {
                const rule = rules[ri];
                if (rule && rule.legacyKey === leg) {
                    has_collision_rule = true;
                    break;
                }
            }
        }
        out.push({ legacyKey: leg, distinctPlayerCount: distinct.length, configuredCollisionRule: has_collision_rule, players: rows });
    }
    out.sort((a, b) => (a.legacyKey < b.legacyKey ? -1 : a.legacyKey > b.legacyKey ? 1 : 0));
    return out;
}

/**
 * True when remote config reserves per-slate appearance maps (`ud_*_appearance_id_map`).
 * Treat non-empty Firestore path strings as reserved so we do not derive appearance_id → id from player_map_ud.
 */
function contentScriptHasExplicitUdAppearanceMaps(datasets) {
    if (!datasets || typeof datasets !== 'object') {
        return false;
    }
    const keys = Object.keys(datasets);
    for (let i = 0; i < keys.length; i++) {
        const k = keys[i];
        if (!k.endsWith('_appearance_id_map')) {
            continue;
        }
        const v = datasets[k];
        if (v == null) {
            continue;
        }
        if (typeof v === 'string' && v.trim()) {
            return true;
        }
        if (v && typeof v === 'object' && !Array.isArray(v)) {
            if (v.map && typeof v.map === 'object' && Object.keys(v.map).length > 0) {
                return true;
            }
        }
    }
    return false;
}

function get_content_script_datasets() {
    const defaults = get_config_defaults().content_script_datasets || CONFIG_FALLBACK.content_script_datasets || {};
    const datasets = cloneDeep(defaults);

    const keys = Object.keys(datasets);
    for (let ki = 0; ki < keys.length; ki++) {
        const dk = keys[ki];
        if (!dk.endsWith('_appearance_id_map')) {
            continue;
        }
        const raw = datasets[dk];
        if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
            continue;
        }
        if (raw.map && typeof raw.map === 'object') {
            datasets[dk] = {
                map: cloneDeep(raw.map),
                updated: raw.updated != null ? raw.updated : null
            };
        }
    }

    const skipDerivedAppearanceIdPlayers = contentScriptHasExplicitUdAppearanceMaps(datasets);

    // Trim player_map_ud: appearance_id -> ud id (unless explicit ud_*_appearance_id_map datasets supply maps),
    // plus `player_data.key` -> id for ribbon DOM fallback.
    // Remote config provides `key` as the precomputed ribbon string (e.g. "D. Robinson_WR - SF"); we do not synthesize it.
    // Duplicate config keys: content_script_underdog_legacy_key_collision_config.js (__LEGUP_UD_LEGACY_KEY_COLLISION__).
    if (datasets.player_map_ud && datasets.player_map_ud.players) {
        const trimmed_players = {};
        const players_by_legacy_lookup = {};
        const players_by_dk_id = {};
        const player_info_by_id = {};
        const udLegacyLookupAppearanceByStorageKey = {};
        const legacy_lookup_unhandled_collisions = [];
        const original_players = datasets.player_map_ud.players;
        const legacy_lookup_raw_collisions = collectUdRawLegacyKeyCollisions(original_players);
        for (const [appearance_id, player_data] of Object.entries(original_players)) {
            if (player_data && player_data.id) {
                if (!skipDerivedAppearanceIdPlayers) {
                    trimmed_players[appearance_id] = player_data.id;
                }
                // Keep display fields for exposure/settings (keyed by canonical player id).
                const pid = String(player_data.id).trim();
                if (pid) {
                    const full_name = player_data.full_name || player_data.fullName || player_data.name || player_data.player_name || null;
                    const position = player_data.position || player_data.pos || null;
                    const team = player_data.team || player_data.team_abbr || player_data.teamAbbr || player_data.team_abbreviation || null;
                    const info = {};
                    if (full_name != null && String(full_name).trim()) info.full_name = String(full_name).trim();
                    if (position != null && String(position).trim()) info.position = String(position).trim();
                    if (team != null && String(team).trim()) info.team = String(team).trim();
                    if (Object.keys(info).length > 0) {
                        player_info_by_id[pid] = info;
                    }
                    const rawDk = player_data.dk_id != null ? player_data.dk_id : player_data.dkId;
                    if (rawDk != null && rawDk !== '') {
                        const dkKey = String(rawDk).trim();
                        if (dkKey) {
                            const existingId = players_by_dk_id[dkKey];
                            if (existingId != null && String(existingId).trim() !== pid) {
                            }
                            players_by_dk_id[dkKey] = player_data.id;
                        }
                    }
                }
                const raw = player_data.key;
                if (typeof raw === 'string') {
                    const leg = raw.trim();
                    if (leg) {
                        const storage_key = udLegacyLookupStorageKey(leg, player_data.id);
                        if (storage_key !== leg) {
                            const udLegacyMapCollisionWarn = { legacyKey: leg, storageKey: storage_key, resolvedPlayerId: player_data.id };
                        }
                        const existing_legacy_id = players_by_legacy_lookup[storage_key];
                        if (existing_legacy_id && existing_legacy_id !== player_data.id) {
                            legacy_lookup_unhandled_collisions.push({
                                storageKey: storage_key,
                                legacyKey: leg,
                                previousPlayerId: existing_legacy_id,
                                previousAppearanceId: udLegacyLookupAppearanceByStorageKey[storage_key] || null,
                                incomingPlayerId: player_data.id,
                                incomingAppearanceId: appearance_id
                            });
                        }
                        players_by_legacy_lookup[storage_key] = player_data.id;
                        udLegacyLookupAppearanceByStorageKey[storage_key] = appearance_id;
                    }
                }
            }
        }
        const player_map_ud_out = {
            players: trimmed_players,
            players_by_legacy_lookup,
            players_by_dk_id,
            player_info_by_id,
            updated: datasets.player_map_ud.updated
        };
        if (legacy_lookup_raw_collisions.length > 0) {
            player_map_ud_out.legacy_lookup_raw_collisions = legacy_lookup_raw_collisions;
            const udLegacyBgRawSummary = { count: legacy_lookup_raw_collisions.length, collisions: legacy_lookup_raw_collisions };
            const legacy_lookup_fatal_if_ribbon_keys = [];
            for (let fi = 0; fi < legacy_lookup_raw_collisions.length; fi++) {
                const c = legacy_lookup_raw_collisions[fi];
                if (!c || !c.legacyKey) {
                    continue;
                }
                if (g_ud_debug_ignore_legacy_collision_rules || c.configuredCollisionRule === false) {
                    legacy_lookup_fatal_if_ribbon_keys.push(c.legacyKey);
                }
            }
            if (legacy_lookup_fatal_if_ribbon_keys.length > 0) {
                player_map_ud_out.legacy_lookup_fatal_if_ribbon_keys = legacy_lookup_fatal_if_ribbon_keys;
            }
        }
        if (legacy_lookup_unhandled_collisions.length > 0) {
            player_map_ud_out.legacy_lookup_unhandled_collisions = legacy_lookup_unhandled_collisions;
            const udLegacyBgUnhandledSummary = { count: legacy_lookup_unhandled_collisions.length, collisions: legacy_lookup_unhandled_collisions };
        }
        datasets.player_map_ud = player_map_ud_out;
    }

    // DK id → canonical (Underdog) id for exposure / cross-site joins (remote `background_datasets.id_map`).
    const bgDs = get_datasets();
    const idMapSrc = bgDs && bgDs.id_map && typeof bgDs.id_map === 'object' ? bgDs.id_map : null;
    if (idMapSrc && idMapSrc.map && typeof idMapSrc.map === 'object' && Object.keys(idMapSrc.map).length > 0) {
        datasets.id_map = {
            updated: idMapSrc.updated != null ? idMapSrc.updated : null,
            map: cloneDeep(idMapSrc.map)
        };
    } else {
        datasets.id_map = null;
    }

    const exposureIdMapSrc =
        bgDs && bgDs.exposure_id_map && typeof bgDs.exposure_id_map === 'object' ? bgDs.exposure_id_map : null;
    if (
        exposureIdMapSrc &&
        exposureIdMapSrc.map &&
        typeof exposureIdMapSrc.map === 'object' &&
        Object.keys(exposureIdMapSrc.map).length > 0
    ) {
        datasets.exposure_id_map = {
            updated: exposureIdMapSrc.updated != null ? exposureIdMapSrc.updated : null,
            map: cloneDeep(exposureIdMapSrc.map)
        };
    } else {
        datasets.exposure_id_map = null;
    }

    if (typeof mergePlayerExposureIntoContentScriptDatasets === 'function') {
        mergePlayerExposureIntoContentScriptDatasets(datasets);
    }
    
    return datasets;
}

function get_content_script_dataset(key) {
    const datasets = get_content_script_datasets();
    if (typeof key === 'undefined') return datasets;
    return cloneDeep(datasets[key]);
}

/**
 * Lean maps + player info for the homepage SPA (CSV / PE client processing).
 * Prefer CS datasets; fall back to background blobs for merged BBM.
 */
function build_home_exposure_datasets() {
    const cs = get_content_script_datasets() || {};
    const appearanceMap = {};
    const appearanceKeys = Object.keys(cs).filter(
        (k) => typeof k === 'string' && k.endsWith('_appearance_id_map')
    );
    for (let i = 0; i < appearanceKeys.length; i++) {
        const blob = cs[appearanceKeys[i]];
        const map = blob && blob.map && typeof blob.map === 'object' ? blob.map : null;
        if (!map) continue;
        for (const [appearanceId, playerId] of Object.entries(map)) {
            if (appearanceId && playerId != null && appearanceMap[appearanceId] == null) {
                appearanceMap[String(appearanceId)] = String(playerId);
            }
        }
    }

    const exposureIdMap =
        cs.exposure_id_map && cs.exposure_id_map.map && typeof cs.exposure_id_map.map === 'object'
            ? cs.exposure_id_map.map
            : {};
    const idMap =
        cs.id_map && cs.id_map.map && typeof cs.id_map.map === 'object' ? cs.id_map.map : {};

    // Per-format live ADP fields. The homepage picks one of these per lineup
    // using its historical_adp_key, mirroring
    // unified_exposure._HISTORICAL_KEY_TO_LIVE_ADP_FIELD on the backend. Without
    // them the page can only ever compute BBM ADP, which is wrong for
    // eliminator / superflex / sprint / marathon / weekly-winner / ppr drafts.
    const FORMAT_ADP_FIELDS = [
        'ud_bbm_adp',
        'ud_eli_adp',
        'ud_sf_adp',
        'ud_spr_adp',
        'ud_mar_adp',
        'ud_ww_adp',
        'ud_ppr_adp',
        'ud_tep_adp',
    ];

    function copyFormatAdps(target, src) {
        for (let i = 0; i < FORMAT_ADP_FIELDS.length; i++) {
            const field = FORMAT_ADP_FIELDS[i];
            if (target[field] == null && src && src[field] != null) {
                target[field] = src[field];
            }
        }
    }

    const playerInfoById = {};
    const infoSrc =
        cs.player_map_ud && cs.player_map_ud.player_info_by_id && typeof cs.player_map_ud.player_info_by_id === 'object'
            ? cs.player_map_ud.player_info_by_id
            : null;
    if (infoSrc) {
        for (const [pid, info] of Object.entries(infoSrc)) {
            if (!pid || !info || typeof info !== 'object') continue;
            const row = {
                full_name: info.full_name || info.fullName || null,
                team: info.team || null,
                position: info.position || info.pos || null,
                ud_bbm_adp: info.ud_bbm_adp != null ? info.ud_bbm_adp : info.adp != null ? info.adp : null,
                // Generic fallback, matching the backend's behaviour when a UD
                // row exposes only `adp`.
                adp: info.adp != null ? info.adp : null,
            };
            copyFormatAdps(row, info);
            playerInfoById[String(pid)] = row;
        }
    }

    // Supplement from merged BBM when player_map_ud is thin.
    function absorbMerged(doc, site) {
        if (!doc || typeof doc !== 'object') return;
        const raw = doc.players;
        const list = Array.isArray(raw)
            ? raw
            : raw && typeof raw === 'object'
              ? Object.values(raw)
              : [];
        for (let i = 0; i < list.length; i++) {
            const p = list[i];
            if (!p || typeof p !== 'object') continue;
            const id = p.id != null ? String(p.id) : null;
            if (!id) continue;
            if (!playerInfoById[id]) {
                playerInfoById[id] = {
                    full_name: p.full_name || p.fullName || null,
                    team: p.team || null,
                    position: p.position || p.pos || null,
                    ud_bbm_adp: null,
                    adp: null,
                };
            }
            const row = playerInfoById[id];
            if (!row.full_name && (p.full_name || p.fullName)) {
                row.full_name = p.full_name || p.fullName;
            }
            if (!row.team && p.team) row.team = p.team;
            if (!row.position && (p.position || p.pos)) row.position = p.position || p.pos;
            if (site === 'ud' && row.ud_bbm_adp == null && p.ud_bbm_adp != null) {
                row.ud_bbm_adp = p.ud_bbm_adp;
            }
            if (site === 'dk' && row.adp == null && p.adp != null) {
                row.adp = p.adp;
            }
            // merged_ud_bbm carries every UD format's ADP on each player row.
            if (site === 'ud') copyFormatAdps(row, p);
        }
    }
    absorbMerged(get_dataset('merged_ud_bbm'), 'ud');
    absorbMerged(get_dataset('merged_dk_bbm'), 'dk');

    return {
        exposure_id_map: exposureIdMap,
        id_map: idMap,
        appearance_map: appearanceMap,
        player_info_by_id: playerInfoById,
    };
}

function get_user_rankings_datasets() {
    const defaults = get_config_defaults().user_rankings_datasets || CONFIG_FALLBACK.user_rankings_datasets || {};
    return cloneDeep(defaults);
}

function get_user_rankings_dataset(key) {
    const datasets = get_user_rankings_datasets();
    if (typeof key === 'undefined') return datasets;
    return cloneDeep(datasets[key]);
}

function user_rankings_dataset_key_for_draft_site_name(site_name) {
    if (!site_name || typeof site_name !== 'string') {
        return null;
    }
    const s = site_name.trim().toLowerCase();
    if (s.includes('underdog')) {
        return 'ud_bbm';
    }
    if (s.includes('draftking')) {
        return 'dk_bbm';
    }
    return null;
}

/** When ranking_set is custom, returns the rankings array for the draft site; [] if unknown site or missing data. Otherwise undefined (omit from payload). */
function custom_rankings_for_rankings_request(request_data) {
    if (!request_data || request_data.ranking_set !== 'custom') {
        return undefined;
    }
    const set_key = user_rankings_dataset_key_for_draft_site_name(
        request_data.draft && request_data.draft.site_name
    );
    if (!set_key) {
        return [];
    }
    const ds = get_user_rankings_dataset(set_key);
    const rankings = ds && ds.rankings;
    if (!Array.isArray(rankings)) {
        return [];
    }
    return cloneDeep(rankings);
}

function hydrate_content_script_settings(persisted = {}) {
    const defaults = get_default_content_script_settings();
    const result = { ...defaults };
    const overlayDefault = cloneDeep(defaults.overlay || {});
    
    // For overlay settings, we need special handling:
    // Remote config defaults should override persisted values that match fallback defaults
    // But user changes should still override remote config
    const fallbackOverlay = cloneDeep(CONFIG_FALLBACK.content_script_settings?.overlay || {});
    const persistedOverlay = persisted.overlay || {};
    
    // Start with remote config defaults
    let mergedOverlay = cloneDeep(overlayDefault);
    
    // For each site (underdog, draftkings), merge persisted settings but allow remote config to override
    // if persisted value matches fallback default
    for (const siteKey of ['underdog', 'draftkings']) {
        const persistedSite = persistedOverlay[siteKey] || {};
        const fallbackSite = fallbackOverlay[siteKey] || {};
        const remoteSite = overlayDefault[siteKey] || {};
        
        // Ensure the site structure exists in mergedOverlay
        if (!mergedOverlay[siteKey]) {
            mergedOverlay[siteKey] = { overlayState: {}, ui: {}, draftSelections: {} };
        }
        if (!mergedOverlay[siteKey].ui) {
            mergedOverlay[siteKey].ui = {};
        }
        // mergedOverlay[siteKey].ui already contains remote config values from cloneDeep(overlayDefault)
        
        // For UI settings like selected_algo_type:
        // - If remote config has a value, use it (overrides fallback)
        // - UNLESS persisted value exists and differs from both fallback and remote config (user change)
        const persistedUI = persistedSite.ui || {};
        const fallbackUI = fallbackSite.ui || {};
        const remoteUI = remoteSite.ui || {};
        
        // Process UI settings with correct priority:
        // 1. User selections (persisted) ALWAYS override everything
        // 2. Remote config overrides fallback defaults
        // 3. Fallback is last resort
        
        // First, collect all UI keys from all sources
        const allUIKeys = new Set([
            ...Object.keys(persistedUI),
            ...Object.keys(remoteUI),
            ...Object.keys(fallbackUI)
        ]);
        
        for (const uiKey of allUIKeys) {
            const persistedValue = persistedUI[uiKey];
            const remoteValue = remoteUI[uiKey];
            const fallbackValue = fallbackUI[uiKey];
            
            // Priority: User selection > Remote config > Fallback
            if (persistedValue !== undefined) {
                // User explicitly set this value - always use it
                mergedOverlay[siteKey].ui[uiKey] = persistedValue;
            } else if (remoteValue !== undefined) {
                // Use remote config (overrides fallback)
                mergedOverlay[siteKey].ui[uiKey] = remoteValue;
            } else if (fallbackValue !== undefined) {
                // Use fallback as last resort
                mergedOverlay[siteKey].ui[uiKey] = fallbackValue;
            }
        }
        
        // For overlayState and draftSelections, use standard merge (persisted overrides remote)
        if (persistedSite.overlayState || remoteSite.overlayState) {
            if (!mergedOverlay[siteKey]) {
                mergedOverlay[siteKey] = { overlayState: {}, ui: {}, draftSelections: {} };
            }
            mergedOverlay[siteKey].overlayState = {
                ...(remoteSite.overlayState || {}),
                ...(persistedSite.overlayState || {})
            };
        }

        if (persistedSite.streamerOverlayState || remoteSite.streamerOverlayState) {
            if (!mergedOverlay[siteKey]) {
                mergedOverlay[siteKey] = { overlayState: {}, ui: {}, draftSelections: {} };
            }
            mergedOverlay[siteKey].streamerOverlayState = {
                ...(remoteSite.streamerOverlayState || {}),
                ...(persistedSite.streamerOverlayState || {})
            };
        }
        
        if (persistedSite.draftSelections || remoteSite.draftSelections) {
            if (!mergedOverlay[siteKey]) {
                mergedOverlay[siteKey] = { overlayState: {}, ui: {}, draftSelections: {} };
            }
            mergedOverlay[siteKey].draftSelections = {
                ...(remoteSite.draftSelections || {}),
                ...(persistedSite.draftSelections || {})
            };
        }
    }
    
    // Handle other overlay keys (non-site entries on overlay root)
    for (const [key, value] of Object.entries(persistedOverlay)) {
        if (key !== 'underdog' && key !== 'draftkings') {
            mergedOverlay[key] = value;
        }
    }
    
    result.overlay = mergedOverlay;
    
    // Handle static_settings: whitelists come only from remote config (defaults), not from persisted
    // Other static_settings can be overridden by persisted values
    const whitelistKeys = [
        'underdog_slate_whitelist',
        'underdog_slate_friendly_labels',
        'draftkings_slate_whitelist',
        'draftkings_slate_friendly_labels',
        'draftkings_tournament_whitelist',
        'season_stage',
        'ud_intercept_extraction_enabled'
    ];
    result.static_settings = { ...defaults.static_settings };
    
    if (persisted.static_settings && typeof persisted.static_settings === 'object') {
        // For non-whitelist static_settings, allow persisted values to override defaults
        for (const [key, value] of Object.entries(persisted.static_settings)) {
            if (!whitelistKeys.includes(key)) {
                result.static_settings[key] = value;
            }
            // Whitelist keys are intentionally skipped - they only come from remote config
        }
    }
    
    // User settings: persisted values ALWAYS override defaults and remote config
    // This ensures user preferences (like user_sound_enabled) are never overridden
    if (persisted.user_settings && typeof persisted.user_settings === 'object') {
        // Start with defaults, then override with persisted values
        // This ensures persisted user_settings always take priority
        result.user_settings = { ...defaults.user_settings, ...persisted.user_settings };
    } else {
        // If no persisted user_settings, use defaults
        result.user_settings = { ...defaults.user_settings };
    }

    // Persisted chrome.storage blobs may carry tag prefs (and exposure display) at the top level
    // because saves use `{ ...merged }` from hydration; those keys were not folded into
    // user_settings. Prefer explicit top-level values so user_settings matches storage truth.
    const topLevelUserTagKeys = [
        'tag_icon_quarterback',
        'tag_icon_teammate',
        'tag_icon_exposure',
        'tag_icon_exposure_display',
        'tag_icon_week_17',
        'tag_icon_bye_overlap',
        'tag_icon_combination_uniqueness',
        'tag_icon_draft_availability',
        'tag_icon_r1_active',
        'tag_icon_conf_champ_opp',
        'tag_icon_hide_inactive',
        'tag_icon_compact'
    ];
    for (let ti = 0; ti < topLevelUserTagKeys.length; ti++) {
        const k = topLevelUserTagKeys[ti];
        if (Object.prototype.hasOwnProperty.call(persisted, k)) {
            result.user_settings[k] = persisted[k];
        }
    }
    
    for (const [key, value] of Object.entries(persisted || {})) {
        if (key === 'overlay' || key === 'static_settings' || key === 'user_settings') continue;
        result[key] = value;
    }
    return result;
}

function hydrate_background_settings(persisted = {}) {
    const defaults = get_default_background_settings();
    return { ...BASE_BG, ...defaults, ...RUNTIME_BG, ...persisted };
}


function is_settings_corrupted(persisted, configReady) {
    if (!configReady) return false;
    // After config is ready, settings should have structure
    // If persisted is completely empty and config is ready, it might be corrupted
    // But we allow empty persisted if it's just defaults, so check for malformed structure
    if (persisted && typeof persisted === 'object') {
        // Check if it has expected top-level keys (even if empty)
        const hasExpectedStructure = 
            persisted.hasOwnProperty('user_settings') || 
            persisted.hasOwnProperty('overlay') ||
            persisted.hasOwnProperty('static_settings');
        // If it's an object but has none of the expected keys, it might be corrupted
        // But empty object is OK (will be hydrated from defaults)
        return false; // Empty object is fine, hydration will fill it
    }
    return false;
}


async function recover_content_script_settings() {
    try {
        // Force ensure config is ready (will fetch if needed)
        await ensure_config_ready();
        // Rebuild settings from defaults (remote config)
        const recovered = await build_content_script_settings({ persistIfChanged: true });
        return recovered;
    } catch (err) {
        console.error('[config] RECOVERY: Failed to recover content script settings', err);
        // Return defaults on error
        return get_default_content_script_settings();
    }
}

async function build_content_script_settings({ persistIfChanged = false } = {}) {
    // Ensure config is ready first
    await ensure_config_ready();
    
    const res = await storage.get(KEYS.settings_content_script);
    const persisted = (res && res[KEYS.settings_content_script]) || {};
    
    // Check for corruption: if storage.get returned undefined/null, that's already handled
    // But if persisted exists but is malformed, we could detect it here
    // For now, hydration will handle malformed data by using defaults
    
    const merged = hydrate_content_script_settings(persisted);
    if (persistIfChanged && !deepEqual(persisted, merged)) {
        // When persisting, ensure user_settings from persisted are preserved
        // This prevents remote config updates from overriding user preferences
        const toSave = { ...merged };
        if (persisted.user_settings && typeof persisted.user_settings === 'object') {
            // Preserve all user-set values, merging with any new defaults
            toSave.user_settings = { ...merged.user_settings, ...persisted.user_settings };
        }
        await storage.set({ [KEYS.settings_content_script]: toSave });
    }
    syncUdDebugLegacyCollisionRulesFromUserSettings(merged.user_settings);
    return merged;
}


async function recover_background_settings() {
    try {
        // Force ensure config is ready (will fetch if needed)
        await ensure_config_ready();
        // Rebuild settings from defaults (remote config)
        const recovered = hydrate_background_settings({});
        return recovered;
    } catch (err) {
        console.error('[config] RECOVERY: Failed to recover background settings', err);
        // Return base defaults on error
        return { ...BASE_BG, ...RUNTIME_BG };
    }
}

async function resolve_background_settings({ ensureConfig = true } = {}) {
    if (ensureConfig) await ensure_config_ready();
    const res = await storage.get(KEYS.settings_background);
    const persisted = (res && res[KEYS.settings_background]) || {};
    
    // If config is ready but persisted is completely missing/corrupted, 
    // hydration will use defaults, which is fine
    // No need for explicit recovery here since defaults come from remote config
    
    if (ensureConfig) {
        return hydrate_background_settings(persisted);
    }
    return { ...BASE_BG, ...RUNTIME_BG, ...persisted };
}

async function apply_config_update(rawConfig, { broadcast = false, fetchedForUserUuid } = {}) {
    const normalized = normalize_config(rawConfig);
    const changed = !deepEqual(configState.data, normalized);

    configState.data = normalized;
    configState.lastFetch = Date.now();
    if (fetchedForUserUuid !== undefined) {
        configState.remote_config_fetched_for_user_uuid = fetchedForUserUuid;
    }

    try {
        const cachePayload = {
            [KEYS.remote_config_cache]: normalized,
            [KEYS.remote_config_cache_ts]: configState.lastFetch,
        };
        if (fetchedForUserUuid !== undefined) {
            cachePayload[KEYS.remote_config_cache_user_uuid] = fetchedForUserUuid;
        }
        await storage.set(cachePayload);
    } catch (err) {
        console.error('[config] failed to cache remote config', err);
    }

    // Remote config should clobber sidecar/dev overrides for certain static_settings.
    // These are debug toggles that may be persisted locally, but must reset when a remote config update lands.
    try {
        const res = await storage.get(KEYS.settings_content_script);
        const persisted = (res && res[KEYS.settings_content_script]) || {};
        const ss = persisted.static_settings && typeof persisted.static_settings === 'object' ? { ...persisted.static_settings } : null;
        const debugStaticKeysToResetOnRemote = ['ud_enable_nonop_tick_after_nav'];
        let ssMutated = false;
        if (ss) {
            for (const k of debugStaticKeysToResetOnRemote) {
                if (Object.prototype.hasOwnProperty.call(ss, k)) {
                    delete ss[k];
                    ssMutated = true;
                }
            }
            if (ssMutated) {
                const next = { ...persisted, static_settings: ss };
                await storage.set({ [KEYS.settings_content_script]: next });
            }
        }
    } catch (err) {
    }

    const mergedContentSettings = await build_content_script_settings({ persistIfChanged: true });

    // Record last_config_update after merge/persist so every successful apply bumps the timestamp
    // even when merged content_script_settings match storage (persistIfChanged skips a write).
    try {
        const sessionAfter = await read_session_data_from_storage();
        if (sessionAfter && typeof sessionAfter === 'object') {
            const updatedSession = {
                ...sessionAfter,
                last_config_update: configState.lastFetch
            };
            await set_session_data(updatedSession);
            notify_auth_status(updatedSession);
        }
    } catch (err) {
    }

    if (broadcast && changed) {
        notify_content_scripts('UPDATE_SETTINGS', { settings: mergedContentSettings });
        notify_content_scripts('UPDATE_DATASETS', { datasets: get_content_script_datasets() });
        if (state.popup_port) {
            try {
                state.popup_port.postMessage({ action: 'UPDATE_SETTINGS', settings: mergedContentSettings });
            } catch (err) {
            }
        }
        if (state.settings_ports && state.settings_ports.size > 0) {
            state.settings_ports.forEach((settingsPort) => {
                try {
                    settingsPort.postMessage({ action: 'UPDATE_SETTINGS', settings: mergedContentSettings });
                } catch (err) {
                }
            });
        }
    }

    return { changed, settings: mergedContentSettings };
}

async function fetch_json(url, options = {}) {
    const {
        timeoutMs,
        headers,
        method,
        body: payload,
        logLabel,
        silent,
        allowNotModified,
        includeMeta,
    } = options || {};
    try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), timeoutMs || 60000);
        const res = await fetch(url, {
            method: method || 'GET',
            headers: {
                'Content-Type': 'application/json',
                ...(headers || {})
            },
            body: payload ? JSON.stringify(payload) : undefined,
            signal: controller.signal
        });
        clearTimeout(timeout);
        const body = await res.json().catch(() => null);
        if (res.status === 304 && allowNotModified) {
            const meta = {
                notModified: true,
                status: 304,
                body: null,
                headers: res.headers,
            };
            if (!silent) {
                const label = logLabel ? ` ${logLabel}` : '';
            }
            return includeMeta ? meta : null;
        }
        if (!res.ok) {
            const label = logLabel ? ` ${logLabel}` : '';
            console.error(`[fetch_json] HTTP ${res.status}${label}`, {
                url,
                method: method || 'GET',
                status: res.status,
                statusText: res.statusText,
                responseBody: body
            });
            const err = new Error(body?.detail || body?.message || res.statusText || 'Request failed');
            err.status = res.status;
            err.responseBody = body;
            throw err;
        }
        // Log successful responses (unless silent flag is set)
        if (!silent) {
            const label = logLabel ? ` ${logLabel}` : '';
            const responseData = {
                url,
                method: method || 'GET',
                status: res.status,
                statusText: res.statusText
            };
        }
        if (includeMeta) {
            return {
                notModified: false,
                status: res.status,
                body,
                headers: res.headers,
            };
        }
        return body;
    } catch (err) {
        if (!silent) {
            const label = logLabel ? ` ${logLabel}` : '';
            console.error(`[fetch_json] error${label}`, err);
        }
        throw err;
    }
}

function normalize_client_etag(value) {
    if (value == null) return '';
    let cleaned = String(value).trim();
    if (!cleaned) return '';
    if (cleaned.toUpperCase().startsWith('W/')) {
        cleaned = cleaned.slice(2).trim();
    }
    if (cleaned.length >= 2 && cleaned[0] === '"' && cleaned[cleaned.length - 1] === '"') {
        cleaned = cleaned.slice(1, -1);
    }
    return cleaned.trim();
}

function etags_from_response_headers(headers) {
    if (!headers || typeof headers.get !== 'function') {
        return { config: '', datasets: '', user_rankings: '', user_exposure: '', datasets_response: '' };
    }
    return {
        config: normalize_client_etag(headers.get('etag')),
        datasets: normalize_client_etag(headers.get('x-config-datasets-etag')),
        user_rankings: normalize_client_etag(headers.get('x-config-user-rankings-etag')),
        user_exposure: normalize_client_etag(headers.get('x-config-user-exposure-etag')),
        datasets_response: normalize_client_etag(headers.get('etag')),
    };
}

function etags_from_body(body) {
    const src = body && typeof body === 'object' ? body.etags : null;
    if (!src || typeof src !== 'object') {
        return { config: '', datasets: '', user_rankings: '', user_exposure: '' };
    }
    return {
        config: normalize_client_etag(src.config),
        datasets: normalize_client_etag(src.datasets),
        user_rankings: normalize_client_etag(src.user_rankings),
        user_exposure: normalize_client_etag(src.user_exposure),
    };
}

function merge_etag_state(partial) {
    const next = {
        ...(configState.etags || {}),
        ...(partial || {}),
    };
    configState.etags = {
        config: normalize_client_etag(next.config),
        datasets: normalize_client_etag(next.datasets),
        user_rankings: normalize_client_etag(next.user_rankings),
        user_exposure: normalize_client_etag(next.user_exposure),
        datasets_response: normalize_client_etag(next.datasets_response),
    };
    return configState.etags;
}

async function persist_config_etags(partial) {
    const etags = merge_etag_state(partial);
    try {
        await storage.set({
            [KEYS.remote_config_etag]: etags.config || '',
            [KEYS.remote_datasets_etag]: etags.datasets || '',
            [KEYS.remote_user_rankings_etag]: etags.user_rankings || '',
            [KEYS.remote_user_exposure_etag]: etags.user_exposure || '',
            [KEYS.remote_datasets_response_etag]: etags.datasets_response || '',
        });
    } catch (err) {
    }
    return etags;
}

async function load_config_etags_from_storage() {
    try {
        const cached = await storage.get([
            KEYS.remote_config_etag,
            KEYS.remote_datasets_etag,
            KEYS.remote_user_rankings_etag,
            KEYS.remote_user_exposure_etag,
            KEYS.remote_datasets_response_etag,
        ]);
        return merge_etag_state({
            config: (cached && cached[KEYS.remote_config_etag]) || '',
            datasets: (cached && cached[KEYS.remote_datasets_etag]) || '',
            user_rankings: (cached && cached[KEYS.remote_user_rankings_etag]) || '',
            user_exposure: (cached && cached[KEYS.remote_user_exposure_etag]) || '',
            datasets_response: (cached && cached[KEYS.remote_datasets_response_etag]) || '',
        });
    } catch (err) {
        return merge_etag_state({});
    }
}

// The user we have already seen a non-empty custom rankings set for. Without this,
// "local rankings are empty" is ambiguous — it could mean the user has none — and
// forcing an uncached datasets pull on that alone would defeat etag caching for
// every user who does not use custom rankings.
let userRankingsSeenForUserUuid = null; // null = not yet read from storage

function normalize_user_uuid(userUuid) {
    return userUuid && String(userUuid).trim() ? String(userUuid).trim() : '';
}

async function load_user_rankings_seen_from_storage() {
    if (userRankingsSeenForUserUuid !== null) return userRankingsSeenForUserUuid;
    try {
        const cached = await storage.get(KEYS.user_rankings_seen_for_user_uuid);
        userRankingsSeenForUserUuid = (cached && cached[KEYS.user_rankings_seen_for_user_uuid]) || '';
    } catch (err) {
        userRankingsSeenForUserUuid = '';
    }
    return userRankingsSeenForUserUuid;
}

async function note_user_rankings_seen(userUuid, datasets) {
    const uuid = normalize_user_uuid(userUuid);
    if (!uuid || user_rankings_dataset_count(datasets) === 0) return;
    if (userRankingsSeenForUserUuid === uuid) return;
    userRankingsSeenForUserUuid = uuid;
    try {
        await storage.set({ [KEYS.user_rankings_seen_for_user_uuid]: uuid });
    } catch (err) {
    }
}

function user_rankings_known_for_user(userUuid) {
    const uuid = normalize_user_uuid(userUuid);
    return !!uuid && userRankingsSeenForUserUuid === uuid;
}

async function clear_config_etags_storage() {
    merge_etag_state({
        config: '',
        datasets: '',
        user_rankings: '',
        user_exposure: '',
        datasets_response: '',
    });
    try {
        await storage.remove([
            KEYS.remote_config_etag,
            KEYS.remote_datasets_etag,
            KEYS.remote_user_rankings_etag,
            KEYS.remote_user_exposure_etag,
            KEYS.remote_datasets_response_etag,
        ]);
    } catch (err) {
    }
}

function dataset_map_has_path_strings(map) {
    if (!map || typeof map !== 'object') return false;
    return Object.values(map).some((value) => typeof value === 'string');
}

function prepare_lean_config_for_apply(leanRaw, previous) {
    const out = { ...(leanRaw && typeof leanRaw === 'object' ? leanRaw : {}) };
    delete out.etags;
    const prev = previous && typeof previous === 'object' ? previous : {};
    for (const key of ['background_datasets', 'content_script_datasets', 'user_rankings_datasets']) {
        const incoming = out[key];
        const looksLikePaths = dataset_map_has_path_strings(incoming);
        const omitted = incoming === undefined;
        if (omitted || looksLikePaths) {
            if (prev[key] && typeof prev[key] === 'object') {
                out[key] = cloneDeep(prev[key]);
            } else if (looksLikePaths) {
                delete out[key];
            }
        }
    }
    return out;
}

function user_rankings_dataset_count(datasets) {
    if (!datasets || typeof datasets !== 'object') return 0;
    return Object.keys(datasets).length;
}

function local_user_rankings_count() {
    return user_rankings_dataset_count(configState.data?.user_rankings_datasets);
}

function merge_datasets_payload_into_config(datasetsBody, previous, options = {}) {
    const base = previous && typeof previous === 'object' ? previous : {};
    const body = datasetsBody && typeof datasetsBody === 'object' ? datasetsBody : {};
    const merged = { ...base };
    if (body.background_datasets && typeof body.background_datasets === 'object') {
        merged.background_datasets = body.background_datasets;
    }
    if (body.content_script_datasets && typeof body.content_script_datasets === 'object') {
        merged.content_script_datasets = body.content_script_datasets;
    }
    if (body.user_rankings_datasets && typeof body.user_rankings_datasets === 'object') {
        // An empty object is what the server sends both for "user has no rankings"
        // and for "the Firestore read failed" — it is never worth clobbering a
        // known-good set with. Settings would render blank and live drafts would
        // send custom_rankings: [].
        //
        // Keyed on the user we last saw rankings for, so a second account signing
        // in (empty set, different uuid) still clears the previous user's list
        // instead of inheriting it.
        const keepLastGood =
            user_rankings_dataset_count(body.user_rankings_datasets) === 0
            && user_rankings_dataset_count(base.user_rankings_datasets) > 0
            && user_rankings_known_for_user(options.userUuid);
        if (keepLastGood) {
        } else {
            merged.user_rankings_datasets = body.user_rankings_datasets;
        }
    }
    return merged;
}

/**
 * Fetch custom rankings with app JWT only (no install instance proof).
 * Merges user_rankings_datasets into configState so Settings / drafts see them.
 */
async function fetch_and_apply_user_rankings_with_app_jwt(options = {}) {
    const session = options.session || await read_session_data_from_storage();
    const userUuid = session?.user_uuid && String(session.user_uuid).trim()
        ? String(session.user_uuid).trim()
        : '';
    if (!userUuid) {
        const err = new Error('Sign in to load rankings.');
        err.status = 401;
        throw err;
    }

    await ensure_config_ready();
    await load_user_rankings_seen_from_storage();

    const headers = {};
    if (session?.app_jwt) {
        headers.Authorization = `Bearer ${session.app_jwt}`;
    }
    const body = await make_http_request_with_auth_retry(USER_RANKINGS_ENDPOINT_PATH, {
        method: 'GET',
        headers,
        ensureConfig: false,
    });
    const rankingsDatasets =
        body && typeof body === 'object' && body.user_rankings_datasets && typeof body.user_rankings_datasets === 'object'
            ? body.user_rankings_datasets
            : {};

    const merged = merge_datasets_payload_into_config(
        { user_rankings_datasets: rankingsDatasets },
        configState.data || CONFIG_FALLBACK,
        { userUuid }
    );
    await apply_config_update(merged, {
        broadcast: true,
        fetchedForUserUuid: userUuid,
    });
    await note_user_rankings_seen(userUuid, configState.data?.user_rankings_datasets);

    const datasets = get_user_rankings_datasets();
    if (BASE_BG.env !== 'prod') {
        const log_data = {
            datasetKeys: datasets && typeof datasets === 'object' ? Object.keys(datasets) : [],
            udLen: Array.isArray(datasets?.ud_bbm?.rankings) ? datasets.ud_bbm.rankings.length : 0,
            dkLen: Array.isArray(datasets?.dk_bbm?.rankings) ? datasets.dk_bbm.rankings.length : 0,
        };
    }
    return { ok: true, datasets };
}

function local_exposure_slate_count() {
    if (typeof exposureState !== 'object' || !exposureState) return 0;
    const ud =
        exposureState.ud_by_slate && typeof exposureState.ud_by_slate === 'object'
            ? exposureState.ud_by_slate
            : {};
    const dk =
        exposureState.dk_by_slate && typeof exposureState.dk_by_slate === 'object'
            ? exposureState.dk_by_slate
            : {};
    return Object.keys(ud).length + Object.keys(dk).length;
}

/**
 * Pull Layer A rollups into local storage when the extension has no exposure yet.
 * Independent of dataset etag short-circuit so reinstall / background restart
 * still hydrates even when lean config says datasets are unchanged.
 */
async function hydrate_exposure_from_config_if_needed(options = {}) {
    const force = !!options.force;
    if (typeof applyServerExposureRollups !== 'function') {
        return { attempted: false, reason: 'apply_unavailable' };
    }
    if (!force && local_exposure_slate_count() > 0) {
        return { attempted: false, reason: 'local_present' };
    }
    try {
        if (!exposureState._hydrated && typeof hydrateExposureFromStorage === 'function') {
            try {
                await hydrateExposureFromStorage();
            } catch (err) {
            }
            if (!force && local_exposure_slate_count() > 0) {
                return { attempted: false, reason: 'local_present_after_storage' };
            }
        }

        const ctx = await build_config_request_context();
        if (!ctx.authenticated) {
            return { attempted: false, reason: 'not_authenticated' };
        }

        const datasetsResult = await fetch_remote_datasets({ force: true });
        if (datasetsResult.bootstrapWhileLoggedIn) {
            return { attempted: false, reason: 'attestation_pending' };
        }
        const payload =
            datasetsResult.raw && datasetsResult.raw.user_exposure_datasets
                ? datasetsResult.raw.user_exposure_datasets
                : null;
        if (!payload) {
            return { attempted: true, reason: 'no_payload', applied_count: 0 };
        }
        const applyResult = await applyServerExposureRollups(payload);
        const appliedCount = applyResult && applyResult.applied_count ? applyResult.applied_count : 0;
        const serverSlates = Array.isArray(payload.slates) ? payload.slates.length : 0;
        let exposureEtag =
            (datasetsResult.etags && datasetsResult.etags.user_exposure) || '';
        if (serverSlates > 0 && local_exposure_slate_count() === 0) {
            exposureEtag = '';
            if (BASE_BG.env !== 'prod') {
                const log_data = {
                    server_slates: serverSlates,
                    apply_result: applyResult || null,
                };
            }
        }
        await persist_config_etags({
            datasets: (datasetsResult.etags && datasetsResult.etags.datasets) || configState.etags.datasets,
            user_rankings:
                (datasetsResult.etags && datasetsResult.etags.user_rankings) ||
                configState.etags.user_rankings,
            user_exposure: exposureEtag,
            datasets_response:
                (datasetsResult.etags && datasetsResult.etags.datasets_response) ||
                configState.etags.datasets_response,
        });
        if (BASE_BG.env !== 'prod') {
            const log_data = {
                server_slates: serverSlates,
                applied_count: appliedCount,
                local_slates: local_exposure_slate_count(),
            };
        }
        return {
            attempted: true,
            reason: 'ok',
            applied_count: appliedCount,
            server_slates: serverSlates,
        };
    } catch (err) {
        return { attempted: true, reason: 'error', error: err };
    }
}

function should_refetch_datasets({ force, authenticated, serverEtags, userUuid } = {}) {
    if (force) return true;
    const stored = configState.etags || {};
    const server = serverEtags || {};
    if (!stored.datasets) return true;
    if (server.datasets && server.datasets !== stored.datasets) return true;
    if (authenticated) {
        if (!stored.user_rankings && server.user_rankings) return true;
        if (server.user_rankings && server.user_rankings !== stored.user_rankings) return true;
        // Same failed/skipped-apply case as exposure below: a persisted etag that
        // matches while local rankings are empty otherwise wedges the Sidekick on
        // an empty set until a forced reload. Only fires for users we have already
        // seen rankings for, so no-custom-rankings users keep their 304s.
        if (
            server.user_rankings
            && local_user_rankings_count() === 0
            && user_rankings_known_for_user(userUuid)
        ) {
            return true;
        }
        if (!stored.user_exposure && server.user_exposure) return true;
        if (server.user_exposure && server.user_exposure !== stored.user_exposure) return true;
        // Etags can match after a failed/skipped apply; keep retrying hydrate until local has slates.
        if (server.user_exposure && local_exposure_slate_count() === 0) return true;
    }
    const data = configState.data || {};
    if (dataset_map_has_path_strings(data.background_datasets)) return true;
    if (dataset_map_has_path_strings(data.content_script_datasets)) return true;
    return false;
}

function is_config_attestation_http_error(err) {
    const status = err?.status;
    return status === 401 || status === 403;
}

function has_user_scoped_remote_config() {
    const uid = configState.remote_config_fetched_for_user_uuid;
    return uid != null && String(uid).trim() !== '';
}

async function build_config_request_context() {
    const bg = await resolve_background_settings({ ensureConfig: false });
    const base = http_base_url(bg);
    const session = await read_session_data_from_storage();
    const userUuid = session?.user_uuid && String(session.user_uuid).trim()
        ? String(session.user_uuid).trim()
        : '';

    const instanceId = await ensure_install_instance_id();
    const query = new URLSearchParams({
        instance_id: instanceId,
        extension_version: get_extension_version()
    });
    let headers = {};
    let authenticated = false;

    if (userUuid) {
        let instanceSecret = await get_install_instance_secret();
        if (!instanceSecret && session?.ghost_jwt && typeof register_install_instance === 'function') {
            try {
                await register_install_instance({
                    userUuid,
                    ghostJwt: session.ghost_jwt,
                    force: false
                });
                instanceSecret = await get_install_instance_secret();
            } catch (err) {
                if (BASE_BG.env !== 'prod') {
                    const log_data = {
                        status: err?.status || null,
                        message: err?.message || String(err)
                    };
                }
            }
        }

        if (instanceSecret) {
            const attestedId = await get_install_instance_id() || instanceId;
            query.set('instance_id', attestedId);
            query.set('user_uuid', userUuid);
            if (typeof get_fantasy_site_usernames === 'function') {
                try {
                    const siteUsernames = await get_fantasy_site_usernames();
                    if (siteUsernames && siteUsernames.dk_username) {
                        query.set('dk_username', siteUsernames.dk_username);
                    }
                    if (siteUsernames && siteUsernames.ud_username) {
                        query.set('ud_username', siteUsernames.ud_username);
                    }
                } catch (err) {
                }
            }
            headers = await config_headers_for_user(userUuid, attestedId, instanceSecret);
            authenticated = true;
        } else {
            if (typeof request_ghost_session_refresh === 'function') {
                request_ghost_session_refresh();
            }
        }
    }

    return {
        base,
        session,
        userUuid,
        query,
        headers,
        authenticated,
    };
}

async function retry_config_after_attestation_failure(err, options, session, userUuid, retryFn) {
    if (
        !is_config_attestation_http_error(err)
        || options._instanceProofRetried
        || typeof register_install_instance !== 'function'
    ) {
        throw err;
    }
    const ghostJwt = session?.ghost_jwt || null;
    if (ghostJwt) {
        if (BASE_BG.env !== 'prod') {
            const log_data = {
                status: err?.status || null,
            };
        }
        try {
            if (typeof clear_install_instance_secret === 'function') {
                await clear_install_instance_secret();
            }
            await register_install_instance({
                userUuid,
                ghostJwt,
                force: true
            });
            return await retryFn({ ...options, _instanceProofRetried: true });
        } catch (regErr) {
            if (BASE_BG.env !== 'prod') {
                const log_data = {
                    status: regErr?.status || null,
                    message: regErr?.message || String(regErr)
                };
            }
        }
    } else if (typeof request_ghost_session_refresh === 'function') {
        request_ghost_session_refresh();
    }
    throw err;
}

async function fetch_remote_config(options = {}) {
    const force = !!options.force;
    const ctx = await build_config_request_context();
    const { base, session, userUuid, query, headers, authenticated } = ctx;

    query.set('include_datasets', '0');
    const knownConfigEtag = force ? '' : normalize_client_etag(configState.etags?.config);
    if (knownConfigEtag) {
        query.set('known_etag', knownConfigEtag);
        headers['If-None-Match'] = `"${knownConfigEtag}"`;
    }

    const url = `${base}${CONFIG_ENDPOINT_PATH}?${query.toString()}`;
    if (BASE_BG.env !== 'prod') {
        const log_data = {
            url,
            instance_id: query.get('instance_id') || null,
            extension_version: query.get('extension_version') || null,
            authenticated,
            force,
            known_etag: knownConfigEtag || null,
            dk_username: query.get('dk_username') || null,
            ud_username: query.get('ud_username') || null
        };
    }

    try {
        const meta = await fetch_json(url, {
            method: 'GET',
            headers,
            silent: true,
            allowNotModified: true,
            includeMeta: true,
        });
        const headerEtags = etags_from_response_headers(meta.headers);
        const bodyEtags = etags_from_body(meta.body);
        const etags = {
            config: bodyEtags.config || headerEtags.config,
            datasets: bodyEtags.datasets || headerEtags.datasets,
            user_rankings: bodyEtags.user_rankings || headerEtags.user_rankings,
            user_exposure: bodyEtags.user_exposure || headerEtags.user_exposure,
        };
        return {
            raw: meta.body,
            etags,
            notModified: !!meta.notModified,
            fetchedForUserUuid: authenticated ? userUuid : '',
            bootstrapWhileLoggedIn: !!userUuid && !authenticated,
            authenticated,
        };
    } catch (err) {
        if (authenticated) {
            return await retry_config_after_attestation_failure(
                err,
                options,
                session,
                userUuid,
                (nextOpts) => fetch_remote_config(nextOpts)
            );
        }
        throw err;
    }
}

async function fetch_remote_datasets(options = {}) {
    const force = !!options.force;
    const ctx = await build_config_request_context();
    const { base, session, userUuid, query, headers, authenticated } = ctx;

    if (authenticated) {
        query.set('include_user_rankings', '1');
        query.set('include_user_exposure', '1');
    }
    const knownDatasetsEtag = force
        ? ''
        : normalize_client_etag(configState.etags?.datasets_response || configState.etags?.datasets);
    if (knownDatasetsEtag) {
        query.set('known_etag', knownDatasetsEtag);
        headers['If-None-Match'] = `"${knownDatasetsEtag}"`;
    }

    const url = `${base}${CONFIG_DATASETS_ENDPOINT_PATH}?${query.toString()}`;
    if (BASE_BG.env !== 'prod') {
        const log_data = {
            url,
            authenticated,
            force,
            known_etag: knownDatasetsEtag || null,
        };
    }

    try {
        const meta = await fetch_json(url, {
            method: 'GET',
            headers,
            silent: true,
            allowNotModified: true,
            includeMeta: true,
        });
        const headerEtags = etags_from_response_headers(meta.headers);
        const bodyEtags = etags_from_body(meta.body);
        const etags = {
            config: bodyEtags.config || headerEtags.config,
            datasets: bodyEtags.datasets || headerEtags.datasets,
            user_rankings: bodyEtags.user_rankings || headerEtags.user_rankings,
            user_exposure: bodyEtags.user_exposure || headerEtags.user_exposure,
            datasets_response: headerEtags.datasets_response || knownDatasetsEtag,
        };
        return {
            raw: meta.body,
            etags,
            notModified: !!meta.notModified,
            authenticated,
            fetchedForUserUuid: authenticated ? userUuid : '',
            bootstrapWhileLoggedIn: !!userUuid && !authenticated,
        };
    } catch (err) {
        if (authenticated) {
            return await retry_config_after_attestation_failure(
                err,
                options,
                session,
                userUuid,
                (nextOpts) => fetch_remote_datasets(nextOpts)
            );
        }
        throw err;
    }
}

function schedule_next_config_refresh(delayMs = CONFIG_REFRESH_INTERVAL_MS) {
    if (configState.refreshTimer) {
        clearTimeout(configState.refreshTimer);
    }
    configState.refreshTimer = setTimeout(async () => {
        configState.refreshTimer = null;
        try {
            await refresh_config();
        } catch (err) {
            console.error('[config] refresh failed', err);
        }
    }, delayMs);
}

async function refresh_config(options = {}) {
    const force = !!options.force;
    const skipSchedule = !!options.skipSchedule;
    try {
        await load_user_rankings_seen_from_storage();
        if (force) {
            await clear_config_etags_storage();
        } else if (!configState.etags?.config && !configState.etags?.datasets) {
            await load_config_etags_from_storage();
        }

        const lean = await fetch_remote_config({ force });

        // Logged-in bootstrap has no user_rankings_datasets. Keep last-good user-scoped
        // config so custom rankings / upload refresh cannot be wiped by a failed attestation.
        if (lean.bootstrapWhileLoggedIn && has_user_scoped_remote_config()) {
            if (!skipSchedule) {
                const retryDelay = Math.min(CONFIG_RETRY_MAX_DELAY_MS, CONFIG_REFRESH_INTERVAL_MS / 2);
                schedule_next_config_refresh(retryDelay);
            }
            return {
                ok: false,
                authenticated: false,
                attestationPending: true,
                datasets: get_user_rankings_datasets(),
            };
        }

        let changed = false;
        if (lean.notModified) {
            await persist_config_etags({
                config: lean.etags.config || configState.etags.config,
                datasets: lean.etags.datasets || configState.etags.datasets,
                user_rankings: lean.etags.user_rankings || configState.etags.user_rankings,
                user_exposure: lean.etags.user_exposure || configState.etags.user_exposure,
            });
        } else {
            const prepared = prepare_lean_config_for_apply(lean.raw, configState.data);
            const applied = await apply_config_update(prepared, {
                broadcast: true,
                fetchedForUserUuid: lean.fetchedForUserUuid,
            });
            changed = !!applied.changed;
            await persist_config_etags({
                config: lean.etags.config,
                datasets: lean.etags.datasets || configState.etags.datasets,
                user_rankings: lean.etags.user_rankings || configState.etags.user_rankings,
                user_exposure: lean.etags.user_exposure || configState.etags.user_exposure,
            });
        }

        const authenticated = !!(lean.fetchedForUserUuid && String(lean.fetchedForUserUuid).trim());
        if (should_refetch_datasets({
            force,
            authenticated,
            serverEtags: lean.etags,
            userUuid: lean.fetchedForUserUuid,
        })) {
            const needExposureHydrate =
                authenticated &&
                local_exposure_slate_count() === 0 &&
                !!(lean.etags && lean.etags.user_exposure);
            // Rankings we know this user has, but that are missing locally, need the
            // same uncached pull — a matching etag would otherwise 304 forever.
            const needRankingsHydrate =
                authenticated &&
                local_user_rankings_count() === 0 &&
                user_rankings_known_for_user(lean.fetchedForUserUuid) &&
                !!(lean.etags && lean.etags.user_rankings);
            let datasetsResult = await fetch_remote_datasets({
                force: force || needExposureHydrate || needRankingsHydrate,
            });
            // 304 can still happen with a matching combined etag while local storage is empty
            // (etag persisted before a failed apply). Force one uncached pull to hydrate.
            if (datasetsResult.notModified && (needExposureHydrate || needRankingsHydrate)) {
                datasetsResult = await fetch_remote_datasets({ force: true });
            }
            if (datasetsResult.bootstrapWhileLoggedIn && has_user_scoped_remote_config()) {
            } else if (datasetsResult.notModified) {
                await persist_config_etags({
                    datasets: datasetsResult.etags.datasets || configState.etags.datasets,
                    user_rankings: datasetsResult.etags.user_rankings || configState.etags.user_rankings,
                    user_exposure: datasetsResult.etags.user_exposure || configState.etags.user_exposure,
                    datasets_response: datasetsResult.etags.datasets_response || configState.etags.datasets_response,
                });
            } else if (datasetsResult.raw) {
                const datasetsForUserUuid = datasetsResult.fetchedForUserUuid !== undefined
                    ? datasetsResult.fetchedForUserUuid
                    : lean.fetchedForUserUuid;
                const merged = merge_datasets_payload_into_config(
                    datasetsResult.raw,
                    configState.data,
                    { userUuid: datasetsForUserUuid }
                );
                const appliedDatasets = await apply_config_update(merged, {
                    broadcast: true,
                    fetchedForUserUuid: datasetsForUserUuid,
                });
                changed = changed || !!appliedDatasets.changed;
                await note_user_rankings_seen(
                    datasetsForUserUuid,
                    configState.data?.user_rankings_datasets
                );

                let exposureEtag = datasetsResult.etags.user_exposure;
                if (
                    authenticated &&
                    datasetsResult.raw.user_exposure_datasets &&
                    typeof applyServerExposureRollups === 'function'
                ) {
                    try {
                        const applyResult = await applyServerExposureRollups(
                            datasetsResult.raw.user_exposure_datasets
                        );
                        const serverSlates = Array.isArray(
                            datasetsResult.raw.user_exposure_datasets.slates
                        )
                            ? datasetsResult.raw.user_exposure_datasets.slates.length
                            : 0;
                        if (
                            serverSlates > 0 &&
                            local_exposure_slate_count() === 0 &&
                            !(applyResult && applyResult.applied_count > 0)
                        ) {
                            // Keep user_exposure etag unset so the next refresh retries hydrate.
                            exposureEtag = '';
                            if (BASE_BG.env !== 'prod') {
                                const log_data = {
                                    server_slates: serverSlates,
                                    apply_result: applyResult || null,
                                };
                            }
                        }
                    } catch (expErr) {
                        exposureEtag = '';
                    }
                }

                await persist_config_etags({
                    config: datasetsResult.etags.config || configState.etags.config,
                    datasets: datasetsResult.etags.datasets,
                    user_rankings: datasetsResult.etags.user_rankings,
                    user_exposure: exposureEtag,
                    datasets_response: datasetsResult.etags.datasets_response,
                });
            }
        }

        if (authenticated && local_exposure_slate_count() === 0) {
            // Never let exposure hydrate fail a config refresh (upload depends on ok:true).
            try {
                await hydrate_exposure_from_config_if_needed({ force: true });
            } catch (hydrateErr) {
            }
        }


        if (!skipSchedule) {
            schedule_next_config_refresh(CONFIG_REFRESH_INTERVAL_MS);
        }
        return {
            ok: true,
            authenticated,
            attestationPending: !!lean.bootstrapWhileLoggedIn,
            datasets: get_user_rankings_datasets(),
        };
    } catch (err) {
        console.error('[config] refresh attempt failed', err);
        if (!skipSchedule) {
            const retryDelay = Math.min(CONFIG_RETRY_MAX_DELAY_MS, CONFIG_REFRESH_INTERVAL_MS / 2);
            schedule_next_config_refresh(retryDelay);
        }
        return {
            ok: false,
            authenticated: false,
            attestationFailed: is_config_attestation_http_error(err),
            error: err,
            datasets: get_user_rankings_datasets(),
        };
    }
}


function is_config_cache_corrupted(cachedConfig) {
    if (!cachedConfig) return false;
    // Check if config has expected structure
    if (typeof cachedConfig !== 'object') return true;
    // Should have at least schema_version and content_script_settings or background_settings
    const hasExpectedStructure = 
        cachedConfig.hasOwnProperty('schema_version') &&
        (cachedConfig.hasOwnProperty('content_script_settings') || 
         cachedConfig.hasOwnProperty('background_settings'));
    return !hasExpectedStructure;
}

async function ensure_config_ready() {
    if (configState.data) return configState.data;
    if (configState.pending) return configState.pending;

    configState.pending = (async () => {
        try {
            await load_config_etags_from_storage();
            const cached = await storage.get([
                KEYS.remote_config_cache,
                KEYS.remote_config_cache_ts,
                KEYS.remote_config_cache_user_uuid,
            ]);
            const cachedConfig = (cached && cached[KEYS.remote_config_cache]) || null;
            const cachedTimestamp = (cached && cached[KEYS.remote_config_cache_ts]) || 0;
            const cachedConfigUserUuid = cached && Object.prototype.hasOwnProperty.call(cached, KEYS.remote_config_cache_user_uuid)
                ? cached[KEYS.remote_config_cache_user_uuid]
                : undefined;
            
            // Restore lastFetch timestamp from storage
            if (cachedTimestamp > 0) {
                configState.lastFetch = cachedTimestamp;
            }
            
            if (cachedConfig) {
                // Check for corruption
                if (is_config_cache_corrupted(cachedConfig)) {
                    console.error('[config] CORRUPTION DETECTED: Remote config cache is corrupted, forcing refetch', {
                        has_schema_version: cachedConfig.hasOwnProperty('schema_version'),
                        has_content_script_settings: cachedConfig.hasOwnProperty('content_script_settings'),
                        has_background_settings: cachedConfig.hasOwnProperty('background_settings'),
                        type: typeof cachedConfig
                    });
                    // Clear corrupted cache and force refetch
                    await storage.remove([
                        KEYS.remote_config_cache,
                        KEYS.remote_config_cache_ts,
                        KEYS.remote_config_cache_user_uuid,
                    ]);
                    await clear_config_etags_storage();
                    configState.data = null;
                } else {
                    try {
                        const sessionForCache = await read_session_data_from_storage();
                        const sessionUid = (sessionForCache && sessionForCache.user_uuid) || '';
                        const cachedUid =
                            cachedConfigUserUuid === undefined || cachedConfigUserUuid === null
                                ? undefined
                                : String(cachedConfigUserUuid);
                        const cacheUserMismatch =
                            cachedUid !== undefined && cachedUid !== sessionUid;
                        const legacyCacheMaybeAnonWhileLoggedIn =
                            cachedUid === undefined && !!sessionUid;
                        if (cacheUserMismatch || legacyCacheMaybeAnonWhileLoggedIn) {
                            await storage.remove([
                                KEYS.remote_config_cache,
                                KEYS.remote_config_cache_ts,
                                KEYS.remote_config_cache_user_uuid,
                            ]);
                            await clear_config_etags_storage();
                            configState.data = null;
                        } else {
                            const fetchedForApply =
                                cachedUid === undefined ? undefined : cachedUid;
                            await apply_config_update(cachedConfig, {
                                broadcast: false,
                                fetchedForUserUuid: fetchedForApply,
                            });
                            if (configState.data) {
                            }
                        }
                    } catch (err) {
                        // Clear cache on apply failure and force refetch
                        await storage.remove([
                            KEYS.remote_config_cache,
                            KEYS.remote_config_cache_ts,
                            KEYS.remote_config_cache_user_uuid,
                        ]);
                        await clear_config_etags_storage();
                        configState.data = null;
                    }
                }
                if (configState.data) {
                    schedule_next_config_refresh(5000);
                    // Cached lean config does not run applyServerExposureRollups — hydrate now.
                    hydrate_exposure_from_config_if_needed({ force: false }).catch((err) => {
                    });
                    return configState.data;
                }
            }

            // No cache or cache was corrupted - fetch from remote (omit known etags)
            await clear_config_etags_storage();
            let attempt = 0;
            while (!configState.data) {
                attempt += 1;
                try {
                    const result = await refresh_config({ force: true, skipSchedule: true });
                    if (result && result.attestationPending && has_user_scoped_remote_config()) {
                        break;
                    }
                    if (configState.data) {
                        break;
                    }
                    throw (result && result.error) || new Error('config refresh returned no data');
                } catch (err) {
                    console.error(`[config] fetch attempt ${attempt} failed`, err);
                    const delayMs = Math.min(CONFIG_RETRY_BASE_DELAY_MS * 2 ** (attempt - 1), CONFIG_RETRY_MAX_DELAY_MS);
                    await delay(delayMs);
                }
            }
            schedule_next_config_refresh(CONFIG_REFRESH_INTERVAL_MS);
            return configState.data;
        } finally {
            configState.pending = null;
        }
    })();

    return configState.pending;
}

async function load_background_settings() {
    return resolve_background_settings({ ensureConfig: true });
}

async function save_background_settings(patch) {
    await ensure_config_ready();
    const res = await storage.get(KEYS.settings_background);
    const persisted = (res && res[KEYS.settings_background]) || {};

    const nextPersisted = { ...persisted };
    for (const k of PERSISTABLE_BG_KEYS) {
        if (k in patch) nextPersisted[k] = patch[k];
    }

    await storage.set({ [KEYS.settings_background]: nextPersisted });
    return hydrate_background_settings(nextPersisted);
}

async function get_content_script_settings(keys = null) {
    await ensure_config_ready();
    // Don't persist on every read - only merge and return. Persisting happens:
    // 1. When remote config is applied (apply_config_update)
    // 2. When user explicitly changes settings (set_content_script_settings)
    const settings = await build_content_script_settings({ persistIfChanged: false });

    if (!keys) {
        return settings;
    }
    if (Array.isArray(keys)) {
        const filtered = keys.reduce((acc, k) => {
            if (settings.hasOwnProperty(k)) {
                acc[k] = settings[k];
            }
            return acc;
        }, {});
        return filtered;
    }
    if (typeof keys === 'string') {
        if (settings.hasOwnProperty(keys)) {
            return { [keys]: settings[keys] };
        }
    }
    return settings;
}

async function set_content_script_settings(patch) {
    await ensure_config_ready();
    const current = await build_content_script_settings();
    const next = { ...current };
    if (patch.overlay) {
        next.overlay = deepMergeOverlay(cloneDeep(current.overlay || {}), patch.overlay);
    }
    if (patch.static_settings && typeof patch.static_settings === 'object') {
        // Sidecar/dev overrides should update static_settings without clobbering other static keys.
        if (!next.static_settings) next.static_settings = {};
        next.static_settings = { ...next.static_settings, ...patch.static_settings };
    }
    // Remote config only for this flag (same as hydrate whitelist); never persist a divergent value.
    const remoteStatic = get_default_content_script_settings().static_settings || {};
    if (remoteStatic && Object.prototype.hasOwnProperty.call(remoteStatic, 'ud_intercept_extraction_enabled')) {
        if (!next.static_settings) next.static_settings = {};
        next.static_settings.ud_intercept_extraction_enabled = !!remoteStatic.ud_intercept_extraction_enabled;
    }
    if (!next.user_settings) {
        next.user_settings = {};
    }
    
    // List of user_settings properties that should be nested
    const userSettingsKeys = [
        'icon_size', 'use_image_icons', 'enable_mouse_over_text',
        'user_sound_enabled', 'use_cached_rankings', 'force_lite_mode', 'low_resources_mode',
        'suppress_nonfatal_warning_notifications',
        'tag_icon_quarterback', 'tag_icon_teammate', 'tag_icon_exposure', 'tag_icon_exposure_display',
        'exposure_aggregate_across_sites',
        'tag_icon_week_17',
        'tag_icon_bye_overlap', 'tag_icon_combination_uniqueness',
        'tag_icon_draft_availability', 'tag_icon_r1_active',
        'tag_icon_conf_champ_opp', 'tag_icon_hide_inactive', 'tag_icon_compact',
        'sidecar_enabled',
        'streamer_overlay_enabled',
        'ghost_enable_button_container', 'ghost_enable_player_card', 'ghost_enable_draft_board',
        'ud_xhr_replay_disabled',
        'ud_debug_ignore_legacy_collision_rules',
        // Underdog exposure aggregation controls (settings page).
        'ud_exposure_included_slates',
        'dk_exposure_included_slates',
        'ud_exposure_include_older',
        'ud_exposure_aggregate_slates',
        'dk_exposure_aggregate_slates'
    ];
    
    for (const [k, v] of Object.entries(patch)) {
        if (k === 'overlay') continue;
        if (k === 'static_settings') continue;
        if (userSettingsKeys.includes(k)) {
            next.user_settings[k] = v;
        } else {
        next[k] = v;
        }
    }
    // Avoid duplicating user_settings keys on the top level of the persisted blob (spread from
    // hydrated settings can leave stale copies that confuse readers).
    for (let ui = 0; ui < userSettingsKeys.length; ui++) {
        const k = userSettingsKeys[ui];
        if (Object.prototype.hasOwnProperty.call(next, k)) {
            delete next[k];
        }
    }
    await storage.set({ [KEYS.settings_content_script]: next });
    syncUdDebugLegacyCollisionRulesFromUserSettings(next.user_settings);
    return next;
}

async function reset_content_script_user_settings() {
    await ensure_config_ready();
    const res = await storage.get(KEYS.settings_content_script);
    const persisted = (res && res[KEYS.settings_content_script]) || {};
    const next = { ...persisted };
    delete next.user_settings;
    await storage.set({ [KEYS.settings_content_script]: next });
    return build_content_script_settings({ persistIfChanged: false });
}

async function reset_tag_icon_user_settings() {
    const res = await storage.get(KEYS.settings_content_script);
    const persisted = (res && res[KEYS.settings_content_script]) || {};
    if (!persisted.user_settings || typeof persisted.user_settings !== 'object') {
        return persisted;
    }
    const next = { ...persisted };
    const user_settings = { ...persisted.user_settings };
    // Only clear schedule-dependent regular-season tag toggles; other tag prefs stay user-controlled.
    const tagIconKeys = ['tag_icon_week_17', 'tag_icon_bye_overlap'];
    tagIconKeys.forEach((key) => {
        if (key in user_settings) {
            delete user_settings[key];
        }
        if (Object.prototype.hasOwnProperty.call(next, key)) {
            delete next[key];
        }
    });
    if (Object.keys(user_settings).length === 0) {
        delete next.user_settings;
    } else {
        next.user_settings = user_settings;
    }
    await storage.set({ [KEYS.settings_content_script]: next });
    return next;
}

async function get_fantasy_site_usernames() {
    const res = await storage.get(KEYS.fantasy_site_usernames);
    const data = res && res[KEYS.fantasy_site_usernames];
    if (!data || typeof data !== 'object') {
        return { dk_username: null, ud_username: null };
    }
    return {
        dk_username: data.dk_username != null && String(data.dk_username).trim() ? String(data.dk_username).trim() : null,
        ud_username: data.ud_username != null && String(data.ud_username).trim() ? String(data.ud_username).trim() : null,
        dk_username_updated_at_ms: data.dk_username_updated_at_ms || null,
        ud_username_updated_at_ms: data.ud_username_updated_at_ms || null
    };
}

function fantasy_site_username_key(site) {
    if (site === 'draftkings' || site === 'dk') {
        return 'dk_username';
    }
    if (site === 'underdog' || site === 'ud') {
        return 'ud_username';
    }
    return null;
}

async function store_fantasy_site_username(site, username) {
    const normalized = typeof username === 'string' ? username.trim() : '';
    if (!normalized || normalized.length >= 50) {
        return { stored: false, reason: 'empty_username' };
    }
    const lower = normalized.toLowerCase();
    if (lower === 'undefined' || lower === 'null' || lower === 'account' || lower === 'username') {
        return { stored: false, reason: 'invalid_username' };
    }

    const siteKey = fantasy_site_username_key(site);
    if (!siteKey) {
        return { stored: false, reason: 'unknown_site' };
    }

    const current = await get_fantasy_site_usernames();
    if (current[siteKey] === normalized) {
        return { stored: false, unchanged: true, [siteKey]: normalized };
    }

    const updatedAtKey = siteKey + '_updated_at_ms';
    const next = {
        ...current,
        [siteKey]: normalized,
        [updatedAtKey]: Date.now()
    };
    await storage.set({ [KEYS.fantasy_site_usernames]: next });
    return { stored: true, [siteKey]: normalized };
}

async function clear_fantasy_site_username(site) {
    const siteKey = fantasy_site_username_key(site);
    if (!siteKey) {
        return { cleared: false, reason: 'unknown_site' };
    }

    const current = await get_fantasy_site_usernames();
    if (!current[siteKey]) {
        return { cleared: false, unchanged: true, [siteKey]: null };
    }

    const updatedAtKey = siteKey + '_updated_at_ms';
    const next = {
        ...current,
        [siteKey]: null,
        [updatedAtKey]: Date.now()
    };
    await storage.set({ [KEYS.fantasy_site_usernames]: next });
    return { cleared: true, [siteKey]: null };
}

function detect_by_scheme() {
    const url = chrome.runtime.getURL('');
    if (url.startsWith('moz-extension://')) return 'Firefox';
    if (url.startsWith('chrome-extension://')) return 'Chrome';
    return 'Unknown';
}


function default_session_data() {
    return {
        user_uuid: null,
        allow_rankings: null,
        reason: null,
        tier: null,
        validated_at: null,
        validation_expires_at: null,
        app_jwt: null,
        app_jwt_expires_at: null,
        ghost_jwt: null,
        ghost_jwt_expires_at: null,
        email: null
    };
}

function is_session_data_corrupted(session) {
    if (!session) return false;
    if (!session.user_uuid || typeof session.user_uuid !== 'string' || session.user_uuid.length === 0) {
        return false;
    }
    const hasCriticalFields =
        session.hasOwnProperty('allow_rankings') &&
        session.hasOwnProperty('reason');
    if (hasCriticalFields) {
        return false;
    }
    // Fresh logins store user_uuid before validation fills allow_rankings/reason.
    const looksValidated = !!(session.app_jwt || session.validated_at);
    return looksValidated;
}

let sessionRecoveryInProgress = false;

function session_needs_validation(session) {
    if (!session?.user_uuid) return false;
    return !session.hasOwnProperty('allow_rankings') || !session.hasOwnProperty('reason');
}

function schedule_session_recovery_async() {
    if (sessionRecoveryInProgress) return;
    recover_session_data().catch((err) => {
        console.error('[auth] async session recovery failed', err);
    });
}

function schedule_session_repair_if_needed(session) {
    if (is_session_data_corrupted(session)) {
        console.error('[auth] CORRUPTION DETECTED: Session data has user_uuid but missing critical fields', {
            has_user_uuid: !!session.user_uuid,
            has_allow_rankings: session.hasOwnProperty('allow_rankings'),
            has_reason: session.hasOwnProperty('reason'),
            has_app_jwt: !!session.app_jwt,
            has_validated_at: !!session.validated_at
        });
        schedule_session_recovery_async();
    } else if (session_needs_validation(session)) {
        schedule_auth_retry(0);
    }
}

function sanitize_session_fields(obj) {
    if (!obj || typeof obj !== 'object') {
        return { session: obj, changed: false };
    }
    const sanitized = { ...obj };
    let changed = false;

    if (Object.prototype.hasOwnProperty.call(sanitized, 'jwt')) {
        if (!sanitized.ghost_jwt && sanitized.jwt) {
            sanitized.ghost_jwt = sanitized.jwt;
            changed = true;
        }
        delete sanitized.jwt;
        changed = true;
    }
    if (sanitized.ghost_jwt && !sanitized.ghost_jwt_expires_at) {
        const ghostExp = decode_jwt_expires_at(sanitized.ghost_jwt);
        if (ghostExp) {
            sanitized.ghost_jwt_expires_at = ghostExp;
            changed = true;
        }
    }
    if (Object.prototype.hasOwnProperty.call(sanitized, 'token')) {
        if (!sanitized.app_jwt && sanitized.token) {
            sanitized.app_jwt = sanitized.token;
            changed = true;
        }
        delete sanitized.token;
        changed = true;
    }
    if (Object.prototype.hasOwnProperty.call(sanitized, 'token_expires_at')) {
        if (!sanitized.app_jwt_expires_at && sanitized.token_expires_at) {
            sanitized.app_jwt_expires_at = sanitized.token_expires_at;
            changed = true;
        }
        delete sanitized.token_expires_at;
        changed = true;
    }
    if (!sanitized.user_uuid && sanitized.uuid) {
        sanitized.user_uuid = sanitized.uuid;
        changed = true;
    }
    return { session: sanitized, changed };
}

async function read_session_data_from_storage() {
    const res = await storage.get(KEYS.session_data);
    if (res && res[KEYS.session_data]) {
        const { session, changed } = sanitize_session_fields(res[KEYS.session_data]);
        if (changed) {
            storage.set({ [KEYS.session_data]: session }).catch((err) => {
            });
        }
        return session;
    }
    return default_session_data();
}

async function recover_session_data() {
    if (sessionRecoveryInProgress) {
        return await read_session_data_from_storage();
    }
    sessionRecoveryInProgress = true;
    try {
        const session = await read_session_data_from_storage();
        if (session?.user_uuid) {
            const recovered = await validate_session_via_http();
            if (recovered) {
                return recovered;
            }
        }
        return session || default_session_data();
    } catch (err) {
        console.error('[auth] RECOVERY: Failed to recover session data', err);
        return default_session_data();
    } finally {
        sessionRecoveryInProgress = false;
    }
}

async function get_session_data() {
    const session = await read_session_data_from_storage();
    if (session?.ghost_jwt && !session.ghost_jwt_expires_at) {
        const ghostExp = decode_jwt_expires_at(session.ghost_jwt);
        if (ghostExp) {
            session.ghost_jwt_expires_at = ghostExp;
            set_session_data({ ghost_jwt_expires_at: ghostExp }, { merge: true }).catch((err) => {
            });
        }
    }
    schedule_session_repair_if_needed(session);
    return session;
}

async function set_session_data(obj, options = {}) {
    let sanitized = null;
    if (obj && typeof obj === 'object') {
        sanitized = sanitize_session_fields(obj).session;
    }
    if (options.merge && sanitized) {
        const res = await storage.get(KEYS.session_data);
        const existing = res && res[KEYS.session_data];
        if (existing && typeof existing === 'object') {
            // Re-sanitize after merge so legacy keys on either side are remapped once.
            sanitized = sanitize_session_fields({ ...existing, ...sanitized }).session;
        }
    }
    await storage.set({ [KEYS.session_data]: sanitized });
    if (sanitized?.app_jwt_expires_at) {
        schedule_app_jwt_refresh();
    } else {
        clear_app_jwt_refresh_alarm();
    }
    return sanitized;
}

async function reset_session_auth_for_client_auth_migration() {
    clear_app_jwt_refresh_alarm();
    const latest = await read_session_data_from_storage();
    if (!latest?.user_uuid) {
        return latest || default_session_data();
    }
    // Keep identity + Ghost JWT when present so Path A can remint app JWT after tab refresh.
    // Drop app JWT and rankings gate so ensure_valid_app_jwt / validate must run again.
    const next = {
        ...latest,
        allow_rankings: null,
        reason: null,
        app_jwt: null,
        app_jwt_expires_at: null,
        validated_at: null,
        validation_expires_at: null,
    };
    await set_session_data(next);
    notify_auth_status(next);
    return next;
}

function compute_server_address(bg) {
    const env = bg.env || BASE_BG.env;
    // If env is unknown, fall back to prod.
    const host = BASE_BG.server_address_by_env[env] ?? BASE_BG.server_address_by_env.prod;
    return host;
}

function http_base_url(bg) {
    const host = compute_server_address(bg);
    const isLocal = (bg.env === 'local') || host.startsWith('localhost') || host.startsWith('127.0.0.1');
    const scheme = isLocal ? 'http' : 'https';
    return `${scheme}://${host}${bg.api_base_path}`;
}

async function upsert_session_via_http(session, ghostJwt) {
    const user_uuid = session?.user_uuid;
    if (!user_uuid || !ghostJwt) {
        return { skipped: true, reason: 'missing user_uuid or ghost jwt' };
    }

    const payload = {
        uuid: user_uuid,
        user_uuid,
        jwt: ghostJwt,
        email: session.email || null,
        subscriptions: Array.isArray(session.subscriptions) ? session.subscriptions : [],
        extension_version: get_extension_version()
    };
    if (session.last_validated != null) {
        payload.last_validated = session.last_validated;
    }

    const env = (typeof BASE_BG !== 'undefined' && BASE_BG && BASE_BG.env) ? BASE_BG.env : 'prod';
    if (['dev', 'local'].includes(env)) {
        const temp = {
            user_uuid,
            has_email: !!payload.email,
            subscription_count: payload.subscriptions.length,
            last_validated: payload.last_validated ?? null
        };
    }

    const response = await make_http_request('/session', {
        method: 'POST',
        body: payload,
        ensureConfig: false
    });
    return { skipped: false, response };
}

async function sync_session_with_backend(options = {}) {
    const session = await read_session_data_from_storage();
    const ghostJwt = options.ghostJwt || session?.ghost_jwt || null;

    if (ghostJwt && session?.user_uuid) {
        await upsert_session_via_http(session, ghostJwt);
        // Only register when no secret yet. force:true rotates instance_secret and races
        // concurrent /config proofs (Invalid instance proof). Re-register on config 401/403 instead.
        if (typeof register_install_instance === 'function') {
            try {
                await register_install_instance({
                    userUuid: session.user_uuid,
                    ghostJwt,
                    force: false
                });
            } catch (err) {
                if (BASE_BG.env !== 'prod') {
                    const log_data = {
                        status: err?.status || null,
                        message: err?.message || String(err)
                    };
                }
            }
        }
    }

    return await refresh_app_jwt({
        ghostJwt,
        preferGhost: !!ghostJwt,
    });
}

function auth_reason_session_window_expired() {
    return (typeof AUTH_REASON !== 'undefined' && AUTH_REASON.session_window_expired)
        ? AUTH_REASON.session_window_expired
        : 'auth:session_window_expired';
}

function auth_reason_app_jwt_expired() {
    return (typeof AUTH_REASON !== 'undefined' && AUTH_REASON.app_jwt_expired)
        ? AUTH_REASON.app_jwt_expired
        : 'auth:app_jwt_expired';
}

function auth_reason_tokens_missing() {
    return (typeof AUTH_REASON !== 'undefined' && AUTH_REASON.tokens_missing)
        ? AUTH_REASON.tokens_missing
        : 'auth:tokens_missing';
}

function auth_reason_refresh_failed() {
    return (typeof AUTH_REASON !== 'undefined' && AUTH_REASON.refresh_failed)
        ? AUTH_REASON.refresh_failed
        : 'auth:refresh_failed';
}

function auth_reason_user_not_found() {
    return (typeof AUTH_REASON !== 'undefined' && AUTH_REASON.user_not_found)
        ? AUTH_REASON.user_not_found
        : 'auth:user_not_found';
}

// Legacy aliases — prefer the auth_reason_* helpers at new call sites.
function ghost_jwt_missing_reason() {
    return auth_reason_tokens_missing();
}

function ghost_jwt_expired_reason() {
    return auth_reason_app_jwt_expired();
}

// Refresh well before expiry so rankings rarely hit the fully-expired path.
// chrome.alarms (not setTimeout) so MV3 SW sleep cannot drop the schedule.
// Chrome clamps/rejects sub-minute alarms — keep delay/period >= 1.
// Period matches pre-a252d82 (30m). Never re-arm a short delay on every SW wake
// while past skew — that caused the Chrome service-worker thrash loop.
const APP_JWT_REFRESH_SKEW_MS = 30 * 60 * 1000;
const APP_JWT_REFRESH_ALARM = 'app_jwt_refresh';
const APP_JWT_REFRESH_PERIOD_MINUTES = 30;
const APP_JWT_REFRESH_MIN_DELAY_MINUTES = 1;
const GHOST_JWT_REFRESH_BUFFER_MS = 30 * 60 * 1000;
let lastGhostRefreshRequestMs = 0;
const GHOST_REFRESH_REQUEST_COOLDOWN_MS = 60 * 1000;
let appJwtRefreshInFlight = null;
let scheduledAppJwtRefreshFailures = 0;
const MAX_SCHEDULED_APP_JWT_REFRESH_FAILURES = 6;
let appJwtRefreshAlarmListenerBound = false;

function decode_jwt_expires_at(token) {
    if (!token || typeof token !== 'string') return null;
    const parts = token.split('.');
    if (parts.length !== 3) return null;
    try {
        const base64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
        const pad = base64.length % 4;
        const padded = base64 + (pad ? '='.repeat(4 - pad) : '');
        const payload = JSON.parse(atob(padded));
        if (!payload?.exp) return null;
        return new Date(Number(payload.exp) * 1000).toISOString();
    } catch (err) {
        return null;
    }
}

function is_ghost_jwt_expired(ghostJwt, session) {
    if (!ghostJwt) return true;
    const expIso = (session?.ghost_jwt === ghostJwt && session.ghost_jwt_expires_at)
        ? session.ghost_jwt_expires_at
        : decode_jwt_expires_at(ghostJwt);
    if (!expIso) return false;
    const expMs = Date.parse(expIso);
    if (Number.isNaN(expMs)) return false;
    return Date.now() >= expMs;
}

function auth_error_detail(err) {
    const body = err?.responseBody;
    if (body && typeof body === 'object') {
        return String(body.detail || body.message || '').trim();
    }
    return err?.message || '';
}

function is_session_expired_auth_error(err) {
    if (err?.status !== 401) return false;
    const detail = auth_error_detail(err).toLowerCase();
    return detail.includes('session expired') || detail.includes('sign in at legendaryupside.com');
}

function is_rankings_subscription_error(err) {
    if (err?.status !== 403) return false;
    const detail = auth_error_detail(err).toLowerCase();
    return detail.includes('sidekick') || detail.includes('subscription') || detail.includes('rankings require');
}

function app_jwt_expiry_ms(token, expiresAtIso) {
    let expMs = null;
    if (expiresAtIso) {
        const parsed = Date.parse(expiresAtIso);
        if (!Number.isNaN(parsed)) {
            expMs = parsed;
        }
    }
    const fromJwt = decode_jwt_expires_at(token);
    if (fromJwt) {
        const jwtMs = Date.parse(fromJwt);
        if (!Number.isNaN(jwtMs)) {
            expMs = expMs == null ? jwtMs : Math.min(expMs, jwtMs);
        }
    }
    return expMs;
}

function is_app_jwt_fully_expired(session) {
    if (!session?.app_jwt) return true;
    const expMs = app_jwt_expiry_ms(session.app_jwt, session.app_jwt_expires_at);
    if (expMs == null) return false;
    return Date.now() >= expMs;
}

function is_app_jwt_near_expiration(session) {
    const expiresAt = session?.app_jwt_expires_at;
    if (!expiresAt) return false;
    const expMs = Date.parse(expiresAt);
    if (Number.isNaN(expMs)) return false;
    return (expMs - Date.now()) <= APP_JWT_REFRESH_SKEW_MS;
}

function is_jwt_near_expiration(session) {
    return is_app_jwt_near_expiration(session) || is_app_jwt_fully_expired(session);
}

function clear_app_jwt_refresh_alarm() {
    if (!chrome.alarms || !chrome.alarms.clear) {
        return;
    }
    try {
        chrome.alarms.clear(APP_JWT_REFRESH_ALARM);
    } catch (err) {
    }
}

function ensure_app_jwt_refresh_alarm_listener() {
    if (appJwtRefreshAlarmListenerBound) {
        return;
    }
    if (!chrome.alarms || !chrome.alarms.onAlarm) {
        return;
    }
    chrome.alarms.onAlarm.addListener((alarm) => {
        if (alarm?.name !== APP_JWT_REFRESH_ALARM) {
            return;
        }
        handle_app_jwt_refresh_alarm().catch((err) => {
            console.error('[auth] app JWT refresh alarm handler failed', err);
        });
    });
    appJwtRefreshAlarmListenerBound = true;
}

// Register synchronously at SW load so Chrome does not miss early alarm events.
ensure_app_jwt_refresh_alarm_listener();

async function handle_app_jwt_refresh_alarm() {
    const session = await read_session_data_from_storage();
    if (!session?.user_uuid || !session?.app_jwt) {
        clear_app_jwt_refresh_alarm();
        return;
    }
    try {
        const refreshed = await refresh_app_jwt();
        if (!refreshed?.app_jwt || is_app_jwt_fully_expired(refreshed)) {
            scheduledAppJwtRefreshFailures += 1;
            if (BASE_BG.env !== 'prod') {
                const log_data = { failures: scheduledAppJwtRefreshFailures };
            }
            // Keep drafting on a still-valid JWT; only hard-fail once it is fully expired.
            const stillUsable = session.app_jwt && !is_app_jwt_fully_expired(session);
            if (stillUsable) {
                schedule_auth_retry();
                return;
            }
            if (scheduledAppJwtRefreshFailures >= MAX_SCHEDULED_APP_JWT_REFRESH_FAILURES) {
                scheduledAppJwtRefreshFailures = 0;
                clear_app_jwt_refresh_alarm();
                await invalidate_stale_auth_session(
                    refreshed || session,
                    auth_reason_refresh_failed()
                );
                return;
            }
            schedule_auth_retry();
            return;
        }
        scheduledAppJwtRefreshFailures = 0;
        // set_session_data after validate re-arms the alarm from the new expiry.
        schedule_app_jwt_refresh();
    } catch (err) {
        scheduledAppJwtRefreshFailures += 1;
        console.error('[auth] scheduled app JWT refresh failed', err);
        if (session.app_jwt && !is_app_jwt_fully_expired(session)) {
            schedule_auth_retry();
            return;
        }
        if (scheduledAppJwtRefreshFailures >= MAX_SCHEDULED_APP_JWT_REFRESH_FAILURES) {
            scheduledAppJwtRefreshFailures = 0;
            clear_app_jwt_refresh_alarm();
            try {
                await invalidate_stale_auth_session(session, auth_reason_refresh_failed());
            } catch (invalidateErr) {
                console.error('[auth] invalidate after scheduled refresh failed', invalidateErr);
            }
            return;
        }
        schedule_auth_retry();
    }
}

function get_app_jwt_refresh_alarm() {
    if (!chrome.alarms || !chrome.alarms.get) {
        return Promise.resolve(undefined);
    }
    try {
        const result = chrome.alarms.get(APP_JWT_REFRESH_ALARM);
        if (result && typeof result.then === 'function') {
            return result.catch(() => undefined);
        }
        return new Promise((resolve) => {
            try {
                chrome.alarms.get(APP_JWT_REFRESH_ALARM, (alarm) => resolve(alarm));
            } catch (err) {
                resolve(undefined);
            }
        });
    } catch (err) {
        return Promise.resolve(undefined);
    }
}

function create_app_jwt_refresh_alarm(delayMinutes) {
    try {
        const created = chrome.alarms.create(APP_JWT_REFRESH_ALARM, {
            delayInMinutes: delayMinutes,
            periodInMinutes: APP_JWT_REFRESH_PERIOD_MINUTES
        });
        if (created && typeof created.then === 'function') {
            created.catch((err) => {
                console.error('[auth] chrome.alarms.create failed', err);
            });
        }
        return true;
    } catch (err) {
        console.error('[auth] chrome.alarms.create threw', err);
        return false;
    }
}

function schedule_app_jwt_refresh() {
    ensure_app_jwt_refresh_alarm_listener();
    if (!chrome.alarms || !chrome.alarms.create) {
        return;
    }
    read_session_data_from_storage().then(async (session) => {
        if (!session?.user_uuid || !session?.app_jwt || !session?.app_jwt_expires_at) {
            clear_app_jwt_refresh_alarm();
            return;
        }
        const expMs = Date.parse(session.app_jwt_expires_at);
        if (Number.isNaN(expMs)) {
            clear_app_jwt_refresh_alarm();
            return;
        }
        // First fire at expiry-skew when still ahead of skew. Once past skew, do not
        // recreate a short delayInMinutes on every SW boot — that woke Chrome ~1/min.
        const msUntilSkew = expMs - APP_JWT_REFRESH_SKEW_MS - Date.now();
        let delayMinutes;
        if (msUntilSkew <= 0) {
            const existing = await get_app_jwt_refresh_alarm();
            if (existing) {
                return;
            }
            delayMinutes = APP_JWT_REFRESH_PERIOD_MINUTES;
        } else {
            delayMinutes = Math.min(
                APP_JWT_REFRESH_PERIOD_MINUTES,
                Math.max(APP_JWT_REFRESH_MIN_DELAY_MINUTES, msUntilSkew / 60000)
            );
        }
        if (!create_app_jwt_refresh_alarm(delayMinutes)) {
            return;
        }
        if (BASE_BG.env !== 'prod') {
            const log_data = {
                delay_minutes: delayMinutes,
                period_minutes: APP_JWT_REFRESH_PERIOD_MINUTES,
                skew_minutes: APP_JWT_REFRESH_SKEW_MS / 60000,
                past_skew: msUntilSkew <= 0
            };
        }
    }).catch((err) => {
    });
}

function is_ghost_jwt_near_expiration(session) {
    const expiresAt = session?.ghost_jwt_expires_at;
    if (!expiresAt) {
        return false;
    }
    const expMs = Date.parse(expiresAt);
    if (Number.isNaN(expMs)) {
        return false;
    }
    return (expMs - Date.now()) <= GHOST_JWT_REFRESH_BUFFER_MS;
}

function ghost_jwt_needs_refresh(session) {
    if (!session?.ghost_jwt) {
        return true;
    }
    const expiresAt = session.ghost_jwt_expires_at;
    if (!expiresAt) {
        return false;
    }
    const expMs = Date.parse(expiresAt);
    if (Number.isNaN(expMs)) {
        return false;
    }
    return Date.now() >= expMs;
}

function request_ghost_session_refresh() {
    const now = Date.now();
    if (now - lastGhostRefreshRequestMs < GHOST_REFRESH_REQUEST_COOLDOWN_MS) {
        return false;
    }
    lastGhostRefreshRequestMs = now;
    if (typeof notify_content_scripts === 'function') {
        notify_content_scripts('REFRESH_GHOST_SESSION', {});
    }
    return true;
}

async function invalidate_stale_auth_session(session, reason) {
    clear_app_jwt_refresh_alarm();
    if (typeof clearStaleRankingsWork === 'function') {
        try {
            clearStaleRankingsWork({ reason: 'auth_invalidated' });
        } catch (clearErr) {
        }
    }
    const latest = await read_session_data_from_storage();
    const next = {
        ...latest,
        ...(session || {}),
        allow_rankings: false,
        reason: reason || auth_reason_tokens_missing(),
        app_jwt: null,
        app_jwt_expires_at: null,
    };
    await set_session_data(next);
    notify_auth_status(next);
    request_ghost_session_refresh();
    schedule_auth_retry();
    return next;
}

async function ensure_ghost_session_fresh() {
    const session = await read_session_data_from_storage();
    if (!session?.user_uuid) {
        return session;
    }
    if (!ghost_jwt_needs_refresh(session) && !is_ghost_jwt_near_expiration(session)) {
        return session;
    }
    request_ghost_session_refresh();
    return session;
}

async function apply_validate_response(response) {
    const validationResponseData = {
        allow_rankings: response.allow_rankings,
        reason: response.reason,
        tier: response.tier,
        validated_at: response.validated_at,
        validation_expires_at: response.validation_expires_at,
        has_token: !!response.token,
        has_email: !!response.email
    };

    const latest = await read_session_data_from_storage();
    const next = {
        ...latest,
        allow_rankings: response.allow_rankings,
        reason: response.reason,
        tier: normalize_tier(response.tier)
    };

    if (Object.prototype.hasOwnProperty.call(response, 'validated_at')) {
        next.validated_at = response.validated_at ?? null;
    }
    if (Object.prototype.hasOwnProperty.call(response, 'validation_expires_at')) {
        next.validation_expires_at = response.validation_expires_at ?? null;
    } else if (next.validated_at == null) {
        next.validation_expires_at = null;
    }

    if (response.email) {
        next.email = response.email;
    }

    if (response.token) {
        next.app_jwt = response.token;
        next.app_jwt_expires_at = response.token_expires_at || null;
    } else if (!response.allow_rankings) {
        next.app_jwt = null;
        next.app_jwt_expires_at = null;
    }

    await set_session_data(next);
    notify_auth_status(next);
    handledAuthFailureStreak = 0;
    if (authRetryTimer) {
        clearTimeout(authRetryTimer);
        authRetryTimer = null;
    }
    const uid = next.user_uuid || '';
    const fetchedFor = configState.remote_config_fetched_for_user_uuid;
    if (uid && fetchedFor !== uid) {
        refresh_config().catch((err) => {
            console.error('[auth] refresh_config after session validation failed', err);
        });
    }
    return next;
}

async function handle_auth_failure(err, session) {
    const latest = await read_session_data_from_storage();
    const base = { ...latest, ...(session || {}) };

    if (err?.status === 400) {
        console.error('[auth] 400 on /auth/validate — must send Bearer app JWT or ghost jwt in body');
        schedule_auth_retry_backoff();
        return null;
    }

    if (err?.status === 401) {
        const reason = is_session_expired_auth_error(err)
            ? auth_reason_session_window_expired()
            : auth_reason_tokens_missing();
        const next = {
            ...base,
            allow_rankings: false,
            reason,
            app_jwt: null,
            app_jwt_expires_at: null,
        };
        if (is_session_expired_auth_error(err)) {
            next.ghost_jwt = null;
            next.ghost_jwt_expires_at = null;
        }
        await set_session_data(next);
        notify_auth_status(next);
        request_ghost_session_refresh();
        schedule_auth_retry_backoff();
        return next;
    }

    if (err?.status === 403) {
        if (is_rankings_subscription_error(err)) {
            const next = {
                ...base,
                allow_rankings: false,
                reason: auth_error_detail(err) || 'Sidekick subscription required for rankings',
            };
            await set_session_data(next);
            notify_auth_status(next);
            return next;
        }
        clear_app_jwt_refresh_alarm();
        await storage.remove(KEYS.session_data);
        notify_auth_status(null);
        schedule_auth_retry_backoff();
        return null;
    }

    if (err?.status === 404) {
        const next = {
            ...base,
            allow_rankings: false,
            reason: auth_reason_user_not_found(),
            tier: null,
            validated_at: null,
            validation_expires_at: null,
            app_jwt: null,
            app_jwt_expires_at: null
        };
        await set_session_data(next);
        notify_auth_status(next);
        schedule_auth_retry_backoff();
        return next;
    }

    return undefined;
}

async function refresh_app_jwt(options = {}) {
    // Coalesce concurrent refresh callers (polls + timer + rankings) onto one validate.
    if (appJwtRefreshInFlight && !options._bypassSingleFlight) {
        return appJwtRefreshInFlight;
    }

    const run = (async () => {
        const session = await read_session_data_from_storage();
        const userUuid = options.userUuid || session?.user_uuid;
        const ghostJwt = options.ghostJwt || session?.ghost_jwt || null;
        const appJwt = options.appJwt || session?.app_jwt || null;
        const preferGhost = !!options.preferGhost;

        if (!userUuid) {
            notify_auth_status(session || null);
            schedule_auth_retry();
            return null;
        }

        if (typeof userUuid !== 'string' || userUuid.length === 0) {
            console.error('[auth] refresh_app_jwt: invalid user_uuid', { user_uuid: userUuid });
            clear_app_jwt_refresh_alarm();
            await storage.remove(KEYS.session_data);
            notify_auth_status(null);
            return null;
        }

        const appJwtExpired = is_app_jwt_fully_expired({
            app_jwt: appJwt,
            app_jwt_expires_at: session?.app_jwt_expires_at
        });
        const ghostExpired = is_ghost_jwt_expired(ghostJwt, session);
        const headers = {};
        const body = {
            user_uuid: userUuid,
            extension_version: get_extension_version()
        };
        let pathLabel = 'A';

        if (!preferGhost && appJwt && !appJwtExpired) {
            headers.Authorization = `Bearer ${appJwt}`;
            pathLabel = 'B';
        } else if (ghostJwt && !ghostExpired) {
            body.jwt = ghostJwt;
            pathLabel = 'A';
        } else if (appJwt) {
            // An expired app JWT is still an authentic refresh credential: Path B
            // verifies its signature plus the 48h last_validated window, and only
            // 401s "Session expired" once that window has truly lapsed. This is the
            // overnight-gap recovery path — never a soft legacy fallback (backend
            // Path B strictly 401s since 2.2.50 attestation).
            headers.Authorization = `Bearer ${appJwt}`;
            pathLabel = 'B';
            if (appJwtExpired) {
            }
        } else if (ghostJwt) {
            // Expired Ghost JWT and no app JWT at all — let the backend reject it so
            // the failure reason/telemetry come from the server, then re-prompt.
            body.jwt = ghostJwt;
            pathLabel = 'A';
        } else {
            // Never POST /auth/validate with user_uuid alone (2.2.50+ attestation).
            return await invalidate_stale_auth_session(session, auth_reason_tokens_missing());
        }


        async function maybe_register_instance_after_ghost_validate() {
            if (!ghostJwt || typeof register_install_instance !== 'function') {
                return;
            }
            try {
                await register_install_instance({
                    userUuid,
                    ghostJwt,
                    force: false
                });
            } catch (err) {
                if (BASE_BG.env !== 'prod') {
                    const log_data = {
                        status: err?.status || null,
                        message: err?.message || String(err)
                    };
                }
            }
        }

        try {
            const response = await make_http_request('/auth/validate', {
                method: 'POST',
                body,
                headers,
                ensureConfig: false
            });
            // Permissive backend may soft-fall back to legacy and still 200. Prefer a real
            // Ghost Path A when available so last_validated is refreshed for strict mode later.
            if (
                pathLabel === 'B'
                && response?.auth_path === 'legacy_fallback'
                && ghostJwt
                && !options._legacyFallbackRetried
            ) {
                return await refresh_app_jwt({
                    ...options,
                    userUuid,
                    ghostJwt,
                    preferGhost: true,
                    _legacyFallbackRetried: true,
                    _bypassSingleFlight: true
                });
            }
            const next = await apply_validate_response(response);
            if (pathLabel === 'A') {
                await maybe_register_instance_after_ghost_validate();
            }
            return next;
        } catch (err) {
            // Only retry Path A with a still-valid Ghost JWT. Replaying an expired one
            // is doomed and would mask a true "Session expired" 401 (which must clear
            // the Ghost JWT and prompt sign-in) with a generic JWT-validation failure.
            if (pathLabel === 'B' && err?.status === 401 && ghostJwt && !ghostExpired) {
                try {
                    const response = await make_http_request('/auth/validate', {
                        method: 'POST',
                        body: {
                            user_uuid: userUuid,
                            jwt: ghostJwt,
                            extension_version: get_extension_version()
                        },
                        ensureConfig: false
                    });
                    const next = await apply_validate_response(response);
                    await maybe_register_instance_after_ghost_validate();
                    return next;
                } catch (retryErr) {
                    const handled = await handle_auth_failure(retryErr, session);
                    if (handled !== undefined) {
                        return handled;
                    }
                    throw retryErr;
                }
            }
            const handled = await handle_auth_failure(err, session);
            if (handled !== undefined) {
                return handled;
            }
            throw err;
        }
    })();

    if (!options._bypassSingleFlight) {
        // Track the finally-wrapped promise, not `run`. Comparing inFlight to `run`
        // never cleared the slot (Promise.finally returns a new promise), so the first
        // boot refresh (missing user_uuid → null) poisoned every later validate until SW restart.
        const tracked = run.finally(() => {
            if (appJwtRefreshInFlight === tracked) {
                appJwtRefreshInFlight = null;
            }
        });
        appJwtRefreshInFlight = tracked;
        return tracked;
    }
    return run;
}

async function validate_session_via_http() {
    return await refresh_app_jwt();
}

async function ensure_valid_app_jwt() {
    const session = await get_session_data();
    if (!session?.user_uuid) {
        return session;
    }
    if (session.app_jwt && !is_app_jwt_near_expiration(session) && !is_app_jwt_fully_expired(session)) {
        return session;
    }
    const recoveringFromExpired = !session.app_jwt || is_app_jwt_fully_expired(session);
    const keepUsableSession = () => {
        // Near-expiry refresh failed, but the current Bearer is still valid — do not
        // kick the user out of a live draft for a transient Path B miss.
        // Do not re-arm the refresh alarm here: with near-expiry tokens that used to
        // schedule delayInMinutes < 1 and thrash Chrome's service worker.
        scheduledAppJwtRefreshFailures += 1;
        schedule_auth_retry();
        return session;
    };
    try {
        const refreshed = await refresh_app_jwt();
        if (refreshed?.app_jwt && !is_app_jwt_fully_expired(refreshed)) {
            scheduledAppJwtRefreshFailures = 0;
            if (recoveringFromExpired && typeof clearStaleRankingsWork === 'function') {
                try {
                    clearStaleRankingsWork({ reason: 'auth_recovered_from_expired' });
                } catch (clearErr) {
                }
            }
            return refreshed;
        }
        // refresh_app_jwt may already have invalidated with a more specific reason
        // (true session-window expiry, missing tokens, etc.) — honor that.
        if (refreshed && refreshed.allow_rankings === false && refreshed.reason) {
            return refreshed;
        }
        if (!recoveringFromExpired && session.app_jwt && !is_app_jwt_fully_expired(session)) {
            return keepUsableSession();
        }
        return await invalidate_stale_auth_session(
            refreshed || session,
            auth_reason_refresh_failed()
        );
    } catch (err) {
        console.error('[auth] ensure_valid_app_jwt failed', err);
        if (!recoveringFromExpired && session.app_jwt && !is_app_jwt_fully_expired(session)) {
            return keepUsableSession();
        }
        return await invalidate_stale_auth_session(session, auth_reason_refresh_failed());
    }
}

async function make_http_request(path, options = {}) {
    const ensureConfig = options.ensureConfig !== false;
    const bg = await resolve_background_settings({ ensureConfig });
    let base = http_base_url(bg);
    if (options.useProdUrl) {
        const prodHost = BASE_BG.server_address_by_env.prod;
        base = `https://${prodHost}${bg.api_base_path}`;
    }
    const url = `${base}${path}`;
    const requestData = {
        path,
        base,
        payload: options.body,
        env: bg.env
    };
    try {
        return await fetch_json(url, { ...options, logLabel: `(${path})` });
    } catch (err) {
        console.error(`[make_http_request] error for ${path}`, {
            url,
            method: options.method || 'GET',
            payload: options.body,
            error: err.message,
            stack: err.stack
        });
        throw err;
    }
}

let authRetryTimer = null;
let handledAuthFailureStreak = 0;

// Backoff for retries after a *handled* auth failure (4xx we mapped to a reason).
// Those resolve without throwing, so schedule_auth_retry's own catch-based
// escalation never kicks in and a constant 5s loop would replay the same doomed
// validate against the backend indefinitely.
function schedule_auth_retry_backoff() {
    handledAuthFailureStreak += 1;
    const delay = Math.min(5000 * (2 ** (handledAuthFailureStreak - 1)), 60000);
    schedule_auth_retry(delay);
}

function schedule_auth_retry(delayMs = 5000) {
    if (authRetryTimer) return;
    authRetryTimer = setTimeout(async () => {
        authRetryTimer = null;
        try {
            await validate_session_via_http();
        } catch (err) {
            console.error('[schedule_auth_retry] retry failed', err);
            const nextDelay = Math.min(delayMs * 2, 60000);
            schedule_auth_retry(nextDelay);
        }
    }, delayMs);
}

function notify_auth_status(session_data) {
    const normalized = { ...(session_data || {}) };
    if (!Object.prototype.hasOwnProperty.call(normalized, 'user_uuid')) {
        normalized.user_uuid = null;
    }
    if (!Object.prototype.hasOwnProperty.call(normalized, 'allow_rankings')) {
        normalized.allow_rankings = null;
    }
    if (!Object.prototype.hasOwnProperty.call(normalized, 'reason')) {
        normalized.reason = null;
    }
    if (!Object.prototype.hasOwnProperty.call(normalized, 'app_jwt')) {
        normalized.app_jwt = null;
    }
    if (!Object.prototype.hasOwnProperty.call(normalized, 'app_jwt_expires_at')) {
        normalized.app_jwt_expires_at = null;
    }
    if (!Object.prototype.hasOwnProperty.call(normalized, 'email')) {
        normalized.email = null;
    }
    if (!Object.prototype.hasOwnProperty.call(normalized, 'tier')) {
        normalized.tier = null;
    } else {
        normalized.tier = normalize_tier(normalized.tier);
    }
    if (!Object.prototype.hasOwnProperty.call(normalized, 'validated_at')) {
        normalized.validated_at = null;
    }
    if (!Object.prototype.hasOwnProperty.call(normalized, 'validation_expires_at')) {
        normalized.validation_expires_at = null;
    }

    // console.log("[notify_auth_status]", normalized);
    state.auth_status_data = normalized;
    if (state.popup_port) {
        state.popup_port.postMessage({ action: 'UPDATE_SESSION_DATA', session_data: normalized });
    }

    const { message, type } = compute_session_auth_notification(normalized);

    // console.log("[notify_auth_status] Message: ", message, "Type: ", type);
    broadcast_notification(message, type, normalized);
    sync_extension_action_icon(normalized).catch((err) => {
        console.error('[auth] sync_extension_action_icon failed after notify_auth_status', err);
    });
}

function broadcast_notification(message, type = 'auth_error', session_data = null) {
    if (state.last_auth_message === message && state.last_auth_type === type) return;
    state.last_auth_message = message;
    state.last_auth_type = type;

    for (const [, port] of contentPorts) {
        try {
            const payload = { action: 'UPDATE_NOTIFICATION', message, type };
            if (session_data) {
                payload.session_data = session_data;
            }
            port.postMessage(payload);
        } catch (err) {
        }
    }
}


async function get_auth_status_from_backend() {
    try {
        await validate_session_via_http();
    } catch (err) {
        console.error('[get_auth_status_from_backend] failed', err);
        schedule_auth_retry();
    }
}


async function refresh_session_if_needed() {
    return await ensure_valid_app_jwt();
}

async function make_http_request_with_auth_retry(path, options = {}) {
    let session = await ensure_valid_app_jwt();
    const headers = { ...(options.headers || {}) };
    if (session?.app_jwt && !headers.Authorization) {
        headers.Authorization = `Bearer ${session.app_jwt}`;
    }
    // 2.2.50+: authenticated APIs (rankings, exposure, uploads) must not go out without Bearer app JWT.
    if (!headers.Authorization) {
        const alreadySet = session?.allow_rankings === false && session?.reason;
        if (!alreadySet) {
            await invalidate_stale_auth_session(session, auth_reason_tokens_missing());
        }
        const err = new Error(`Authenticated request to ${path} requires app JWT`);
        err.status = 401;
        throw err;
    }
    try {
        return await make_http_request(path, { ...options, headers });
    } catch (err) {
        if (err?.status !== 401 || options._authRetried) {
            throw err;
        }
        const refreshed = await refresh_app_jwt();
        if (!refreshed?.app_jwt) {
            if (!(refreshed && refreshed.allow_rankings === false && refreshed.reason)) {
                await invalidate_stale_auth_session(session, auth_reason_refresh_failed());
            }
            throw err;
        }
        const retryHeaders = {
            ...(options.headers || {}),
            Authorization: `Bearer ${refreshed.app_jwt}`,
        };
        return await make_http_request(path, { ...options, headers: retryHeaders, _authRetried: true });
    }
}

let installInstanceRegisterInFlight = null;

async function get_install_instance_id() {
    const res = await storage.get(KEYS.install_instance_id);
    const value = res && res[KEYS.install_instance_id];
    if (value != null && String(value).trim()) {
        return String(value).trim();
    }
    return null;
}

async function get_install_instance_secret() {
    const res = await storage.get(KEYS.install_instance_secret);
    const value = res && res[KEYS.install_instance_secret];
    if (value != null && String(value).trim()) {
        return String(value).trim();
    }
    return null;
}

async function ensure_install_instance_id() {
    const existing = await get_install_instance_id();
    if (existing) {
        return existing;
    }
    const instanceId = (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function')
        ? crypto.randomUUID()
        : `inst_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 12)}`;
    await storage.set({ [KEYS.install_instance_id]: instanceId });
    return instanceId;
}

async function store_install_instance_attestation(instanceId, instanceSecret) {
    const id = instanceId != null && String(instanceId).trim() ? String(instanceId).trim() : null;
    const secret = instanceSecret != null && String(instanceSecret).trim() ? String(instanceSecret).trim() : null;
    if (!id || !secret) {
        throw new Error('store_install_instance_attestation requires instance_id and instance_secret');
    }
    await storage.set({
        [KEYS.install_instance_id]: id,
        [KEYS.install_instance_secret]: secret
    });
}

async function clear_install_instance_secret() {
    await storage.remove(KEYS.install_instance_secret);
}

async function clear_install_instance_attestation() {
    await storage.remove([KEYS.install_instance_id, KEYS.install_instance_secret]);
}

async function build_instance_proof(instanceSecret, userUuid, instanceId, timestamp) {
    const message = `${userUuid}:${instanceId}:${timestamp}`;
    const enc = new TextEncoder();
    const key = await crypto.subtle.importKey(
        'raw',
        enc.encode(instanceSecret),
        { name: 'HMAC', hash: 'SHA-256' },
        false,
        ['sign']
    );
    const sig = await crypto.subtle.sign('HMAC', key, enc.encode(message));
    return [...new Uint8Array(sig)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

async function config_headers_for_user(userUuid, instanceId, instanceSecret) {
    const ts = Math.floor(Date.now() / 1000);
    const proof = await build_instance_proof(instanceSecret, userUuid, instanceId, ts);
    return {
        'X-Instance-Proof': proof,
        'X-Instance-Timestamp': String(ts)
    };
}

async function register_install_instance({ userUuid, ghostJwt, force = false } = {}) {
    if (!userUuid || !ghostJwt) {
        return { registered: false, reason: 'missing_user_or_ghost_jwt' };
    }
    if (!force) {
        const existingSecret = await get_install_instance_secret();
        if (existingSecret) {
            const instanceId = await ensure_install_instance_id();
            return { registered: false, reason: 'already_attested', instance_id: instanceId };
        }
    }
    if (installInstanceRegisterInFlight) {
        return installInstanceRegisterInFlight;
    }

    installInstanceRegisterInFlight = (async () => {
        const instanceId = await ensure_install_instance_id();
        if (BASE_BG.env !== 'prod') {
            const log_data = {
                user_uuid: userUuid,
                instance_id: instanceId,
                force: !!force
            };
        }
        try {
            const response = await make_http_request(INSTANCES_REGISTER_ENDPOINT_PATH, {
                method: 'POST',
                body: {
                    user_uuid: userUuid,
                    jwt: ghostJwt,
                    instance_id: instanceId,
                    extension_version: get_extension_version()
                },
                ensureConfig: false,
                silent: true
            });
            const returnedId = response?.instance_id != null && String(response.instance_id).trim()
                ? String(response.instance_id).trim()
                : instanceId;
            const returnedSecret = response?.instance_secret != null && String(response.instance_secret).trim()
                ? String(response.instance_secret).trim()
                : null;
            if (!returnedSecret) {
                throw new Error('instances/register response missing instance_secret');
            }
            await store_install_instance_attestation(returnedId, returnedSecret);
            if (BASE_BG.env !== 'prod') {
                const log_data = {
                    instance_id: returnedId,
                    created: response?.created === true
                };
            }
            return {
                registered: true,
                instance_id: returnedId,
                created: response?.created === true
            };
        } catch (err) {
            if (BASE_BG.env !== 'prod') {
                const log_data = {
                    status: err?.status || null,
                    message: err?.message || String(err)
                };
            }
            throw err;
        } finally {
            installInstanceRegisterInFlight = null;
        }
    })();

    return installInstanceRegisterInFlight;
}

async function ensure_install_instance_registered({ force = false } = {}) {
    const session = await read_session_data_from_storage();
    const userUuid = session?.user_uuid || null;
    const ghostJwt = session?.ghost_jwt || null;
    if (!userUuid || !ghostJwt) {
        return { registered: false, reason: 'missing_user_or_ghost_jwt' };
    }
    return await register_install_instance({ userUuid, ghostJwt, force });
}

function payoutRowsToPrizeCountMap(rows) {
    const out = Object.create(null);
    if (!Array.isArray(rows)) {
        return out;
    }
    for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const start = Number(row && row.place_start);
        const end = Number(row && row.place_end);
        const prize = Number.parseFloat(row && row.prize);
        if (!Number.isFinite(start) || !Number.isFinite(end) || start > end || !(prize > 0)) {
            continue;
        }
        const key = String(prize);
        out[key] = (out[key] || 0) + (end - start + 1);
    }
    return out;
}

function hasUsableUnderdogPayoutStructure(payout_structure) {
    if (!payout_structure || typeof payout_structure !== 'object') {
        return false;
    }
    for (const tierKey of ['1', '2', '3', '4']) {
        const tier = payout_structure[tierKey];
        if (tier && typeof tier === 'object' && Object.keys(tier).length > 0) {
            return true;
        }
    }
    return false;
}

function normalizeUnderdogPayoutsAndFee(tournament_data) {
    if (!tournament_data) {
        return { payout_structure: {}, entry_fee: null };
    }

    const entry_style = tournament_data.entry_style || tournament_data.payouts || {};
    const totalPlanned = Number(entry_style?.entry_count ?? tournament_data.entry_count ?? 0);
    const feeRaw = entry_style?.fee ?? tournament_data.entry_fee ?? null;
    const fee = Number.parseFloat(feeRaw);
    const entry_fee = Number.isFinite(fee) && fee > 0 ? fee : null;
    const rows = Array.isArray(entry_style?.payouts) ? entry_style.payouts : [];
    const tournamentRoundRows = Array.isArray(entry_style?.tournament_round_payouts)
        ? entry_style.tournament_round_payouts
        : [];

    const adv = tournament_data.advancement_structure;

    // Sprint: entry_style.payouts is empty; finals payouts live in tournament_round_payouts.
    if (!rows.length && tournamentRoundRows.length) {
        const finalsMap = payoutRowsToPrizeCountMap(tournamentRoundRows);
        if (!Object.keys(finalsMap).length) {
            return { payout_structure: {}, entry_fee };
        }
        const payout_structure = {
            1: {},
            2: {},
            3: {},
            4: finalsMap,
        };
        return { payout_structure, entry_fee };
    }

    const advDenom = adv && adv.regular_season_denom;
    const advDenomNum = typeof advDenom === 'number' ? advDenom : parseFloat(advDenom);
    const hasAdvancementDenom = Number.isFinite(advDenomNum) && advDenomNum > 0;

    if (!adv || !hasAdvancementDenom || !totalPlanned || rows.length === 0) {
        return { payout_structure: {}, entry_fee };
    }

    let r2 = Math.round(totalPlanned * (adv.regular_season_num / adv.regular_season_denom || 0));
    let r3 = Math.round(r2 * (adv.w15_num / adv.w15_denom || 0));
    const finalsFromAdv = Math.round(r3 * (adv.w16_num / adv.w16_denom || 0));
    let finals = Number.isFinite(adv.finals_size) && adv.finals_size > 0 ? adv.finals_size : finalsFromAdv;

    r2 = Math.min(totalPlanned, Math.max(0, r2 || 0));
    r3 = Math.min(r2, Math.max(0, r3 || 0));
    finals = Math.min(r3, Math.max(0, finals || 0));

    const ranges = {
        4: [1, finals],
        3: [finals + 1, r3],
        2: [r3 + 1, r2],
        1: [r2 + 1, totalPlanned],
    };

    const payoutsRows = rows
        .map(r => ({
            start: Number(r.place_start),
            end: Number(r.place_end),
            prize: Number.parseFloat(r.prize) || 0,
        }))
        .filter(r => Number.isFinite(r.start) && Number.isFinite(r.end) && r.start <= r.end)
        .sort((a, b) => a.start - b.start);

    const addToMap = (map, amount, count) => {
        if (!Number.isFinite(amount) || !Number.isFinite(count) || count <= 0) return;
        const key = String(amount);
        map[key] = (map[key] || 0) + count;
    };

    function extractPaidMap(start, end) {
        const out = Object.create(null);
        if (!(Number.isFinite(start) && Number.isFinite(end)) || start > end) return out;
        for (const row of payoutsRows) {
            if (row.end < start || row.start > end) continue;
            const s = Math.max(row.start, start);
            const e = Math.min(row.end, end);
            if (s <= e && row.prize > 0) {
                addToMap(out, row.prize, e - s + 1);
            }
        }
        return out;
    }

    const payout_structure = {
        1: extractPaidMap(...ranges[1]),
        2: extractPaidMap(...ranges[2]),
        3: extractPaidMap(...ranges[3]),
        4: extractPaidMap(...ranges[4]),
    };

    return { payout_structure, entry_fee };
}

/**
 * Extract display picks from a rankings cache entry for the overlay algo_type.
 * Returns null if nothing usable (e.g. sim without blended_picks).
 */
function getPicksFromCacheEntryForAlgo(entry, algo_type) {
    if (!entry || typeof entry !== 'object') {
        return null;
    }
    let picks_for_response;
    if (algo_type) {
        const normalized_algo = algo_type.toLowerCase();
        if (normalized_algo === 'classic') {
            picks_for_response = entry.classic_picks || entry.picks;
        } else if (normalized_algo === 'pure_sim') {
            picks_for_response = entry.sim_picks;
        } else if (normalized_algo === 'sim' || normalized_algo === 'dev_sim') {
            picks_for_response = entry.blended_picks;
        } else {
            picks_for_response = entry.picks;
        }
    } else {
        picks_for_response = entry.picks;
    }
    if (algo_type && algo_type.toLowerCase() === 'sim' && !picks_for_response) {
        return null;
    }
    if (picks_for_response && Array.isArray(picks_for_response) && picks_for_response.length > 0) {
        return picks_for_response;
    }
    return null;
}

/**
 * When no exact request_identifier match, choose a stale row by draft state (num_picks), not timestamp.
 * Use only rows with num_picks <= needed (highest such row). Rows ahead of needed are invalid / inconsistent.
 */
function pickBestDraftCacheEntryByDraftState(candidates, neededNumPicks) {
    if (!Array.isArray(candidates) || candidates.length === 0) {
        return null;
    }
    const np = neededNumPicks;
    if (np == null || !Number.isFinite(np)) {
        return candidates.reduce((a, b) => (b.num_picks || 0) > (a.num_picks || 0) ? b : a);
    }
    const withN = candidates.map((e) => ({
        e,
        n: typeof e.num_picks === 'number' ? e.num_picks : -1
    }));
    const known = withN.filter((x) => x.n >= 0);
    const usable = known.length ? known : withN;
    const atOrBelow = usable.filter((x) => x.n <= np);
    if (atOrBelow.length) {
        const maxN = Math.max(...atOrBelow.map((x) => x.n));
        return atOrBelow.find((x) => x.n === maxN).e;
    }
    return null;
}

function normalizeUnderdogSlateWhitelistIds(raw) {
    // Backwards-compatible: allow `underdog_slate_whitelist` to be either:
    // - Array<string> (legacy)
    // - { [label: string]: string } (new; ignore labels, use values)
    if (!raw) return [];
    const out = [];
    if (Array.isArray(raw)) {
        for (let i = 0; i < raw.length; i++) {
            const v = raw[i];
            if (typeof v === 'string' && v.trim()) out.push(v.trim());
        }
        return out;
    }
    if (typeof raw === 'object') {
        const values = Object.values(raw);
        for (let i = 0; i < values.length; i++) {
            const v = values[i];
            if (typeof v === 'string' && v.trim()) {
                out.push(v.trim());
            } else if (Array.isArray(v)) {
                for (let j = 0; j < v.length; j++) {
                    const vv = v[j];
                    if (typeof vv === 'string' && vv.trim()) out.push(vv.trim());
                }
            }
        }
        return out;
    }
    return [];
}

/**
 * When `underdog_slate_whitelist` is an object { ud_bbm: "<slate uuid>", ... }, map the tournament's
 * slate id to the dataset key `ud_bbm_appearance_id_map`, etc.
 */
function resolveUnderdogAppearanceIdMapDatasetKeyFromSlates(slates, whitelistRaw, whitelistIds) {
    if (!Array.isArray(slates) || !whitelistIds.length) {
        return null;
    }
    if (!whitelistRaw || typeof whitelistRaw !== 'object' || Array.isArray(whitelistRaw)) {
        return null;
    }
    const lower = (x) => String(x).trim().toLowerCase();
    for (let i = 0; i < slates.length; i++) {
        const s = slates[i];
        const sid = s && s.id;
        if (!sid || !whitelistIds.includes(sid)) {
            continue;
        }
        const entries = Object.entries(whitelistRaw);
        for (let j = 0; j < entries.length; j++) {
            const label = entries[j][0];
            const val = entries[j][1];
            if (typeof val !== 'string' || !label) {
                continue;
            }
            if (lower(val) === lower(sid)) {
                return String(label) + '_appearance_id_map';
            }
        }
    }
    return null;
}

function buildUnderdogTournamentSummary(tournament_data) {
    if (!tournament_data) {
        return { supported: false, reason: 'no_data' };
    }

    const slates = tournament_data.slates || tournament_data.states || [];
    const slate_ids = Array.isArray(slates)
        ? slates.map((s) => (s?.id != null && String(s.id).trim() ? String(s.id).trim() : null)).filter(Boolean)
        : [];
    const is_nfl = slates.some(s => s?.sport_id === 'NFL');

    const whitelistRaw =
        (configState?.data?.content_script_settings?.static_settings?.underdog_slate_whitelist) ||
        (CONFIG_FALLBACK?.content_script_settings?.static_settings?.underdog_slate_whitelist) ||
        [];
    const whitelistIds = normalizeUnderdogSlateWhitelistIds(whitelistRaw);
    const has_whitelisted = whitelistIds.length > 0
        ? slates.some(s => s?.id && whitelistIds.includes(s.id))
        : false;

    const appearance_id_map_dataset_key = resolveUnderdogAppearanceIdMapDatasetKeyFromSlates(
        slates,
        whitelistRaw,
        whitelistIds
    );

    const supported = is_nfl && has_whitelisted && !tournament_data.no_tournament_data;
    const reason = (() => {
        if (tournament_data.no_tournament_data) return 'no_data';
        if (!is_nfl) return 'non_nfl';
        if (!has_whitelisted) return 'not_whitelisted';
        return null;
    })();

    const advancement_structure = tournament_data.advancement_structure || null;
    const is_marathon =
        typeof isUnderdogMarathonTournament === 'function' &&
        isUnderdogMarathonTournament(tournament_data);
    const contest_rounds =
        tournament_data.contest_style?.rounds != null
            ? tournament_data.contest_style.rounds
            : tournament_data.total_rounds != null
              ? tournament_data.total_rounds
              : null;
    const draft_size = advancement_structure?.regular_season_denom || null;
    const contest_style_name = tournament_data.contest_style?.name || null;
    const description = tournament_data.description || null;

    const { payout_structure, entry_fee } = normalizeUnderdogPayoutsAndFee(tournament_data);
    // Whitelist friendly key (ud_bbm, ud_tep, …); the content script maps it to `scoring`.
    const slate_key = appearance_id_map_dataset_key
        ? appearance_id_map_dataset_key.replace(/_appearance_id_map$/, '')
        : null;

    const summary = {
        supported,
        reason,
        is_marathon,
        tournament_id: tournament_data.id || 'no_id',
        title: tournament_data.title || null,
        description,
        contest_style_name,
        advancement_structure,
        payout_structure,
        entry_fee,
        contest_rounds,
        draft_size,
        slate_ids,
        appearance_id_map_dataset_key,
        slate_key,
        tournament_info: {
            id: tournament_data.id || 'no_id',
            title: tournament_data.title || null,
            description,
            contest_style_name,
            is_marathon,
            slate_key,
            advancement_structure,
            payout_structure: payout_structure || {},
            entry_fee
        }
    };

    const advancement_raw_preview = typeof advancement_structure?.raw_string === 'string' ? advancement_structure.raw_string.slice(0, 200) : null;
    const summaryLogDbg = { tournament_id: summary.tournament_id, title: summary.title, contest_style_name: summary.contest_style_name, description_preview: typeof summary.description === 'string' ? summary.description.slice(0, 120) : null, draft_size: summary.draft_size, contest_rounds: summary.contest_rounds, supported: summary.supported, reason: summary.reason, is_marathon: summary.is_marathon, appearance_id_map_dataset_key: summary.appearance_id_map_dataset_key, slate_key: summary.slate_key, is_nfl: slates.some((s) => s?.sport_id === 'NFL'), slate_ids, slate_count: slates.length, advancement_has_regular_season_denom: draft_size != null, advancement_raw_preview: advancement_raw_preview, contest_style_id: tournament_data.contest_style_id ?? null, contest_style_resolved: !!tournament_data.contest_style };

    return summary;
}

/**
 * Resolve contest_style + entry_style from stats.underdogfantasy.com using IDs on the draft XHR
 * (when /v1/drafts/{id}/tournament 404s). Reuses the same catalogs as fetch_underdog_tournament.
 * Partial advancement (e.g. only regular_season_denom from intercept) is omitted for payout tiers
 * so normalizeUnderdogPayoutsAndFee still returns entry_fee from entry_style.
 */
async function enrichUnderdogInterceptSummaryFromStyleIds(payload) {
    const contest_style_id =
        payload && payload.contest_style_id != null && String(payload.contest_style_id).trim() !== ''
            ? String(payload.contest_style_id).trim()
            : null;
    const entry_style_id =
        payload && payload.entry_style_id != null && String(payload.entry_style_id).trim() !== ''
            ? String(payload.entry_style_id).trim()
            : null;
    const draft_entry_count =
        payload && payload.draft_entry_count != null && Number.isFinite(Number(payload.draft_entry_count))
            ? Number(payload.draft_entry_count)
            : null;

    let advancement_structure =
        payload && payload.advancement_structure && typeof payload.advancement_structure === 'object'
            ? payload.advancement_structure
            : null;
    if (
        advancement_structure &&
        advancement_structure.regular_season_num == null &&
        advancement_structure.raw_string == null
    ) {
        advancement_structure = null;
    }

    const tournament_like = {
        id: 'draft_intercept_enrichment',
        contest_style_id,
        entry_style_id,
        advancement_structure,
        entry_count: draft_entry_count
    };

    const enriched =
        typeof enrich_tournament_data_with_styles === 'function'
            ? await enrich_tournament_data_with_styles(tournament_like)
            : tournament_like;

    const { payout_structure, entry_fee } = normalizeUnderdogPayoutsAndFee(enriched);
    const contest_rounds =
        enriched.contest_style && enriched.contest_style.rounds != null ? enriched.contest_style.rounds : null;
    const contest_style_name =
        enriched.contest_style && enriched.contest_style.name ? enriched.contest_style.name : null;

    return {
        payout_structure: payout_structure || {},
        entry_fee: entry_fee,
        contest_rounds: contest_rounds,
        contest_style_name: contest_style_name
    };
}

function getExtensionUpdateMessage(error) {
    if (!error) return null;
    const responseBody = error.responseBody || null;
    const messageCandidates = [
        responseBody?.error,
        responseBody?.detail,
        responseBody?.message,
        error.message
    ].filter(Boolean);
    const rawMessage = messageCandidates.find(msg => typeof msg === 'string') || null;
    if (!rawMessage) return null;
    const lowered = rawMessage.toLowerCase();
    if (!lowered.includes('extension version') || !lowered.includes('minimum required version')) {
        return null;
    }
    return rawMessage;
}

function notify_settings_pages(action, payload = {}) {
    if (!state.settings_ports || state.settings_ports.size === 0) return;
    const message = { action, ...payload };
    state.settings_ports.forEach((settingsPort) => {
        try {
            settingsPort.postMessage(message);
        } catch (err) {
        }
    });
}

function summarize_user_rankings_dataset_for_debug(dataset) {
    const rankings = Array.isArray(dataset?.rankings) ? dataset.rankings : [];
    const first = rankings[0] && typeof rankings[0] === 'object' ? rankings[0] : null;
    return {
        rankingsLen: rankings.length,
        firstEntryKeys: first ? Object.keys(first).slice(0, 12) : [],
        firstHasUdId: !!(first && (first.ud_id != null || first.udId != null)),
        firstHasDkId: !!(first && (first.dk_id != null || first.dkId != null)),
        firstHasId: !!(first && first.id != null),
    };
}

async function upload_custom_rankings_and_refresh({ set_name, rankings, session }) {
    const headers = {};
    if (session.app_jwt) {
        headers['Authorization'] = `Bearer ${session.app_jwt}`;
    }
    const uploadedLen = Array.isArray(rankings) ? rankings.length : 0;
    const uploadedFirst = rankings?.[0] && typeof rankings[0] === 'object' ? rankings[0] : null;
    if (BASE_BG.env !== 'prod') {
        const log_data = {
            set_name,
            uploadedLen,
            uploadedFirstKeys: uploadedFirst ? Object.keys(uploadedFirst).slice(0, 12) : [],
        };
    }
    await make_http_request_with_auth_retry('/upload-custom-rankings', {
        method: 'POST',
        body: { user_uuid: session.user_uuid, set_name, rankings },
        headers
    });
    // Refresh saved list via app JWT only — do not depend on install instance attestation.
    try {
        const refreshResult = await fetch_and_apply_user_rankings_with_app_jwt({ session });
        const datasets = refreshResult?.datasets || get_user_rankings_datasets();
        const dsSummary = summarize_user_rankings_dataset_for_debug(datasets?.[set_name]);
        if (BASE_BG.env !== 'prod') {
            const log_data = {
                set_name,
                ok: true,
                via: 'app_jwt',
                datasetKeys: datasets && typeof datasets === 'object' ? Object.keys(datasets) : [],
                ...dsSummary,
            };
        }
        return { status: 'ok', datasets };
    } catch (err) {
        const refreshErrMessage = String(err?.message || err?.detail || err?.status || err);
        const datasets = get_user_rankings_datasets();
        const dsSummary = summarize_user_rankings_dataset_for_debug(datasets?.[set_name]);
        if (BASE_BG.env !== 'prod') {
            const log_data = {
                set_name,
                ok: false,
                via: 'app_jwt',
                refreshError: refreshErrMessage,
                refreshErrorStatus: err?.status ?? null,
                datasetKeys: datasets && typeof datasets === 'object' ? Object.keys(datasets) : [],
                ...dsSummary,
            };
        }
        return {
            status: 'error',
            message: `Rankings uploaded, but refreshing your saved list failed. Try again in a moment. (${refreshErrMessage})`,
            uploaded: true,
            datasets,
            refreshError: refreshErrMessage,
        };
    }
}

function normalize_streamer_mode_data(raw) {
    const src = raw && typeof raw === 'object' ? raw : {};
    const currentlyWinningRaw = src.currently_winning;
    const currently_winning = typeof currentlyWinningRaw === 'string'
        ? currentlyWinningRaw.trim().slice(0, 64)
        : null;
    const entry_fees_total_cents = Number.isFinite(+src.entry_fees_total_cents) ? +src.entry_fees_total_cents : null;
    const updated_at_ms = Number.isFinite(+src.updated_at_ms) ? +src.updated_at_ms : null;
    const source_site = typeof src.source_site === 'string' ? src.source_site : null;
    const source_url = typeof src.source_url === 'string' ? src.source_url : null;
    return {
        currently_winning: currently_winning || null,
        entry_fees_total_cents: entry_fees_total_cents != null ? Math.max(0, Math.round(entry_fees_total_cents)) : null,
        updated_at_ms,
        source_site,
        source_url
    };
}

async function get_streamer_mode_data() {
    const res = await storage.get(KEYS.streamer_mode_data);
    const persisted = (res && res[KEYS.streamer_mode_data]) || {};
    return normalize_streamer_mode_data(persisted);
}

async function set_streamer_mode_data(patch = {}) {
    const current = await get_streamer_mode_data();
    const next = normalize_streamer_mode_data({
        ...current,
        ...patch,
        updated_at_ms: Date.now()
    });
    await storage.set({ [KEYS.streamer_mode_data]: next });
    const changed = JSON.stringify(current) !== JSON.stringify(next);
    return { data: next, changed };
}

async function streamer_mode_feature_enabled_for_settings() {
    try {
        const cs = await get_content_script_settings();
        const bg = await load_background_settings();
        const enabled = !!(cs && cs.user_settings && cs.user_settings.streamer_overlay_enabled);
        const envOk = ['dev', 'local'].includes(bg && bg.env);
        return enabled && envOk;
    } catch (e) {
        return false;
    }
}

async function handle_set_streamer_mode_data_request(patch) {
    const allowed = await streamer_mode_feature_enabled_for_settings();
    if (!allowed) {
        const streamer_mode_data = await get_streamer_mode_data();
        return { status: 'ok', ignored: true, streamer_mode_data };
    }
    const { data, changed } = await set_streamer_mode_data(patch || {});
    if (changed) {
        notify_content_scripts('UPDATE_STREAMER_MODE_DATA', { streamer_mode_data: data });
    }
    return { status: 'ok', streamer_mode_data: data };
}

function attach_popup_like_port(port, { setPopupPort = false, registerSettingsPort = false } = {}) {
    if (setPopupPort) {
        state.popup_port = port;
        port.onDisconnect.addListener(() => {
            if (state.popup_port === port) state.popup_port = null;
        });
    }

    if (registerSettingsPort) {
        if (!state.settings_ports) state.settings_ports = new Set();
        state.settings_ports.add(port);
        port.onDisconnect.addListener(() => {
            if (state.settings_ports) state.settings_ports.delete(port);
        });
    }

    // Handle popup-like port requests
    port.onMessage.addListener(async (msg) => {
        if (msg?.request_id) {
            const request_id = msg.request_id;
            const action = msg.action;

            try {
                let response = null;

                if (action === 'GET_SESSION_DATA') {
                    const session = await get_session_data();
                    response = { status: 'ok', session_data: session || null };
                    notify_auth_status(session || null);
                } else if (action === 'GET_SETTINGS') {
                    const scope = msg.scope || 'content_script';
                    if (scope === 'background') {
                        const bg = await load_background_settings();
                        response = { status: 'ok', settings: bg };
                    } else {
                        const keys = msg.keys || null;
                        const cs = await get_content_script_settings(keys);
                        response = { status: 'ok', settings: cs };
                    }
                } else if (action === 'GET_ENVIRONMENT') {
                    const bg = await load_background_settings();
                    response = { status: 'ok', env: bg.env };
                } else if (action === 'GET_EXPOSURE_STATUS') {
                    if (typeof getExposureStatusForPopup === 'function') {
                        response = { status: 'ok', exposure: getExposureStatusForPopup() };
                    } else {
                        response = { status: 'ok', exposure: { ud_last_updated_ms: null, dk_last_updated_ms: null, approx_storage_bytes: 0 } };
                    }
                } else if (action === 'GET_STREAMER_MODE_DATA') {
                    const streamer_mode_data = await get_streamer_mode_data();
                    response = { status: 'ok', streamer_mode_data };
                } else if (action === 'SET_STREAMER_MODE_DATA') {
                    response = await handle_set_streamer_mode_data_request(msg.data || {});
                } else if (action === 'GET_EXPOSURE_STORAGE') {
                    if (typeof getExposureStorageForSettingsRequest === 'function') {
                        const exposure_storage = await getExposureStorageForSettingsRequest();
                        response = { status: 'ok', exposure_storage };
                    } else {
                        response = {
                            status: 'ok',
                            exposure_storage: { by_id: {}, ud_last_updated_ms: null, dk_last_updated_ms: null }
                        };
                    }
                } else if (action === 'SET_SETTINGS') {
                    const scope = msg.scope || 'content_script';
                    const patch = msg.settings || {};
                    if (scope === 'background') {
                        const next = await save_background_settings(patch);
                        response = { status: 'ok', settings: next, scope };
                    } else {
                        const next = await set_content_script_settings(patch);
                        notify_content_scripts('UPDATE_SETTINGS', { settings: next });
                        notify_settings_pages('UPDATE_SETTINGS', { settings: next });
                        if (Object.prototype.hasOwnProperty.call(patch, 'ud_debug_ignore_legacy_collision_rules')) {
                            notify_content_scripts('UPDATE_DATASETS', { datasets: get_content_script_datasets() });
                        }
                        if (
                            Object.prototype.hasOwnProperty.call(patch, 'ud_exposure_included_slates') ||
                            Object.prototype.hasOwnProperty.call(patch, 'dk_exposure_included_slates') ||
                            Object.prototype.hasOwnProperty.call(patch, 'ud_exposure_include_older') ||
                            Object.prototype.hasOwnProperty.call(patch, 'ud_exposure_aggregate_slates') ||
                            Object.prototype.hasOwnProperty.call(patch, 'dk_exposure_aggregate_slates') ||
                            Object.prototype.hasOwnProperty.call(patch, 'exposure_aggregate_across_sites')
                        ) {
                            if (typeof recomputeExposureAggregationFromCurrentSettings === 'function') {
                                await recomputeExposureAggregationFromCurrentSettings();
                            } else {
                                notify_content_scripts('UPDATE_DATASETS', { datasets: get_content_script_datasets() });
                            }
                        }
                        if (Object.prototype.hasOwnProperty.call(patch, 'force_lite_mode')) {
                            request_extension_action_icon_resync(await get_session_data()).catch((err) => {
                                console.error('[settings] sync_extension_action_icon after force_lite_mode failed', err);
                            });
                        }
                        response = { status: 'ok', settings: next, scope };
                    }
                } else if (action === 'RESET_SETTINGS_DEFAULTS') {
                    try {
                        await reset_content_script_user_settings();
                        await refresh_config();
                        const settings = await get_content_script_settings();
                        notify_content_scripts('UPDATE_SETTINGS', { settings });
                        notify_settings_pages('UPDATE_SETTINGS', { settings });
                        response = { status: 'ok', settings };
                    } catch (err) {
                        console.error('[settings] Failed to reset defaults', err);
                        response = { status: 'error', message: err?.message || 'Reset defaults failed' };
                    }
                } else if (action === 'GET_USER_RANKINGS_DATASETS') {
                    await ensure_config_ready();
                    const session = await get_session_data();
                    const wantRefresh = msg.refresh === true;
                    if (wantRefresh && session?.app_jwt && session?.user_uuid) {
                        try {
                            const fetched = await fetch_and_apply_user_rankings_with_app_jwt({ session });
                            response = { status: 'ok', datasets: fetched?.datasets || get_user_rankings_datasets() };
                        } catch (err) {
                            response = { status: 'ok', datasets: get_user_rankings_datasets() };
                        }
                    } else {
                        response = { status: 'ok', datasets: get_user_rankings_datasets() };
                    }
                } else if (action === 'UPLOAD_CUSTOM_RANKINGS') {
                    const set_name = msg.set_name;
                    const rankings = msg.rankings;
                    const session = await get_session_data();
                    if (!session?.user_uuid) {
                        response = { status: 'error', message: 'Sign in to upload rankings.' };
                    } else if (!set_name || (set_name !== 'ud_bbm' && set_name !== 'dk_bbm')) {
                        response = { status: 'error', message: 'Invalid set_name.' };
                    } else if (!Array.isArray(rankings)) {
                        response = { status: 'error', message: 'Invalid rankings.' };
                    } else if (rankings.length === 0) {
                        // An empty upload overwrites the saved set server-side. This can only
                        // happen if the UI rendered an empty list from stale/failed state, so
                        // refuse it rather than destroying the user's real rankings.
                        response = {
                            status: 'error',
                            message: 'No rankings to upload. Your saved rankings were left unchanged.',
                        };
                    } else {
                        try {
                            response = await upload_custom_rankings_and_refresh({ set_name, rankings, session });
                        } catch (err) {
                            const backendMessage = (err?.responseBody && (err.responseBody.detail ?? err.responseBody.message)) ?? err?.message ?? 'Upload failed';
                            response = { status: 'error', message: backendMessage };
                        }
                    }
                } else if (action === 'RESTART_BACKGROUND_SCRIPT') {
                    // Helper function to reload all tabs with content scripts (clears FSM memory)
                    const reload_content_script_tabs = (callback) => {
                        const content_script_urls = [
                            '*://www.legendaryupside.com/*',
                            '*://app.underdogsports.com/*',
                            '*://app.underdogfantasy.com/*',
                            '*://www.draftkings.com/*'
                        ];

                        chrome.tabs.query({ url: content_script_urls }, (tabs) => {
                            let reloaded = 0;
                            const total = tabs.length;

                            if (total === 0) {
                                if (callback) callback();
                                return;
                            }

                            tabs.forEach((tab) => {
                                chrome.tabs.reload(tab.id, () => {
                                    if (chrome.runtime.lastError) {
                                    }
                                    reloaded++;
                                    if (reloaded === total) {
                                        if (callback) callback();
                                    }
                                });
                            });
                        });
                    };

                    response = { status: 'ok', message: 'Background script restarting' };
                    // Reload content script tabs first to clear FSM memory, then restart background
                    reload_content_script_tabs(() => {
                        // Use setTimeout to ensure tabs are reloaded before background script restarts
                        setTimeout(() => {
                            chrome.runtime.reload();
                        }, 100);
                    });
                } else if (action === 'LOGOUT_AND_RESTART') {
                    // Helper function to reload all tabs with content scripts (clears FSM memory)
                    const reload_content_script_tabs = (callback) => {
                        const content_script_urls = [
                            '*://www.legendaryupside.com/*',
                            '*://app.underdogsports.com/*',
                            '*://app.underdogfantasy.com/*',
                            '*://www.draftkings.com/*'
                        ];

                        chrome.tabs.query({ url: content_script_urls }, (tabs) => {
                            let reloaded = 0;
                            const total = tabs.length;

                            if (total === 0) {
                                if (callback) callback();
                                return;
                            }

                            tabs.forEach((tab) => {
                                chrome.tabs.reload(tab.id, () => {
                                    if (chrome.runtime.lastError) {
                                    }
                                    reloaded++;
                                    if (reloaded === total) {
                                        if (callback) callback();
                                    }
                                });
                            });
                        });
                    };

                    response = { status: 'ok', message: 'Clearing storage and restarting' };
                    // Clear all storage, reload content script tabs, then restart background
                    chrome.storage.local.clear(() => {
                        reload_content_script_tabs(() => {
                            // Use setTimeout to ensure tabs are reloaded before background script restarts
                            setTimeout(() => {
                                chrome.runtime.reload();
                            }, 100);
                        });
                    });
                } else {
                    response = { status: 'error', message: `Unknown action: ${action}` };
                }

                if (response !== null) {
                    port.postMessage({ request_id, ...response });
                }
            } catch (err) {
                console.error(`[popup port handler] Error handling ${action}:`, err);
                port.postMessage({ 
                    request_id, 
                    status: 'error', 
                    message: err?.message || 'Internal error' 
                });
            }
            return;
        }

        if (msg?.action === 'SETTINGS_KEEPALIVE') {
            try {
                port.postMessage({ action: 'BG_KEEPALIVE_ACK', boot_id: state.boot_id });
            } catch (err) {
            }
        }
    });
}

chrome.runtime.onConnect.addListener(port => {
    
    if (port.name === 'popup') {
        attach_popup_like_port(port, { setPopupPort: true });
        return;
    }

    if (port.name === 'settings_page') {
        attach_popup_like_port(port, { setPopupPort: false, registerSettingsPort: true });
        return;
    }

    if (port.name !== 'content') {
        return;
    }

    // In Chrome service workers, port.sender.tab might be undefined initially
    // Use a more robust method to get tabId
    let tabId = null;
    const actualTabId = port.sender?.tab?.id; // Store actual tab ID for cleanup check
    if (actualTabId) {
        tabId = actualTabId;
    } else if (port.sender?.frameId !== undefined) {
        // Fallback: use frameId if available (Chrome service worker quirk)
        tabId = `frame_${port.sender.frameId}_${Date.now()}`;
    } else {
        // Last resort: generate unique ID
        tabId = `tab_${Date.now()}_${Math.random()}`;
    }
    
    // FIREFOX MEMORY LEAK FIX: Clean up any existing ports for the same tab
    // In Firefox, background scripts are persistent, so old ports can accumulate
    // when content scripts reload (page navigation, refresh). We need to:
    // 1. Check if there's an existing port for the actual tab ID
    // 2. Check if there's an existing port with a different tabId but same actual tab
    // 3. Disconnect and clean up the old port before adding the new one
    const portsToCleanup = [];
    if (actualTabId) {
        // First check if we already have a port with this exact tab ID
        if (contentPorts.has(actualTabId)) {
            const existingPort = contentPorts.get(actualTabId);
            if (existingPort !== port) {
                portsToCleanup.push({ tabId: actualTabId, port: existingPort });
            }
        }
        
        // Also check all ports to find any with the same actual tab ID but different tabId key
        // This handles cases where tabId was generated with a fallback but we now have the real ID
        for (const [existingTabId, existingPort] of contentPorts.entries()) {
            // Skip if it's the same port, if we already handled it above, or if tabId matches actualTabId
            if (existingPort === port || existingTabId === actualTabId) {
                continue;
            }
            
            // Check if this port's sender has the same actual tab ID
            // Note: port.sender might not be accessible in Firefox after the port is stored
            // but we try anyway - if it fails, we'll catch it
            try {
                const existingActualTabId = existingPort.sender?.tab?.id;
                if (existingActualTabId === actualTabId) {
                    portsToCleanup.push({ tabId: existingTabId, port: existingPort });
                }
            } catch (err) {
                // port.sender might not be accessible, skip this port
                continue;
            }
        }
    } else {
        // If we don't have an actual tab ID, check if there's already a port with this generated tabId
        // This handles the case where the same frame reconnects quickly
        if (contentPorts.has(tabId)) {
            const existingPort = contentPorts.get(tabId);
            if (existingPort !== port) {
                portsToCleanup.push({ tabId: tabId, port: existingPort });
            }
        }
    }
    
    // Clean up all identified ports.
    // Deliberately does NOT stop in-flight polls: polls resolve the live port from
    // contentPorts on every tick, so they survive a reconnect and keep fetching
    // results into the cache. Killing them here silently orphaned finished results
    // whenever a tab's port churned mid-request (MV3 SW restarts, health reconnects).
    for (const { tabId: cleanupTabId, port: cleanupPort } of portsToCleanup) {
        try {
            // Disconnect the old port
            cleanupPort.disconnect();
        } catch (err) {
        }
        // Remove from map
        contentPorts.delete(cleanupTabId);
    }
    
    // Don't add to contentPorts yet - wait until sendHello succeeds to avoid race conditions
    // where polling might start before the port is confirmed ready

    const sendHello = async () => {
        try {
            await ensure_config_ready();
            const [settings, session, bg, streamer_mode_data, udMarkerClearGenRes] = await Promise.all([
                get_content_script_settings(),
                get_session_data(),
                load_background_settings(),
                get_streamer_mode_data(),
                storage.get(KEYS.ud_tournament_marker_clear_gen),
            ]);
            const ud_tournament_marker_clear_gen =
                udMarkerClearGenRes && typeof udMarkerClearGenRes[KEYS.ud_tournament_marker_clear_gen] === 'number'
                    ? udMarkerClearGenRes[KEYS.ud_tournament_marker_clear_gen]
                    : null;
            
            try {
            port.postMessage({
                action: 'BG_HELLO',
                settings,
                datasets: get_content_script_datasets(),
                session_data: session,
                env: bg.env,
                web_socket_status: Boolean(state.auth_status_data?.allow_rankings),
                streamer_mode_data,
                ...(ud_tournament_marker_clear_gen != null
                    ? { ud_tournament_marker_clear_gen }
                    : {}),
            });
                // Only add to contentPorts after hello succeeds - this prevents polling from starting
                // with a port that might be disconnected during install refresh scenarios
                contentPorts.set(tabId, port);
            } catch (postErr) {
                console.error('[BG] Failed to post BG_HELLO message:', postErr);
                // If port is disconnected, don't add it to the map
                if (chrome.runtime.lastError) {
                    console.error('[BG] Chrome runtime error:', chrome.runtime.lastError.message);
                }
                // Port was never added, so no need to delete
                return;
            }
            
            if (typeof state.last_auth_message === 'string') {
                try {
                const replayNotification = {
                    action: 'UPDATE_NOTIFICATION',
                    message: state.last_auth_message,
                    type: state.last_auth_type || 'auth_error',
                };
                if (state.auth_status_data) {
                    replayNotification.session_data = state.auth_status_data;
                }
                port.postMessage(replayNotification);
                } catch (postErr) {
                    console.error('[BG] Failed to post UPDATE_NOTIFICATION:', postErr);
                }
            }
        } catch (err) {
            console.error('[content port hello] failed', err);
            // Port was never added, so no need to delete
        }
    };

    sendHello();

    port.onMessage.addListener(async (msg) => {
        if (chrome.runtime.lastError) {
            console.error('[BG] Port message error:', chrome.runtime.lastError.message);
            return;
        }
        
        if (msg?.request_id) {
            const request_id = msg.request_id;
            const action = msg.action;
            
            try {
                let response = null;
                
                if (action === 'GET_SETTINGS') {
                    const scope = msg.scope || 'content_script';
                    if (scope === 'background') {
                        const bg = await load_background_settings();
                        response = { status: 'ok', settings: bg };
                    } else {
                        const keys = msg.keys || null;
                        const cs = await get_content_script_settings(keys);
                        response = { status: 'ok', settings: cs };
                    }
                } else if (action === 'SET_SETTINGS') {
                    const scope = msg.scope || 'content_script';
                    const patch = msg.settings || {};
                    if (scope === 'background') {
                        const next = await save_background_settings(patch);
                        response = { status: 'ok', settings: next, scope };
                    } else {
                        const next = await set_content_script_settings(patch);
                        notify_content_scripts('UPDATE_SETTINGS', { settings: next });
                        notify_settings_pages('UPDATE_SETTINGS', { settings: next });
                        if (Object.prototype.hasOwnProperty.call(patch, 'ud_debug_ignore_legacy_collision_rules')) {
                            notify_content_scripts('UPDATE_DATASETS', { datasets: get_content_script_datasets() });
                        }
                        if (Object.prototype.hasOwnProperty.call(patch, 'force_lite_mode')) {
                            request_extension_action_icon_resync(await get_session_data()).catch((err) => {
                                console.error('[settings] sync_extension_action_icon after force_lite_mode failed', err);
                            });
                        }
                        response = { status: 'ok', settings: next, scope };
                    }
                } else if (action === 'GET_ENVIRONMENT') {
                    const bg = await load_background_settings();
                    response = { status: 'ok', env: bg.env };
                } else if (action === 'GET_EXPOSURE_STATUS') {
                    if (typeof getExposureStatusForPopup === 'function') {
                        response = { status: 'ok', exposure: getExposureStatusForPopup() };
                    } else {
                        response = { status: 'ok', exposure: { ud_last_updated_ms: null, dk_last_updated_ms: null, approx_storage_bytes: 0 } };
                    }
                } else if (action === 'GET_STREAMER_MODE_DATA') {
                    const streamer_mode_data = await get_streamer_mode_data();
                    response = { status: 'ok', streamer_mode_data };
                } else if (action === 'SET_STREAMER_MODE_DATA') {
                    response = await handle_set_streamer_mode_data_request(msg.data || {});
                } else if (action === 'GET_SESSION_DATA') {
                    const session = await get_session_data();
                    response = { status: 'ok', session_data: session || null };
                    notify_auth_status(session || null);
                } else if (action === 'ENSURE_VALID_APP_JWT') {
                    const session = await ensure_valid_app_jwt();
                    response = { status: 'ok', session_data: session || null };
                    notify_auth_status(session || null);
                } else if (action === 'SET_SESSION_DATA') {
                    try {
                        const incoming = msg.session_data || null;
                        const ghostJwt = incoming && typeof incoming === 'object'
                            ? (incoming.jwt || incoming.ghost_jwt || null)
                            : null;
                        await set_session_data(incoming, { merge: true });
                        const validated = await sync_session_with_backend({ ghostJwt });
                        response = {
                            status: 'ok',
                            message: 'session_stored',
                            allow_rankings: validated?.allow_rankings ?? null,
                            tier: validated?.tier ?? null
                        };
                    } catch (err) {
                        console.error('[set_session_data] failed', err);
                        response = { status: 'error', message: err?.message || 'session store failed' };
                        schedule_auth_retry();
                    }
                } else if (action === 'CLEAR_SESSION_DATA' || action === 'clearSessionData') {
                    await storage.remove(KEYS.session_data);
                    state.last_extension_icon_key = null;
                    request_extension_action_icon_resync(null).catch((err) => {
                        console.error('[session] sync_extension_action_icon after clear session failed', err);
                    });
                    refresh_config().catch((err) => {
                        console.error('[session] refresh_config after clear session failed', err);
                    });
                    response = { status: 'ok', message: 'session_cleared' };
                } else if (action === 'GET_DATASET') {
                    await ensure_config_ready();
                    const key = typeof msg.key === 'string' && msg.key.trim() ? msg.key.trim() : null;
                    let dataset = key ? get_content_script_dataset(key) : get_content_script_datasets();
                    if (key && (dataset === undefined || dataset === null)) {
                        dataset = get_dataset(key);
                    }
                    if (dataset !== undefined && dataset !== null) {
                        response = { status: 'ok', key, dataset };
                    } else {
                        response = { status: 'not_found', key, dataset: null };
                    }
                } else if (action === 'GET_HOME_EXPOSURE_DATASETS') {
                    await ensure_config_ready();
                    response = { status: 'ok', datasets: build_home_exposure_datasets() };
                } else if (action === 'GET_USER_RANKINGS_DATASETS') {
                    await ensure_config_ready();
                    const session = await get_session_data();
                    const wantRefresh = msg.refresh === true;
                    if (wantRefresh && session?.app_jwt && session?.user_uuid) {
                        try {
                            const fetched = await fetch_and_apply_user_rankings_with_app_jwt({ session });
                            response = { status: 'ok', datasets: fetched?.datasets || get_user_rankings_datasets() };
                        } catch (err) {
                            response = { status: 'ok', datasets: get_user_rankings_datasets() };
                        }
                    } else {
                        response = { status: 'ok', datasets: get_user_rankings_datasets() };
                    }
                } else if (action === 'UPLOAD_CUSTOM_RANKINGS') {
                    const set_name = msg.set_name;
                    const rankings = msg.rankings;
                    const session = await get_session_data();
                    if (!session?.user_uuid) {
                        response = { status: 'error', message: 'Sign in to upload rankings.' };
                    } else if (!set_name || (set_name !== 'ud_bbm' && set_name !== 'dk_bbm')) {
                        response = { status: 'error', message: 'Invalid set_name.' };
                    } else if (!Array.isArray(rankings)) {
                        response = { status: 'error', message: 'Invalid rankings.' };
                    } else if (rankings.length === 0) {
                        // An empty upload overwrites the saved set server-side. This can only
                        // happen if the UI rendered an empty list from stale/failed state, so
                        // refuse it rather than destroying the user's real rankings.
                        response = {
                            status: 'error',
                            message: 'No rankings to upload. Your saved rankings were left unchanged.',
                        };
                    } else {
                        try {
                            response = await upload_custom_rankings_and_refresh({ set_name, rankings, session });
                        } catch (err) {
                            const backendMessage = (err?.responseBody && (err.responseBody.detail ?? err.responseBody.message)) ?? err?.message ?? 'Upload failed';
                            response = { status: 'error', message: backendMessage };
                        }
                    }
                } else if (action === 'GET_CONFIG_SNAPSHOT') {
                    await ensure_config_ready();
                    const snapshot = {
                        schema_version: configState.data?.schema_version ?? CONFIG_FALLBACK.schema_version ?? null,
                        content_script_settings: await get_content_script_settings(),
                        background_settings: await load_background_settings(),
                        content_script_datasets: get_content_script_datasets(),
                    };
                    response = { status: 'ok', snapshot };
                } else if (action === 'GET_MATCHUP_PROBABILITIES') {
                    const res = await storage.get(KEYS.matchup_odds_fields);
                    const data = (res && res[KEYS.matchup_odds_fields]) || null;
                    if (data) {
                        response = { status: 'success', data };
                    } else {
                        response = { status: 'error', message: 'matchup odds not found' };
                    }
                } else if (action === 'GET_AUTH_STATUS') {
                    const session = await validate_session_via_http();
                    response = { status: 'ok', session };
                } else if (action === 'OPEN_NEW_TAB') {
                    if (!msg.url) {
                        response = { status: 'error', message: 'missing url' };
                    } else {
                        const bg = await load_background_settings();
                        const server = compute_server_address(bg);
                        let redirect_to = null;
                        let real_url = msg.url;
                        try {
                            const u = new URL(msg.url);
                            redirect_to = u.searchParams.get('redirect_to');
                            real_url = redirect_to ? `https://${server}/${redirect_to}` : msg.url;
                        } catch (err) {
                        }
                        
                        const openActive = msg.active === true;
                        const shouldReload = msg.reload === true
                            || (!openActive && !String(real_url || '').includes('sidekick'));

                        const replyOk = (result) => {
                            port.postMessage({ request_id, status: 'ok', result });
                        };

                        const focusTab = (tabId, done) => {
                            chrome.tabs.get(tabId, (tab) => {
                                if (chrome.runtime.lastError || !tab) {
                                    chrome.tabs.update(tabId, { active: true }, () => done?.());
                                    return;
                                }
                                const finish = () => {
                                    chrome.tabs.update(tabId, { active: true }, () => done?.());
                                };
                                if (typeof tab.windowId === 'number' && chrome.windows?.update) {
                                    chrome.windows.update(tab.windowId, { focused: true }, () => {
                                        void chrome.runtime.lastError;
                                        finish();
                                    });
                                } else {
                                    finish();
                                }
                            });
                        };

                        chrome.tabs.query({}, (tabs) => {
                            let found = false;
                            for (const tab of tabs) {
                                const tabUrl = tab.url || '';
                                if (real_url && tabUrl.includes(real_url)) {
                                    const finishExisting = () => {
                                        if (shouldReload) {
                                            chrome.tabs.reload(tab.id, () => {
                                                replyOk({
                                                    status: openActive ? 'switched_and_refreshed_existing_tab' : 'tab_refreshed',
                                                    tabId: tab.id
                                                });
                                            });
                                        } else {
                                            replyOk({
                                                status: 'switched_to_existing_tab',
                                                tabId: tab.id
                                            });
                                        }
                                    };
                                    if (openActive) {
                                        focusTab(tab.id, finishExisting);
                                    } else if (shouldReload) {
                                        chrome.tabs.reload(tab.id, () => {
                                            replyOk({ status: 'tab_refreshed', tabId: tab.id });
                                        });
                                    } else {
                                        focusTab(tab.id, () => {
                                            replyOk({ status: 'switched_to_existing_tab', tabId: tab.id });
                                        });
                                    }
                                    found = true;
                                    break;
                                }
                            }

                            if (!found) {
                                const targetUrl = redirect_to ? msg.url : real_url;
                                chrome.tabs.create({ url: targetUrl, active: openActive }, (tab) => {
                                    replyOk({ status: 'tab_opened', tabId: tab?.id || null });
                                });
                            }
                        });
                        return;
                    }
                } else if (action === 'OPEN_EXTENSION_POPUP') {
                    try {
                        if (state.popup_port) {
                            try {
                                state.popup_port.postMessage({ action: 'CLOSE_POPUP_UI' });
                            } catch (e) {
                            }
                            response = { status: 'ok', result: { toggled: 'closed' } };
                        } else {
                            const actionApi = (typeof browser !== 'undefined' && browser.action)
                                ? browser.action
                                : (typeof chrome !== 'undefined' ? chrome.action : null);
                            if (!actionApi?.openPopup) {
                                response = { status: 'error', message: 'openPopup not available' };
                            } else {
                                const wid = port.sender?.tab?.windowId;
                                const opts = typeof wid === 'number' ? { windowId: wid } : undefined;
                                await actionApi.openPopup(opts);
                                response = { status: 'ok', result: { toggled: 'opened' } };
                            }
                        }
                    } catch (e) {
                        response = { status: 'error', message: e?.message || 'openPopup failed' };
                    }
                } else if (action === 'FORCE_CONFIG_REFRESH') {
                    try {
                        await refresh_config({ force: true });
                        response = { status: 'ok', message: 'Config refreshed successfully' };
                    } catch (err) {
                        console.error('[background-http] force config refresh failed:', err);
                        response = { status: 'error', message: err.message || 'Config refresh failed' };
                    }
                } else if (action === 'REQUEST_CONFIG_REFRESH_PLAYER_MAP') {
                    const now = Date.now();
                    const elapsed = now - (state.last_player_map_miss_config_refresh || 0);
                    if (elapsed >= CONFIG_REFRESH_PLAYER_MAP_MISS_MIN_INTERVAL_MS) {
                        try {
                            state.last_player_map_miss_config_refresh = now;
                            await refresh_config();
                            response = { status: 'ok', refreshed: true };
                        } catch (err) {
                            console.error('[background-http] player-map config refresh failed:', err);
                            response = { status: 'error', refreshed: false, message: err.message || 'Config refresh failed' };
                        }
                    } else {
                        response = { status: 'ok', refreshed: false, message: 'Rate limited' };
                    }
                } else if (action === 'RESET_DRAFT_SEED') {
                    const draftId = msg.draft_id || msg.draftId || null;
                    const session = await get_session_data();
                    const userUuid = msg.user_uuid || session?.user_uuid || null;
                    
                    if (!draftId) {
                        response = { status: 'error', message: 'missing draft_id' };
                    } else if (!userUuid) {
                        response = { status: 'error', message: 'missing user_uuid' };
                    } else {
                        try {
                            const headers = {};
                            if (session?.app_jwt) {
                                headers['Authorization'] = `Bearer ${session.app_jwt}`;
                            }
                            
                            await make_http_request('/reset-seed', {
                                method: 'POST',
                                body: {
                                    draft_id: draftId,
                                    user_uuid: userUuid
                                },
                                headers
                            });
                            
                            await clear_draft_state_for_id(draftId);
                            notify_content_scripts('FORCE_REPOLL', { draft_id: draftId });
                            response = { status: 'ok', draft_id: draftId };
                        } catch (err) {
                            console.error('[reset_draft_seed] failed', err);
                            response = { status: 'error', message: err?.message || 'reset failed' };
                        }
                    }
                } else if (action === 'RESET_DRAFT_STATE') {
                    const draftId = msg.draft_id || msg.draftId || null;
                    const session = await get_session_data();
                    const userUuid = msg.user_uuid || session?.user_uuid || null;
                    const requestIdentifier = msg.request_identifier || null;
                    
                    if (!draftId) {
                        response = { status: 'error', message: 'missing draft_id' };
                    } else if (!userUuid) {
                        response = { status: 'error', message: 'missing user_uuid' };
                    } else if (!requestIdentifier) {
                        response = { status: 'error', message: 'missing request_identifier' };
                    } else {
                        try {
                            // Stop all polls for this draft_id before resetting
                            stopAllPollsForDraftId(draftId, null);
                            
                            const headers = {};
                            if (session?.app_jwt) {
                                headers['Authorization'] = `Bearer ${session.app_jwt}`;
                            }
                            
                            await make_http_request('/reset-draft-state', {
                                method: 'POST',
                                body: {
                                    user_uuid: userUuid,
                                    draft_id: draftId,
                                    request_identifier: requestIdentifier
                                },
                                headers
                            });
                            
                            // Clear local cache for this draft_id
                            await clear_draft_state_for_id(draftId);
                            
                            response = { status: 'ok', draft_id: draftId, request_identifier: requestIdentifier };
                        } catch (err) {
                            console.error('[reset_draft_state] failed', err);
                            response = { status: 'error', message: err?.message || 'reset failed' };
                        }
                    }
                } else if (action === 'WAKE_UP') {
                    // Wake up the background script - used by content script keepalive watchdog
                    response = { status: 'ok', message: 'awake' };
                } else if (action === 'RESTART_BACKGROUND_SCRIPT') {
                    // Helper function to reload all tabs with content scripts (clears FSM memory)
                    const reload_content_script_tabs = (callback) => {
                        const content_script_urls = [
                            '*://www.legendaryupside.com/*',
                            '*://app.underdogsports.com/*',
                            '*://app.underdogfantasy.com/*',
                            '*://www.draftkings.com/*'
                        ];
                        
                        chrome.tabs.query({ url: content_script_urls }, (tabs) => {
                            let reloaded = 0;
                            const total = tabs.length;
                            
                            if (total === 0) {
                                if (callback) callback();
                                return;
                            }
                            
                            tabs.forEach((tab) => {
                                chrome.tabs.reload(tab.id, () => {
                                    if (chrome.runtime.lastError) {
                                    }
                                    reloaded++;
                                    if (reloaded === total) {
                                        if (callback) callback();
                                    }
                                });
                            });
                        });
                    };
                    
                    response = { status: 'ok', message: 'Background script restarting' };
                    // Reload content script tabs first to clear FSM memory, then restart background
                    reload_content_script_tabs(() => {
                        // Use setTimeout to ensure tabs are reloaded before background script restarts
                        setTimeout(() => {
                            chrome.runtime.reload();
                        }, 100);
                    });
                } else if (action === 'LOGOUT_AND_RESTART') {
                    // Helper function to reload all tabs with content scripts (clears FSM memory)
                    const reload_content_script_tabs = (callback) => {
                        const content_script_urls = [
                            '*://www.legendaryupside.com/*',
                            '*://app.underdogsports.com/*',
                            '*://app.underdogfantasy.com/*',
                            '*://www.draftkings.com/*'
                        ];
                        
                        chrome.tabs.query({ url: content_script_urls }, (tabs) => {
                            let reloaded = 0;
                            const total = tabs.length;
                            
                            if (total === 0) {
                                if (callback) callback();
                                return;
                            }
                            
                            tabs.forEach((tab) => {
                                chrome.tabs.reload(tab.id, () => {
                                    if (chrome.runtime.lastError) {
                                    }
                                    reloaded++;
                                    if (reloaded === total) {
                                        if (callback) callback();
                                    }
                                });
                            });
                        });
                    };
                    
                    response = { status: 'ok', message: 'Clearing storage and restarting' };
                    // Clear all storage (including all dynamic keys like tournament:*, draft:*, etc.)
                    // This matches what happens on extension uninstall/reinstall
                    chrome.storage.local.clear(() => {
                        reload_content_script_tabs(() => {
                            // Use setTimeout to ensure tabs are reloaded before background script restarts
                            setTimeout(() => {
                                chrome.runtime.reload();
                            }, 100);
                        });
                    });
                } else if (action === 'GET_TOURNAMENT_DATA') {
                    const draft_id = msg.draft_id;
                    
                    if (!draft_id) {
                        console.error(`[BG Tournament] GET_TOURNAMENT_DATA: Missing draft_id`);
                        response = { status: 'error', message: 'missing draft_id' };
                    } else {
                        try {
                            let tournament_data = await get_tournament_data(draft_id);
                            let from_cache = false;

                            if (!tournament_data) {
                                const fetched = await fetch_underdog_tournament(draft_id);
                                const tournament_id = fetched?.id || 'no_id';
                                const has_no_data = fetched?.no_tournament_data || false;
                                
                                const cached_tournament_data = await set_tournament_data(draft_id, fetched);
                                if (cached_tournament_data) {
                                    tournament_data = cached_tournament_data;
                                    from_cache = !has_no_data;
                                } else if (fetched?.no_tournament_data) {
                                    tournament_data = { no_tournament_data: true };
                                    from_cache = false;
                                    } else {
                                        response = { status: 'error', message: 'Failed to cache tournament data' };
                                    }
                            } else {
                                const tournament_id = tournament_data?.id || 'no_id';
                                from_cache = !tournament_data.no_tournament_data;
                                }

                            if (!response) {
                                const summary = buildUnderdogTournamentSummary(tournament_data);
                                response = { status: 'ok', tournament_summary: summary, from_cache };
                                // Trusted clients only; once per tournament_id per install (fire-and-forget).
                                maybe_submit_ud_tournament_slate_map(tournament_data);
                            }
                        } catch (err) {
                            console.error(`[BG Tournament] GET_TOURNAMENT_DATA: Exception for draft_id=${draft_id}:`, err);
                            
                            // Determine error type for better caching
                            let error_type = 'unknown';
                            let error_message = err?.message || 'Failed to fetch tournament data';
                            
                            if (error_message.includes('timeout') || error_message.includes('aborted')) {
                                error_type = 'timeout';
                            } else if (error_message.includes('Rate limit')) {
                                error_type = 'rate_limit';
                            } else if (error_message.includes('HTTP')) {
                                error_type = 'http_error';
                            }
                            
                            
                            // Cache the error to prevent repeated failed calls (short TTL for temporary errors)
                            await set_tournament_error_cache(draft_id, error_type, error_message);
                            
                            response = { status: 'error', message: error_message };
                        }
                    }
                    
                    const response_tail = response.status === 'ok' && response.tournament_summary ? { from_cache: response.from_cache, draft_size: response.tournament_summary.draft_size, contest_rounds: response.tournament_summary.contest_rounds, supported: response.tournament_summary.supported, reason: response.tournament_summary.reason } : {};
                } else if (action === 'ENRICH_UD_INTERCEPT_FROM_STYLE_IDS') {
                    try {
                        const enrichment = await enrichUnderdogInterceptSummaryFromStyleIds(msg);
                        response = { status: 'ok', enrichment };
                    } catch (err) {
                        console.error('[BG Tournament] ENRICH_UD_INTERCEPT_FROM_STYLE_IDS failed', err);
                        response = { status: 'error', message: err && err.message ? String(err.message) : 'enrich failed' };
                    }
                } else if (action === 'STORE_FANTASY_SITE_USERNAME') {
                    const site = msg.site;
                    const username = msg.username;
                    if (!site || username == null) {
                        response = { status: 'error', message: 'missing site or username' };
                    } else if (typeof store_fantasy_site_username !== 'function') {
                        response = { status: 'error', message: 'store_fantasy_site_username unavailable' };
                    } else {
                        const result = await store_fantasy_site_username(site, username);
                        response = { status: 'ok', ...result };
                    }
                } else if (action === 'CLEAR_FANTASY_SITE_USERNAME') {
                    const site = msg.site;
                    if (!site) {
                        response = { status: 'error', message: 'missing site' };
                    } else if (typeof clear_fantasy_site_username !== 'function') {
                        response = { status: 'error', message: 'clear_fantasy_site_username unavailable' };
                    } else {
                        const result = await clear_fantasy_site_username(site);
                        response = { status: 'ok', ...result };
                    }
                } else if (action === 'GET_FANTASY_SITE_USERNAME') {
                    const site = msg.site;
                    if (!site) {
                        response = { status: 'error', message: 'missing site' };
                    } else if (typeof get_fantasy_site_usernames !== 'function') {
                        response = { status: 'error', message: 'get_fantasy_site_usernames unavailable' };
                    } else if (site !== 'draftkings' && site !== 'dk' && site !== 'underdog' && site !== 'ud') {
                        response = { status: 'error', message: 'unknown site' };
                    } else {
                        const all = await get_fantasy_site_usernames();
                        const isDk = site === 'draftkings' || site === 'dk';
                        response = {
                            status: 'ok',
                            site: site,
                            username: isDk ? all.dk_username || null : all.ud_username || null,
                            updated_at_ms: isDk ? all.dk_username_updated_at_ms || null : all.ud_username_updated_at_ms || null
                        };
                    }
                } else if (action === 'STORE_UD_DRAFT_XHR_CAPTURE') {
                    const draft_id = msg.draft_id;
                    const url = msg.url;
                    const headers = msg.headers;
                    if (!draft_id || !url) {
                        response = { status: 'error', message: 'missing draft_id or url' };
                    } else {
                        await set_ud_draft_xhr_snapshot(draft_id, url, headers);
                        response = { status: 'ok' };
                    }
                } else if (action === 'MERGE_UD_EXPOSURE_FROM_OWNERSHIP') {
                    const rows = msg.rows;
                    if (!Array.isArray(rows)) {
                        response = { status: 'error', message: 'missing rows' };
                    } else if (typeof mergeUdExposureOwnershipRows !== 'function') {
                        response = { status: 'error', message: 'mergeUdExposureOwnershipRows unavailable' };
                    } else {
                        const slate_id = msg.slate_id != null && String(msg.slate_id).trim() ? String(msg.slate_id).trim() : null;
                        const ud_draft_count = Number(msg.ud_draft_count);
                        const draft_count = Number.isFinite(ud_draft_count) && ud_draft_count > 0 ? ud_draft_count : null;
                        const tournaments = Array.isArray(msg.tournaments) ? msg.tournaments : null;
                        if (draft_count == null) {
                            response = { status: 'error', message: 'missing ud_draft_count (ownership.draft_count)' };
                        } else {
                            const mergeResult = await mergeUdExposureOwnershipRows(rows, {
                                slate_id,
                                draft_count,
                                tournaments
                            });
                            if (mergeResult && mergeResult.merged === false) {
                                response = {
                                    status: 'ok',
                                    skipped: true,
                                    reason: mergeResult.reason || 'merge_rejected',
                                    slate_id,
                                    draft_count,
                                    prev_draft_count: mergeResult.prev_draft_count,
                                    max_pick_count: mergeResult.max_pick_count
                                };
                            } else {
                                response = {
                                    status: 'ok',
                                    skipped: false,
                                    row_count: rows.length,
                                    slate_id,
                                    draft_count
                                };
                            }
                        }
                    }
                } else if (action === 'MERGE_DK_EXPOSURE_FROM_LINEUPS') {
                    const slates = msg.slates;
                    if (!slates || typeof slates !== 'object' || Array.isArray(slates)) {
                        response = { status: 'error', message: 'missing slates object' };
                    } else if (typeof mergeDkExposureLineupsRows !== 'function') {
                        response = { status: 'error', message: 'mergeDkExposureLineupsRows unavailable' };
                    } else {
                        const keys = Object.keys(slates);
                        if (!keys.length) {
                            response = { status: 'error', message: 'empty slates' };
                        } else {
                            let invalid = null;
                            for (let si = 0; si < keys.length; si++) {
                                const k = keys[si];
                                const ent = slates[k];
                                if (!ent || typeof ent !== 'object') {
                                    invalid = 'invalid slate entry';
                                    break;
                                }
                                const te = Number(ent.total_entries);
                                if (!Number.isFinite(te) || te <= 0) {
                                    invalid = 'missing total_entries for slate ' + k;
                                    break;
                                }
                                if (!Array.isArray(ent.rows) || !ent.rows.length) {
                                    invalid = 'missing rows for slate ' + k;
                                    break;
                                }
                            }
                            if (invalid) {
                                response = { status: 'error', message: invalid };
                            } else {
                                try {
                                    await mergeDkExposureLineupsRows(slates);
                                    response = { status: 'ok', slate_count: keys.length };
                                } catch (mergeErr) {
                                    response = {
                                        status: 'error',
                                        message: mergeErr && mergeErr.message ? String(mergeErr.message) : 'merge_error'
                                    };
                                }
                            }
                        }
                    }
                } else if (action === 'FORCE_EXPOSURE_SYNC') {
                    const forceSites = Array.isArray(msg.forceSites) ? msg.forceSites : [];
                    if (!forceSites.length) {
                        response = { status: 'error', message: 'missing forceSites' };
                    } else if (typeof scheduleExposureSyncToBackend !== 'function') {
                        response = { status: 'error', message: 'scheduleExposureSyncToBackend unavailable' };
                    } else {
                        scheduleExposureSyncToBackend({ forceSites });
                        response = { status: 'ok', forceSites };
                    }
                } else if (action === 'GET_UD_DRAFT_XHR_SNAPSHOT') {
                    const draft_id = msg.draft_id;
                    if (!draft_id) {
                        response = { status: 'error', message: 'missing draft_id' };
                    } else {
                        const snapshot = await get_ud_draft_xhr_snapshot(draft_id);
                        if (snapshot) {
                            response = { status: 'ok', snapshot };
                        } else {
                            response = { status: 'not_found', snapshot: null };
                        }
                    }
                } else if (action === 'DISPATCH_UD_DRAFT_XHR_REPLAY') {
                    const draft_id = msg.draft_id;
                    if (!draft_id) {
                        response = { status: 'error', message: 'missing draft_id' };
                    } else if (typeof actualTabId !== 'number') {
                        response = { status: 'error', message: 'no_tab_id' };
                    } else {
                        const snapshot = await get_ud_draft_xhr_snapshot(draft_id);
                        if (!snapshot || !snapshot.url) {
                            response = { status: 'not_found', message: 'no snapshot' };
                        } else {
                            const detail = {
                                url: snapshot.url,
                                headers: snapshot.headers && typeof snapshot.headers === 'object' ? snapshot.headers : {}
                            };
                            try {
                                await chrome.scripting.executeScript({
                                    target: { tabId: actualTabId },
                                    world: 'MAIN',
                                    func: (d) => {
                                        window.dispatchEvent(
                                            new CustomEvent('__legup_ud_replay_draft_xhr', { detail: d })
                                        );
                                    },
                                    args: [detail]
                                });
                                response = { status: 'ok' };
                            } catch (err) {
                                console.error('[BG] DISPATCH_UD_DRAFT_XHR_REPLAY executeScript failed', err);
                                response = {
                                    status: 'error',
                                    message: err?.message || String(err)
                                };
                            }
                        }
                    }
                } else if (action === 'GET_DK_TOURNAMENT_DATA') {
                    const draft_id = msg.draft_id;
                    const tournament_key = msg.tournament_key;
                    if (!draft_id || !tournament_key) {
                        response = { status: 'error', message: 'missing draft_id or tournament_key' };
                    } else {
                        try {
                            const tournament_data = await get_tournament_data_dk(draft_id);
                            
                            if (tournament_data) {
                                response = { status: 'ok', tournament_data, from_cache: true };
                            } else {
                                // Not in cache - return null, content script will fetch and cache it
                                response = { status: 'ok', tournament_data: null, from_cache: false };
                            }
                        } catch (err) {
                            console.error('[get_tournament_data_dk] failed', err);
                            response = { status: 'error', message: err?.message || 'Failed to get tournament data' };
                        }
                    }
                } else if (action === 'GET_DK_CONTEST_DATA') {
                    const draft_id = msg.draft_id;
                    if (!draft_id) {
                        response = { status: 'error', message: 'missing draft_id' };
                    } else {
                        try {
                            const contest_data = await get_contest_data_dk(draft_id);
                            
                            if (contest_data) {
                                response = { status: 'ok', contest_data, from_cache: true };
                            } else {
                                // Not in cache - return null, content script will fetch and cache it
                                response = { status: 'ok', contest_data: null, from_cache: false };
                            }
                        } catch (err) {
                            console.error('[get_contest_data_dk] failed', err);
                            response = { status: 'error', message: err?.message || 'Failed to get contest data' };
                        }
                    }
                } else if (action === 'SET_DK_CONTEST_DATA') {
                    const draft_id = msg.draft_id;
                    const contest_data = msg.contest_data;
                    if (!draft_id || !contest_data) {
                        response = { status: 'error', message: 'missing draft_id or contest_data' };
                    } else {
                        try {
                            const contest_id = draft_id; // For DraftKings, contest_id is the same as draft_id
                            await set_contest_data_dk(draft_id, contest_id, contest_data);
                            response = { status: 'ok' };
                        } catch (err) {
                            console.error('[set_contest_data_dk] failed', err);
                            response = { status: 'error', message: err?.message || 'Failed to cache contest data' };
                        }
                    }
                } else if (action === 'SET_DK_TOURNAMENT_DATA') {
                    const draft_id = msg.draft_id;
                    const tournament_key = msg.tournament_key;
                    const tournament_data = msg.tournament_data;
                    if (!draft_id || !tournament_key || !tournament_data) {
                        response = { status: 'error', message: 'missing draft_id, tournament_key, or tournament_data' };
                    } else {
                        try {
                            await set_tournament_data_dk(draft_id, tournament_key, tournament_data);
                            // Trusted clients only; once per tournament_key per install (fire-and-forget).
                            maybe_submit_dk_tournament_map(tournament_key, tournament_data);
                            response = { status: 'ok' };
                        } catch (err) {
                            console.error('[set_tournament_data_dk] failed', err);
                            response = { status: 'error', message: err?.message || 'Failed to cache tournament data' };
                        }
                    }
                } else if (action === 'DKSLATES_REQUEST') {
                    // Handle DraftKings slate data request
                    try {
                        // Refresh session if JWT is expired or near expiration
                        const session = await refresh_session_if_needed();
                        
                        if (!session?.user_uuid) {
                            response = { status: 'error', message: 'Missing user_uuid in session' };
                        } else {
                            // Check if user is allowed to send dkslates data
                            if (!TRUSTED_DATA_UPLOAD_UUIDS.includes(session.user_uuid)) {
                                response = { status: 'error', message: 'User not authorized to send dkslates data' };
                            } else {
                                const slate_data = msg.slate_data || {};
                                
                                if (!slate_data || typeof slate_data !== 'object' || Object.keys(slate_data).length === 0) {
                                    response = { status: 'error', message: 'Invalid or empty slate_data' };
                                } else {
                                    // Prepare request payload with user_uuid
                                    const request_payload = {
                                        user_uuid: session.user_uuid,
                                        slate_data: slate_data
                                    };


                                    // Make HTTP request with JWT in Authorization header
                                    const headers = {};
                                    if (session?.app_jwt) {
                                        headers['Authorization'] = `Bearer ${session.app_jwt}`;
                                    }

                                    try {
                                        const backendResponse = await make_http_request('/dkslates', {
                                            method: 'POST',
                                            body: request_payload,
                                            headers: headers
                                        });


                                        response = {
                                            status: 'success',
                                            message: backendResponse?.message || `Stored ${Object.keys(slate_data).length} slate(s) successfully`,
                                            data: backendResponse
                                        };
                                    } catch (httpError) {
                                        console.error('[background-http] HTTP error calling /api/dkslates:', httpError);
                                        response = { 
                                            status: 'error', 
                                            message: httpError?.message || 'Failed to send slate data to backend'
                                        };
                                    }
                                }
                            }
                        }
                    } catch (error) {
                        console.error('[background-http] Error processing dkslates request:', error);
                        console.error('[background-http] Error stack:', error?.stack);
                        response = { status: 'error', message: error?.message || 'Failed to send slate data to backend' };
                    }
                } else if (action === 'UD_STYLES_REQUEST') {
                    // Handle Underdog contest/entry styles data request
                    try {
                        // Refresh session if JWT is expired or near expiration
                        const session = await refresh_session_if_needed();
                        
                        if (!session?.user_uuid) {
                            response = { status: 'error', message: 'Missing user_uuid in session' };
                        } else {
                            // Reuse the same allowlist as DK slates / tournament slate map
                            if (!TRUSTED_DATA_UPLOAD_UUIDS.includes(session.user_uuid)) {
                                response = { status: 'error', message: 'User not authorized to send UD styles data' };
                            } else {
                                // Fetch cached (or live) contest/entry styles
                                const [contest_styles, entry_styles] = await Promise.all([
                                    fetch_contest_styles(),
                                    fetch_entry_styles()
                                ]);

                                const ud_styles = {
                                    contest_styles: Array.isArray(contest_styles) ? contest_styles : [],
                                    entry_styles: Array.isArray(entry_styles) ? entry_styles : []
                                };

                                const request_payload = {
                                    user_uuid: session.user_uuid,
                                    ud_styles
                                };

                                const headers = {};
                                if (session?.app_jwt) {
                                    headers['Authorization'] = `Bearer ${session.app_jwt}`;
                                }

                                try {
                                    const backendResponse = await make_http_request('/udstyles', {
                                        method: 'POST',
                                        body: request_payload,
                                        headers: headers
                                    });


                                    response = {
                                        status: 'success',
                                        message: backendResponse?.message || `Stored UD styles successfully`,
                                        data: backendResponse
                                    };
                                } catch (httpError) {
                                    console.error('[background-http] HTTP error calling /api/udstyles:', httpError);
                                    response = { 
                                        status: 'error', 
                                        message: httpError?.message || 'Failed to send UD styles data to backend'
                                    };
                                }
                            }
                        }
                    } catch (error) {
                        console.error('[background-http] Error processing UD styles request:', error);
                        console.error('[background-http] Error stack:', error?.stack);
                        response = { status: 'error', message: error?.message || 'Failed to send UD styles data to backend' };
                    }
                } else {
                    response = { status: 'error', message: `Unknown action: ${action}` };
                }
                
                if (response !== null) {
                    port.postMessage({ request_id, ...response });
                }
            } catch (err) {
                console.error(`[port handler] Error handling ${action}:`, err);
                port.postMessage({ 
                    request_id, 
                    status: 'error', 
                    message: err?.message || 'Internal error' 
                });
            }
            return;
        }
        
        // Legacy actions without request_id (keep for backward compatibility)
        if (msg?.action === 'CS_GET_STATE') {
            await sendHello();
        } else if (msg?.action === 'RANKINGS_REQUEST') {
            
            try {
                const sessionForRankings = await read_session_data_from_storage();
                if (!session_allows_sidekick_rankings(sessionForRankings)) {
                    const env = (typeof BASE_BG !== 'undefined' && BASE_BG && BASE_BG.env) ? BASE_BG.env : 'prod';
                    if (['dev', 'local'].includes(env)) {
                        const temp = {
                            user_uuid: sessionForRankings?.user_uuid || null,
                            allow_rankings: sessionForRankings?.allow_rankings ?? null,
                            tier: sessionForRankings?.tier ?? null
                        };
                    }
                    if (typeof notifyRankingsRequestFailed === 'function') {
                        const gateReason = sessionForRankings?.reason || null;
                        const gateMessage = (typeof auth_reason_user_message === 'function'
                            ? auth_reason_user_message(gateReason)
                            : '')
                            || gateReason
                            || 'Sidekick access required for rankings. Refresh your session at legendaryupside.com.';
                        notifyRankingsRequestFailed(port, {
                            request_identifier: msg.data?.request_identifier || null,
                            draft_id: msg.data?.draft?.draft_id || msg.data?.draft_id || null,
                            message: gateMessage,
                            type: 'auth_error',
                            reason: 'sidekick_gate'
                        });
                    } else if (typeof notify_auth_status === 'function') {
                        notify_auth_status(sessionForRankings || null);
                    }
                    return;
                }

                // Skip debounce logic only for in-flight result polling
                const is_poll_for_results = Boolean(msg.data?.poll_for_results);
                let shouldProcess = false;
                const queueMetrics = state.queue_metrics;
                
                if (queueMetrics) {
                    queueMetrics.total_requests++;
                    queueMetrics.interval_requests++;
                    if (is_poll_for_results) {
                        queueMetrics.total_poll_requests++;
                        queueMetrics.interval_poll_requests++;
                    }
                }
                
                if (is_poll_for_results) {
                    // For in-flight polling, skip debounce and go straight to processing
                    shouldProcess = true;
                } else {
                    // All requests go through debounce logic
                    const debounceResult = await process_draft_state_debounce(msg.data);
                    shouldProcess = debounceResult.shouldProcess;
                }
                
                if (shouldProcess) {
                    const request_identifier = msg.data.request_identifier;
                    if (!request_identifier) {
                        return;
                    }
                    
                    // Check for duplicate in-flight request using identifier (atomic check-and-set)
                    // Allow polling requests through even if there's an in-flight request (we're checking for results)
                    if (!is_poll_for_results) {
                        // Atomically check and set to prevent race conditions when multiple tabs send requests simultaneously
                        const existingMarker = inFlightRankingsRequests.get(request_identifier);
                        const markerAgeMs = existingMarker
                            ? Date.now() - (existingMarker.at || 0)
                            : null;
                        if (existingMarker && markerAgeMs <= IN_FLIGHT_MARKER_STALE_MS) {
                            const tabId = port.sender?.tab?.id || 'unknown';
                            const duplicateRequestData = {
                                request_identifier,
                                tabId,
                                queue_size: rankingsRequestQueue.queue.length,
                                processing: rankingsRequestQueue.processing
                            };
                            if (queueMetrics) {
                                queueMetrics.total_duplicates++;
                                queueMetrics.interval_duplicates++;
                            }
                            return;
                        }
                        if (existingMarker) {
                            // Self-heal: a marker this old means its request died without
                            // running cleanup (dropped queue item, thrown before processing).
                            // Deduping against it would swallow every retry for this pick
                            // until the reload button or a service-worker restart cleared it.
                            // console.error so this survives the prod log strip — it is the
                            // signal that a marker leaked, and the bug it guards was invisible
                            // for months precisely because nothing was logged in prod.
                            const stale_marker_log_data = {
                                request_identifier,
                                marker_age_ms: markerAgeMs
                            };
                            console.error('[background-http] Clearing stale in-flight marker and processing request', stale_marker_log_data);
                            inFlightRankingsRequests.delete(request_identifier);
                            if (queueMetrics) {
                                queueMetrics.total_stale_markers_cleared++;
                            }
                        }
                        // Mark as in-flight immediately to prevent race conditions
                        // We'll set the actual promise later after queue processing
                        inFlightRankingsRequests.set(request_identifier, { promise: Promise.resolve(), at: Date.now() });
                    }
                    
                    const cache = await get_rankings_cache();
                    const cached_response = cache[request_identifier];
                    const use_cached_rankings = Boolean(msg.data?.use_cached_rankings);
                    
                    if (use_cached_rankings && cached_response) {
                        if (cached_response.request_identifier === request_identifier) {
                            
                            try {
                                const algo_type = msg.data.algo_type || cached_response.algo_type;
                                
                                // If we have the full sim-like structure stored, extract picks based on current algo_type
                                let picks_for_response;
                                if (cached_response.classic_picks || cached_response.sim_picks || cached_response.blended_picks) {
                                    // Reconstruct response structure and extract picks based on current algo_type
                                    const response_structure = {
                                        classic_picks: cached_response.classic_picks,
                                        sim_picks: cached_response.sim_picks,
                                        blended_picks: cached_response.blended_picks,
                                        picks: cached_response.picks
                                    };
                                    picks_for_response = extract_picks_from_response(response_structure, algo_type);
                                } else {
                                    picks_for_response = cached_response.picks;
                                }
                                
                                // For sim algo_type, if extract_picks_from_response returned null (blended_picks missing),
                                // treat as cache miss - don't send invalid picks
                                if (algo_type && algo_type.toLowerCase() === 'sim' && !picks_for_response) {
                                    // Fall through to make new request
                                } else {
                                    if (picks_for_response && Array.isArray(picks_for_response) && picks_for_response.length > 0) {
                                        // Cache hit - just return, don't send UPDATE_RECOMMENDED_PICKS
                                        // Content script will poll for cached rankings via CHECK_CACHED_RANKINGS
                                        inFlightRankingsRequests.delete(request_identifier);
                                        // Nudge so the requesting tab pulls the cached row immediately.
                                        notifyRankingsResultsReady(port, port.sender?.tab?.id, {
                                            request_identifier,
                                            draft_id: msg.data?.draft?.draft_id || msg.data?.draft_id || null,
                                            num_picks: cached_response.num_picks ?? null
                                        });
                                        return;
                                    } else {
                                        // Fall through to make new request
                                    }
                                }
                            } catch (cacheError) {
                                console.error('[background-http] Error processing cache hit, bypassing cache and making new request:', cacheError);
                                // Fall through to make new request
                            }
                        } else {
                        }
                    } else if (cached_response) {
                    }
                    
                    // Get tabId for logging
                    const tabId = port.sender?.tab?.id || 'unknown';
                    
                    // Process the actual rankings request
                    const processRankingsRequest = async () => {
                        const startTime = Date.now();
                        const processingData = {
                            request_identifier,
                            tabId,
                            queue_size: rankingsRequestQueue.queue.length,
                            processing: rankingsRequestQueue.processing
                        };
                        
                        try {
                            // Refresh session if JWT is expired or near expiration
                            const session = await refresh_session_if_needed();
                            
                            // Rankings requests are now lean; enrichment happens in the backend
                            const request_data = msg.data && typeof msg.data === 'object' ? msg.data : {};
                            
                            const advancement_structure_with_evs = await prepare_advancement_structure_for_rankings(
                                request_data.advancement_structure || null,
                                {
                                    tournament_info: request_data.tournament_info,
                                    draft_id: request_data.draft?.draft_id || null,
                                    format_type: request_data.format_type || null,
                                    log_prefix: '[background-http]'
                                }
                            );
                            
                            // use_prod_url is dev-only (e.g. draft test page); strip from payload and use for routing only
                            const use_prod_url = Boolean(request_data.use_prod_url);
                            const { use_prod_url: _dropped, ...request_data_for_backend } = request_data;
                            // Prepare the request payload with enriched data
                            // current_roster is inside draft
                            const request_payload = {
                                ...(is_poll_for_results ? { poll: true } : {}),
                                ...request_data_for_backend,
                                extension_version: get_extension_version(),
                                user_uuid: session?.user_uuid || null,
                                request_identifier: request_identifier,
                                advancement_structure: advancement_structure_with_evs
                            };

                            if (request_data.format_type === 'sprint' && request_payload.tournament_info) {
                                request_payload.tournament_info = {
                                    ...request_payload.tournament_info,
                                    payout_structure: flattenUnderdogSprintPayoutStructureIfApplicable(
                                        request_payload.tournament_info.payout_structure,
                                        'sprint'
                                    )
                                };
                            }

                            if (request_data.ranking_set === 'custom') {
                                await ensure_config_ready();
                                const custom_rankings = custom_rankings_for_rankings_request(request_data);
                                if (custom_rankings !== undefined) {
                                    request_payload.custom_rankings = custom_rankings;
                                }
                            }
                            
                            // Log the full ranking request being sent to the backend
                            
                            // Make the HTTP request to the backend (Bearer app JWT required via auth retry helper).
                            // Bounded at 20s to match the content script's own give-up-and-retry timeout;
                            // a slot sitting on a hung request past that starves the 3-slot queue.
                            const response = await make_http_request_with_auth_retry('/rankings', {
                                method: 'POST',
                                body: request_payload,
                                useProdUrl: use_prod_url,
                                timeoutMs: RANKINGS_HTTP_TIMEOUT_MS
                            });
                            
                            
                            // Check if response indicates request is in-flight
                            if (response && response.status === 'in_flight' && response.request_identifier) {
                                
                                // Start polling timer for this in-flight request
                                startInFlightPolling(response.request_identifier, port, {
                                    request_identifier: request_identifier,
                                    ...request_data,
                                    advancement_structure: request_data.advancement_structure,
                                    num_picks: request_data.num_picks ?? request_data.draft?.picks?.length ?? 0,
                                    user_uuid: session?.user_uuid || null
                                });
                                
                                return response;
                            }
                            
                            // Determine picks array - handle both regular picks and sim algo dynamic_sim_rankings
                            // Also handle new sim-like response structure (classic_picks, sim_picks, blended_picks)
                            let picks = extract_picks_from_response(response, request_data.algo_type);
                            
                            // Store response in cache using identifier
                            // For sim-like responses, store the full structure so we can extract correct picks for different algo types
                            if (picks && Array.isArray(picks) && picks.length > 0) {
                                const num_picks = request_data.num_picks ?? request_data.draft?.picks?.length ?? 0;
                                const cache_entry = {
                                    picks: picks,
                                    advancement_structure: response.advancement_structure || {},
                                    request_identifier: request_identifier,
                                    algo_type: request_data.algo_type,
                                    timestamp: Date.now(),
                                    num_picks: num_picks,
                                    draft_id: request_data.draft?.draft_id || null
                                };

                                // If this is a sim-like response with the new structure, store the full structure
                                if (is_sim_like_algo(request_data.algo_type) &&
                                    (response.classic_picks || response.sim_picks || response.blended_picks)) {
                                    cache_entry.classic_picks = response.classic_picks;
                                    cache_entry.sim_picks = response.sim_picks;
                                    cache_entry.blended_picks = response.blended_picks;
                                }

                                const draft_id_for_cache = request_data.draft?.draft_id || null;
                                // Serialized store: never write back the snapshot read at message
                                // arrival — by now it can be 20+ seconds stale and missing every
                                // entry other drafts cached in the meantime.
                                await store_rankings_cache_entry(draft_id_for_cache, request_identifier, cache_entry);


                                // Stop polling if it was active (results arrived)
                                stopInFlightPolling(request_identifier);
                                // Nudge the owning tab to pull the fresh row now instead of
                                // waiting for its next extraction tick.
                                notifyRankingsResultsReady(port, port.sender?.tab?.id, {
                                    request_identifier,
                                    draft_id: draft_id_for_cache,
                                    num_picks: cache_entry.num_picks
                                });
                            }
                            return response;
                        } catch (rankingsError) {
                            const extensionUpdateMessage = getExtensionUpdateMessage(rankingsError);
                            if (extensionUpdateMessage) {
                                const notificationMessage = `Your extension is out of date. Click the refresh button to update it. ${extensionUpdateMessage}`;
                                if (typeof broadcast_notification === 'function') {
                                    broadcast_notification(notificationMessage, 'auth_error_update');
                                }
                            }
                            const errorTime = Date.now() - startTime;
                            console.error('[background-http] Error fetching rankings:', {
                                request_identifier,
                                tabId,
                                error: rankingsError?.message || rankingsError,
                                duration_ms: errorTime
                            });

                            // Silent only when 401 was already recovered inside make_http_request_with_auth_retry.
                            // Any surfaced failure here must unblock the overlay.
                            if (!extensionUpdateMessage && typeof notifyRankingsRequestFailed === 'function') {
                                const detail = (typeof auth_error_detail === 'function'
                                    ? auth_error_detail(rankingsError)
                                    : '') || String(rankingsError?.message || '');
                                const isAuth = rankingsError?.status === 401
                                    || /token_expired|session expired|sign in at legendaryupside|auth:/i.test(detail);
                                const isSub = typeof is_rankings_subscription_error === 'function'
                                    && is_rankings_subscription_error(rankingsError);
                                let message = 'Rankings request failed. Try again shortly.';
                                let type = 'rankings_error';
                                let reason = 'request_failed';
                                if (isAuth) {
                                    const authReason = (typeof auth_reason_app_jwt_expired === 'function'
                                        ? auth_reason_app_jwt_expired()
                                        : 'auth:app_jwt_expired');
                                    message = (typeof auth_reason_user_message === 'function'
                                        ? auth_reason_user_message(authReason)
                                        : null)
                                        || (typeof ghost_jwt_expired_reason === 'function'
                                            ? ghost_jwt_expired_reason()
                                            : authReason);
                                    type = 'auth_error';
                                    reason = 'auth';
                                } else if (isSub) {
                                    message = detail || 'Sidekick subscription required for rankings.';
                                    type = 'auth_error';
                                    reason = 'subscription';
                                }
                                notifyRankingsRequestFailed(port, {
                                    request_identifier,
                                    draft_id: msg.data?.draft?.draft_id || msg.data?.draft_id || null,
                                    message,
                                    type,
                                    reason
                                });
                            }
                            throw rankingsError;
                        } finally {
                            const totalTime = Date.now() - startTime;
                            const completedData = {
                                request_identifier,
                                tabId,
                                duration_ms: totalTime
                            };
                            // Clear the in-flight request when done
                            inFlightRankingsRequests.delete(request_identifier);
                        }
                    };
                    
                    // Process request through queue to limit concurrent processing
                    const draftIdForQueue = msg.data?.draft?.draft_id || msg.data?.draft_id || null;
                    const requestPromise = (async () => {
                        // Wait for queue slot to become available
                        await new Promise((resolve) => {
                            const processRequest = async () => {
                                rankingsRequestQueue.processing++;
                                resolve();
                                
                                try {
                                    await processRankingsRequest();
                                } finally {
                                    rankingsRequestQueue.processing--;
                                    // Process next fresh item in queue if available
                                    const next = typeof shiftFreshQueueItem === 'function'
                                        ? shiftFreshQueueItem(rankingsRequestQueue)
                                        : rankingsRequestQueue.queue.shift();
                                    if (next) {
                                        const run = typeof next === 'function' ? next : next.run;
                                        if (typeof run === 'function') {
                                            run();
                                        }
                                    }
                                }
                            };
                            
                            if (rankingsRequestQueue.processing < rankingsRequestQueue.maxConcurrent) {
                                processRequest();
                            } else {
                                const queueItem = {
                                    run: processRequest,
                                    enqueued_at: Date.now(),
                                    request_identifier,
                                    draft_id: draftIdForQueue,
                                    // Runs if this item is discarded without ever processing
                                    // (queue cap, stale TTL, or superseded by a newer pick).
                                    // Without this the in-flight marker leaks and the duplicate
                                    // filter swallows every retry for this request forever.
                                    onDrop: (dropReason) => {
                                        inFlightRankingsRequests.delete(request_identifier);
                                        if (queueMetrics) {
                                            queueMetrics.total_dropped++;
                                            queueMetrics.interval_dropped++;
                                        }
                                        if (dropReason !== 'superseded') {
                                            // console.error so load-shedding stays visible in prod;
                                            // a dropped request is real work lost, not just noise.
                                            const drop_log_data = { request_identifier, draft_id: draftIdForQueue, reason: dropReason };
                                            console.error('[background-http] Rankings request dropped from queue', drop_log_data);
                                        }
                                        // Superseded means a newer request for this draft is queued
                                        // from the same tab; the content script is already waiting
                                        // on that one, so don't disturb its state.
                                        if (dropReason !== 'superseded' && typeof notifyRankingsRequestFailed === 'function') {
                                            notifyRankingsRequestFailed(port, {
                                                request_identifier,
                                                draft_id: draftIdForQueue,
                                                message: 'Rankings request dropped under load — retrying',
                                                type: 'rankings_error',
                                                reason: 'queue_dropped',
                                                broadcast: false
                                            });
                                        }
                                    }
                                };
                                // Newest wins per draft: a queued request for an older state of
                                // this draft is worthless the moment this one exists, and letting
                                // it age out via TTL is exactly the silent-drop path that poisons
                                // drafts. Replace it deliberately and clean up its marker.
                                if (draftIdForQueue) {
                                    for (let qi = rankingsRequestQueue.queue.length - 1; qi >= 0; qi--) {
                                        const queued = rankingsRequestQueue.queue[qi];
                                        if (queued && queued.draft_id === draftIdForQueue && queued.request_identifier !== request_identifier) {
                                            rankingsRequestQueue.queue.splice(qi, 1);
                                            if (BASE_BG.env !== 'prod') {
                                                const supersede_log_data = {
                                                    superseded: queued.request_identifier,
                                                    by: request_identifier
                                                };
                                            }
                                            if (typeof runQueueItemOnDrop === 'function') {
                                                runQueueItemOnDrop(queued, 'superseded', 'background-http');
                                            } else if (typeof queued.onDrop === 'function') {
                                                queued.onDrop('superseded');
                                            }
                                        }
                                    }
                                }
                                if (typeof enqueueBoundedQueue === 'function') {
                                    enqueueBoundedQueue(rankingsRequestQueue, queueItem, 'background-http');
                                } else {
                                    rankingsRequestQueue.queue.push(queueItem);
                                }
                                if (queueMetrics) {
                                    queueMetrics.total_enqueued++;
                                    queueMetrics.interval_enqueued++;
                                }
                                const queuedRequestData = {
                                    request_identifier,
                                    tabId,
                                    queue_position: rankingsRequestQueue.queue.length,
                                    processing: rankingsRequestQueue.processing
                                };
                            }
                        });
                    })();
                    
                    // Store the promise to track this in-flight request (timestamped so the
                    // duplicate filter can detect and clear orphaned markers)
                    inFlightRankingsRequests.set(request_identifier, { promise: requestPromise, at: Date.now() });
                }
            } catch (error) {
                console.error('[background-http] Error processing rankings request:', error);
            }
        } else if (msg?.action === 'REQUEST_CACHED_RANKINGS') {
            try {
                const request_data = msg.data || {};
                const request_identifier = request_data.request_identifier;
                if (!request_identifier) {
                    return;
                }

                const cache = await get_rankings_cache();
                const cached_response = cache[request_identifier];

                if (cached_response && Array.isArray(cached_response.picks) && cached_response.picks.length > 0) {
                    // Get the algo_type from request_data (current request) or cached_response
                    const algo_type = request_data.algo_type || cached_response.algo_type;
                    
                    // If we have the full sim-like structure stored, extract picks based on current algo_type
                    let picks_for_response;
                    if (cached_response.classic_picks || cached_response.sim_picks || cached_response.blended_picks) {
                        // Reconstruct response structure and extract picks based on current algo_type
                        const response_structure = {
                            classic_picks: cached_response.classic_picks,
                            sim_picks: cached_response.sim_picks,
                            blended_picks: cached_response.blended_picks,
                            picks: cached_response.picks
                        };
                        picks_for_response = extract_picks_from_response(response_structure, algo_type);
                    } else {
                        // Use cached picks directly
                        picks_for_response = cached_response.picks;
                    }
                    
                    // For sim algo_type, if extract_picks_from_response returned null (blended_picks missing),
                    // treat as cache miss - don't send invalid picks
                    if (algo_type && algo_type.toLowerCase() === 'sim' && !picks_for_response) {
                        port.postMessage({
                            action: 'CACHED_RANKINGS_MISSING',
                            request_identifier: request_identifier,
                            algo_type: request_data.algo_type || null
                        });
                        return;
                    }

                    // REQUEST_CACHED_RANKINGS is deprecated - use CHECK_CACHED_RANKINGS instead
                    // This handler is kept for backwards compatibility but should not be used
                    port.postMessage({
                        action: 'CACHED_RANKINGS_MISSING',
                        request_identifier: request_identifier,
                        algo_type: request_data.algo_type || null
                    });
                } else {
                    port.postMessage({
                        action: 'CACHED_RANKINGS_MISSING',
                        request_identifier: request_identifier,
                        algo_type: request_data.algo_type || null
                    });
                }
            } catch (error) {
                console.error('[background-http] Error handling request_cached_rankings:', error);
            }
        } else if (msg?.action === 'CHECK_CACHED_RANKINGS') {
            // Content script is checking for cached rankings based on rankings_needed.
            // Prefer exact cache[request_identifier]; else best draft-state match (num_picks), never timestamp.
            const queueMetrics = state.queue_metrics;
            if (queueMetrics) {
                queueMetrics.total_cache_checks++;
                queueMetrics.interval_cache_checks++;
            }

            const processCachedRankingsCheck = async () => {
                try {
                    const rankings_needed = msg.data?.rankings_needed;
                    if (!rankings_needed || !rankings_needed.draft_id) {
                        port.postMessage({
                            action: 'CACHED_RANKINGS_MISSING',
                            rankings_needed: rankings_needed
                        });
                        return;
                    }

                    const draft_id = rankings_needed.draft_id;
                    const algo_type = msg.data?.algo_type || null;
                    const neededRid = rankings_needed.request_identifier || null;
                    const neededNumPicks = rankings_needed.num_picks;

                    const cache = await get_rankings_cache();

                    // All cache rows for this draft (storage keys are full request_identifier strings)
                    const draft_cache_entries = Object.entries(cache)
                        .filter(([key]) => key.startsWith(`${draft_id}-`))
                        .map(([key, value]) => ({
                            request_identifier: key,
                            ...value
                        }));

                    if (draft_cache_entries.length === 0) {
                        port.postMessage({
                            action: 'CACHED_RANKINGS_MISSING',
                            rankings_needed: rankings_needed
                        });
                        return;
                    }

                    // 1) Prefer exact key match: cache[request_identifier] === what the content script asked for
                    let selected_entry = null;
                    if (neededRid && cache[neededRid]) {
                        const raw = { request_identifier: neededRid, ...cache[neededRid] };
                        if (getPicksFromCacheEntryForAlgo(raw, algo_type)) {
                            const rowNp = raw.num_picks;
                            const rowAheadOfNeeded =
                                neededNumPicks != null &&
                                Number.isFinite(neededNumPicks) &&
                                typeof rowNp === 'number' &&
                                rowNp > neededNumPicks;
                            if (!rowAheadOfNeeded) {
                                selected_entry = raw;
                            }
                        }
                    }

                    // 2) Otherwise pick best stale row by draft state (num_picks), never by timestamp
                    if (!selected_entry) {
                        const candidates = draft_cache_entries.filter((e) => getPicksFromCacheEntryForAlgo(e, algo_type));
                        if (!candidates.length) {
                            port.postMessage({
                                action: 'CACHED_RANKINGS_MISSING',
                                rankings_needed: rankings_needed
                            });
                            return;
                        }
                        selected_entry = pickBestDraftCacheEntryByDraftState(candidates, neededNumPicks);
                        if (!selected_entry) {
                            port.postMessage({
                                action: 'CACHED_RANKINGS_MISSING',
                                rankings_needed: rankings_needed
                            });
                            return;
                        }
                    }

                    const picks_for_response = getPicksFromCacheEntryForAlgo(selected_entry, algo_type);

                    // "Up to date" only when we are returning the row for the exact request_identifier the CS asked for
                    const is_most_up_to_date =
                        Boolean(neededRid) &&
                        selected_entry.request_identifier === neededRid;

                    const cached_num_picks = selected_entry.num_picks;

                    if (picks_for_response && Array.isArray(picks_for_response) && picks_for_response.length > 0) {
                        port.postMessage({
                            action: 'CACHED_RANKINGS_FOUND',
                            picks: picks_for_response,
                            advancement_structure: selected_entry.advancement_structure || {},
                            request_identifier: selected_entry.request_identifier,
                            algo_type: algo_type || selected_entry.algo_type || null,
                            is_most_up_to_date,
                            rankings_needed: rankings_needed,
                            num_picks: cached_num_picks,
                            draft_id: selected_entry.draft_id || draft_id,
                            cached_timestamp: selected_entry.timestamp || null
                        });
                    } else {
                        port.postMessage({
                            action: 'CACHED_RANKINGS_MISSING',
                            rankings_needed: rankings_needed
                        });
                    }
                } catch (error) {
                    console.error('[background-http] Error handling CHECK_CACHED_RANKINGS:', error);
                    port.postMessage({
                        action: 'CACHED_RANKINGS_MISSING',
                        rankings_needed: msg.data?.rankings_needed || null
                    });
                }
            };

            await new Promise((resolve) => {
                const runCheck = async () => {
                    cachedRankingsRequestQueue.processing++;
                    resolve();
                    try {
                        await processCachedRankingsCheck();
                    } finally {
                        cachedRankingsRequestQueue.processing--;
                        const next = typeof shiftFreshQueueItem === 'function'
                            ? shiftFreshQueueItem(cachedRankingsRequestQueue)
                            : cachedRankingsRequestQueue.queue.shift();
                        if (next) {
                            const run = typeof next === 'function' ? next : next.run;
                            if (typeof run === 'function') {
                                run();
                            }
                        }
                    }
                };

                if (cachedRankingsRequestQueue.processing < cachedRankingsRequestQueue.maxConcurrent) {
                    runCheck();
                } else {
                    const queueItem = {
                        run: runCheck,
                        enqueued_at: Date.now(),
                        request_identifier: msg.data?.rankings_needed?.request_identifier || null,
                        draft_id: msg.data?.rankings_needed?.draft_id || null
                    };
                    if (typeof enqueueBoundedQueue === 'function') {
                        enqueueBoundedQueue(cachedRankingsRequestQueue, queueItem, 'background-http-cache');
                    } else {
                        cachedRankingsRequestQueue.queue.push(queueItem);
                    }
                    if (queueMetrics) {
                        queueMetrics.total_cache_enqueued++;
                        queueMetrics.interval_cache_enqueued++;
                    }
                    const queuedCheckData = {
                        draft_id: msg.data?.rankings_needed?.draft_id || null,
                        queue_position: cachedRankingsRequestQueue.queue.length,
                        queue_length: cachedRankingsRequestQueue.queue.length,
                        processing: cachedRankingsRequestQueue.processing
                    };
                }
            });
        } else if (msg?.action === 'STOP_POLLING') {
            // Content script is requesting to stop polling for a specific request
            const request_identifier = msg.request_identifier;
            if (request_identifier) {
                stopInFlightPolling(request_identifier);
            }
        } else if (msg?.action === 'CS_KEEPALIVE') {
            // Content script is sending keepalive to prevent background script from being terminated
            // Respond with acknowledgment to confirm we're alive
            try {
                port.postMessage({ action: 'BG_KEEPALIVE_ACK' });
            } catch (err) {
            }
        }
    });

    port.onDisconnect.addListener(() => {
        if (chrome.runtime.lastError) {
            console.error('[BG] Port disconnect error:', chrome.runtime.lastError.message);
        }
        // Only unregister if this port is still the one registered for the tab — on a
        // fast reconnect the new port may already be in the map, and deleting it here
        // would leave the tab unreachable for result nudges and failure notices.
        if (contentPorts.get(tabId) === port) {
            contentPorts.delete(tabId);
        }
        // Polls are deliberately left running: they re-resolve the live port each tick
        // and their job is to land results in the cache regardless of port churn. A
        // poll whose tab really closed dies on its own at the max-poll cap.
    });
});

// DEPRECATED: All communication now uses port-based communication (bg_port)
// This listener is kept for backward compatibility with test files and legacy code
// but should not be used in new code. All new code should use port requests.
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    // WAKE_UP is a special case - used to wake up the background script if it's been terminated
    if (request.action === 'WAKE_UP') {
        sendResponse({ status: 'awake' });
        return true;
    }
    
    // Helper function to reload all tabs with content scripts (clears FSM memory)
    const reload_content_script_tabs = (callback) => {
        const content_script_urls = [
            '*://www.legendaryupside.com/*',
            '*://app.underdogsports.com/*',
            '*://app.underdogfantasy.com/*',
            '*://www.draftkings.com/*'
        ];
        
        chrome.tabs.query({ url: content_script_urls }, (tabs) => {
            let reloaded = 0;
            const total = tabs.length;
            
            if (total === 0) {
                if (callback) callback();
                return;
            }
            
            tabs.forEach((tab) => {
                chrome.tabs.reload(tab.id, () => {
                    if (chrome.runtime.lastError) {
                    }
                    reloaded++;
                    if (reloaded === total) {
                        if (callback) callback();
                    }
                });
            });
        });
    };
    
    // RESTART_BACKGROUND_SCRIPT - manually restart the background script
    if (request.action === 'RESTART_BACKGROUND_SCRIPT') {
        sendResponse({ status: 'ok', message: 'Background script restarting' });
        // Reload content script tabs first to clear FSM memory, then restart background
        reload_content_script_tabs(() => {
            // Use setTimeout to ensure tabs are reloaded before background script restarts
            setTimeout(() => {
                chrome.runtime.reload();
            }, 100);
        });
        return true;
    }
    
    // LOGOUT_AND_RESTART - clear all storage and restart background script
    if (request.action === 'LOGOUT_AND_RESTART') {
        sendResponse({ status: 'ok', message: 'Clearing storage and restarting' });
        // Clear all storage (including all dynamic keys like tournament:*, draft:*, etc.)
        // This matches what happens on extension uninstall/reinstall
        chrome.storage.local.clear(() => {
            reload_content_script_tabs(() => {
                // Use setTimeout to ensure tabs are reloaded before background script restarts
                setTimeout(() => {
                    chrome.runtime.reload();
                }, 100);
            });
        });
        return true;
    }
    
    // All other actions should use port-based communication
    // Only WAKE_UP, RESTART_BACKGROUND_SCRIPT, and LOGOUT_AND_RESTART are kept above
    // as minimal fallbacks for when port is not available
    
    // No other handlers - all actions should use port-based communication
    return false;
});


const PORT_KEEPALIVE_ALARM = 'port_keepalive';
const PORT_KEEPALIVE_PERIOD_MINUTES = 1;

function ping_connected_ports() {
    const ping = { action: 'BG_PING', boot_id: state.boot_id, ts: Date.now() };

    if (typeof contentPorts !== 'undefined' && contentPorts) {
        for (const [, contentPort] of contentPorts) {
            try {
                contentPort.postMessage(ping);
            } catch (err) {
            }
        }
    }

    if (state.settings_ports && state.settings_ports.size) {
        state.settings_ports.forEach((settingsPort) => {
            try {
                settingsPort.postMessage(ping);
            } catch (err) {
            }
        });
    }
}

function start_port_keepalive_alarms() {
    if (!chrome.alarms || !chrome.alarms.create) {
        return;
    }

    chrome.alarms.create(PORT_KEEPALIVE_ALARM, { periodInMinutes: PORT_KEEPALIVE_PERIOD_MINUTES });
    chrome.alarms.onAlarm.addListener((alarm) => {
        if (alarm.name === PORT_KEEPALIVE_ALARM) {
            ping_connected_ports();
        }
    });
}

async function notify_content_scripts(action, payload) {
    // Notify all connected content scripts via port-based communication
    for (const [, port] of contentPorts) {
        try {
            port.postMessage({ action, ...payload });
        } catch (err) {
        }
    }
    // Note: Removed legacy chrome.tabs.sendMessage - all communication now via ports
}

async function refresh_tabs_on_install() {
    const domains_to_refresh = [
        'www.legendaryupside.com',
        'app.underdogsports.com',
        'app.underdogfantasy.com',
        'www.draftkings.com'
    ];
    
    try {
        const allTabs = await new Promise((resolve) => {
            chrome.tabs.query({}, resolve);
        });
        
        const tabs_to_refresh = allTabs.filter(tab => {
            if (!tab.url) return false;
            try {
                const url = new URL(tab.url);
                return domains_to_refresh.some(domain => url.hostname === domain);
            } catch (err) {
                return false;
            }
        });
        
        if (tabs_to_refresh.length > 0) {
            for (const tab of tabs_to_refresh) {
                try {
                    await new Promise((resolve) => {
                        chrome.tabs.reload(tab.id, {}, resolve);
                    });
                } catch (err) {
                }
            }
        } else {
        }
    } catch (err) {
        console.error('[onInstalled] Error refreshing tabs:', err);
    }
}

/**
 * Natural updates from pre-attestation / early 2.2.50 builds keep chrome.storage that
 * uninstall+reinstall would wipe. That stale state blocks rankings (expired/missing app
 * JWT, orphaned instance secrets that never 401 when soft-allowed, lean/pre-lean config
 * cache, stuck rankings polls/cache). One-shot clear + remint approximates reinstall for
 * auth/config/rankings without wiping user overlay settings.
 */
async function clear_client_auth_update_poison_storage() {

    if (typeof clearStaleRankingsWork === 'function') {
        try {
            clearStaleRankingsWork({ reason: 'client_auth_update_migration' });
        } catch (err) {
        }
    }

    if (typeof clear_install_instance_attestation === 'function') {
        await clear_install_instance_attestation();
    } else {
        await storage.remove([KEYS.install_instance_id, KEYS.install_instance_secret]);
    }

    await storage.remove([
        KEYS.remote_config_cache,
        KEYS.remote_config_cache_ts,
        KEYS.remote_config_cache_user_uuid,
        KEYS.rankings_cache,
        KEYS.active_polls,
    ]);
    if (typeof clear_config_etags_storage === 'function') {
        await clear_config_etags_storage();
    }
    if (typeof configState !== 'undefined' && configState) {
        configState.data = null;
        configState.pending = null;
        configState.remote_config_fetched_for_user_uuid = null;
        configState.lastFetch = 0;
    }

    if (typeof reset_session_auth_for_client_auth_migration === 'function') {
        await reset_session_auth_for_client_auth_migration();
    }

    if (typeof ensure_install_instance_id === 'function') {
        await ensure_install_instance_id();
    }
}

async function mark_client_auth_storage_reset_done() {
    await storage.set({ [KEYS.client_auth_storage_reset_v1]: Date.now() });
}

async function client_auth_storage_reset_already_done() {
    const res = await storage.get(KEYS.client_auth_storage_reset_v1);
    return !!(res && res[KEYS.client_auth_storage_reset_v1]);
}

chrome.runtime.onInstalled.addListener(async (details) => {
    if (BASE_BG.env !== 'prod') {
        const log_data = {
            previousVersion: details.previousVersion || null,
            currentVersion: (typeof get_extension_version === 'function')
                ? get_extension_version()
                : (chrome.runtime.getManifest()?.version || null),
        };
    }

    let ranClientAuthReset = false;
    try {
        if (details.reason === 'install') {
            if (typeof ensure_install_instance_id === 'function') {
                await ensure_install_instance_id();
            }
            await mark_client_auth_storage_reset_done();
        } else if (details.reason === 'update') {
            const alreadyDone = await client_auth_storage_reset_already_done();
            if (!alreadyDone) {
                await clear_client_auth_update_poison_storage();
                await mark_client_auth_storage_reset_done();
                ranClientAuthReset = true;
            }
        }
    } catch (err) {
        console.error('[onInstalled] Failed client-auth storage reset', err);
    }

    try {
        if (typeof clear_all_underdog_tournament_no_data_markers === 'function') {
            await clear_all_underdog_tournament_no_data_markers();
        }
        await storage.set({ [KEYS.ud_tournament_marker_clear_gen]: Date.now() });
    } catch (err) {
        console.error('[onInstalled] Failed to clear Underdog tournament 404 cache markers', err);
    }

    try {
        if (typeof clearDkExposureContestFeeCache === 'function') {
            await clearDkExposureContestFeeCache();
        }
    } catch (err) {
        console.error('[onInstalled] Failed to clear DraftKings contest fee cache', err);
    }

    try {
        if (typeof clear_all_tournament_evs === 'function') {
            await clear_all_tournament_evs();
        }
    } catch (err) {
        console.error('[onInstalled] Failed to clear tournament EV cache', err);
    }

    if (details.reason === 'update') {
        try {
            await refresh_config({ force: true });
            await set_content_script_settings({ suppress_nonfatal_warning_notifications: false });
            const settings = await get_content_script_settings();
            notify_content_scripts('UPDATE_SETTINGS', { settings });
            if (typeof notify_settings_pages === 'function') {
                notify_settings_pages('UPDATE_SETTINGS', { settings });
            }
        } catch (err) {
            console.error('[onInstalled] Failed to handle update flow', err);
        }

        if (ranClientAuthReset) {
            // Reload LegUp / draft sites first so Ghost content script can re-supply jwt
            // before we remint app JWT / instance secret.
            await refresh_tabs_on_install();
            if (typeof request_ghost_session_refresh === 'function') {
                request_ghost_session_refresh();
            }
            const recoverAfterGhost = async () => {
                try {
                    if (typeof ensure_valid_app_jwt === 'function') {
                        await ensure_valid_app_jwt();
                    }
                    if (typeof ensure_install_instance_registered === 'function') {
                        await ensure_install_instance_registered({ force: true });
                    }
                    await refresh_config({ force: true });
                } catch (err) {
                    if (typeof schedule_auth_retry === 'function') {
                        schedule_auth_retry(2000);
                    }
                }
            };
            // Give refreshed legendaryupside.com tabs a moment to push Ghost session.
            setTimeout(() => {
                recoverAfterGhost().catch((err) => {
                });
            }, 2500);
            // Also attempt immediately in case Ghost JWT in storage is still valid.
            try {
                await recoverAfterGhost();
            } catch (err) {
            }
        }
    }
    if (details.reason === 'install') {
        refresh_tabs_on_install();
    }
});

async function restore_config_refresh_timer() {
    try {
        // Always trigger an immediate refresh on startup to ensure config is up to date
        // This handles cases where the background script was restarted or the extension was just installed
        // refresh_config() will handle scheduling the next periodic refresh after it completes
        refresh_config().catch(err => {
            console.error('[recovery] Immediate config refresh failed', err);
            // refresh_config() already schedules a retry on failure, so we don't need to do anything here
        });
    } catch (err) {
        console.error('[recovery] Failed to restore config refresh timer:', err);
        // Try to trigger refresh anyway - it will schedule the next attempt
        refresh_config().catch(refreshErr => {
            console.error('[recovery] Immediate config refresh failed', refreshErr);
        });
    }
}

async function restore_auth_retry() {
    try {
        const session = await get_session_data();
        if (!session?.user_uuid) {
            schedule_auth_retry(5000);
            return;
        }
        // Arm only when missing / still ahead of skew; past-skew skip-if-exists
        // lives inside schedule_app_jwt_refresh (avoids 1-min recreate thrash).
        schedule_app_jwt_refresh();
        if (!session.app_jwt || is_app_jwt_near_expiration(session) || is_app_jwt_fully_expired(session)) {
            const refreshed = await ensure_valid_app_jwt();
            if (refreshed?.app_jwt && typeof clearStaleRankingsWork === 'function') {
                clearStaleRankingsWork({ reason: 'sw_boot_auth_ok' });
            }
        } else if (typeof clearStaleRankingsWork === 'function') {
            // Fresh SW boot: drop any persisted polling/queue leftovers from previous life.
            clearStaleRankingsWork({ reason: 'sw_boot' });
        }
    } catch (err) {
        console.error('[recovery] Failed to restore auth retry:', err);
        schedule_auth_retry(5000);
    }
}

async function recovery_startup() {
    const startupTime = Date.now();
    
    // Check if this is a restart (previous startup time exists)
    const res = await storage.get(KEYS.background_startup_time);
    const previousStartupTime = (res && res[KEYS.background_startup_time]) || null;
    
    if (previousStartupTime) {
        const timeSinceLastStartup = startupTime - previousStartupTime;
    } else {
    }
    
    await storage.set({ [KEYS.background_startup_time]: startupTime });
    
    try {
        // Restore config refresh timer
        await restore_config_refresh_timer();
        
        // Restore auth retry timer
        await restore_auth_retry();

        // Restore toolbar icon from cached session before validation round-trip completes.
        try {
            await sync_extension_action_icon(await get_session_data());
        } catch (err) {
            console.error('[recovery] sync_extension_action_icon failed', err);
        }
        
    } catch (err) {
        console.error('[recovery] Error during recovery startup:', err);
    }
}

function register_extension_action_icon_tab_listeners() {
    const tabsApi = (typeof browser !== 'undefined' && browser.tabs)
        ? browser.tabs
        : (typeof chrome !== 'undefined' ? chrome.tabs : null);
    if (!tabsApi) {
        return;
    }

    const resync = () => {
        get_session_data()
            .then((session) => request_extension_action_icon_resync(session))
            .catch((err) => {
                console.error('[icon] extension action icon resync failed', err);
            });
    };

    tabsApi.onActivated.addListener(() => {
        resync();
    });

    tabsApi.onUpdated.addListener((_tabId, changeInfo, tab) => {
        if (!changeInfo.url && changeInfo.status !== 'complete') {
            return;
        }
        if (extension_site_from_url(tab?.url || changeInfo.url || '')) {
            resync();
        }
    });
}

function start_periodic_auth_poll() {
    load_background_settings().then(bg => {
        const intervalMs = bg.auth_poll_interval_ms || BASE_BG.auth_poll_interval_ms;
        setInterval(async () => {
            try {
                await ensure_valid_app_jwt();
            } catch (err) {
                console.error('[auth_poll] periodic auth check failed', err);
            }
        }, intervalMs);
    }).catch(err => {
        console.error('[auth_poll] failed to read auth_poll_interval_ms, skipping periodic poll', err);
    });
}

function startQueueVisibilityLogging() {
    // Avoid doing heavy debug object construction in prod: logs are stripped in builds.
    const env = (typeof BASE_BG !== 'undefined' && BASE_BG && BASE_BG.env) ? BASE_BG.env : 'prod';
    if (!['dev', 'local'].includes(env)) {
        return;
    }
    if (state.queue_log_timer) {
        return;
    }

    state.queue_metrics.last_log_ts = Date.now();
    state.queue_log_timer = setInterval(() => {
        const now = Date.now();
        const window_ms = now - (state.queue_metrics.last_log_ts || now);
        const in_flight_ids = Array.from(inFlightRankingsRequests.keys()).slice(0, 5);
        const poll_timer_ids = Array.from(inFlightPollTimers.keys()).slice(0, 5);
        const log_data = {
            queue_length: rankingsRequestQueue.queue.length,
            processing: rankingsRequestQueue.processing,
            cached_queue_length: cachedRankingsRequestQueue.queue.length,
            cached_processing: cachedRankingsRequestQueue.processing,
            in_flight: inFlightRankingsRequests.size,
            in_flight_sample: in_flight_ids,
            poll_timers: inFlightPollTimers.size,
            poll_timer_sample: poll_timer_ids,
            pending_port_requests: pendingPortRequests.size,
            content_ports: contentPorts.size,
            requests_since_last: state.queue_metrics.interval_requests,
            poll_requests_since_last: state.queue_metrics.interval_poll_requests,
            duplicates_since_last: state.queue_metrics.interval_duplicates,
            enqueued_since_last: state.queue_metrics.interval_enqueued,
            cache_checks_since_last: state.queue_metrics.interval_cache_checks,
            cache_enqueued_since_last: state.queue_metrics.interval_cache_enqueued,
            dropped_since_last: state.queue_metrics.interval_dropped,
            total_cache_checks: state.queue_metrics.total_cache_checks,
            total_cache_enqueued: state.queue_metrics.total_cache_enqueued,
            total_dropped: state.queue_metrics.total_dropped,
            total_stale_markers_cleared: state.queue_metrics.total_stale_markers_cleared,
            window_ms: window_ms
        };

        state.queue_metrics.interval_requests = 0;
        state.queue_metrics.interval_poll_requests = 0;
        state.queue_metrics.interval_duplicates = 0;
        state.queue_metrics.interval_enqueued = 0;
        state.queue_metrics.interval_cache_checks = 0;
        state.queue_metrics.interval_cache_enqueued = 0;
        state.queue_metrics.interval_dropped = 0;
        state.queue_metrics.last_log_ts = now;
    }, QUEUE_LOG_INTERVAL_MS);
}

(async function init() {
    // Generate boot ID on startup to track background script restarts
    state.boot_id = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    state.hello_seq = 0;
    
    try {
        await hydrateExposureFromStorage();
        await ensure_config_ready();
        await get_auth_status_from_backend();
        await cleanup_old_draft_states();
        
        // Clean up old tournament EV cache entries (7 days old)
        await cleanup_old_tournament_evs().catch(err => {
            console.error('[init] Tournament EV cleanup failed:', err);
        });
        
        // Perform recovery operations after initial setup
        await recovery_startup();

        register_extension_action_icon_tab_listeners();
        start_periodic_auth_poll();
        startQueueVisibilityLogging();
        start_port_keepalive_alarms();

    } catch (err) {
        console.error('[init] failed to fetch auth status', err);
        // Still try to do recovery even if initial setup failed
        try {
            await recovery_startup();
        } catch (recoveryErr) {
            console.error('[init] recovery startup also failed', recoveryErr);
        }
    }
})();


