(function () {
    const AUTH_REQUEST = 'legup-home-auth-request';
    const AUTH_RESPONSE = 'legup-home-auth-response';
    const DATASETS_REQUEST = 'legup-home-datasets-request';
    const DATASETS_RESPONSE = 'legup-home-datasets-response';

    let bgPort = null;
    let portConnected = false;
    let portRequestCounter = 0;
    const pendingPortRequests = new Map();

    function ensurePort() {
        if (bgPort && portConnected) {
            return Promise.resolve(bgPort);
        }
        return new Promise((resolve, reject) => {
            try {
                const port = chrome.runtime.connect({ name: 'content' });
                if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message));
                    return;
                }

                bgPort = port;
                portConnected = true;

                port.onDisconnect.addListener(() => {
                    portConnected = false;
                    bgPort = null;
                    for (const [, ent] of pendingPortRequests) {
                        clearTimeout(ent.timeout);
                        ent.reject(new Error('Port disconnected'));
                    }
                    pendingPortRequests.clear();
                });

                port.onMessage.addListener((msg) => {
                    if (!msg?.request_id || !pendingPortRequests.has(msg.request_id)) {
                        return;
                    }
                    const ent = pendingPortRequests.get(msg.request_id);
                    clearTimeout(ent.timeout);
                    pendingPortRequests.delete(msg.request_id);
                    if (msg.status === 'ok' || msg.status === 'success') {
                        ent.resolve(msg);
                    } else {
                        ent.reject(new Error(msg.message || 'Request failed'));
                    }
                });

                try {
                    port.postMessage({ action: 'CS_HELLO' });
                } catch (err) {
                    // Background sends BG_HELLO on connect; hello is best-effort.
                }

                resolve(port);
            } catch (err) {
                reject(err);
            }
        });
    }

    function sendPortRequest(action, data, timeoutMs) {
        const timeout = timeoutMs || 5000;
        return ensurePort().then((port) => {
            return new Promise((resolve, reject) => {
                const requestId = 'home_auth_' + String(Date.now()) + '_' + String(++portRequestCounter);
                const timer = setTimeout(() => {
                    if (pendingPortRequests.has(requestId)) {
                        pendingPortRequests.delete(requestId);
                        reject(new Error('Request timeout'));
                    }
                }, timeout);

                pendingPortRequests.set(requestId, { resolve, reject, timeout: timer });

                try {
                    port.postMessage({ action, request_id: requestId, ...data });
                } catch (err) {
                    clearTimeout(timer);
                    pendingPortRequests.delete(requestId);
                    reject(err);
                }
            });
        });
    }

    function ensureValidAppJwtSession() {
        // Prefer a refreshed app JWT when near expiry; fall back to stored session on failure.
        return sendPortRequest('ENSURE_VALID_APP_JWT', {}, 8000)
            .then((response) => response?.session_data || null)
            .catch(() => sendPortRequest('GET_SESSION_DATA', {}, 3000)
                .then((response) => response?.session_data || null)
                .catch(() => null));
    }

    function buildAuthResponse(requestId, session) {
        if (!session?.user_uuid || typeof session.user_uuid !== 'string' || session.user_uuid.length === 0) {
            return null;
        }
        const appJwt = session.app_jwt || null;
        if (!appJwt) {
            return null;
        }
        const ghostJwt = session.ghost_jwt || session.jwt || null;
        const response = {
            type: AUTH_RESPONSE,
            request_id: requestId,
            user_uuid: session.user_uuid,
            app_jwt: appJwt,
            jwt: ghostJwt || null,
        };
        if (session.app_jwt_expires_at) {
            response.app_jwt_expires_at = session.app_jwt_expires_at;
        }
        if (session.email) {
            response.email = session.email;
        }
        if (session.tier) {
            response.tier = session.tier;
        }
        if (session.allow_rankings !== undefined && session.allow_rankings !== null) {
            response.allow_rankings = session.allow_rankings;
        }
        return response;
    }

    async function handleAuthRequest(event) {
        if (event.source !== window) {
            return;
        }
        if (event.origin !== window.location.origin) {
            return;
        }

        const data = event.data;
        if (!data || typeof data !== 'object') {
            return;
        }
        if (data.source !== 'legup-home') {
            return;
        }
        if (!data.request_id) {
            return;
        }

        if (data.type === AUTH_REQUEST) {
            const session = await ensureValidAppJwtSession();
            const response = buildAuthResponse(data.request_id, session);
            if (!response) {
                return;
            }
            window.postMessage(response, window.location.origin);
            return;
        }

        if (data.type === DATASETS_REQUEST) {
            try {
                const msg = await sendPortRequest('GET_HOME_EXPOSURE_DATASETS', {}, 20000);
                window.postMessage(
                    {
                        type: DATASETS_RESPONSE,
                        request_id: data.request_id,
                        status: 'ok',
                        datasets: msg?.datasets || null,
                    },
                    window.location.origin
                );
            } catch (err) {
                window.postMessage(
                    {
                        type: DATASETS_RESPONSE,
                        request_id: data.request_id,
                        status: 'error',
                        message: err && err.message ? err.message : 'datasets_failed',
                        datasets: null,
                    },
                    window.location.origin
                );
            }
        }
    }

    window.addEventListener('message', (event) => {
        handleAuthRequest(event).catch(() => {});
    });

    ensurePort().catch(() => {});
})();

const STATE = {
    INIT: 'INIT',
    LEGUP_ACCOUNT_SYNC: 'LEGUP_ACCOUNT_SYNC',
    INIT_OVERLAY: 'INIT_OVERLAY',
    DETERMINE_ACTION: 'DETERMINE_ACTION',
    EXTRACTION: 'EXTRACTION',
    ERROR: 'ERROR'
};

const TICK_INTERVALS = {
    INIT: 1000,
    LEGUP_ACCOUNT_SYNC: 1000,
    INIT_OVERLAY: 1000,
    EXTRACTION: 600,
    ERROR: 2000
};

// Request throttling constants
const REQUEST_TIMEOUT_MS = 10000; // 10 seconds timeout for requests
// Align with backend poll budget (~5 polls + delays); soft timeout shows notice + one retry.
const RANKINGS_REQUEST_TIMEOUT_MS = 20000;
const EMPTY_CONTAINER_RETRY_INTERVAL_MS = 5000; // 5 seconds between empty container retries

const CONTENT_SETTINGS_KEYS = [
  'user_settings',
  'static_settings'
];

// Keys under user_settings that drive overlay tag icons (keep in sync with background_config userSettingsKeys tag_* entries)
const TAG_ICON_USER_SETTING_KEYS = [
    'tag_icon_quarterback',
    'tag_icon_teammate',
    'tag_icon_exposure',
    'tag_icon_week_17',
    'tag_icon_bye_overlap',
    'tag_icon_combination_uniqueness',
    'tag_icon_draft_availability',
    'tag_icon_r1_active',
    'tag_icon_conf_champ_opp',
    'tag_icon_hide_inactive'
];

/** Fallback when a tag key is absent from persisted/API data (keep in sync with CONFIG_FALLBACK user_settings in background_constants.js). */
const TAG_ICON_DEFAULTS = Object.freeze({
    tag_icon_quarterback: true,
    tag_icon_teammate: true,
    tag_icon_exposure: false,
    tag_icon_week_17: true,
    tag_icon_bye_overlap: true,
    tag_icon_combination_uniqueness: false,
    tag_icon_draft_availability: true,
    tag_icon_r1_active: true,
    tag_icon_conf_champ_opp: true,
    tag_icon_hide_inactive: false
});

const teamNames = {
    ARI: { fullName: "Arizona Cardinals", dkId: 355, conference: "NFC" },
    ATL: { fullName: "Atlanta Falcons", dkId: 323, conference: "NFC" },
    BAL: { fullName: "Baltimore Ravens", dkId: 366, conference: "AFC" },
    BUF: { fullName: "Buffalo Bills", dkId: 324, conference: "AFC" },
    CAR: { fullName: "Carolina Panthers", dkId: 364, conference: "NFC" },
    CHI: { fullName: "Chicago Bears", dkId: 326, conference: "NFC" },
    CIN: { fullName: "Cincinnati Bengals", dkId: 327, conference: "AFC" },
    CLE: { fullName: "Cleveland Browns", dkId: 329, conference: "AFC" },
    DAL: { fullName: "Dallas Cowboys", dkId: 331, conference: "NFC" },
    DEN: { fullName: "Denver Broncos", dkId: 332, conference: "AFC" },
    DET: { fullName: "Detroit Lions", dkId: 334, conference: "NFC" },
    GB: { fullName: "Green Bay Packers", dkId: 335, conference: "NFC" },
    HOU: { fullName: "Houston Texans", dkId: 325, conference: "AFC" },
    IND: { fullName: "Indianapolis Colts", dkId: 338, conference: "AFC" },
    JAX: { fullName: "Jacksonville Jaguars", dkId: 365, conference: "AFC" },
    JAC: { fullName: "Jacksonville Jaguars", dkId: 365, conference: "AFC" },
    KC: { fullName: "Kansas City Chiefs", dkId: 339, conference: "AFC" },
    MIA: { fullName: "Miami Dolphins", dkId: 345, conference: "AFC" },
    MIN: { fullName: "Minnesota Vikings", dkId: 347, conference: "NFC" },
    NE: { fullName: "New England Patriots", dkId: 348, conference: "AFC" },
    NO: { fullName: "New Orleans Saints", dkId: 350, conference: "NFC" },
    NYG: { fullName: "New York Giants", dkId: 351, conference: "NFC" },
    NYJ: { fullName: "New York Jets", dkId: 352, conference: "AFC" },
    LV: { fullName: "Las Vegas Raiders", dkId: 341, conference: "AFC" },
    PHI: { fullName: "Philadelphia Eagles", dkId: 354, conference: "NFC" },
    PIT: { fullName: "Pittsburgh Steelers", dkId: 356, conference: "AFC" },
    LAC: { fullName: "Los Angeles Chargers", dkId: 357, conference: "AFC" },
    SF: { fullName: "San Francisco 49ers", dkId: 359, conference: "NFC" },
    SEA: { fullName: "Seattle Seahawks", dkId: 361, conference: "NFC" },
    LAR: { fullName: "Los Angeles Rams", dkId: 343, conference: "NFC" },
    LA: { fullName: "Los Angeles Rams", dkId: 343, conference: "NFC" },
    TB: { fullName: "Tampa Bay Buccaneers", dkId: 362, conference: "NFC" },
    TEN: { fullName: "Tennessee Titans", dkId: 336, conference: "AFC" },
    WAS: { fullName: "Washington Commanders", dkId: 363, conference: "NFC" },
    FA: { fullName: "Free Agent", dkId: null, conference: null}
};

const positionNames = {
    QB: "Quarterback",
    RB: "Running Back",
    WR: "Wide Receiver",
    TE: "Tight End"
};

// --- Underdog (content_script_underdog.js) ---
const UD_LEGACY_EXTRACTION_WARNING_MESSAGE =
    'We detected a non-fatal issue with draft extraction. You should still receive ranking updates.<br>We recommend refreshing the page at your earliest convenience.';
const UD_LEGACY_FALLBACK_WARNING_SOURCE = 'ud_legacy_fallback';

const UD_FATAL_EXTRACTION_ERROR_WARNING_MESSAGE =
    'We detected a fatal issue with draft extraction.<br><b>Please refresh this page as soon as possible.</b><br>Draft extraction will keep running, but rankings related to the following players may be wrong until you refresh:';
const UD_FATAL_EXTRACTION_ERROR_WARNING_SOURCE = 'ud_fatal_extraction_error';

// Content↔background messaging is dead (e.g. chrome.runtime invalidated); keep copy generic.
const BACKGROUND_COMMUNICATION_BROKEN_WARNING_MESSAGE =
    'Something went wrong. Please refresh this page.';
const BACKGROUND_COMMUNICATION_BROKEN_WARNING_SOURCE = 'background_communication_broken';
const BACKGROUND_COMMUNICATION_BROKEN_MAX_UNIQUE_ERRORS = 5;

// Draft extraction failed (site DOM/API changed, etc.); refresh rarely fixes — nudge support.
const EXTRACTION_ERROR_WARNING_MESSAGE =
    'Something went wrong extracting draft data. Please refresh this page. If this keeps happening, contact support.';
const EXTRACTION_ERROR_WARNING_SOURCE = 'extraction_error';
const EXTRACTION_ERROR_MAX_UNIQUE_ERRORS = 5;

/** Consecutive ticks with same URL draft id before active-page settle (tick interval ~600ms). */
const UD_ACTIVE_NAV_STABLE_TICKS_NEEDED = 2;
/** Max wait for intercept/DOM after an active draft URL change before allowing extraction anyway. */
const UD_ACTIVE_NAV_SETTLE_MAX_MS = 4000;

// --- DraftKings slate API (content_script_draft_kings.js) ---
// Whitelist of user UUIDs allowed to fetch DK slates
const DK_SLATES_WHITELIST = [
    "ae6c933b-bfbe-43a8-a452-f8571e782f8a",  // Phil
    "f7bac68c-e408-4e16-ad7e-7cbb78fb4a23",  // Luke
    "f21bb883-09f7-4930-9262-9428caa91f93",  // Kerrane
    "d139bab6-f3a7-4d00-bc57-95c06390505f",  // Shaidy
    "8326aca0-3e26-49d1-abdd-61e2a557c136",  // Sack
    "9be0259e-0b93-445d-b2ee-fb78ff4e7f1b",  // Daniel R
    "e4ac953e-e7ad-4d8b-aad6-3891d7ded565",  // Zach L
    "b16283c8-538f-4180-82dd-9d7f6833287d",  // CeeGee
    "407ce03a-5f6e-4243-9106-ae1221a91bcf",  // Steph
    "5b96c8d9-e38c-4015-8b1f-b000f53bc127",  // Gretch
    "c2aae676-e08c-46ce-8398-152178f23d0c",  // Bert Sure
    "05c9af64-7a0e-4697-9c15-f4442b75b49c"   // Kyle Dvo
];

const DK_SLATE_API_COOLDOWN_MS = 60 * 1000; // 1 minute cooldown between API calls
// When draftStatus 404s (pre-start / waiting), back off instead of warning + refetch every tick.
const DK_DRAFT_STATUS_404_BACKOFF_BASE_MS = 5 * 1000;
const DK_DRAFT_STATUS_404_BACKOFF_MAX_MS = 60 * 1000;
// DKSLATES_REQUEST must outlast BG JWT refresh + /dkslates upload (fetch_json default 60s).
const DK_SLATES_PORT_TIMEOUT_MS = 90 * 1000;

// Seat enrichment: process lineups in chunks with bounded parallel draftStatus fetches.
const DK_EXPOSURE_SEAT_ENRICH_CHUNK_SIZE = 10;
const DK_EXPOSURE_SEAT_ENRICH_CONCURRENCY = 4;

// DK contest metadata for exposure comes from one /mycontests scrape (fees, game type, fill state)
// instead of a per-contest API call. Cached briefly so repeat merges on the same page reuse it.
const DK_EXPOSURE_MYCONTESTS_URL = 'https://www.draftkings.com/mycontests';
const DK_EXPOSURE_MYCONTESTS_CACHE_TTL_MS = 5 * 60 * 1000;

// Contests outside these game types are excluded from exposure.
// 145 = NFL Best Ball, 301 = NFL Playoff Best Ball.
const DK_EXPOSURE_ALLOWED_GAME_TYPE_IDS = new Set([145, 301]);

// Underdog legacy ribbon DOM (content_script_underdog_legacy_extraction.js)
const UD_RIBBON_COLOR_TO_POSITION = {
    'rgb(150, 71, 184)': 'QB',
    'rgb(21, 153, 126)': 'RB',
    'rgb(230, 126, 34)': 'WR',
    'rgb(41, 128, 185)': 'TE'
};

const PICK_POSITION_COLORS_UNDERDOG = Object.freeze({
    RB: '#15997e',
    WR: '#e67e22',
    QB: '#9647b8',
    TE: '#2980b9'
});

const PICK_POSITION_COLORS_DRAFTKINGS = Object.freeze({
    RB: '#91de80',
    WR: '#f3dc60',
    QB: '#eb7e8b',
    TE: '#5fbef7'
});

const PICK_POSITION_LITE_SATURATION_SCALE = 0.5;

function _clamp01(n) {
    return Math.min(1, Math.max(0, n));
}

function hex_to_rgb(hex) {
    const s = String(hex).replace('#', '').trim();
    if (s.length !== 6) return null;
    const n = parseInt(s, 16);
    if (Number.isNaN(n)) return null;
    return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
}

function rgb_to_hex(r, g, b) {
    const toHex = (v) => Math.round(_clamp01(v / 255) * 255).toString(16).padStart(2, '0');
    return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
}

function rgb_to_hsl(r, g, b) {
    r /= 255;
    g /= 255;
    b /= 255;
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    let h = 0;
    let s = 0;
    const l = (max + min) / 2;
    if (max !== min) {
        const d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        switch (max) {
            case r: h = (g - b) / d + (g < b ? 6 : 0); break;
            case g: h = (b - r) / d + 2; break;
            default: h = (r - g) / d + 4; break;
        }
        h /= 6;
    }
    return { h, s, l };
}

function hsl_to_rgb(h, s, l) {
    if (s === 0) {
        const v = Math.round(l * 255);
        return { r: v, g: v, b: v };
    }
    const hue2rgb = (p, q, t) => {
        if (t < 0) t += 1;
        if (t > 1) t -= 1;
        if (t < 1 / 6) return p + (q - p) * 6 * t;
        if (t < 1 / 2) return q;
        if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
        return p;
    };
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;
    return {
        r: Math.round(hue2rgb(p, q, h + 1 / 3) * 255),
        g: Math.round(hue2rgb(p, q, h) * 255),
        b: Math.round(hue2rgb(p, q, h - 1 / 3) * 255)
    };
}

function desaturate_hex(hex, saturationScale = PICK_POSITION_LITE_SATURATION_SCALE) {
    const rgb = hex_to_rgb(hex);
    if (!rgb) return hex;
    const hsl = rgb_to_hsl(rgb.r, rgb.g, rgb.b);
    hsl.s *= saturationScale;
    const out = hsl_to_rgb(hsl.h, hsl.s, hsl.l);
    return rgb_to_hex(out.r, out.g, out.b);
}

function build_lite_pick_position_colors(baseColors) {
    const out = {};
    for (const [position, hex] of Object.entries(baseColors)) {
        out[position] = desaturate_hex(hex);
    }
    return Object.freeze(out);
}

const PICK_POSITION_COLORS_UNDERDOG_LITE = build_lite_pick_position_colors(PICK_POSITION_COLORS_UNDERDOG);
const PICK_POSITION_COLORS_DRAFTKINGS_LITE = build_lite_pick_position_colors(PICK_POSITION_COLORS_DRAFTKINGS);

function get_pick_position_color_map(site_type, liteMode = false) {
    const isUnderdog = site_type === 'underdog';
    if (liteMode) {
        return isUnderdog ? PICK_POSITION_COLORS_UNDERDOG_LITE : PICK_POSITION_COLORS_DRAFTKINGS_LITE;
    }
    return isUnderdog ? PICK_POSITION_COLORS_UNDERDOG : PICK_POSITION_COLORS_DRAFTKINGS;
}

function get_pick_position_color(site_type, position, liteMode = false) {
    const colors = get_pick_position_color_map(site_type, liteMode);
    if (position === 'W/T') {
        return colors.WR || '#555';
    }
    return colors[position] || '#555';
}

// Fuzzy name matching (content_script.js)
const fuzzyNameSuffixes = new Set(['jr', 'sr', 'ii', 'iii', 'iv', 'v', 'vi']);
const fuzzyLastNamePrefixes = new Set(['st', 'saint', 'de', 'del', 'la', 'le', 'van', 'von', 'da', 'di', 'du', 'mc', 'mac', 'o', 'al', 'bin']);

// Overlay bottom bar (overlay_bottom_bar.js)
const BOTTOM_BAR_RANKING_SET_GROUP_LABEL = 'Ranking Set';
const BOTTOM_BAR_ALGO_TYPE_GROUP_LABEL = 'Algo Type';

// Ghost / member JWT (content_script_ghost.js)
const GHOST_JWKS_BY_ENV = Object.freeze({
    prod: 'https://www.legendaryupside.com/members/.well-known/jwks.json',
    dev: 'https://www.legendaryupside.com/members/.well-known/jwks.json',
    local: 'http://localhost:2368/members/.well-known/jwks.json'
});

const GHOST_JWT_AUDIENCE = 'https://www.legendaryupside.com/members/api';
const GHOST_JWT_ISSUER = 'https://www.legendaryupside.com/members/api';
const GHOST_JWKS_CACHE_MS = 5 * 60 * 1000;

// Underdog slate display names for exposure toast (keep in sync with settings.js buildUnderdogWhitelistUuidToLabel)
const FRIENDLY_UNDERDOG_SLATE_LABEL_KEYS = {
    ud_bbm: 'Regular Bestball',
    ud_sf: 'Superflex',
    ud_ww: 'Weekly Winners',
    ud_spr: 'Sprint',
    ud_mar: 'Marathon',
    ud_eli: 'Eliminator',
    ud_ppr: 'PPR',
    ud_tep: 'TEP'
};

// Scoring-variant Underdog slates keep format_type=standard and send a top-level
// `scoring` key. Keyed by underdog_slate_whitelist friendly key (resolved from the
// draft's slate id); slates absent here use the site default scoring.
const UD_SLATE_KEY_TO_SCORING = {
    ud_ppr: 'fppr',
    ud_tep: 'tep'
};

// Underdog slate display names (incl. legacy UUID-keyed DK slates stored under ud_by_slate)
// come from remote config: static_settings.underdog_slate_friendly_labels = { "<uuid>": "<label>" }.
// Decoupled from underdog_slate_whitelist so retired slate UUIDs can still be labeled.
function buildUnderdogFriendlyLabelMap(staticSettings) {
    const w = staticSettings && staticSettings.underdog_slate_friendly_labels;
    if (!w || typeof w !== 'object' || Array.isArray(w)) {
        return {};
    }
    const out = {};
    for (const [uuid, label] of Object.entries(w)) {
        if (uuid == null || label == null) continue;
        const idStr = String(uuid).trim();
        const labelStr = String(label).trim();
        if (!idStr || !labelStr) continue;
        out[idStr] = labelStr;
    }
    return out;
}

// DraftKings draft group display names come from remote config:
//   static_settings.draftkings_slate_friendly_labels = { "<draftGroupId>": "<label>", … }
// Decoupled from static_settings.draftkings_slate_whitelist so legacy/retired draft groups
// (e.g. older Pre-Draft Bestball groups) can still get readable labels without being marked
// as "active" slates in the whitelist.
function buildDraftKingsFriendlyLabelMap(staticSettings) {
    const w = staticSettings && staticSettings.draftkings_slate_friendly_labels;
    if (!w || typeof w !== 'object' || Array.isArray(w)) {
        return {};
    }
    const out = {};
    for (const [slateId, label] of Object.entries(w)) {
        if (slateId == null || label == null) continue;
        const idStr = String(slateId).trim();
        const labelStr = String(label).trim();
        if (!idStr || !labelStr) continue;
        out[idStr] = labelStr;
    }
    return out;
}

function formatDraftKingsSlateLabelForExposureToast(draftGroupId, staticSettings, fallbackLabel) {
    const s = draftGroupId != null ? String(draftGroupId).trim() : '';
    if (!s) return 'Unknown Draft Group';
    const idToLabel = buildDraftKingsFriendlyLabelMap(staticSettings);
    const mapped = idToLabel[s] ? String(idToLabel[s]).trim() : '';
    if (mapped) return mapped;
    if (fallbackLabel && typeof fallbackLabel === 'string' && fallbackLabel.trim()) {
        return fallbackLabel.trim();
    }
    return `Draft Group ${s}`;
}

function buildUnderdogSlateUuidToLabelMap(staticSettings) {
    const w = staticSettings && staticSettings.underdog_slate_whitelist;
    if (!w || typeof w !== 'object' || Array.isArray(w)) {
        return {};
    }
    const out = {};
    for (const [label, uuid] of Object.entries(w)) {
        if (!label || typeof uuid !== 'string' || !uuid.trim()) continue;
        const raw = String(label).trim();
        const nicer = Object.prototype.hasOwnProperty.call(FRIENDLY_UNDERDOG_SLATE_LABEL_KEYS, raw)
            ? FRIENDLY_UNDERDOG_SLATE_LABEL_KEYS[raw]
            : raw;
        out[String(uuid).trim()] = nicer;
    }
    return out;
}

function formatUnderdogSlateLabelForExposureToast(slateId, staticSettings) {
    const s = slateId != null ? String(slateId).trim() : '';
    if (!s || s === 'legacy') {
        return 'Legacy / unknown slate';
    }
    const friendly = buildUnderdogFriendlyLabelMap(staticSettings);
    if (friendly[s]) {
        return String(friendly[s]).trim();
    }
    const uuidToLabel = buildUnderdogSlateUuidToLabelMap(staticSettings);
    const mapped = uuidToLabel[s] ? String(uuidToLabel[s]).trim() : '';
    if (mapped) {
        return mapped;
    }
    return `Unknown Slate (${s.slice(0, 8)}…)`;
}

const SUBSCRIPTION_TIER_SIDEKICK = 'sidekick';
const SUBSCRIPTION_TIER_LEGUP = 'legup';

const TIER_CAPABILITIES = Object.freeze({
    sidekick: Object.freeze({
        rankings: true,
        overlay_extraction: true
    }),
    legup: Object.freeze({
        rankings: false,
        overlay_extraction: true
    }),
    none: Object.freeze({
        rankings: false,
        overlay_extraction: false
    })
});

function normalize_tier(raw) {
    if (raw == null || raw === '') return null;
    const s = String(raw).trim().toLowerCase();
    if (s === SUBSCRIPTION_TIER_SIDEKICK || s.includes('sidekick')) return SUBSCRIPTION_TIER_SIDEKICK;
    if (s === SUBSCRIPTION_TIER_LEGUP || s === 'leg up') return SUBSCRIPTION_TIER_LEGUP;
    return null;
}

function session_access_level(session) {
    const s = session && typeof session === 'object' ? session : {};
    const tier = normalize_tier(s.tier);
    if (s.allow_rankings === true || tier === SUBSCRIPTION_TIER_SIDEKICK) {
        return SUBSCRIPTION_TIER_SIDEKICK;
    }
    if (tier === SUBSCRIPTION_TIER_LEGUP) {
        return SUBSCRIPTION_TIER_LEGUP;
    }
    return 'none';
}

function is_session_authenticated(session) {
    const uuid = session?.user_uuid;
    return typeof uuid === 'string' && uuid.length > 0;
}

function is_legup_lite_mode(session, user_settings) {
    if (!is_session_authenticated(session)) {
        return false;
    }
    if (user_settings?.force_lite_mode) {
        return true;
    }
    return session_access_level(session) === SUBSCRIPTION_TIER_LEGUP;
}

// Keep in sync with background_constants.js AUTH_REASON* helpers.
const AUTH_REASON = Object.freeze({
    session_window_expired: 'auth:session_window_expired',
    app_jwt_expired: 'auth:app_jwt_expired',
    tokens_missing: 'auth:tokens_missing',
    refresh_failed: 'auth:refresh_failed',
    user_not_found: 'auth:user_not_found',
});

const AUTH_REASON_USER_MESSAGES = Object.freeze({
    [AUTH_REASON.session_window_expired]:
        "It's been a while since you went to legendaryupside.com. Click the button to refresh your session.",
    [AUTH_REASON.app_jwt_expired]:
        'Your Sidekick session timed out. Click the button to renew it at legendaryupside.com.',
    [AUTH_REASON.tokens_missing]:
        'Sidekick needs you to sign in at legendaryupside.com. Click the button to continue.',
    [AUTH_REASON.refresh_failed]:
        'Sidekick could not refresh your session. Click the button to try again, or restart the background script if this keeps happening.',
    [AUTH_REASON.user_not_found]:
        'Your Sidekick account was not found on the server. Click the button to sign in at legendaryupside.com.',
});

function auth_reason_user_message(reason) {
    const raw = reason == null ? '' : String(reason);
    if (!raw) {
        return '';
    }
    if (AUTH_REASON_USER_MESSAGES[raw]) {
        return AUTH_REASON_USER_MESSAGES[raw];
    }
    if (raw.includes('Validation time exceeded') || raw === 'Session expired; sign in at legendaryupside.com') {
        return AUTH_REASON_USER_MESSAGES[AUTH_REASON.session_window_expired];
    }
    if (raw.includes('Session not found on server')) {
        return AUTH_REASON_USER_MESSAGES[AUTH_REASON.user_not_found];
    }
    if (raw.includes('does not have the required subscription') || raw.includes('Sidekick subscription required')) {
        return "You do not have Sidekick access. Subscribe to the LegUp + Sidekick tier at <a href='https://www.legendaryupside.com/#/portal/account' target='_blank'>Legendary Upside</a> and then press the button to refresh your session.";
    }
    if (raw.includes('auth:app_jwt_expired') || /app jwt expired|app session expired/i.test(raw)) {
        return AUTH_REASON_USER_MESSAGES[AUTH_REASON.app_jwt_expired];
    }
    if (raw.includes('auth:refresh_failed') || /could not refresh|refresh failed/i.test(raw)) {
        return AUTH_REASON_USER_MESSAGES[AUTH_REASON.refresh_failed];
    }
    if (raw.includes('auth:tokens_missing') || raw.includes('sign in at legendaryupside.com')) {
        return AUTH_REASON_USER_MESSAGES[AUTH_REASON.tokens_missing];
    }
    if (raw.includes('legendaryupside.com') || raw.includes('Session expired')) {
        return AUTH_REASON_USER_MESSAGES[AUTH_REASON.session_window_expired];
    }
    return '';
}

function session_auth_refresh_needed(session) {
    const reason = session?.reason == null ? '' : String(session.reason);
    if (!reason) {
        return false;
    }
    if (reason.startsWith('auth:')) {
        return reason === AUTH_REASON.session_window_expired
            || reason === AUTH_REASON.app_jwt_expired
            || reason === AUTH_REASON.tokens_missing
            || reason === AUTH_REASON.refresh_failed
            || reason === AUTH_REASON.user_not_found;
    }
    return reason.includes('legendaryupside.com')
        || reason.includes('Session expired')
        || reason.includes('Validation time exceeded')
        || reason.includes('Session not found on server');
}

function compute_session_auth_notification(session) {
    const normalized = { ...(session || {}) };
    if (!Object.prototype.hasOwnProperty.call(normalized, 'user_uuid')) {
        normalized.user_uuid = null;
    }
    if (!Object.prototype.hasOwnProperty.call(normalized, 'allow_rankings')) {
        normalized.allow_rankings = null;
    }
    if (!Object.prototype.hasOwnProperty.call(normalized, 'reason')) {
        normalized.reason = null;
    }
    if (!Object.prototype.hasOwnProperty.call(normalized, 'tier')) {
        normalized.tier = null;
    }

    const accessLevel = session_access_level(normalized);
    let message = '';
    const type = 'auth_error';

    const sessionRefreshNeeded =
        normalized.user_uuid &&
        normalized.allow_rankings !== true &&
        session_auth_refresh_needed(normalized);

    if ((accessLevel === SUBSCRIPTION_TIER_SIDEKICK || accessLevel === SUBSCRIPTION_TIER_LEGUP) && !sessionRefreshNeeded) {
        return { message, type };
    }

    if (!normalized.allow_rankings) {
        message = auth_reason_user_message(normalized.reason);
        if (!message) {
            if (normalized.allow_rankings === null || normalized.allow_rankings === undefined) {
                message = 'Please sign in to Legendary Upside to use Sidekick. Press the button to sign in.';
            } else {
                message = 'Unknown issue. Please contact support.';
            }
        }
    }

    return { message, type };
}


function compute_base_url(env) {
    switch (env) {
            case 'dev':   return 'https://apps.legendaryupside.com';
            case 'local': return 'http://localhost:8000';
            default:      return 'https://apps.legendaryupside.com';
    }
}

function get_sidekick_apps_landing_url(env_value) {
    const base = compute_base_url(env_value || 'prod');
    return `${base}/?redirect_to=sidekick`;
}

// Web app host moved to underdogsports.com; API remains *.underdogfantasy.com. Match legacy app host too.
const UD_APP_HOSTNAME_RE = /^app\.(?:underdogfantasy|underdogsports)\.com$/i;

function detect_site_key() {
  const h = location.hostname;
  if (UD_APP_HOSTNAME_RE.test(h)) return 'underdog';
  if (/draftkings\.com$/i.test(h)) return 'draftkings';
  return 'underdog';
}

function is_underdog_url(url) {
    return /app\.(?:underdogfantasy|underdogsports)\.com\/([a-z0-9\-]+)/i.test(url);
}

function is_draft_kings_url(url) {
    return /draftkings\.com\/([a-z0-9\-]+)/i.test(url);
}

function is_legendary_upside_url(url) {
    return /www\.legendaryupside\.com/i.test(url);
}

// Full host strings (no regex alternation) so the prod build's host rewrite
// (PROD_HOST_REWRITES in _build_extension.py) can swap the dev host out.
const LEGUP_APP_HOSTS = [
    'apps.legendaryupside.com',
    'apps.legendaryupside.com',
    'beta.legendaryupside.com'
];

function is_legup_homepage_url(url) {
    try {
        const u = new URL(url);
        const host = u.hostname.toLowerCase();
        return LEGUP_APP_HOSTS.includes(host);
    } catch (e) {
        const raw = String(url).toLowerCase();
        return LEGUP_APP_HOSTS.some(h => raw.startsWith(h) || raw.includes('//' + h));
    }
}

function is_underdog_draft_url(url) {
    return /app\.(?:underdogfantasy|underdogsports)\.com\/draft\/([a-z0-9\-]+)/i.test(url);
}

function is_active_url(url) {
    return /app\.(?:underdogfantasy|underdogsports)\.com\/active\/([a-z0-9\-]+)/i.test(url);
}

function is_completed_url(url) {
    return /app\.(?:underdogfantasy|underdogsports)\.com\/completed\/([a-z0-9\-]+)/i.test(url);
}

function is_draft_kings_draft_url(url) {
    // Live snake draft rooms (optional ?tournament= is still a real contest key once the draft starts).
    return /draftkings\.com\/draft\/snake\/\d+(?:\/|$|\?|#)/i.test(url);
}

// Path-only tournament lobby (no snake contest key yet). Distinct from /draft/snake/{id}?tournament=…
function is_draft_kings_waiting_room_url(url) {
    return /draftkings\.com\/draft\/tournament\//i.test(url);
}

function is_draft_kings_my_contests_url(url) {
    return /draftkings\.com\/mycontests/i.test(url);
}

// DraftKings exposure UI currently lives at /lineup (distinct from /draft/... draft room URLs).
function is_draft_kings_lineup_url(url) {
    try {
        const u = new URL(url);
        if (!/draftkings\.com$/i.test(u.hostname)) return false;
        const path = u.pathname.replace(/\/+$/, '') || '/';
        return path === '/lineup';
    } catch (e) {
        return /draftkings\.com\/lineup(\/|\?|#|$)/i.test(url);
    }
}

function is_underdog_exposure_url(url) {
    try {
        const u = new URL(url);
        if (!UD_APP_HOSTNAME_RE.test(u.hostname)) return false;
        // Path segment casing varies (e.g. /Exposure/...); compare case-insensitively.
        const path = ((u.pathname.replace(/\/+$/, '') || '/') + '/').toLowerCase();
        return path === '/exposure/' || path.startsWith('/exposure/');
    } catch (e) {
        return /app\.(?:underdogfantasy|underdogsports)\.com\/exposure(\/|$|\?|#)/i.test(url);
    }
}

function is_browser_extension_url(url) {
    return /^chrome-extension:\/\//i.test(url) || /^moz-extension:\/\//i.test(url);
}

function is_test_draft_url(url) {
    return /draft-test\.html$/.test(url);
}

function is_draft_url(url) {
    return is_underdog_draft_url(url) || is_active_url(url) || is_completed_url(url) || is_draft_kings_draft_url(url);
}

function get_draftkings_draft_id_from_url(url) {
    const base_url = url.split('?')[0];
    // Only /draft/snake/{contestKey}. Do not match /draft/tournament/{uuid} — a leading digit
    // in the UUID (e.g. 7b6a…) used to be misread as contest id "7" and 404-spam the contests API.
    const match = base_url.match(/draftkings\.com\/draft\/snake\/(\d+)(?:\/|$)/i);
    return match ? match[1] : null;
}

function get_underdog_draft_id_from_url(url) {
    const clean_url = url.split('?')[0];
    const match = clean_url.match(/app\.(?:underdogfantasy|underdogsports)\.com\/(draft|active|completed)\/([a-z0-9\-]+)/i);
    return match ? match[2] : null;
}

// DraftKings tournament parsing shared by the content script (draft-time
// tournament_info for rankings requests) and the background script
// (/dk_tournament_map submissions). Loaded into both contexts via
// manifest.json — keep this file dependency-free.

function parse_draft_kings_advancement(rounds = []) {
    if (!Array.isArray(rounds) || rounds.length === 0) return null;

    // Helper to grab a round by number; returns {} if not found
    const byNumber = n => rounds.find(r => r.roundNumber === n) || {};

    const r1 = byNumber(1);
    const r2 = byNumber(2);
    const r3 = byNumber(3);
    const r4 = byNumber(4);

    // All three early rounds must have an advancingEntryCount & contestSize
    if (
        [r1, r2, r3].some(
            r => typeof r.advancingEntryCount !== "number" || typeof r.contestSize !== "number"
        ) ||
        typeof r4.contestSize !== "number"
    ) {
        return null; // malformed data
    }

    const regular_season_num = r1.advancingEntryCount;
    const regular_season_denom = r1.contestSize;

    const w15_num = r2.advancingEntryCount;
    const w15_denom = r2.contestSize;

    const w16_num = r3.advancingEntryCount;
    const w16_denom = r3.contestSize;

    const finals_size = r4.contestSize;
    const w17_quantile = Math.min(0.95, (finals_size - 2) / finals_size);
    const raw_string = "Round Advancement: " + regular_season_num + "/" + regular_season_denom + " - " + w15_num + "/" + w15_denom + " - " + w16_num + "/" + w16_denom + " - " + finals_size + " Seat Final";
    return {
        regular_season_num,
        regular_season_denom,
        w15_num,
        w15_denom,
        w16_num,
        w16_denom,
        finals_size,
        w17_quantile,
        raw_string
    };
}

function parse_draft_kings_payouts(rounds = [], { includeZero = true } = {}) {
    if (!Array.isArray(rounds) || rounds.length === 0) return {};

    const toAmount = (v) => {
        if (typeof v === 'number') return v;
        if (typeof v !== 'string') return 0;
        const m = v.match(/[\d,]+(?:\.\d+)?/);
        return m ? parseFloat(m[0].replace(/,/g, '')) || 0 : 0;
    };

    const result = {};

    for (const r of rounds) {
        const roundNumber = r?.roundNumber;
        const contestSize = Number.isFinite(r?.contestSize) ? r.contestSize : 0;
        if (!Number.isFinite(roundNumber) || contestSize <= 0) {
            continue; // skip malformed rounds
        }

        // Initialize per-position cash array (1..contestSize), default 0
        const cashByPos = new Array(contestSize).fill(0);

        // Apply tiers; non-cash tiers (e.g., Ticket) yield amount=0
        for (const tier of (r.payoutSummary || [])) {
            const amount = toAmount(tier?.tierPayoutDescriptions?.Cash); // Tickets/missing => 0
            const min = Math.max(1, Number.isFinite(tier?.minPosition) ? tier.minPosition : 1);
            const maxRaw = Number.isFinite(tier?.maxPosition) ? tier.maxPosition : min;
            const max = Math.min(contestSize, Math.max(min, maxRaw));

            for (let pos = min; pos <= max; pos++) {
                // If overlapping tiers ever occur, keep the larger cash value
                cashByPos[pos - 1] = Math.max(cashByPos[pos - 1], amount);
            }
        }

        // Reduce to { amount: count }
        const map = {};
        for (const amt of cashByPos) {
            if (amt === 0 && !includeZero) continue;
            map[amt] = (map[amt] || 0) + 1;
        }

        result[roundNumber] = map;
    }

    return result;
}

// Underdog legacy ribbon key collisions: defines __LEGUP_UD_LEGACY_KEY_COLLISION__. Set UD_LEGACY_KEY_COLLISION_RULES_ENABLED false to disable at build time.
(function () {
    const UD_LEGACY_KEY_COLLISION_RULES_ENABLED = true;

    // Board order → suffixed keys (legacyKey-1, …). Brittle when ADPs are close — see docs/CONTENT_SCRIPT_DOCUMENTATION.md.
    const UD_LEGACY_KEY_COLLISION_RULES = [
        {
            legacyKey: 'B. Robinson_RB - ATL',
            orderedPlayerIds: [
                '2b0cbe83-48a2-41b0-b03f-42180cfc4b77', // Bijan Robinson
                '63374c3e-26cc-4d22-a77a-e29b8f5b2f4a' // Brian Robinson
            ]
        },
        {
            legacyKey: 'K. Allen_RB - FA',
            orderedPlayerIds: [
                'd016873c-23d2-4635-b85e-0c23dd393745', // Kaytron Allen
                '7ef90151-aca0-429e-afbb-3aec19c8d687' // Kazmeir Allen
            ]
        }
    ];

    const root = typeof globalThis !== 'undefined' ? globalThis : typeof window !== 'undefined' ? window : self;
    root.__LEGUP_UD_LEGACY_KEY_COLLISION__ = {
        enabled: UD_LEGACY_KEY_COLLISION_RULES_ENABLED,
        rules: UD_LEGACY_KEY_COLLISION_RULES
    };
})();

function getUdLegacyKeyCollisionRules() {
    const cfg = typeof __LEGUP_UD_LEGACY_KEY_COLLISION__ !== 'undefined' ? __LEGUP_UD_LEGACY_KEY_COLLISION__ : null;
    if (!cfg || !cfg.enabled || !Array.isArray(cfg.rules)) {
        return null;
    }
    return cfg.rules;
}

function udLegacyRuleForRibbonLookup(base_lookup_key) {
    const rules = getUdLegacyKeyCollisionRules();
    if (!rules) {
        return null;
    }
    for (let i = 0; i < rules.length; i++) {
        const r = rules[i];
        if (r && r.legacyKey === base_lookup_key) {
            return r;
        }
    }
    return null;
}

function udLegacyDisambiguatedLookupKey(base_lookup_key, occurrence_1based) {
    const rule = udLegacyRuleForRibbonLookup(base_lookup_key);
    if (!rule || !Array.isArray(rule.orderedPlayerIds) || rule.orderedPlayerIds.length === 0) {
        return base_lookup_key;
    }
    const n = rule.orderedPlayerIds.length;
    const slot = Math.min(Math.max(occurrence_1based, 1), n);
    return base_lookup_key + '-' + slot;
}

function countUdRibbonFilledPickSlots(drafting_cells) {
    let n = 0;
    drafting_cells.forEach((cell) => {
        const pick_name_element = cell.querySelector('[class^="styles__pickName__"]');
        const pick_name = pick_name_element ? pick_name_element.textContent.trim() : null;
        if (pick_name) {
            n++;
        }
    });
    return n;
}

function getUdRibbonFilledPickSlotNumbers1Based(drafting_cells) {
    const numbers = [];
    drafting_cells.forEach((cell, index) => {
        const pick_name_element = cell.querySelector('[class^="styles__pickName__"]');
        const pick_name = pick_name_element ? pick_name_element.textContent.trim() : null;
        if (pick_name) {
            numbers.push(index + 1);
        }
    });
    return numbers;
}

function extractUdRibbonPickRowsFromDom(drafting_cells) {
    const picks = [];
    drafting_cells.forEach((cell, index) => {
        const pick_name_element = cell.querySelector('[class^="styles__pickName__"]');
        const pick_name = pick_name_element ? pick_name_element.textContent.trim() : null;

        const username_element = cell.querySelector('[class^="styles__username__"]');
        const username = username_element ? username_element.textContent.trim() : 'Unknown User';

        let pos_team_element = cell.querySelector('[class^="styles__pickPos__"]');
        let pos_team = pos_team_element ? pos_team_element.textContent.trim() : null;

        if (!pos_team || !pos_team.includes('-')) {
            const bar_element = cell.querySelector('[class^="styles__bar__"]');
            const bar_color = bar_element ? bar_element.style.backgroundColor : null;

            if (bar_color && UD_RIBBON_COLOR_TO_POSITION[bar_color]) {
                const inferred_position = UD_RIBBON_COLOR_TO_POSITION[bar_color];
                pos_team = `${inferred_position} - FA`;
            }
        }

        if (pick_name) {
            picks.push({
                pick_number: index + 1,
                name: pick_name,
                position_team: pos_team,
                drafted_by: username
            });
        }
    });
    return picks;
}

// fatal_ribbon_base_keys: legacy keys unsafe without a collision rule; hits surface as fatal_legacy_keys_hit (urgent bubble).
function resolveUdIdsFromRibbonPicks(picks, legacy_map, fsm, fatal_ribbon_base_keys) {
    const failed_lookups = [];
    const collision_occurrence_by_key = {};
    const fatal_legacy_keys_hit = [];
    const fatal_legacy_keys_hit_seen = {};
    const fatal_set = fatal_ribbon_base_keys && fatal_ribbon_base_keys.size > 0 ? fatal_ribbon_base_keys : null;

    picks.forEach((pick) => {
        if (!pick.name || !pick.position_team) {
            failed_lookups.push({
                lookup_key: pick.name ? `${pick.name}_` : '(no name)',
                pick
            });
            return;
        }
        let lookup_key = `${pick.name}_${pick.position_team}`;
        if (fatal_set && fatal_set.has(lookup_key) && !fatal_legacy_keys_hit_seen[lookup_key]) {
            fatal_legacy_keys_hit_seen[lookup_key] = true;
            fatal_legacy_keys_hit.push(lookup_key);
        }
        let udLegacyRibbonCollisionBase = null;
        if (udLegacyRuleForRibbonLookup(lookup_key)) {
            const prev = collision_occurrence_by_key[lookup_key] || 0;
            const next = prev + 1;
            collision_occurrence_by_key[lookup_key] = next;
            const udLegacyRibbonCollisionBaseKey = lookup_key;
            lookup_key = udLegacyDisambiguatedLookupKey(lookup_key, next);
            udLegacyRibbonCollisionBase = { baseKey: udLegacyRibbonCollisionBaseKey, disambiguatedKey: lookup_key, occurrence: next, pickNumber: pick.pick_number };
        }
        const player_id = legacy_map[lookup_key];
        if (udLegacyRibbonCollisionBase) {
            const udLegacyRibbonCollisionWarn = { baseKey: udLegacyRibbonCollisionBase.baseKey, disambiguatedKey: udLegacyRibbonCollisionBase.disambiguatedKey, occurrence: udLegacyRibbonCollisionBase.occurrence, pickNumber: udLegacyRibbonCollisionBase.pickNumber, resolvedPlayerId: player_id && typeof player_id === 'string' ? player_id : null };
        }
        if (player_id && typeof player_id === 'string') {
            pick.id = player_id;
        } else {
            failed_lookups.push({ lookup_key, pick });
        }
    });

    if (failed_lookups.length > 0) {
        const base_key_to_ids = {};

        Object.keys(legacy_map).forEach((key) => {
            const last_dash_index = key.lastIndexOf(' - ');
            const base_key = last_dash_index !== -1 ? key.substring(0, last_dash_index) : key;
            const id = legacy_map[key];
            const existing_entry = base_key_to_ids[base_key];

            if (!existing_entry) {
                base_key_to_ids[base_key] = { ids: [id], has_conflict: false };
            } else if (existing_entry.ids.indexOf(id) === -1) {
                existing_entry.ids.push(id);
                existing_entry.has_conflict = true;
            }
        });

        const still_failed = [];
        let used_fallback = false;

        failed_lookups.forEach((entry) => {
            const last_dash_index = entry.lookup_key.lastIndexOf(' - ');
            const base_lookup_key =
                last_dash_index !== -1 ? entry.lookup_key.substring(0, last_dash_index) : entry.lookup_key;
            const base_entry = base_key_to_ids[base_lookup_key];

            if (base_entry && base_entry.ids.length > 0 && !base_entry.has_conflict) {
                const fallback_player_id = base_entry.ids[0];
                if (fallback_player_id && typeof fallback_player_id === 'string') {
                    entry.pick.id = fallback_player_id;
                    used_fallback = true;
                } else {
                    still_failed.push(entry);
                }
            } else {
                still_failed.push(entry);
            }
        });

        failed_lookups.length = 0;
        Array.prototype.push.apply(failed_lookups, still_failed);

        if (used_fallback && fsm && fsm.bg_port) {
            fsm.send_port_request('REQUEST_CONFIG_REFRESH_PLAYER_MAP').catch(() => {});
        }
    }

    if (failed_lookups.length > 0) {
        const error_details = failed_lookups
            .map((f) => `"${f.lookup_key}" (pick #${f.pick.pick_number}, drafted by: ${f.pick.drafted_by})`)
            .join(', ');
        const error_msg = `Failed to get player IDs for ${failed_lookups.length} player(s) during ribbon extraction: ${error_details}`;
        console.error(error_msg, failed_lookups);
        return { ok: false, error_msg, failed_lookups, fatal_legacy_keys_hit };
    }

    const draft_picks = picks
        .filter((pick) => pick.id)
        .map((pick) => ({
            ud_id: pick.id
        }));

    return { ok: true, draft_picks, fatal_legacy_keys_hit };
}

function normalizeUdDraftPayload(detail) {
    if (!detail || typeof detail !== 'object') {
        return null;
    }
    if (detail.draft) {
        return detail;
    }
    if (detail.id != null && Array.isArray(detail.picks)) {
        return { draft: detail };
    }
    // Pusher status_change (and similar): draft-shaped object at top level with id + draft_entries;
    // picks may only appear once the draft is live.
    if (detail.id != null && Array.isArray(detail.draft_entries)) {
        return { draft: detail };
    }
    return null;
}

function getUdUrlDraftIdSafe() {
    try {
        return typeof get_underdog_draft_id_from_url === 'function'
            ? get_underdog_draft_id_from_url(window.location.href)
            : null;
    } catch (e) {
        return null;
    }
}

function sanitizeUdInterceptDraft(incoming, { preferPicksFromPrev = false } = {}) {
    if (!incoming || typeof incoming !== 'object') {
        return null;
    }
    const clean = {};
    if (incoming.id != null) {
        clean.id = incoming.id;
    }
    // Keep only the fields we actually consume downstream.
    // - `picks` is the primary source of truth for extraction.
    // - `draft_entries` appears in some status_change payloads; keep it only as a lightweight signal.
    if (Array.isArray(incoming.picks)) {
        clean.picks = incoming.picks;
    } else if (!preferPicksFromPrev) {
        clean.picks = [];
    }
    if (Array.isArray(incoming.draft_entries)) {
        clean.draft_entries = incoming.draft_entries;
    }
    // Sometimes status/state fields exist; keep them if they are small scalars.
    if (typeof incoming.status === 'string') clean.status = incoming.status;
    if (typeof incoming.state === 'string') clean.state = incoming.state;
    if (typeof incoming.draft_status === 'string') clean.draft_status = incoming.draft_status;
    // Contests without /v1/drafts/{id}/tournament (e.g. Weekly Winners): intercept summary +
    // ENRICH_UD_INTERCEPT_FROM_STYLE_IDS read slate_id, entry_count, title, source, style ids.
    if (incoming.slate_id != null && String(incoming.slate_id).trim() !== '') {
        clean.slate_id =
            typeof incoming.slate_id === 'string' ? incoming.slate_id.trim() : incoming.slate_id;
    }
    if (typeof incoming.entry_count === 'number' && Number.isFinite(incoming.entry_count)) {
        clean.entry_count = incoming.entry_count;
    } else if (incoming.entry_count != null && incoming.entry_count !== '') {
        const ec = Number(incoming.entry_count);
        if (Number.isFinite(ec)) clean.entry_count = ec;
    }
    if (typeof incoming.title === 'string' && incoming.title.trim()) {
        clean.title = incoming.title.trim();
    }
    if (typeof incoming.source === 'string' && incoming.source.trim()) {
        clean.source = incoming.source.trim();
    }
    if (incoming.contest_style_id != null && String(incoming.contest_style_id).trim() !== '') {
        clean.contest_style_id =
            typeof incoming.contest_style_id === 'string'
                ? incoming.contest_style_id.trim()
                : incoming.contest_style_id;
    }
    if (incoming.entry_style_id != null && String(incoming.entry_style_id).trim() !== '') {
        clean.entry_style_id =
            typeof incoming.entry_style_id === 'string'
                ? incoming.entry_style_id.trim()
                : incoming.entry_style_id;
    }
    return clean;
}

function bumpUdInterceptRevision(fsm, draftId) {
    if (!fsm || !fsm.state_data || draftId == null) {
        return;
    }
    const key = String(draftId);
    const by = fsm.state_data.ud_intercept_revision_by_draft || {};
    by[key] = (by[key] || 0) + 1;
    fsm.state_data.ud_intercept_revision_by_draft = by;
}

function noteUdInterceptTouched(fsm, draftId) {
    if (!fsm || !fsm.state_data || draftId == null) {
        return;
    }
    if (!fsm.state_data.ud_intercept_touched_at_ms) {
        fsm.state_data.ud_intercept_touched_at_ms = {};
    }
    fsm.state_data.ud_intercept_touched_at_ms[String(draftId)] = Date.now();
}

function evictUdInterceptCaches(fsm, maxDrafts = 8) {
    if (!fsm || !fsm.state_data) {
        return;
    }
    const drafts = fsm.state_data.ud_intercepted_drafts;
    if (!drafts || typeof drafts !== 'object') {
        return;
    }
    const keys = Object.keys(drafts);
    if (keys.length <= maxDrafts) {
        return;
    }
    const touched = fsm.state_data.ud_intercept_touched_at_ms || {};
    const withTs = keys.map((k) => {
        const ts = typeof touched[k] === 'number' ? touched[k] : 0;
        return { k, ts };
    });
    withTs.sort((a, b) => (a.ts || 0) - (b.ts || 0));
    const dropCount = Math.max(0, withTs.length - maxDrafts);
    for (let i = 0; i < dropCount; i++) {
        const k = withTs[i].k;
        try { delete drafts[k]; } catch {}
        if (fsm.state_data.ud_intercept_revision_by_draft) {
            try { delete fsm.state_data.ud_intercept_revision_by_draft[k]; } catch {}
        }
        if (fsm.state_data.ud_intercept_touched_at_ms) {
            try { delete fsm.state_data.ud_intercept_touched_at_ms[k]; } catch {}
        }
    }
}

function invalidateUdExtractionIfViewingDraft(fsm, draftId) {
    if (!fsm || !fsm.state_data || draftId == null) {
        return;
    }
    const urlId =
        typeof get_underdog_draft_id_from_url === 'function'
            ? get_underdog_draft_id_from_url(window.location.href)
            : null;
    if (urlId && String(urlId) === String(draftId)) {
        fsm.state_data.last_extraction_result = null;
        fsm.state_data.last_draft_status_span_text = null;
        const tcache = fsm.state_data.tournament_summary_cache;
        const ent = tcache && tcache[draftId];
        if (ent && !ent.supported) {
            delete tcache[draftId];
        }
    }
}

/**
 * GET /v2/drafts/... XHR body: authoritative full snapshot for that draft id.
 * Replaces any prior intercept (including Pusher-merged) for the same draft.
 */
function applyUdXhrAuthoritativeSnapshot(norm) {
    const fsm = window.__LEGUP_FSM__;
    if (!fsm || !fsm.state_data || !norm || !norm.draft) {
        return;
    }
    const incoming = norm.draft;
    if (incoming.id == null) {
        return;
    }
    const key = String(incoming.id);
    const urlDraftId = getUdUrlDraftIdSafe();
    if (urlDraftId && String(urlDraftId) !== key) {
        // Single-draft-per-tab: ignore snapshots for other draft ids.
        return;
    }
    const sanitized = sanitizeUdInterceptDraft(incoming) || { id: incoming.id, picks: [] };
    const picks = Array.isArray(sanitized.picks) ? sanitized.picks.slice() : [];
    const mergedDraft = { ...sanitized, picks };
    // Single-draft-per-tab: overwrite to avoid retaining other drafts in this tab.
    fsm.state_data.ud_intercepted_drafts = { [key]: { draft: mergedDraft } };
    noteUdInterceptTouched(fsm, key);
    bumpUdInterceptRevision(fsm, key);
    invalidateUdExtractionIfViewingDraft(fsm, key);
}

/**
 * Pusher status_change / nested draft+picks: merge into the bucket for norm.draft.id only.
 */
function applyUdWsDraftSnapshot(norm) {
    const fsm = window.__LEGUP_FSM__;
    if (!fsm || !fsm.state_data || !norm || !norm.draft) {
        return;
    }
    const incoming = norm.draft;
    if (incoming.id == null) {
        return;
    }
    const key = String(incoming.id);
    const urlDraftId = getUdUrlDraftIdSafe();
    if (urlDraftId && String(urlDraftId) !== key) {
        // Single-draft-per-tab: ignore WS snapshots for other draft ids.
        return;
    }
    const drafts = fsm.state_data.ud_intercepted_drafts || {};
    const prevWrap = drafts[key];
    const prevDraft = prevWrap && prevWrap.draft;

    const sameId =
        prevDraft &&
        incoming.id != null &&
        prevDraft.id != null &&
        String(prevDraft.id) === String(incoming.id);

    const sanitizedIncoming = sanitizeUdInterceptDraft(incoming, { preferPicksFromPrev: true }) || { id: incoming.id };

    let mergedDraft;
    if (sameId && prevDraft) {
        const mergedPicks = Array.isArray(sanitizedIncoming.picks)
            ? sanitizedIncoming.picks
            : Array.isArray(prevDraft.picks)
              ? prevDraft.picks
              : [];
        mergedDraft = { ...prevDraft, ...sanitizedIncoming, picks: mergedPicks };
    } else {
        mergedDraft = sanitizeUdInterceptDraft(incoming) || { id: incoming.id, picks: [] };
        if (!Array.isArray(mergedDraft.picks)) {
            mergedDraft.picks = [];
        }
    }

    // Single-draft-per-tab: overwrite to avoid retaining other drafts in this tab.
    fsm.state_data.ud_intercepted_drafts = { [key]: { draft: mergedDraft } };
    noteUdInterceptTouched(fsm, key);
    bumpUdInterceptRevision(fsm, key);
    invalidateUdExtractionIfViewingDraft(fsm, key);
}

function applyUdXhrInterceptToFsm(detail) {
    const norm = normalizeUdDraftPayload(detail);
    if (!norm || !norm.draft) {
        return;
    }
    applyUdXhrAuthoritativeSnapshot(norm);
}

function extractPusherPayloadDraftId(d) {
    if (!d || typeof d !== 'object') {
        return null;
    }
    if (d.draft != null && typeof d.draft === 'object' && d.draft.id != null) {
        return String(d.draft.id);
    }
    if (d.id != null) {
        return String(d.id);
    }
    if (d.draft_id != null) {
        return String(d.draft_id);
    }
    return null;
}

/**
 * pick_made: only mutates ud_intercepted_drafts[targetDraftId].
 * urlDraftId is used only when the payload has no draft id (single-pick shape) — then we assume
 * the event refers to the draft in the page URL if that bucket already exists (XHR-primed).
 */
function mergePickMadeIntoUdIntercept(pusherData, urlDraftId) {
    const fsm = window.__LEGUP_FSM__;
    if (!fsm || !fsm.state_data) {
        return;
    }
    // Single-draft-per-tab: only apply pick_made updates to the current URL draft.
    if (!urlDraftId) {
        return;
    }
    const targetUrlKey = String(urlDraftId);
    let d = pusherData;
    if (typeof d === 'string') {
        try {
            d = JSON.parse(d);
        } catch (e) {
            return;
        }
    }
    if (!d || typeof d !== 'object') {
        return;
    }

    if (d.draft && Array.isArray(d.draft.picks)) {
        const merged = normalizeUdDraftPayload(d);
        if (merged && merged.draft && merged.draft.id != null) {
            if (String(merged.draft.id) === targetUrlKey) {
                applyUdWsDraftSnapshot(merged);
            }
        }
        return;
    }

    if (Array.isArray(d.picks)) {
        const key = extractPusherPayloadDraftId(d);
        if (!key) {
            return;
        }
        if (String(key) !== targetUrlKey) {
            return;
        }
        const drafts = fsm.state_data.ud_intercepted_drafts || {};
        const wrap = drafts[key];
        if (!wrap || !wrap.draft) {
            return;
        }
        wrap.draft.picks = d.picks;
        noteUdInterceptTouched(fsm, key);
        bumpUdInterceptRevision(fsm, key);
        invalidateUdExtractionIfViewingDraft(fsm, key);
        return;
    }

    const payloadDraftId = extractPusherPayloadDraftId(d);
    if (payloadDraftId && String(payloadDraftId) !== targetUrlKey) {
        return;
    }
    const targetKey = targetUrlKey;

    const drafts = fsm.state_data.ud_intercepted_drafts || {};
    const wrap = drafts[targetKey];
    if (!wrap || !wrap.draft || !Array.isArray(wrap.draft.picks)) {
        return;
    }

    const pick = d.pick || d.player || (d.appearance_id || d.appearanceId ? d : null);
    if (!pick || typeof pick !== 'object') {
        return;
    }

    const picks = wrap.draft.picks;
    const n =
        pick.overall_pick_number != null
            ? pick.overall_pick_number
            : pick.pick_number != null
              ? pick.pick_number
              : pick.number != null
                ? pick.number
                : null;
    const idx = n != null ? n - 1 : -1;
    if (idx >= 0 && idx < picks.length) {
        const prev = picks[idx];
        picks[idx] = prev && typeof prev === 'object' ? { ...prev, ...pick } : pick;
    } else if (idx >= 0 && idx === picks.length) {
        picks.push(pick);
    } else {
        let empty = -1;
        for (let i = 0; i < picks.length; i++) {
            const p = picks[i];
            if (p == null || (typeof p === 'object' && !p.appearance_id && !p.appearanceId)) {
                empty = i;
                break;
            }
        }
        if (empty >= 0) {
            const prev = picks[empty];
            picks[empty] = prev && typeof prev === 'object' ? { ...prev, ...pick } : pick;
        }
    }
    bumpUdInterceptRevision(fsm, targetKey);
    noteUdInterceptTouched(fsm, targetKey);
    invalidateUdExtractionIfViewingDraft(fsm, targetKey);
}

function resolveUdPlayerIdFromApiPick(pick, player_map) {
    if (!pick || !player_map) {
        return null;
    }
    // Never use pick.id from the API — that is the draft-pick row id, not the player id.
    const aid = pick.appearance_id || pick.appearanceId;
    if (aid && typeof player_map[aid] === 'string') {
        return player_map[aid];
    }
    return null;
}

function getUnderdogSlateWhitelistObject(fsm) {
    const w = fsm && fsm.state_data && fsm.state_data.static_settings && fsm.state_data.static_settings.underdog_slate_whitelist;
    if (w && typeof w === 'object' && !Array.isArray(w)) {
        return w;
    }
    return null;
}

function resolveUdAppearanceIdMapDatasetKeyFromProductExperienceId(fsm, productExperienceId) {
    if (productExperienceId == null || productExperienceId === '') {
        return null;
    }
    const w = getUnderdogSlateWhitelistObject(fsm);
    if (!w) {
        return null;
    }
    const needle = String(productExperienceId).trim().toLowerCase();
    const entries = Object.entries(w);
    for (let i = 0; i < entries.length; i++) {
        const label = entries[i][0];
        const val = entries[i][1];
        if (typeof val !== 'string' || !label) {
            continue;
        }
        if (val.trim().toLowerCase() === needle) {
            return String(label) + '_appearance_id_map';
        }
    }
    return null;
}

/**
 * Draft XHR includes `slate_id` (same UUIDs as object-form underdog_slate_whitelist).
 * Some contests (e.g. Weekly Winners) have no /v1/drafts/{id}/tournament response — we still
 * resolve the appearance id map when slate_id matches the remote whitelist.
 * Fee/payout tier maps come from the tournament fetch (entry_style + advancement); this object
 * only fills sizing and slate mapping when that endpoint 404s.
 */
function tryBuildInterceptBackedTournamentSummary(fsm, draft_id) {
    if (!fsm || !fsm.state_data || draft_id == null) {
        return null;
    }
    const drafts = fsm.state_data.ud_intercepted_drafts || {};
    const wrap = drafts[String(draft_id)];
    const d = wrap && wrap.draft;
    if (!d || typeof d !== 'object') {
        return null;
    }
    const slateId = d.slate_id != null && d.slate_id !== '' ? String(d.slate_id).trim() : '';
    if (!slateId) {
        return null;
    }
    const appearance_id_map_dataset_key = resolveUdAppearanceIdMapDatasetKeyFromProductExperienceId(fsm, slateId);
    if (!appearance_id_map_dataset_key) {
        return null;
    }
    const ec = Number(d.entry_count);
    const draft_size = Number.isFinite(ec) && ec > 0 ? Math.round(ec) : null;
    const picks = d.picks;
    let contest_rounds = null;
    if (Array.isArray(picks) && draft_size != null && draft_size > 0) {
        const r = picks.length / draft_size;
        if (Number.isFinite(r) && r > 0) {
            contest_rounds = Math.round(r);
        }
    }
    const title = typeof d.title === 'string' && d.title.trim() ? d.title.trim() : null;
    const source = typeof d.source === 'string' ? d.source : '';
    const contest_style_name =
        source === 'weekly_winner' ? 'Weekly Winners' : title || null;
    const advancement_structure =
        draft_size != null
            ? { regular_season_denom: draft_size, raw_string: null }
            : null;
    const tournament_info = {
        id: d.id != null ? String(d.id) : String(draft_id),
        title: title,
        description: null,
        contest_style_name: contest_style_name,
        advancement_structure: advancement_structure,
        payout_structure: {},
        entry_fee: null
    };
    return {
        supported: true,
        reason: null,
        tournament_id: d.id != null ? String(d.id) : String(draft_id),
        title: title,
        description: null,
        contest_style_name: contest_style_name,
        advancement_structure: advancement_structure,
        payout_structure: {},
        entry_fee: null,
        contest_rounds: contest_rounds,
        draft_size: draft_size,
        slate_ids: [slateId],
        appearance_id_map_dataset_key: appearance_id_map_dataset_key,
        slate_key: appearance_id_map_dataset_key.replace(/_appearance_id_map$/, ''),
        ud_no_tournament_endpoint: true,
        tournament_info: tournament_info
    };
}

async function enrichInterceptBackedTournamentSummary(fsm, draft_id, interceptSummary) {
    if (!fsm || !fsm.bg_port || !fsm.bg_connected || !interceptSummary) {
        return interceptSummary;
    }
    const drafts = fsm.state_data && fsm.state_data.ud_intercepted_drafts ? fsm.state_data.ud_intercepted_drafts : {};
    const wrap = drafts[String(draft_id)];
    const d = wrap && wrap.draft;
    if (!d || typeof d !== 'object') {
        return interceptSummary;
    }

    const contest_style_id =
        d.contest_style_id != null && String(d.contest_style_id).trim() !== ''
            ? String(d.contest_style_id).trim()
            : null;
    const entry_style_id =
        d.entry_style_id != null && String(d.entry_style_id).trim() !== ''
            ? String(d.entry_style_id).trim()
            : null;
    if (!contest_style_id && !entry_style_id) {
        return interceptSummary;
    }

    const payload = {
        contest_style_id: contest_style_id,
        entry_style_id: entry_style_id,
        draft_entry_count: d.entry_count,
        advancement_structure: interceptSummary.advancement_structure || null
    };

    try {
        const res = await fsm.send_port_request('ENRICH_UD_INTERCEPT_FROM_STYLE_IDS', payload);
        const enrichment = res && res.status === 'ok' ? res.enrichment : null;
        if (!enrichment || typeof enrichment !== 'object') {
            return interceptSummary;
        }

        const merged = {
            ...interceptSummary,
            contest_style_name:
                enrichment.contest_style_name != null && enrichment.contest_style_name !== ''
                    ? enrichment.contest_style_name
                    : interceptSummary.contest_style_name,
            contest_rounds:
                enrichment.contest_rounds != null ? enrichment.contest_rounds : interceptSummary.contest_rounds,
            entry_fee: enrichment.entry_fee != null ? enrichment.entry_fee : interceptSummary.entry_fee,
            payout_structure:
                enrichment.payout_structure && typeof enrichment.payout_structure === 'object'
                    ? enrichment.payout_structure
                    : interceptSummary.payout_structure
        };
        const ti = merged.tournament_info && typeof merged.tournament_info === 'object' ? merged.tournament_info : {};
        merged.tournament_info = {
            ...ti,
            contest_style_name: merged.contest_style_name,
            entry_fee: merged.entry_fee,
            payout_structure: merged.payout_structure
        };
        return merged;
    } catch (err) {
        return interceptSummary;
    }
}

function getUdAppearanceIdMapFlat(fsm, datasetKey) {
    if (!datasetKey || !fsm || !fsm.datasets) {
        return null;
    }
    const o = fsm.datasets[datasetKey];
    const m = o && o.map && typeof o.map === 'object' ? o.map : null;
    if (m && Object.keys(m).length > 0) {
        return m;
    }
    return null;
}

function getUdLegacyAppearanceIdMapFlat(fsm) {
    return getUdAppearanceIdMapFlat(fsm, 'legacy_appearance_id_map');
}

/** Mirrors background `contentScriptHasExplicitUdAppearanceMaps`: explicit ud_*_appearance_id_map datasets mean do not use derived player_map_ud.players for appearance_id resolution. */
function legupUdExplicitAppearanceIdMapsConfigured(fsm) {
    const ds = fsm && fsm.datasets;
    if (!ds || typeof ds !== 'object') {
        return false;
    }
    const keys = Object.keys(ds);
    for (let i = 0; i < keys.length; i++) {
        const k = keys[i];
        if (!k.endsWith('_appearance_id_map')) {
            continue;
        }
        const v = ds[k];
        if (v == null) {
            continue;
        }
        if (typeof v === 'string' && v.trim()) {
            return true;
        }
        if (v && typeof v === 'object' && !Array.isArray(v)) {
            if (v.map && typeof v.map === 'object' && Object.keys(v.map).length > 0) {
                return true;
            }
        }
    }
    return false;
}

function udTryParseFirstUuidFromString(s) {
    if (!s || typeof s !== 'string') {
        return null;
    }
    const m = s.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i);
    return m && m[0] ? String(m[0]) : null;
}

function udResolveOwnershipProductExperienceIdFromRequestUrl(url) {
    if (!url || typeof url !== 'string') {
        return { productExperienceId: null, source: null, parse_error: null };
    }
    try {
        const u = new URL(url);
        // Ownership endpoints for newer contests encode the slate UUID directly in the path:
        // /v1/user/slates/{slate_uuid}/contest_styles/{...}/ownership
        // We want the UUID immediately after /slates/.
        const slatesMatch = u.pathname.match(/\/slates\/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})/i);
        if (slatesMatch && slatesMatch[1]) {
            return { productExperienceId: String(slatesMatch[1]), source: 'path:/slates/{uuid}', parse_error: null };
        }
        const fromQuery = u.searchParams.get('product_experience_id');
        if (fromQuery && String(fromQuery).trim() !== '') {
            return { productExperienceId: String(fromQuery).trim(), source: 'query:product_experience_id', parse_error: null };
        }
        // Fallback: best-effort UUID scan (least reliable; URL can contain many UUIDs).
        const fromPath = udTryParseFirstUuidFromString(u.pathname);
        if (fromPath) {
            return { productExperienceId: fromPath, source: 'path:first_uuid_fallback', parse_error: null };
        }
        return { productExperienceId: null, source: null, parse_error: null };
    } catch (e) {
        // If URL parsing fails (relative URL or unexpected), try a best-effort UUID scan.
        const bestEffort = udTryParseFirstUuidFromString(url);
        return {
            productExperienceId: bestEffort,
            source: bestEffort ? 'string:first_uuid' : null,
            parse_error: e && e.message ? String(e.message) : 'url_parse_failed'
        };
    }
}

function legupUdExposureLog(fsm, level, message, obj) {
    const m = `[LegUp exposure][UD] ${message}`;
    if (fsm && typeof fsm.conditional_log === 'function') {
        // conditional_log signature: (context, messages, log_level)
        const ctx = 'ud_exposure:' + message;
        const payload = obj != null ? [m, obj] : [m];
        fsm.conditional_log(ctx, payload, level || 'log');
        return;
    }
    if (level === 'warn') {
    } else if (level === 'error') {
        console.error(m, obj != null ? obj : '');
    } else {
    }
}

/**
 * Ownership GET includes product_experience_id in the URL; slate whitelist maps that UUID to a dataset
 * key such as ud_bbm_appearance_id_map. If no slate matches, use legacy_appearance_id_map.
 * Falls back to legacy player_map_ud.players only when no explicit *_appearance_id_map datasets are configured.
 */
function resolveUdAppearanceIdMapForOwnershipDetail(fsm, detail) {
    const url = detail && detail.__legup_ownership_request_url;
    const parsed = udResolveOwnershipProductExperienceIdFromRequestUrl(url);
    const productExperienceId = parsed && parsed.productExperienceId ? parsed.productExperienceId : null;

    const key = resolveUdAppearanceIdMapDatasetKeyFromProductExperienceId(fsm, productExperienceId);
    let map = getUdAppearanceIdMapFlat(fsm, key);
    const chosen = map ? (key || null) : null;
    if (!map) {
        map = getUdLegacyAppearanceIdMapFlat(fsm);
    }
    const usedLegacy = !chosen && !!map;
    let usedPlayerMapFallback = false;
    if (!map && !legupUdExplicitAppearanceIdMapsConfigured(fsm)) {
        const pm = fsm && fsm.datasets && fsm.datasets.player_map_ud && fsm.datasets.player_map_ud.players;
        if (pm && typeof pm === 'object' && Object.keys(pm).length > 0) {
            map = pm;
            usedPlayerMapFallback = true;
        }
    }
    // Log once per URL (or "no-url") to pinpoint failures in non-legacy slates.
    if (fsm && fsm.state_data) {
        const cache = fsm.state_data.ud_ownership_map_resolution_log_cache || {};
        const cacheKey = url && typeof url === 'string' ? url : 'no-url';
        if (!cache[cacheKey]) {
            cache[cacheKey] = Date.now();
            fsm.state_data.ud_ownership_map_resolution_log_cache = cache;
            legupUdExposureLog(fsm, 'log', 'ownership map resolution', {
                productExperienceId,
                id_source: parsed ? parsed.source : null,
                url_parse_error: parsed ? parsed.parse_error : null,
                resolved_dataset_key: key,
                map_selected: chosen || (usedLegacy ? 'legacy_appearance_id_map' : usedPlayerMapFallback ? 'player_map_ud.players' : null),
                map_size: map && typeof map === 'object' ? Object.keys(map).length : 0,
                explicit_maps_configured: legupUdExplicitAppearanceIdMapsConfigured(fsm)
            });
        }
    }
    return map;
}

function resolveUdAppearanceIdMapForDraftExtraction(fsm, tournament_summary) {
    const key = tournament_summary && tournament_summary.appearance_id_map_dataset_key;
    let map = getUdAppearanceIdMapFlat(fsm, key);
    if (!map && !legupUdExplicitAppearanceIdMapsConfigured(fsm)) {
        const pm = fsm && fsm.datasets && fsm.datasets.player_map_ud && fsm.datasets.player_map_ud.players;
        if (pm && typeof pm === 'object' && Object.keys(pm).length > 0) {
            map = pm;
        }
    }
    return map;
}

function udInterceptPicksUsableForIdResolution(draft_obj) {
    if (!draft_obj || !Array.isArray(draft_obj.picks)) {
        return false;
    }
    return draft_obj.picks.some(
        (p) =>
            p &&
            typeof p === 'object' &&
            Object.keys(p).length > 0 &&
            (p.appearance_id != null || p.appearanceId != null)
    );
}

function countUdInterceptPicksWithAppearance(api_picks) {
    if (!Array.isArray(api_picks)) {
        return 0;
    }
    let n = 0;
    for (let i = 0; i < api_picks.length; i++) {
        const p = api_picks[i];
        if (p == null || typeof p !== 'object' || Object.keys(p).length === 0) {
            continue;
        }
        if (p.appearance_id != null || p.appearanceId != null) {
            n++;
        }
    }
    return n;
}

function getUdInterceptAppearancePickNumberLog(api_picks) {
    const out = [];
    if (!Array.isArray(api_picks)) {
        return out;
    }
    for (let i = 0; i < api_picks.length; i++) {
        const p = api_picks[i];
        if (p == null || typeof p !== 'object' || Object.keys(p).length === 0) {
            continue;
        }
        if (p.appearance_id == null && p.appearanceId == null) {
            continue;
        }
        const reported =
            p.overall_pick_number != null
                ? p.overall_pick_number
                : p.pick_number != null
                  ? p.pick_number
                  : p.number != null
                    ? p.number
                    : null;
        out.push({
            array_index: i,
            reported_pick_number: reported != null ? reported : i + 1,
            appearance_id: p.appearance_id != null ? p.appearance_id : p.appearanceId
        });
    }
    return out;
}

function extractUdOwnershipAppearanceDisplayFields(a) {
    if (!a || typeof a !== 'object') {
        return { full_name: null, position: null, team: null };
    }
    const tryPlayer = a.player && typeof a.player === 'object' ? a.player : null;
    const tryAppearance = a.appearance && typeof a.appearance === 'object' ? a.appearance : null;
    const candidates = [tryPlayer, tryAppearance, a];
    let fullName = '';
    let position = '';
    let team = '';
    for (let c = 0; c < candidates.length; c++) {
        const src = candidates[c];
        if (!src) {
            continue;
        }
        if (!fullName) {
            fullName = src.full_name || src.fullName || src.name || src.player_name || src.display_name || '';
            if (!fullName && (src.first_name != null || src.last_name != null)) {
                fullName = [src.first_name, src.last_name].filter((x) => x != null && String(x).trim() !== '').join(' ');
            }
        }
        if (!position) {
            position = src.position || src.pos || '';
        }
        if (!team) {
            team = src.team || src.team_abbr || src.teamAbbr || src.team_abbreviation || '';
        }
    }
    return {
        full_name: fullName ? String(fullName).trim() : null,
        position: position ? String(position).trim() : null,
        team: team ? String(team).trim() : null
    };
}

// Slate-level tournament metadata from the ownership payload (`ownership.tournaments`).
// Each row carries `title` (e.g. "The Puppy", "The Little Dalmatian") plus the rest of that tournament object.
function extractUdOwnershipTournaments(own) {
    const arr = own && Array.isArray(own.tournaments) ? own.tournaments : null;
    if (!arr || !arr.length) {
        return null;
    }
    const out = [];
    for (let i = 0; i < arr.length; i++) {
        const t = arr[i];
        if (!t || typeof t !== 'object') {
            continue;
        }
        let clone = null;
        try {
            // JSON round-trip yields a clean deep copy (drops functions / Firefox XrayWrappers).
            clone = JSON.parse(JSON.stringify(t));
        } catch (e) {
            clone = null;
        }
        if (clone && typeof clone === 'object') {
            out.push(clone);
        }
    }
    return out.length ? out : null;
}

function buildUdExposureRowsFromOwnershipPayload(parsed, playerMap, playerInfoById) {
    const own = parsed && parsed.ownership;
    if (!own || typeof own !== 'object') {
        return null;
    }
    const appearances = own.appearances;
    if (!Array.isArray(appearances) || appearances.length === 0) {
        return null;
    }
    const map = playerMap && typeof playerMap === 'object' ? playerMap : null;
    const infoById = playerInfoById && typeof playerInfoById === 'object' ? playerInfoById : null;
    const draftCount = Number(own.draft_count);
    const metaDraftCount = Number.isFinite(draftCount) && draftCount > 0 ? draftCount : null;
    if (metaDraftCount == null) {
        return {
            error: 'missing_or_invalid_ownership.draft_count',
            ud_draft_count: null,
            rows: []
        };
    }
    const rows = [];
    let missingAppearanceId = 0;
    let missingCanonical = 0;
    const unmappedAppearanceIdSample = [];
    for (let i = 0; i < appearances.length; i++) {
        const a = appearances[i];
        if (!a || typeof a !== 'object') {
            continue;
        }
        const appearanceId = a.appearance_id != null ? a.appearance_id : a.appearanceId;
        if (appearanceId == null || appearanceId === '') {
            missingAppearanceId++;
            continue;
        }
        const canonicalId = map ? resolveUdPlayerIdFromApiPick({ appearance_id: appearanceId }, map) : null;
        if (!canonicalId || typeof canonicalId !== 'string') {
            missingCanonical++;
            if (unmappedAppearanceIdSample.length < 8) {
                unmappedAppearanceIdSample.push(String(appearanceId));
            }
            continue;
        }
        const id = String(canonicalId).trim();
        if (!id) {
            continue;
        }
        const fees = Number(a.total_entry_fees);
        const pickCount = Number(a.pick_count);
        const ud_entry_fees = Number.isFinite(fees) ? fees : null;
        const ud_pick_count = Number.isFinite(pickCount) ? pickCount : null;
        if (ud_entry_fees == null || ud_pick_count == null) {
            continue;
        }
        const disp = extractUdOwnershipAppearanceDisplayFields(a);
        const row = { id: id, ud_entry_fees: ud_entry_fees, ud_pick_count: ud_pick_count };
        if (disp.full_name) row.full_name = disp.full_name;
        if (disp.position) row.position = disp.position;
        if (disp.team) row.team = disp.team;

        // Prefer player-map display fields when ownership appearances don't include them.
        if (infoById && (!row.full_name || !row.position || !row.team)) {
            const info = infoById[id];
            if (info && typeof info === 'object') {
                if (!row.full_name && info.full_name) row.full_name = String(info.full_name).trim();
                if (!row.position && info.position) row.position = String(info.position).trim();
                if (!row.team && info.team) row.team = String(info.team).trim();
            }
        }
        rows.push(row);
    }
    // High-signal debugging: only log when we saw appearances but mapped few (or none).
    if (typeof window !== 'undefined' && window.__LEGUP_FSM__ && (missingCanonical > 0 || missingAppearanceId > 0)) {
        const fsm = window.__LEGUP_FSM__;
        const total = appearances.length;
        const resolved = rows.length;
        const ratio = total > 0 ? resolved / total : 0;
        if (resolved === 0 || ratio < 0.25) {
            legupUdExposureLog(fsm, 'warn', 'ownership normalization had many unmapped appearance_ids', {
                appearances_total: total,
                rows_resolved: resolved,
                missing_appearance_id: missingAppearanceId,
                missing_canonical_id_from_map: missingCanonical,
                unmapped_appearance_id_sample: unmappedAppearanceIdSample
            });
        }
    }
    const tournaments = extractUdOwnershipTournaments(own);
    return rows.length
        ? { rows: rows, ud_draft_count: metaDraftCount, tournaments: tournaments }
        : { error: 'no_rows_resolved', ud_draft_count: metaDraftCount, rows: [], tournaments: tournaments };
}

function sendUdOwnershipExposureMerge(fsm, payload) {
    if (!payload || !payload.rows || !payload.rows.length || !fsm || !fsm.bg_port || !fsm.bg_connected) {
        return;
    }
    fsm
        .send_port_request('MERGE_UD_EXPOSURE_FROM_OWNERSHIP', payload)
        .then((res) => {
            if (!res || res.status !== 'ok') {
                return;
            }
            if (res.skipped) {
                return;
            }
            const om = fsm && fsm.overlay_manager;
            if (!om || typeof om.show_exposure_saved_toast !== 'function') {
                return;
            }
            const staticSettings = fsm.state_data && fsm.state_data.static_settings;
            const slateLabel =
                typeof formatUnderdogSlateLabelForExposureToast === 'function'
                    ? formatUnderdogSlateLabelForExposureToast(payload.slate_id, staticSettings)
                    : String(payload.slate_id || '').trim() || 'Legacy / unknown slate';
            om.show_exposure_saved_toast(`Exposure data saved · Underdog · ${slateLabel}`);
        })
        .catch((err) => {
        });
}

function tryFlushPendingUdOwnershipMerge(fsm) {
    const detail = fsm && fsm.state_data && fsm.state_data.pending_ud_ownership_detail;
    if (!detail) {
        return;
    }
    const playerMap = resolveUdAppearanceIdMapForOwnershipDetail(fsm, detail);
    const infoById = fsm.datasets && fsm.datasets.player_map_ud && fsm.datasets.player_map_ud.player_info_by_id;
    if (!playerMap || typeof playerMap !== 'object' || Object.keys(playerMap).length === 0) {
        return;
    }
    const payload = buildUdExposureRowsFromOwnershipPayload(detail, playerMap, infoById);
    if (!payload || !payload.rows.length) {
        return;
    }
    delete fsm.state_data.pending_ud_ownership_detail;
    sendUdOwnershipExposureMerge(fsm, payload);
}

function sendFantasySiteUsernameToBackground(fsm, site, username) {
    const normalized = typeof username === 'string' ? username.trim() : '';
    if (!normalized || !fsm) {
        return;
    }
    if (!fsm.bg_port || !fsm.bg_connected) {
        if (!fsm.state_data) {
            fsm.state_data = {};
        }
        fsm.state_data.pending_fantasy_site_username = { site: site, username: normalized };
        return;
    }
    if (fsm.state_data) {
        delete fsm.state_data.pending_fantasy_site_username;
    }
    fsm.send_port_request('STORE_FANTASY_SITE_USERNAME', { site: site, username: normalized }).catch(() => {});
}

function flushPendingFantasySiteUsername(fsm) {
    const pending = fsm && fsm.state_data && fsm.state_data.pending_fantasy_site_username;
    if (!pending || !pending.site || !pending.username) {
        return;
    }
    sendFantasySiteUsernameToBackground(fsm, pending.site, pending.username);
}

(function register_legup_underdog_intercept_listeners() {
    if (typeof window === 'undefined' || window.__legupUdDraftV2ListenerInstalled) {
        return;
    }
    window.__legupUdDraftV2ListenerInstalled = true;
    window.addEventListener('__legup_ud_draft_v2_json', (ev) => {
        applyUdXhrInterceptToFsm(ev.detail);
    });
    window.addEventListener('__legup_ud_ownership_json', (ev) => {
        const fsm = window.__LEGUP_FSM__;
        const detail = ev.detail;
        const playerMap = fsm ? resolveUdAppearanceIdMapForOwnershipDetail(fsm, detail) : null;
        const infoById = fsm && fsm.datasets && fsm.datasets.player_map_ud && fsm.datasets.player_map_ud.player_info_by_id;
        const mapReady = playerMap && typeof playerMap === 'object' && Object.keys(playerMap).length > 0;
        if (!mapReady && fsm && fsm.state_data) {
            fsm.state_data.pending_ud_ownership_detail = detail;
            return;
        }
        const payload = buildUdExposureRowsFromOwnershipPayload(detail, playerMap, infoById);
        if (!payload || payload.error) {
            console.error('[LegUp exposure][UD] cannot store exposure: missing required ud_draft_count or no rows', {
                error: payload ? payload.error : 'no_payload',
                url: detail && detail.__legup_ownership_request_url ? detail.__legup_ownership_request_url : null,
                draft_count: detail && detail.ownership ? detail.ownership.draft_count : null,
                appearances: detail && detail.ownership && Array.isArray(detail.ownership.appearances) ? detail.ownership.appearances.length : 0
            });
            return;
        }
        if (!payload.rows.length) {
            console.error('[LegUp exposure][UD] cannot store exposure: payload has zero rows', {
                url: detail && detail.__legup_ownership_request_url ? detail.__legup_ownership_request_url : null,
                appearances: detail && detail.ownership && Array.isArray(detail.ownership.appearances) ? detail.ownership.appearances.length : 0
            });
            return;
        }
        // For non-legacy contests, ownership endpoints include the slate UUID in the URL path:
        // /v1/user/slates/{slate_uuid}/...
        const resolved = udResolveOwnershipProductExperienceIdFromRequestUrl(
            detail && typeof detail === 'object' ? detail.__legup_ownership_request_url : null
        );
        const slate_id = resolved && resolved.productExperienceId ? resolved.productExperienceId : null;
        if (slate_id) {
            payload.slate_id = slate_id;
        }
        // Strict: UD requires draft_count so percent synthesis is always well-defined.
        if (payload.ud_draft_count == null) {
            console.error('[LegUp exposure][UD] cannot store exposure: ud_draft_count missing', {
                url: detail && detail.__legup_ownership_request_url ? detail.__legup_ownership_request_url : null
            });
            return;
        }
        if (fsm && fsm.state_data) {
            delete fsm.state_data.pending_ud_ownership_detail;
        }
        if (!fsm || !fsm.bg_port || !fsm.bg_connected) {
            return;
        }
        sendUdOwnershipExposureMerge(fsm, payload);
    });
    window.addEventListener('__legup_ud_draft_xhr_capture', (ev) => {
        const d = ev.detail || {};
        const draft_id = d.draft_id;
        const url = d.url;
        const headers = d.headers;
        if (!draft_id || !url) {
            return;
        }
        const urlDraftId = getUdUrlDraftIdSafe();
        if (urlDraftId && String(urlDraftId) !== String(draft_id)) {
            // Single-draft-per-tab: do not persist replay info for other drafts.
            return;
        }
        const fsm = window.__LEGUP_FSM__;
        if (!fsm || !fsm.bg_port || !fsm.bg_connected) {
            return;
        }
        fsm
            .send_port_request('STORE_UD_DRAFT_XHR_CAPTURE', {
                draft_id: draft_id,
                url: url,
                headers: headers && typeof headers === 'object' ? headers : {}
            })
            .catch((err) => {
            });
    });
    window.addEventListener('__legup_ud_ws_message', (ev) => {
        const d = ev.detail || {};
        const evName = d.pusherEvent;
        const urlDraftId =
            typeof get_underdog_draft_id_from_url === 'function'
                ? get_underdog_draft_id_from_url(window.location.href)
                : null;
        if (evName === 'pick_made') {
            mergePickMadeIntoUdIntercept(d.pusherData != null ? d.pusherData : d.parsed, urlDraftId);
        } else if (evName === 'status_change') {
            let data = d.pusherData;
            if (data == null) {
                return;
            }
            if (typeof data === 'string') {
                try {
                    data = JSON.parse(data);
                } catch (e) {
                    return;
                }
            }
            const norm = normalizeUdDraftPayload(data);
            if (norm && norm.draft) {
                applyUdWsDraftSnapshot(norm);
            }
        }
    });
})();

async function get_tournament_summary_from_background(draft_id) {
    const fsm = window.__LEGUP_FSM__;
    if (!fsm || !fsm.bg_port || !fsm.bg_connected) {
        return null;
    }

    const MAX_TOURNAMENT_SUMMARY_CACHE = 10;
    const evictTournamentSummaryCacheIfNeeded = () => {
        const c = fsm.state_data.tournament_summary_cache;
        if (!c || typeof c !== 'object') return;
        const keys = Object.keys(c);
        if (keys.length <= MAX_TOURNAMENT_SUMMARY_CACHE) return;
        // Drop the oldest inserted key (best-effort). This cache is an optimization only.
        try {
            const dropKey = keys[0];
            delete c[dropKey];
        } catch {}
    };

    // Always try GET_TOURNAMENT_DATA first when uncached so the background can resolve
    // contest_style_id / entry_style_id (fee, payout rows, rounds) — not present on draft XHR.
    // If the API returns no tournament (404), we overlay tryBuildInterceptBackedTournamentSummary below.

    const cache = fsm.state_data.tournament_summary_cache || {};
    if (cache[draft_id]) {
        return cache[draft_id];
    }

    try {
        const response = await fsm.send_port_request('GET_TOURNAMENT_DATA', {
            draft_id: draft_id
        });
        if (response && response.status === 'ok') {
            const summary = response.tournament_summary || null;
            if (summary) {
                const interceptOverlay = tryBuildInterceptBackedTournamentSummary(fsm, draft_id);
                if (interceptOverlay && summary.reason === 'no_data') {
                    const enrichedIntercept = await enrichInterceptBackedTournamentSummary(
                        fsm,
                        draft_id,
                        interceptOverlay
                    );
                    if (!fsm.state_data.tournament_summary_cache) {
                        fsm.state_data.tournament_summary_cache = {};
                    }
                    fsm.state_data.tournament_summary_cache[draft_id] = enrichedIntercept;
                    evictTournamentSummaryCacheIfNeeded();
                    return enrichedIntercept;
                }
                if (summary.supported || summary.reason !== 'no_data') {
                    if (!fsm.state_data.tournament_summary_cache) {
                        fsm.state_data.tournament_summary_cache = {};
                    }
                    fsm.state_data.tournament_summary_cache[draft_id] = summary;
                    evictTournamentSummaryCacheIfNeeded();
                }
            }
            const env = fsm && fsm.state_data ? fsm.state_data.env_value : null;
            if (env === 'dev' || env === 'local') {
                const csSummaryDbg = {
                    draft_id: draft_id,
                    from_cache: response.from_cache,
                    draft_size: summary?.draft_size ?? null,
                    contest_rounds: summary?.contest_rounds ?? null,
                    supported: summary?.supported,
                    reason: summary?.reason ?? null,
                    tournament_id: summary?.tournament_id ?? null,
                    slate_ids: Array.isArray(summary?.slate_ids) ? summary.slate_ids : []
                };
            }
            return summary;
        } else {
            return null;
        }
    } catch (err) {
        console.error(`[CS Tournament] get_tournament_data_from_background failed for draft_id=${draft_id}:`, err);
        return null;
    }
}

function handle_ud_sheet_overlay(fsm, url) {
    try {
        const overlay_mgr = fsm?.overlay_manager;
        if (!overlay_mgr) return;

        const user_settings = fsm?.user_settings || {};
        const enable_button_container = user_settings.ghost_enable_button_container !== false;
        const enable_player_card = user_settings.ghost_enable_player_card === true;
        const enable_draft_board = user_settings.ghost_enable_draft_board === true;

        let should_ghost = false;

        if (enable_button_container) {
            const sheetButtons = document.querySelector('div[class*="styles__buttonContainer__"][class*="styles__sideBySide__"]');
            if (sheetButtons) {
                should_ghost = true;
            }
        }

        if (enable_player_card && !should_ghost) {
            const playerCard = document.querySelector('div[class*="styles__playerCard__"]');
            if (playerCard) {
                should_ghost = true;
            }
        }

        if (enable_draft_board && !should_ghost) {
            const draftBoard = document.querySelector('div[class^="styles__draftBoardWrapper__"]');
            if (draftBoard) {
                should_ghost = true;
            }
        }

        if (should_ghost) {
            overlay_mgr.enter_ghost_mode?.();
        } else {
            overlay_mgr.exit_ghost_mode?.();
        }
    } catch (err) {
        console.error('[UD] handle_ud_sheet_overlay failed', err);
    }
}

function handle_underdog_bestball_button() {
    try {
        // Find the sport selector scroll container
        const scrollContainer = document.querySelector('div[class*="styles__scrollBar__"]');
        if (!scrollContainer) {
            return;
        }

        // Check if we're on the NFL section by looking for an active button with "NFL" text
        // The active button has a class that starts with "styles__active__"
        const allButtons = scrollContainer.querySelectorAll('button[class*="styles__sportSelectorButton__"]');
        let activeButton = null;
        let isNflSection = false;

        for (const button of allButtons) {
            // Check if button has active class (class name contains "styles__active__")
            const hasActiveClass = Array.from(button.classList).some(cls => cls.startsWith('styles__active__'));
            if (hasActiveClass) {
                activeButton = button;
                // Check if the active button is for NFL
                const buttonText = button.querySelector('p[class*="styles__text__"]');
                if (buttonText && buttonText.textContent.trim() === 'NFL') {
                    isNflSection = true;
                }
                break;
            }
        }

        // If not on NFL section, remove Bestball button if it exists
        if (!isNflSection) {
            const existingBestball = scrollContainer.querySelector('button[data-legup-bestball]');
            if (existingBestball) {
                const scrollItem = existingBestball.closest('div[class*="styles__scrollItem__"]');
                if (scrollItem) {
                    scrollItem.remove();
                } else {
                    existingBestball.remove();
                }
            }
            return;
        }

        // Check if Bestball button already exists
        const existingBestball = scrollContainer.querySelector('button[data-legup-bestball]');
        if (existingBestball) {
            return; // Already exists, no need to recreate
        }

        // Find a reference button to clone the structure
        const referenceButton = scrollContainer.querySelector('button[class*="styles__sportSelectorButton__"]');
        if (!referenceButton) {
            return;
        }

        // Get the scroll item wrapper class from a reference button
        const referenceScrollItem = referenceButton.closest('div[class*="styles__scrollItem__"]');
        const scrollItemClassName = referenceScrollItem ? referenceScrollItem.className : 'styles__scrollItem__vvWNZ';

        // Create the Bestball button by cloning the structure
        const scrollItem = document.createElement('div');
        scrollItem.className = scrollItemClassName;

        const bestballButton = document.createElement('button');
        bestballButton.type = 'button';
        // Get base classes from reference button, but remove any active class
        const baseClasses = Array.from(referenceButton.classList).filter(cls => !cls.startsWith('styles__active__'));
        bestballButton.className = baseClasses.join(' ');
        bestballButton.setAttribute('data-legup-bestball', 'true');

        // Create the content div
        const contentDiv = document.createElement('div');
        const referenceContent = referenceButton.querySelector('div[class*="styles__content__"]');
        if (referenceContent) {
            contentDiv.className = referenceContent.className;
        } else {
            contentDiv.className = 'styles__content__WY8gU';
        }
        // Use NFL colors (rgb(23, 95, 199)) for consistency
        contentDiv.style.backgroundColor = 'rgb(23, 95, 199)';
        contentDiv.style.borderColor = 'rgb(23, 95, 199)';

        // Create logo image instead of icon
        const logoImg = document.createElement('img');
        logoImg.src = chrome.runtime.getURL('assets/Sidekick_Favicon-Transparent.png');
        logoImg.alt = 'Bestball';
        // Size the image to match the text height - use em units to scale with text
        logoImg.style.height = '1em'; // Match text height using em units
        logoImg.style.width = 'auto';
        logoImg.style.objectFit = 'contain';
        logoImg.style.display = 'inline-block';
        logoImg.style.verticalAlign = 'middle';

        // Create text
        const text = document.createElement('p');
        const referenceText = referenceButton.querySelector('p[class*="styles__text__"]');
        if (referenceText) {
            text.className = referenceText.className;
        } else {
            text.className = 'styles__text__kWlGI';
        }
        text.textContent = 'Bestball';

        // Assemble the button - logo first, then text
        contentDiv.appendChild(logoImg);
        contentDiv.appendChild(text);
        bestballButton.appendChild(contentDiv);
        scrollItem.appendChild(bestballButton);
        scrollContainer.appendChild(scrollItem);

        // Measure width when bold to prevent resize on toggle
        // Need to measure after element is in DOM, so use a small delay or requestAnimationFrame
        requestAnimationFrame(() => {
            // Temporarily make text bold to measure the maximum width
            const originalFontWeight = text.style.fontWeight;
            const originalComputedFontWeight = window.getComputedStyle(text).fontWeight;
            text.style.fontWeight = 'bold';
            
            // Force a reflow to ensure measurement is accurate
            void contentDiv.offsetWidth;
            
            const boldWidth = contentDiv.offsetWidth;
            
            // Restore original font weight
            text.style.fontWeight = originalFontWeight;
            
            // Set the width to the bold width to prevent resizing
            if (boldWidth > 0) {
                contentDiv.style.width = `${boldWidth}px`;
                contentDiv.style.minWidth = `${boldWidth}px`;
            }
        });

        // Add click handler for toggle functionality and filtering
        bestballButton.addEventListener('click', () => {
            const isActive = Array.from(bestballButton.classList).some(cls => cls.startsWith('styles__active__'));
            
            // Find the contest section that contains the scroll items
            // Look for the section that contains contest entry tiles
            const contestSection = document.querySelector('section[class*="styles__contestSection__"]') || 
                                   document.querySelector('section[class*="contestSection"]') ||
                                   document.querySelector('section[class*="styles_contestSection"]');
            
            // Find all scroll items (contest entry tiles)
            // Try multiple selectors to find the items
            let scrollItems = [];
            if (contestSection) {
                scrollItems = Array.from(contestSection.querySelectorAll('div[class*="scrollItem"]'));
            }
            
            // Fallback: if no items found, try finding by contest entry tiles and getting their parent scroll items
            if (scrollItems.length === 0) {
                const contestTiles = document.querySelectorAll('button[class*="contestEntryTile"]');
                if (contestTiles.length > 0) {
                    // Get the parent scroll item for each contest tile
                    contestTiles.forEach(tile => {
                        const scrollItem = tile.closest('div[class*="scrollItem"]');
                        if (scrollItem && !scrollItems.includes(scrollItem)) {
                            scrollItems.push(scrollItem);
                        }
                    });
                }
            }
            
            // If still no items found, just toggle button state
            if (scrollItems.length === 0) {
                if (isActive) {
                    const activeClass = Array.from(bestballButton.classList).find(cls => cls.startsWith('styles__active__'));
                    if (activeClass) {
                        bestballButton.classList.remove(activeClass);
                    }
                } else {
                    const activeClass = Array.from(activeButton.classList).find(cls => cls.startsWith('styles__active__'));
                    if (activeClass) {
                        bestballButton.classList.add(activeClass);
                    } else {
                        bestballButton.classList.add('styles__active__dHHZB');
                    }
                }
                return;
            }

            if (isActive) {
                // Currently active - remove filter (show all items)
                const activeClass = Array.from(bestballButton.classList).find(cls => cls.startsWith('styles__active__'));
                if (activeClass) {
                    bestballButton.classList.remove(activeClass);
                }
                
                // Restore all scroll items to their original display state
                scrollItems.forEach(item => {
                    const originalDisplay = item.getAttribute('data-legup-original-display');
                    if (originalDisplay !== null) {
                        item.style.display = originalDisplay || '';
                        item.removeAttribute('data-legup-original-display');
                    } else {
                        // If no stored state, just show it (remove any inline display:none we might have added)
                        if (item.style.display === 'none' && item.hasAttribute('data-legup-filtered')) {
                            item.style.display = '';
                            item.removeAttribute('data-legup-filtered');
                        }
                    }
                });
            } else {
                // Currently inactive - apply filter (show only Best Ball items)
                const activeClass = Array.from(activeButton.classList).find(cls => cls.startsWith('styles__active__'));
                if (activeClass) {
                    bestballButton.classList.add(activeClass);
                } else {
                    bestballButton.classList.add('styles__active__dHHZB');
                }
                
                // Filter scroll items to show only those with Best Ball badge
                scrollItems.forEach(item => {
                    // Check if this item has a Best Ball badge
                    // Try multiple methods to find the Best Ball badge
                    let bestBallBadge = null;
                    
                    // Method 1: Look for badge with title="Best Ball"
                    bestBallBadge = item.querySelector('div[title="Best Ball"]');
                    
                    // Method 2: Look for class containing "bestBall" (case insensitive)
                    if (!bestBallBadge) {
                        const allDivs = item.querySelectorAll('div');
                        for (const div of allDivs) {
                            const classes = Array.from(div.classList);
                            if (classes.some(cls => cls.toLowerCase().includes('bestball') || cls.toLowerCase().includes('best-ball'))) {
                                bestBallBadge = div;
                                break;
                            }
                        }
                    }
                    
                    // Method 3: Check all badges for "Best Ball" text or title
                    if (!bestBallBadge) {
                        const badges = item.querySelectorAll('div[data-testid="badge"]');
                        for (const badge of badges) {
                            const title = badge.getAttribute('title');
                            const text = badge.textContent.trim();
                            if (title === 'Best Ball' || text === 'Best Ball' || 
                                title?.toLowerCase().includes('best ball') || 
                                text.toLowerCase().includes('best ball')) {
                                bestBallBadge = badge;
                                break;
                            }
                        }
                    }
                    
                    // Method 4: Search all elements for "Best Ball" text within the item
                    if (!bestBallBadge) {
                        const allElements = item.querySelectorAll('*');
                        for (const elem of allElements) {
                            const text = elem.textContent.trim();
                            if (text === 'Best Ball' || (text.toLowerCase().includes('best') && text.toLowerCase().includes('ball'))) {
                                // Check if it's a badge-like element
                                const classes = Array.from(elem.classList);
                                if (classes.some(cls => cls.includes('badge') || cls.includes('Badge'))) {
                                    bestBallBadge = elem;
                                    break;
                                }
                            }
                        }
                    }
                    
                    // Store original display state if not already stored
                    if (!item.hasAttribute('data-legup-original-display')) {
                        const computedDisplay = window.getComputedStyle(item).display;
                        item.setAttribute('data-legup-original-display', computedDisplay);
                    }
                    
                    // Hide items without Best Ball badge
                    if (!bestBallBadge) {
                        item.style.display = 'none';
                        item.setAttribute('data-legup-filtered', 'true');
                    } else {
                        // Ensure Best Ball items are visible
                        item.style.display = '';
                        item.removeAttribute('data-legup-filtered');
                    }
                });
            }
        });

    } catch (err) {
        console.error('[UD] handle_underdog_bestball_button failed', err);
    }
}

function escapeHtmlForUdBubbleFragment(s) {
    return String(s)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

function buildUdFatalExtractionUrgentHtmlMessage(detected_keys) {
    const keys = Array.isArray(detected_keys) ? detected_keys : [];
    if (keys.length === 0) {
        return UD_FATAL_EXTRACTION_ERROR_WARNING_MESSAGE + '<br>';
    }
    const lines = keys.map(escapeHtmlForUdBubbleFragment);
    return UD_FATAL_EXTRACTION_ERROR_WARNING_MESSAGE + '<br><br>' + lines.join('<br>') + '<br>';
}

function normalizeUdXhrAutoReplayState(fsm, draft_id) {
    const st = fsm.state_data.ud_xhr_auto_replay;
    if (!st || st.draft_id !== draft_id) {
        fsm.state_data.ud_xhr_auto_replay = {
            draft_id: draft_id,
            phase: null,
            spent: false
        };
    }
}


function maybeHandleUdXhrAutoReplayGate(fsm, draft_id) {
    if (fsm.state_data?.static_settings?.ud_intercept_extraction_enabled !== true) {
        return false;
    }
    normalizeUdXhrAutoReplayState(fsm, draft_id);
    const st = fsm.state_data.ud_xhr_auto_replay;

    if (fsm.user_settings?.ud_xhr_replay_disabled) {
        if (st.phase === 'await_replay' || st.phase === 'post_replay') {
            if (st.phase === 'await_replay') {
                st.spent = true;
            }
            st.phase = null;
        }
        return false;
    }

    if (st.phase === 'await_replay') {
        if (fsm.bg_port && fsm.bg_connected) {
            fsm.send_port_request('DISPATCH_UD_DRAFT_XHR_REPLAY', { draft_id: draft_id }).catch(() => {});
        }
        st.phase = 'post_replay';
        st.spent = true;
        return true;
    }

    if (st.phase === 'post_replay') {
        st.phase = null;
        return false;
    }

    return false;
}


function scheduleUdAutoXhrReplayOrContinue(fsm, draft_id) {
    if (fsm.state_data?.static_settings?.ud_intercept_extraction_enabled !== true) {
        return false;
    }
    if (fsm.user_settings?.ud_xhr_replay_disabled) {
        return false;
    }
    normalizeUdXhrAutoReplayState(fsm, draft_id);
    const st = fsm.state_data.ud_xhr_auto_replay;
    if (st.spent) {
        return false;
    }
    st.phase = 'await_replay';
    return true;
}

function hasUdInterceptBucketForDraft(fsm, draft_id) {
    if (!draft_id || !fsm.state_data || !fsm.state_data.ud_intercepted_drafts) {
        return false;
    }
    const wrap = fsm.state_data.ud_intercepted_drafts[String(draft_id)];
    const d = wrap && wrap.draft;
    return !!(d && d.id != null && String(d.id) === String(draft_id));
}

/**
 * Single-tab intercept path rejects XHR when history.pathname lags the SPA; the prior draft's
 * bucket can remain while the URL already points at a new draft. Drop stale entries so
 * extraction treats intercept as missing and uses ribbon + players_by_legacy_lookup.
 */
function pruneUdInterceptStaleEntriesForUrlDraft(fsm, urlDraftId) {
    if (!fsm || !fsm.state_data) {
        return;
    }
    if (fsm.state_data?.static_settings?.ud_intercept_extraction_enabled !== true) {
        return;
    }
    if (urlDraftId == null || urlDraftId === '') {
        return;
    }
    const want = String(urlDraftId);
    const drafts = fsm.state_data.ud_intercepted_drafts;
    if (!drafts || typeof drafts !== 'object') {
        return;
    }
    const keys = Object.keys(drafts);
    if (keys.length === 0) {
        return;
    }
    const wrap = drafts[want];
    const d = wrap && wrap.draft;
    const hasValidBucket =
        d && typeof d === 'object' && d.id != null && String(d.id) === want;
    if (hasValidBucket) {
        if (keys.length > 1) {
            fsm.state_data.ud_intercepted_drafts = { [want]: wrap };
            const rev = fsm.state_data.ud_intercept_revision_by_draft || {};
            const nextRev = {};
            if (Object.prototype.hasOwnProperty.call(rev, want)) {
                nextRev[want] = rev[want];
            }
            fsm.state_data.ud_intercept_revision_by_draft = nextRev;
            const touched = fsm.state_data.ud_intercept_touched_at_ms || {};
            const nextTouched = {};
            if (Object.prototype.hasOwnProperty.call(touched, want)) {
                nextTouched[want] = touched[want];
            }
            fsm.state_data.ud_intercept_touched_at_ms = nextTouched;
        }
        return;
    }
    fsm.state_data.ud_intercepted_drafts = {};
    fsm.state_data.ud_intercept_revision_by_draft = {};
    fsm.state_data.ud_intercept_touched_at_ms = {};
}

function hasUdActiveMinimalDraftDom() {
    const desktop_section = document.querySelector('[class^="styles__draftDetailsSectionDesktop__"]');
    if (!desktop_section) {
        return false;
    }
    return desktop_section.querySelectorAll('[class*="styles__draftingCell__"]').length > 0;
}

/**
 * Underdog /active/{id} only: after SPA URL change, wait until intercept + minimal DOM align or cap time.
 * @returns {boolean} true if extraction may proceed; false to skip this tick (return undefined from extract).
 */
function updateUdActiveNavigationSettle(fsm, url, draft_id) {
    if (typeof is_active_url !== 'function' || !is_active_url(url)) {
        return true;
    }
    const sd = fsm.state_data;
    if (!sd) {
        return true;
    }

    const prev = sd.ud_active_nav_track_id;
    const now = Date.now();

    if (prev !== draft_id) {
        sd.ud_active_nav_track_id = draft_id;
        sd.ud_active_nav_changed_at = now;
        if (prev != null && draft_id != null) {
            sd.ud_active_nav_generation = (sd.ud_active_nav_generation || 0) + 1;
            sd.ud_active_nav_pending_log_complete = true;
        }
        sd.ud_active_nav_stable_ticks = 1;
    } else {
        sd.ud_active_nav_stable_ticks = (sd.ud_active_nav_stable_ticks || 0) + 1;
    }

    const changedAt = sd.ud_active_nav_changed_at;
    const elapsed = changedAt != null ? now - changedAt : 0;
    const cap = changedAt != null && elapsed >= UD_ACTIVE_NAV_SETTLE_MAX_MS;
    const streakOk = (sd.ud_active_nav_stable_ticks || 0) >= UD_ACTIVE_NAV_STABLE_TICKS_NEEDED;
    const interceptOk = hasUdInterceptBucketForDraft(fsm, draft_id);
    const domOk = hasUdActiveMinimalDraftDom();
    const settled = cap || (streakOk && interceptOk && domOk);

    if (settled && sd.ud_active_nav_pending_log_complete) {
        sd.ud_active_nav_pending_log_complete = false;
    }

    return settled;
}

function udRibbonCellHasUserCellClass(cell) {
    return [...cell.classList].some((c) => c.startsWith('styles__userCell__'));
}

const UD_SITE_USERNAME_SYNC_INTERVAL_MS = 30 * 1000;
let _lastUdSiteUsernameSyncAt = 0;

function extract_ud_username_from_draft_ribbon() {
    const desktop_section = document.querySelector('[class^="styles__draftDetailsSectionDesktop__"]');
    if (!desktop_section) {
        return null;
    }
    const drafting_cells = desktop_section.querySelectorAll('[class*="styles__draftingCell__"]');
    if (!drafting_cells.length) {
        return null;
    }
    for (let i = 0; i < drafting_cells.length; i++) {
        const cell = drafting_cells[i];
        if (!udRibbonCellHasUserCellClass(cell)) {
            continue;
        }
        const username_element = cell.querySelector('[class^="styles__username__"]');
        const username = username_element ? username_element.textContent.trim() : '';
        if (username && username !== 'Unknown User') {
            return username;
        }
    }
    return null;
}

function maybe_sync_ud_site_username(fsm) {
    if (!fsm) {
        return;
    }
    const now = Date.now();
    if (now - _lastUdSiteUsernameSyncAt < UD_SITE_USERNAME_SYNC_INTERVAL_MS) {
        return;
    }
    _lastUdSiteUsernameSyncAt = now;
    const username = extract_ud_username_from_draft_ribbon();
    if (!username) {
        return;
    }
    sendFantasySiteUsernameToBackground(fsm, 'underdog', username);
}

/**
 * Infer lobby size (N) from the draft ribbon in snake order: the user's first pick is overall pick
 * `pick_slot`, and their second pick is overall pick `2N - pick_slot + 1`. Uses only styles__userCell__.
 */
function computeUdDraftSizeFromRibbonDom(drafting_cells, pick_slot) {
    if (!drafting_cells || drafting_cells.length === 0 || pick_slot == null || pick_slot < 1) {
        return null;
    }
    const cells = Array.from(drafting_cells);
    const userCellIndices0 = [];
    for (let i = 0; i < cells.length; i++) {
        if (udRibbonCellHasUserCellClass(cells[i])) {
            userCellIndices0.push(i);
        }
    }
    if (userCellIndices0.length < 2) {
        return null;
    }
    const indices = userCellIndices0;
    if (indices[0] !== pick_slot - 1) {
        return null;
    }
    const secondOverall1Based = indices[1] + 1;
    const num = secondOverall1Based + pick_slot - 1;
    if (num % 2 !== 0) {
        return null;
    }
    const n = num / 2;
    if (!Number.isFinite(n) || n < 2 || n > 512) {
        return null;
    }
    return n;
}

async function extract_underdog_draft_data(fsm, url) {
    if (!fsm || !fsm.state_data) {
        return;
    }
    
    if (!fsm.datasets || !fsm.datasets.player_map_ud) {
        return;
    }

    handle_ud_sheet_overlay(fsm, url);
    
    const draft_id = get_underdog_draft_id_from_url(url);
    
    if (!draft_id) {
        return;
    }

    if (typeof is_active_url === 'function' && !is_active_url(url) && fsm.state_data) {
        const sd = fsm.state_data;
        sd.ud_active_nav_track_id = null;
        sd.ud_active_nav_changed_at = null;
        sd.ud_active_nav_stable_ticks = 0;
        sd.ud_active_nav_pending_log_complete = false;
    }

    if (typeof is_active_url === 'function' && is_active_url(url)) {
        if (!updateUdActiveNavigationSettle(fsm, url, draft_id)) {
            return;
        }
    }
    
    // Lightweight extraction gate: Check draft status span before full extraction
    // This runs before tournament summary check so unsupported contests can still get OTC indicator
    const draft_status_span = document.querySelector('[class*="styles__columnTitle__"] [class*="styles__title__"] span');
    const current_status_text = draft_status_span ? draft_status_span.textContent.trim() : null;
    const last_status_text = fsm.state_data.last_draft_status_span_text;
    
    // Check if user is on the clock (for back-to-back picks, span text doesn't change)
    const on_the_clock_element = document.querySelector('[class*="styles__currentUser__"][class*="styles__onTheClock__"]');
    const is_on_the_clock = !!on_the_clock_element;
    
    // If span is missing, revert to full extraction mode
    const span_missing = !draft_status_span;
    
    // If user is on the clock, always do full extraction (span text doesn't change between back-to-back picks)
    // This mimics the behavior when draft board is open (span disappears, triggers full extraction)
    if (is_on_the_clock) {
        // User is on the clock - skip lightweight gate and do full extraction
        // Update cached status text but don't use it for gate check
        fsm.state_data.last_draft_status_span_text = current_status_text;
    } else if (!span_missing && current_status_text === last_status_text && fsm.state_data.last_extraction_result) {
        // User is NOT on the clock and status text hasn't changed - skip full extraction
        // Return cached result only when it matches the draft id in the URL (SPA can reuse span text across drafts)
        const cached = fsm.state_data.last_extraction_result;
        const cached_id = cached?.draft?.draft_id;
        if (cached_id == null || String(cached_id) !== String(draft_id)) {
            // Fall through to full extraction
        } else {
            const ud_intercept_extraction_enabled =
                fsm.state_data?.static_settings?.ud_intercept_extraction_enabled === true;
            if (!ud_intercept_extraction_enabled) {
                fsm.clear_warning_notification(UD_LEGACY_FALLBACK_WARNING_SOURCE);
            }
            return cached;
        }
    }
    
    // Update cached status text
    fsm.state_data.last_draft_status_span_text = current_status_text;
    
    // console.log(`[CS Tournament] extract_underdog_draft_data: Starting extraction for draft_id=${draft_id}`);
    
    const tournament_summary = await get_tournament_summary_from_background(draft_id);
    if (!tournament_summary) {
        return;
    }
    if (!tournament_summary.supported) {
        const unsupportedSlateIds = Array.isArray(tournament_summary.slate_ids) ? tournament_summary.slate_ids : [];
        fsm.state_data.unsupported_contest = {
            draft_id,
            reason: tournament_summary.reason || null
        };
        if (fsm.overlay_manager?.update_top_bar_from_state) {
            fsm.overlay_manager.update_top_bar_from_state({});
        }
        // Still best-effort OTC (green border + sound) via DOM / intercept — no rankings needed
        if (typeof fsm._check_underdog_otc_best_effort === 'function') {
            fsm._check_underdog_otc_best_effort(draft_id);
        }
        return;
    }

    const was_unsupported = !!fsm.state_data.unsupported_contest;
    fsm.state_data.unsupported_contest = null;
    if (was_unsupported && fsm.overlay_manager?.update_top_bar_from_state) {
        fsm.overlay_manager.update_top_bar_from_state({});
    }
    
    const tournament_id = tournament_summary.tournament_id || 'unknown';
    const tournament_title = tournament_summary.title || 'Unknown';
    // console.log(`[CS Tournament] Tournament summary loaded: draft_id=${draft_id}, tournament_id=${tournament_id}, title="${tournament_title}"`);
    
    let advancement_structure = tournament_summary.advancement_structure || null;
    const payout_structure = tournament_summary.payout_structure || {};
    const entry_fee = tournament_summary.entry_fee || null;
    const tournament_description = tournament_summary.description || null;
    const contest_style_name = tournament_summary.contest_style_name || null;
    
    // Create tournament_info object
    const tournament_info = {
        "id": tournament_id,
        "title": tournament_title,
        "description": tournament_description,
        "contest_style_name": contest_style_name,
        "is_marathon": tournament_summary.is_marathon === true,
        "slate_key": typeof tournament_summary.slate_key === 'string' && tournament_summary.slate_key ? tournament_summary.slate_key : null,
        "advancement_structure": advancement_structure,
        "payout_structure": payout_structure,
        "entry_fee": entry_fee
    };
    
    // console.log(`Tournament: "${tournament_title}"`, `Sport: NFL`, `Advancement: ${advancement_structure?.raw_string || 'N/A'}`);
    
    const desktop_section = document.querySelector('[class^="styles__draftDetailsSectionDesktop__"]');
    
    if (!desktop_section) {
        // console.log("Draft details section not found");
        return;
    }
    
    const drafting_cells = desktop_section.querySelectorAll('[class*="styles__draftingCell__"]');
    
    if (drafting_cells.length === 0) {
        return;
    }

    maybe_sync_ud_site_username(fsm);
    
    // Check if draft has started (look for "fake" bars that appear when waiting)
    const has_fake_bar = Array.from(drafting_cells).some(cell => 
        cell.querySelector('[class*="styles__fakeBar__"]')
    );
    
    const draft_started = !has_fake_bar;
    
    // Check debug flag to skip lobby check
    const skip_lobby_check = fsm?.state_data?.skip_lobby_check_debug || false;
    
    if (!draft_started && !skip_lobby_check) {
        return;
    }
    
    // If in lobby and debug flag is enabled, create spoofed draft request
    if (!draft_started && skip_lobby_check) {
        
        const draft_size = tournament_summary.draft_size || null;
        const num_rounds = tournament_summary.contest_rounds || null;
        
        if (!draft_size || !num_rounds) {
            console.error('Missing draft_size or num_rounds from tournament summary', draft_size, num_rounds);
            return;
        }
        
        // Create spoofed draft with empty picks and pick_slot 1
        const draft = {
            draft_id: draft_id,
            custom_title: null,
            site_name: 'Underdog',
            draft_size: draft_size,
            num_rounds: num_rounds,
            pick_slot: 1,
            picks: []
        };
        
        return {
            draft: draft,
            advancement_structure: advancement_structure,
            tournament_info: tournament_info
        };
    }
    
    // console.log('Draft has started');
    
    let pick_slot = null;
    drafting_cells.forEach((cell, index) => {
        const is_user_cell = [...cell.classList].some(c => c.startsWith('styles__userCell__'));
        if (!pick_slot && is_user_cell) {
            pick_slot = index + 1;
        }
    });
    
    if (pick_slot === null) {
        console.error('Unable to determine user pick slot');
        return;
    }

    const regex_draft_size = tournament_summary.draft_size != null ? tournament_summary.draft_size : null;
    const dom_draft_size = computeUdDraftSizeFromRibbonDom(drafting_cells, pick_slot);
    let draft_size = regex_draft_size;
    let agreement = 'neither';
    if (dom_draft_size != null && regex_draft_size != null) {
        agreement = dom_draft_size === regex_draft_size ? 'match' : 'mismatch';
    } else if (dom_draft_size != null) {
        agreement = 'dom_only';
    } else if (regex_draft_size != null) {
        agreement = 'regex_only';
    }
    if (dom_draft_size != null) {
        draft_size = dom_draft_size;
        if (advancement_structure && typeof advancement_structure === 'object') {
            advancement_structure = { ...advancement_structure, regular_season_denom: dom_draft_size };
            tournament_info.advancement_structure = advancement_structure;
        }
    }

    if (tournament_summary.ud_no_tournament_endpoint && draft_size) {
        const nCells = drafting_cells.length;
        const ds = Number(draft_size);
        if (Number.isFinite(ds) && ds > 0 && nCells > 0 && nCells % ds === 0) {
            const ribbon_rounds = nCells / ds;
            tournament_summary.contest_rounds = ribbon_rounds;
        }
    }

    if (maybeHandleUdXhrAutoReplayGate(fsm, draft_id)) {
        return;
    }

    pruneUdInterceptStaleEntriesForUrlDraft(fsm, draft_id);

    const drafts = fsm.state_data.ud_intercepted_drafts || {};
    const intercept = drafts[String(draft_id)];
    let draft_obj = intercept && intercept.draft;
    if (draft_obj && draft_obj.id && draft_obj.id !== draft_id) {
        draft_obj = null;
    }

    const player_map_dataset = fsm.datasets?.player_map_ud;

    if (!player_map_dataset || player_map_dataset === null) {
        const error_msg = 'player_map_ud dataset is null or not loaded yet - cannot extract player IDs';
        console.error(error_msg);
        throw new Error(error_msg);
    }

    const player_map = resolveUdAppearanceIdMapForDraftExtraction(fsm, tournament_summary);
    if (!player_map || typeof player_map !== 'object' || Object.keys(player_map).length === 0) {
        const error_msg =
            'No Underdog appearance id map: need datasets[appearance_id_map_dataset_key].map for this slate (object-form underdog_slate_whitelist), else legacy_appearance_id_map.map, or legacy player_map_ud.players when no *_appearance_id_map datasets are configured';
        console.error(error_msg, {
            appearance_id_map_dataset_key: tournament_summary && tournament_summary.appearance_id_map_dataset_key
        });
        throw new Error(error_msg);
    }

    const legacy_map = player_map_dataset.players_by_legacy_lookup || {};
    const legacy_keys = Object.keys(legacy_map);
    const raw_fatal_ribbon_keys = player_map_dataset.legacy_lookup_fatal_if_ribbon_keys;
    const fatal_ribbon_key_set =
        Array.isArray(raw_fatal_ribbon_keys) && raw_fatal_ribbon_keys.length > 0 ? new Set(raw_fatal_ribbon_keys) : null;
    const ribbon_fatal_legacy_keys_detected = {};

    const ud_use_intercept_extraction =
        fsm.state_data?.static_settings?.ud_intercept_extraction_enabled === true;
    const has_trusted_intercept_snapshot =
        ud_use_intercept_extraction &&
        draft_obj &&
        draft_obj.id &&
        Array.isArray(draft_obj.picks);
    const usable = has_trusted_intercept_snapshot && udInterceptPicksUsableForIdResolution(draft_obj);
    let draft_picks = null;
    let usedRibbonForPicks = false;
    let intercept_failed_appearance_ids = null;

    if (usable) {
        const api_picks = draft_obj.picks;
        const failed_lookups = [];
        const from_api = [];

        for (let i = 0; i < api_picks.length; i++) {
            const p = api_picks[i];
            if (p == null) {
                continue;
            }
            if (typeof p === 'object' && Object.keys(p).length === 0) {
                continue;
            }
            const ud = resolveUdPlayerIdFromApiPick(p, player_map);
            if (ud) {
                from_api.push({ ud_id: ud });
            } else {
                failed_lookups.push({ index: i, pick: p });
            }
        }

        if (failed_lookups.length === 0) {
            draft_picks = from_api;
            const ribbon_pick_count = countUdRibbonFilledPickSlots(drafting_cells);
            const intercept_pick_count = countUdInterceptPicksWithAppearance(api_picks);
            const ribbon_cell_indices_1based = getUdRibbonFilledPickSlotNumbers1Based(drafting_cells);
            const intercept_pick_number_log = getUdInterceptAppearancePickNumberLog(api_picks);
            const pickCountSanityLog = {
                draft_id,
                ribbon_filled_cell_indices_1based: ribbon_cell_indices_1based,
                ribbon_pick_count,
                intercept_appearance_picks: intercept_pick_number_log,
                intercept_pick_count,
                resolved_from_api_length: from_api.length
            };
            // console.debug('[UD] pick count sanity (pick numbers)', pickCountSanityLog);
            if (ribbon_pick_count !== intercept_pick_count) {
                const detail = {
                    draft_id,
                    ribbon_pick_count,
                    intercept_pick_count,
                    ribbon_filled_cell_indices_1based: ribbon_cell_indices_1based,
                    intercept_appearance_picks: intercept_pick_number_log,
                    ud_intercept_revision:
                        (fsm.state_data.ud_intercept_revision_by_draft &&
                            fsm.state_data.ud_intercept_revision_by_draft[String(draft_id)]) ||
                        0
                };
                fsm.state_data.ud_pick_count_sanity_last = {
                    ...detail,
                    mismatch_at: Date.now(),
                    used_ribbon_fallback: false
                };
                // Any DOM vs intercept count mismatch: try one auto XHR replay for a fresh snapshot before ribbon fallback.
                if (scheduleUdAutoXhrReplayOrContinue(fsm, draft_id)) {
                    return;
                }
                if (ribbon_pick_count > intercept_pick_count && legacy_keys.length > 0) {
                    const ribbon_rows = extractUdRibbonPickRowsFromDom(drafting_cells);
                    const ribbon_result = resolveUdIdsFromRibbonPicks(ribbon_rows, legacy_map, fsm, fatal_ribbon_key_set);
                    if (ribbon_result.ok) {
                        draft_picks = ribbon_result.draft_picks;
                        usedRibbonForPicks = true;
                        const hit = ribbon_result.fatal_legacy_keys_hit;
                        if (hit && hit.length) {
                            for (let hi = 0; hi < hit.length; hi++) {
                                ribbon_fatal_legacy_keys_detected[hit[hi]] = true;
                            }
                        }
                        fsm.state_data.ud_pick_count_sanity_last.used_ribbon_fallback = true;
                    } else {
                        console.error('[UD] pick count sanity: intercept short vs ribbon but ribbon ID resolution failed — data may be wrong', ribbon_result.error_msg);
                    }
                } else if (ribbon_pick_count > intercept_pick_count) {
                    console.error('[UD] pick count sanity: intercept has fewer picks than ribbon; no players_by_legacy_lookup — cannot ribbon fallback; picks may be misattributed', detail);
                } else {
                }
            }
        } else {
            intercept_failed_appearance_ids = failed_lookups
                .map((f) => (f && f.pick ? f.pick.appearance_id || f.pick.appearanceId : null))
                .filter((x) => x != null && x !== '')
                .map((x) => String(x));
            const error_details = failed_lookups
                .map((f) => `index ${f.index} appearance_id=${f.pick && f.pick.appearance_id}`)
                .join(', ');
            if (fsm.bg_port) {
                fsm.send_port_request('REQUEST_CONFIG_REFRESH_PLAYER_MAP').catch(() => {});
            }
        }
    }

    // status_change / early live draft: picks [] or placeholders without appearance_id is normal.
    // Do not fall back to ribbon+legacy when the ribbon also has no filled slots yet.
    if (
        draft_picks === null &&
        has_trusted_intercept_snapshot &&
        !usable &&
        countUdRibbonFilledPickSlots(drafting_cells) === 0
    ) {
        draft_picks = [];
    }

    if (draft_picks === null && legacy_keys.length > 0) {
        // No bucket → replay cannot refresh anything useful this tick; go straight to ribbon legacy.
        if (
            hasUdInterceptBucketForDraft(fsm, draft_id) &&
            scheduleUdAutoXhrReplayOrContinue(fsm, draft_id)
        ) {
            return;
        }
        const ribbon_rows = extractUdRibbonPickRowsFromDom(drafting_cells);
        const ribbon_result = resolveUdIdsFromRibbonPicks(ribbon_rows, legacy_map, fsm, fatal_ribbon_key_set);
        if (ribbon_result.ok) {
            draft_picks = ribbon_result.draft_picks;
            usedRibbonForPicks = true;
            const hit = ribbon_result.fatal_legacy_keys_hit;
            if (hit && hit.length) {
                for (let hi = 0; hi < hit.length; hi++) {
                    ribbon_fatal_legacy_keys_detected[hit[hi]] = true;
                }
            }
            if (!ud_use_intercept_extraction) {
            } else if (!usable) {
            } else {
            }
        } else if (usable) {
            throw new Error(ribbon_result.error_msg);
        } else {
            if (
                hasUdInterceptBucketForDraft(fsm, draft_id) &&
                scheduleUdAutoXhrReplayOrContinue(fsm, draft_id)
            ) {
                return;
            }
            return;
        }
    }

    if (draft_picks === null) {
        if (!usable) {
            if (!ud_use_intercept_extraction) {
                const legacyRaw = player_map_dataset.players_by_legacy_lookup;
                const legacyOnlyRibbonLog = {
                    players_by_legacy_lookup: legacyRaw,
                    legacy_entry_count: legacy_keys.length,
                    appearance_player_entry_count: player_map ? Object.keys(player_map).length : 0
                };
            } else {
                const legacyRaw = player_map_dataset.players_by_legacy_lookup;
                const noInterceptSnapshotLog = {
                    players_by_legacy_lookup: legacyRaw,
                    legacy_entry_count: legacy_keys.length,
                    appearance_player_entry_count: player_map ? Object.keys(player_map).length : 0
                };
            }
            if (
                hasUdInterceptBucketForDraft(fsm, draft_id) &&
                scheduleUdAutoXhrReplayOrContinue(fsm, draft_id)
            ) {
                return;
            }
            return;
        }
        const error_msg =
            'Intercept picks had appearance_ids but resolution failed and players_by_legacy_lookup is empty (cannot use ribbon fallback)';
        console.error(error_msg);
        throw new Error(error_msg);
    }
    
    const num_rounds = tournament_summary.contest_rounds || null;
    
    if (!draft_size || !num_rounds) {
        console.error('Missing draft_size or num_rounds from tournament summary', draft_size, num_rounds);
        return;
    }
    
    const draft = {
        draft_id: draft_id,
        custom_title: null,
        site_name: 'Underdog',
        draft_size: draft_size,
        num_rounds: num_rounds,
        pick_slot: pick_slot,
        picks: draft_picks
    };
    
    const result = {
        draft: draft,
        advancement_structure: advancement_structure,
        tournament_info: tournament_info
    };

    if (ud_use_intercept_extraction) {
        if (usedRibbonForPicks) {
            fsm.set_warning_notification(UD_LEGACY_EXTRACTION_WARNING_MESSAGE, UD_LEGACY_FALLBACK_WARNING_SOURCE, {
                kind: 'page_refresh'
            });
        } else {
            fsm.clear_warning_notification(UD_LEGACY_FALLBACK_WARNING_SOURCE);
        }
    } else {
        fsm.clear_warning_notification(UD_LEGACY_FALLBACK_WARNING_SOURCE);
    }

    if (typeof UD_FATAL_EXTRACTION_ERROR_WARNING_MESSAGE !== 'undefined' && typeof UD_FATAL_EXTRACTION_ERROR_WARNING_SOURCE !== 'undefined') {
        const fatal_keys_sorted = Object.keys(ribbon_fatal_legacy_keys_detected).sort();
        if (usedRibbonForPicks && fatal_keys_sorted.length > 0) {
            fsm.set_urgent_warning_notification(buildUdFatalExtractionUrgentHtmlMessage(fatal_keys_sorted), UD_FATAL_EXTRACTION_ERROR_WARNING_SOURCE, {
                kind: 'page_refresh'
            });
        } else {
            fsm.clear_urgent_warning_notification(UD_FATAL_EXTRACTION_ERROR_WARNING_SOURCE);
        }
    }
    
    // Cache result for lightweight gate
    fsm.state_data.last_extraction_result = result;
    
    return result;
}

/**
 * Underdog active draft: roster vs queue share one column; find the Queue tab control.
 * Prefer columnToggleButton (current app); fall back to columnTitleTabs (older layout).
 */
function find_underdog_active_queue_toggle_button() {
    const fromToggle = Array.from(
        document.querySelectorAll('button[class^="styles__columnToggleButton__"]')
    ).find((button) => {
        const buttonText = button.querySelector('h2')?.textContent.trim().toLowerCase();
        return buttonText === 'queue';
    });
    if (fromToggle) {
        return fromToggle;
    }
    return Array.from(document.querySelectorAll('div[class*="styles__columnTitleTabs__"] > button')).find((button) => {
        const buttonText = button.querySelector('h2')?.textContent.trim();
        return buttonText === 'Queue';
    });
}

/** Parsed count from Queue tab badge, or 0 if empty; null if tab not found (wrong page / DOM). */
function get_underdog_active_dom_queue_count() {
    if (!is_active_url(window.location.href)) {
        return null;
    }
    const queueButton = find_underdog_active_queue_toggle_button();
    if (!queueButton) {
        return null;
    }
    const queueSizeElement = queueButton.querySelector(
        'div[class^="styles__counterBubble__"][class*="queueCounter"]'
    );
    if (!queueSizeElement) {
        return 0;
    }
    return parseInt(queueSizeElement.textContent.trim(), 10) || 0;
}

function observe_underdog_queue_size_changes(fsm) {
    if (!fsm || !fsm.state_data) {
        return;
    }

    const url = window.location.href;
    if (!is_active_url(url)) {
        // Only observe queue size changes on active pages
        // Disconnect observer if we're no longer on an active page
        if (fsm.state_data.queue_size_observer) {
            fsm.state_data.queue_size_observer.disconnect();
            fsm.state_data.queue_size_observer = null;
        }
        // Re-entering active draft should run init + DOM vs tracked mismatch again (navigation may clear players[]).
        fsm.state_data.last_queue_size = null;
        return;
    }

    const queueButton = find_underdog_active_queue_toggle_button();

    if (!queueButton) {
        // Queue button not found, disconnect existing observer if any
        if (fsm.state_data.queue_size_observer) {
            fsm.state_data.queue_size_observer.disconnect();
            fsm.state_data.queue_size_observer = null;
        }
        return;
    }

    // Select the queue size element inside the "Queue" button
    const queueSizeElement = queueButton.querySelector(
        'div[class^="styles__counterBubble__"][class*="queueCounter"]'
    );

    if (!queueSizeElement) {
        // console.info('[Underdog Queue] queue counter bubble not found under Queue tab (empty queue or class names changed); cannot observe size');
        // Queue size element not found (queue is empty)
        // Always set last_queue_size to 0 when element doesn't exist
        fsm.state_data.last_queue_size = 0;
        // Disconnect existing observer if any
        if (fsm.state_data.queue_size_observer) {
            fsm.state_data.queue_size_observer.disconnect();
            fsm.state_data.queue_size_observer = null;
        }
        return;
    }

    // Get current queue size
    const currentQueueSize = parseInt(queueSizeElement.textContent.trim(), 10) || 0;
    const previousQueueSize = fsm.state_data.last_queue_size !== null ? fsm.state_data.last_queue_size : 0;
    
    const trackedLen = Array.isArray(fsm.state_data.queue?.players) ? fsm.state_data.queue.players.length : 0;
    const domTrackedMismatch = currentQueueSize !== trackedLen;

    // Check if this is the first time we see the element (was null) or if size changed
    if (fsm.state_data.last_queue_size === null) {
        const tabSelected = queueButton.classList.contains('styles__selected__');
        // Initialize on first run or when element is first found
        fsm.state_data.last_queue_size = currentQueueSize;
        // Reload / Roster tab: DOM badge matches site queue, but our players[] may be empty or stale.
        // Only auto-open when badge count disagrees with tracked length (avoids yanking users off Roster when already in sync).
        if (!tabSelected && domTrackedMismatch) {
            queueButton.click();
            fsm.state_data.queue_size_changed = true;
        }
    } else if (currentQueueSize !== previousQueueSize) {
        // Queue size changed - this handles the 0->1 transition when element appears
        fsm.state_data.last_queue_size = currentQueueSize;
        fsm.state_data.queue_size_changed = true;
        
        // Trigger the Queue button click only when size changes
        if (!queueButton.classList.contains('styles__selected__')) {
            queueButton.click();
        } else {
        }
    }

    // If observer already exists and is observing the same element, don't recreate it
    if (fsm.state_data.queue_size_observer) {
        // Check if we're already observing this element
        const observedTarget = fsm.state_data.queue_size_observer._observedTarget;
        if (observedTarget === queueSizeElement) {
            // Observer already exists for this element
            // We've already checked for size changes above, so we can return
            return; // Already observing this element
        }
        // Disconnect old observer if observing different element
        fsm.state_data.queue_size_observer.disconnect();
    }

    const config = {
        childList: true,
        subtree: true,
        characterData: true,
    };

    const callback = (mutationsList) => {
        for (const mutation of mutationsList) {
            if (mutation.type === 'childList' || mutation.type === 'characterData') {
                // Extract the new queue size from the element
                const newQueueSize = parseInt(queueSizeElement.textContent.trim(), 10) || 0;
                const previousQueueSize = fsm.state_data.last_queue_size || 0;
                
                // Only act if the queue size actually changed
                if (newQueueSize !== previousQueueSize) {
                    fsm.state_data.last_queue_size = newQueueSize;
                    fsm.state_data.queue_size_changed = true;

                    // Trigger the Queue button click only when size changes
                    const alreadySelected = queueButton.classList.contains('styles__selected__');
                    if (!alreadySelected) {
                        queueButton.click();
                    } else {
                    }
                }
            }
        }
    };

    fsm.state_data.queue_size_observer = new MutationObserver(callback);
    fsm.state_data.queue_size_observer._observedTarget = queueSizeElement; // Store reference for comparison
    fsm.state_data.queue_size_observer.observe(queueSizeElement, config);
}

function observe_underdog_queue(fsm) {
    if (!fsm || !fsm.state_data) {
        return;
    }

    const url = window.location.href;
    if (!is_underdog_url(url)) {
        return;
    }

    // Check if draft board is open - if so, skip queue update to preserve existing state
    const draft_board = document.querySelector('div[class^="styles__draftBoardWrapper__"]');
    if (draft_board) {
        return;
    }

    // Find queue list wrapper - different selectors for draft vs active pages
    let queue_list_wrapper = null;
    if (is_underdog_draft_url(url)) {
        queue_list_wrapper = document.querySelector('[class^="styles__queueListWrapper"]');
    } else if (is_active_url(url)) {
        queue_list_wrapper = document.querySelector('[class*="queueRosterWrapper"]');
        
        // For active pages, check if Queue button is selected
        const queue_button = find_underdog_active_queue_toggle_button();

        if (!queue_button || !queue_button.className.includes('styles__selected__')) {
            return;
        }
    }

    let queue_players = [];
    let queue_detected = false;

    if (queue_list_wrapper) {
        queue_detected = true; // Queue wrapper exists, so queue is detected (even if empty)
        
        if (is_underdog_draft_url(url)) {
            // Draft page: look for both cell and card players
            const cell_players = queue_list_wrapper.querySelectorAll('[class*="styles__playerCell__"]');
            const cell_array = Array.from(cell_players).map(cell => {
                const name_element = cell.querySelector('[class^="styles__playerName__"]');
                return name_element ? name_element.textContent.trim() : null;
            }).filter(name => name !== null);

            const card_players = queue_list_wrapper.querySelectorAll('[class*="styles__playerCard__"]');
            const card_array = Array.from(card_players).map(cell => {
                const name_element = cell.querySelector('[class^="styles__playerName__"]');
                return name_element ? name_element.textContent.trim() : null;
            }).filter(name => name !== null);

            queue_players = cell_array.concat(card_array);
        } else if (is_active_url(url)) {
            // Match draft page: queue rows use playerCell when condensed and playerCard when expanded.
            const cell_players = queue_list_wrapper.querySelectorAll('[class*="styles__playerCell__"]');
            const cell_array = Array.from(cell_players).map(cell => {
                const name_element = cell.querySelector('[class*="styles__playerName__"]');
                return name_element ? name_element.textContent.trim() : null;
            }).filter(name => name !== null);

            const card_players = queue_list_wrapper.querySelectorAll('[class*="styles__playerCard__"]');
            const card_array = Array.from(card_players).map(card => {
                const name_element =
                    card.querySelector('[class^="styles__playerName__"]') ||
                    card.querySelector('[class*="styles__playerName__"]');
                return name_element ? name_element.textContent.trim() : null;
            }).filter(name => name !== null);

            queue_players = cell_array.concat(card_array);
        }
    }

    const current_state = {
        detected: queue_detected,
        players: queue_players,
        count: queue_players.length
    };

    const state_changed = JSON.stringify(current_state) !== JSON.stringify(fsm.state_data.queue.last_logged_queue_state);

    fsm.state_data.queue.is_detected = queue_detected;
    fsm.state_data.queue.players = queue_players;

    if (state_changed) {
        if (!queue_detected) {
        } else {
        }
        fsm.state_data.queue.last_logged_queue_state = current_state;
        
        if (fsm.overlay_manager && fsm.overlay_manager.update_stars_from_queue) {
            fsm.overlay_manager.update_stars_from_queue();
        }
    }
}
/**
 * Element that indicates the logged-in DraftKings DFS header is ready.
 * Legacy UI: deposit link in the old account bar.
 * Standardized header: wallet balance button, or the alternate combined /
 * shared balance pill variants some users see.
 */
function find_draft_kings_dom_ready_element() {
    const legacyDepositLink = document.querySelector('a[data-test-id="deposit-link"].draftkings');
    if (legacyDepositLink) {
        return legacyDepositLink;
    }
    const standardizedWalletBalance = document.querySelector(
        '[data-testid="standardized-header-user-balance"],' +
        '[data-testid="standardized-header-combined-balance-pill"],' +
        '[data-testid="standardized-header-shared-balance-pill"]'
    );
    if (standardizedWalletBalance) {
        return standardizedWalletBalance;
    }
    return null;
}

// Helper function to get DraftKings tournament data from background script cache
// If not cached, fetches from API and caches it
async function get_dk_tournament_data_from_background(draft_id, tournament_key) {
    const fsm = window.__LEGUP_FSM__;
    if (!fsm || !fsm.bg_port || !fsm.bg_connected) {
        return null;
    }
    try {
        // Check cache first
        const response = await fsm.send_port_request('GET_DK_TOURNAMENT_DATA', {
            draft_id: draft_id,
            tournament_key: tournament_key
        });

        if (response && response.status === 'ok') {
            if (response.tournament_data) {
                // Found in cache
                return response.tournament_data;
            } else {
                // Not in cache - fetch from API (content script context has proper auth)
                const tournamentApiUrl = `https://api.draftkings.com/tournaments/v1/${tournament_key}?format=json`;

                const tournamentResp = await fetch(tournamentApiUrl, {
                    method: 'GET',
                    mode: 'cors',
                    headers: {
                        'Accept': '*/*',
                        'Accept-Language': 'en-US,en;q=0.5'
                    }
                });

                if (!tournamentResp.ok) {
                    console.error(`[DK] Failed to fetch tournament data: ${tournamentResp.status}`);
                    return null;
                }

                const tournamentData = await tournamentResp.json();

                // Cache it in background script
                await fsm.send_port_request('SET_DK_TOURNAMENT_DATA', {
                    draft_id: draft_id,
                    tournament_key: tournament_key,
                    tournament_data: tournamentData
                });

                return tournamentData;
            }
        } else {
            return null;
        }
    } catch (err) {
        console.error('[content_script_draft_kings] get_dk_tournament_data failed', err);
        return null;
    }
}

// Helper function to get DraftKings contest data from background script cache
// If not cached, fetches from API and caches it
async function get_dk_contest_data_from_background(draft_id) {
    const fsm = window.__LEGUP_FSM__;
    if (!fsm || !fsm.bg_port || !fsm.bg_connected) {
        return null;
    }
    try {
        // Check cache first
        const response = await fsm.send_port_request('GET_DK_CONTEST_DATA', {
            draft_id: draft_id
        });

        if (response && response.status === 'ok') {
            if (response.contest_data) {
                // Found in cache
                return response.contest_data;
            } else {
                // Not in cache - fetch from API (content script context has proper auth)
                const contestApiUrl = `https://api.draftkings.com/contests/v1/contests/${draft_id}?format=json`;

                const contestResponse = await fetch(contestApiUrl, {
                    credentials: "include",
                    headers: {
                        "Accept": "*/*",
                        "Accept-Language": "en-US,en;q=0.5",
                        "Sec-Fetch-Dest": "empty",
                        "Sec-Fetch-Mode": "cors",
                        "Sec-Fetch-Site": "same-site"
                    },
                    referrer: "https://www.draftkings.com/",
                    method: "GET",
                    mode: "cors"
                });

                if (!contestResponse.ok) {
                    console.error(`[DK] Failed to fetch contest data: ${contestResponse.status}`);
                    return null;
                }

                const contestData = await contestResponse.json();

                // Cache it in background script
                await fsm.send_port_request('SET_DK_CONTEST_DATA', {
                    draft_id: draft_id,
                    contest_data: contestData
                });

                return contestData;
            }
        } else {
            return null;
        }
    } catch (err) {
        console.error('[content_script_draft_kings] get_dk_contest_data failed', err);
        return null;
    }
}

// Contest API lobby capacity lives on contestDetail.maximumEntries (stable). contestDetail.entries
// is often the current fill count and must not be treated as draft_size during live drafts.
function getDkDraftSizeFromContestData(contestData) {
    if (!contestData || typeof contestData !== 'object') {
        return null;
    }
    const detail =
        contestData.contestDetail && typeof contestData.contestDetail === 'object'
            ? contestData.contestDetail
            : null;
    if (!detail) {
        return null;
    }
    const raw =
        detail.maximumEntries != null
            ? detail.maximumEntries
            : detail.entries != null
              ? detail.entries
              : null;
    const n = Number(raw);
    return Number.isFinite(n) && n > 0 ? Math.round(n) : null;
}

function computeDkDraftSizeFromDom() {
    const cards = document.querySelectorAll('.UserCard_user-card');
    const n = cards && cards.length ? cards.length : 0;
    return n >= 2 && n <= 24 ? n : null;
}

function resolveDkDraftSize({ contestData, advancement_structure, users }) {
    const fromContest = getDkDraftSizeFromContestData(contestData);
    const fromAdvancement =
        advancement_structure && advancement_structure.regular_season_denom != null
            ? Number(advancement_structure.regular_season_denom)
            : null;
    const fromUsers = Array.isArray(users) && users.length > 0 ? users.length : null;
    const fromDom = computeDkDraftSizeFromDom();

    const advSize =
        Number.isFinite(fromAdvancement) && fromAdvancement > 0 ? Math.round(fromAdvancement) : null;
    const contestSize = Number.isFinite(fromContest) && fromContest > 0 ? Math.round(fromContest) : null;
    const usersSize = Number.isFinite(fromUsers) && fromUsers > 0 ? Math.round(fromUsers) : null;
    const domSize = Number.isFinite(fromDom) && fromDom > 0 ? Math.round(fromDom) : null;

    const candidates = [advSize, contestSize, domSize, usersSize].filter((v) => v != null);
    const sources = {
        advancement: advSize,
        contest: contestSize,
        dom: domSize,
        users: usersSize
    };
    if (!candidates.length) {
        return { draftSize: null, sources };
    }

    // Tournament rounds and contest maximumEntries are stable; draftStatus.users may only reflect
    // joined drafters during live lobbies, so it is the last resort.
    return { draftSize: advSize || contestSize || domSize || usersSize, sources };
}

function rememberDkDraftGroupIdForExposure(fsm, draftId, draftGroupId) {
    if (!fsm || !fsm.state_data || draftId == null || draftGroupId == null || draftGroupId === '') {
        return;
    }
    const dg = String(draftGroupId).trim();
    if (!dg) return;
    if (!fsm.state_data.draft_kings_exposure_slate_by_draft_id) {
        fsm.state_data.draft_kings_exposure_slate_by_draft_id = {};
    }
    const idKey = String(draftId).trim();
    if (!idKey) return;
    fsm.state_data.draft_kings_exposure_slate_by_draft_id[idKey] = dg;
}

// DK's /mycontests page embeds a `var contests = { upcoming: [...], live: [...] }` blob carrying
// BuyInAmount, GameTypeId and entrant counts for every contest we're in. One scrape replaces the
// old per-contest fee API calls and supplies the game-type and fill-state filters as a side effect.
// Contests absent from that blob (finished/past seasons) are not eligible for exposure.

// Bracket-depth scan rather than a non-greedy regex: contest objects contain nested arrays, so
// a `[\s\S]*?\}\]` match truncates at the first nested `}]`.
function extractDkMyContestsJsonArray(source, key) {
    if (typeof source !== 'string' || !source) return null;
    const keyRe = new RegExp('(?:^|[{,\\s])' + key + '\\s*:\\s*\\[');
    const m = keyRe.exec(source);
    if (!m) return null;
    const start = m.index + m[0].length - 1;
    let depth = 0;
    let inString = false;
    let escaped = false;
    for (let i = start; i < source.length; i++) {
        const ch = source[i];
        if (inString) {
            if (escaped) escaped = false;
            else if (ch === '\\') escaped = true;
            else if (ch === '"') inString = false;
            continue;
        }
        if (ch === '"') {
            inString = true;
            continue;
        }
        if (ch === '[' || ch === '{') {
            depth++;
        } else if (ch === ']' || ch === '}') {
            depth--;
            if (depth === 0) return source.slice(start, i + 1);
        }
    }
    return null;
}

function parseDkMyContestsArray(source, key) {
    const raw = extractDkMyContestsJsonArray(source, key);
    if (!raw) return [];
    try {
        const parsed = JSON.parse(raw);
        return Array.isArray(parsed) ? parsed : [];
    } catch (err) {
        return [];
    }
}

async function fetchDkMyContestsRows() {
    const response = await fetch(DK_EXPOSURE_MYCONTESTS_URL, {
        credentials: 'include',
        method: 'GET',
        headers: { Accept: 'text/html' }
    });
    if (!response.ok) {
        throw new Error('DK contests: /mycontests HTTP ' + response.status);
    }
    const html = await response.text();
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const scripts = Array.from(doc.querySelectorAll('script'));
    const holder = scripts.find((s) => s.textContent && s.textContent.indexOf('var contests =') >= 0);
    if (!holder) {
        throw new Error('DK contests: "var contests =" block not found on /mycontests');
    }
    const source = holder.textContent.slice(holder.textContent.indexOf('var contests ='));
    return [...parseDkMyContestsArray(source, 'upcoming'), ...parseDkMyContestsArray(source, 'live')];
}

function buildDkExposureContestMetaMap(rows) {
    const byKey = {};
    const stats = { rows: 0, eligible: 0, wrong_game_type: 0, unfilled: 0, malformed: 0 };
    const list = Array.isArray(rows) ? rows : [];
    const seenGameTypeIds = {};
    for (let i = 0; i < list.length; i++) {
        const row = list[i];
        stats.rows++;
        if (!row || typeof row !== 'object') {
            stats.malformed++;
            continue;
        }
        const contestKey = row.ContestId != null ? String(row.ContestId).trim() : '';
        if (!contestKey) {
            stats.malformed++;
            continue;
        }
        const gameTypeId = row.GameTypeId != null ? Number(row.GameTypeId) : NaN;
        if (!Number.isFinite(gameTypeId) || !DK_EXPOSURE_ALLOWED_GAME_TYPE_IDS.has(gameTypeId)) {
            const seenKey = Number.isFinite(gameTypeId) ? String(gameTypeId) : 'unknown';
            seenGameTypeIds[seenKey] = (seenGameTypeIds[seenKey] || 0) + 1;
            stats.wrong_game_type++;
            continue;
        }
        // Best ball exposure is only meaningful once the draft has filled and completed.
        const entrants = row.NumberOfEntrants != null ? Number(row.NumberOfEntrants) : NaN;
        const maxPlayers = row.MaxNumberPlayers != null ? Number(row.MaxNumberPlayers) : NaN;
        if (
            !Number.isFinite(entrants) ||
            !Number.isFinite(maxPlayers) ||
            maxPlayers <= 0 ||
            entrants !== maxPlayers
        ) {
            stats.unfilled++;
            continue;
        }
        const feeRaw = row.BuyInAmount != null ? Number(row.BuyInAmount) : NaN;
        const name = row.ContestName != null ? String(row.ContestName).trim() : '';
        const tournamentKey = row.TournamentKey != null ? String(row.TournamentKey).trim() : '';
        const userContestId = row.UserContestId != null ? String(row.UserContestId).trim() : '';
        byKey[contestKey] = {
            contest_key: contestKey,
            entry_fee: Number.isFinite(feeRaw) && feeRaw >= 0 ? feeRaw : null,
            game_type_id: gameTypeId,
            draft_size: Math.round(maxPlayers),
            name: name || null,
            tournament_key: tournamentKey || null,
            user_contest_id: userContestId || null
        };
        stats.eligible++;
    }
    if (Object.keys(seenGameTypeIds).length) {
        stats.excluded_game_type_ids = seenGameTypeIds;
    }
    return { byKey, stats };
}

async function loadDkExposureContestMeta(fsm) {
    const sd = fsm && fsm.state_data ? fsm.state_data : null;
    const cached = sd && sd.dk_exposure_contest_meta;
    const cachedAt = cached ? Number(cached.fetched_at_ms) : NaN;
    if (
        cached &&
        Number.isFinite(cachedAt) &&
        Date.now() - cachedAt <= DK_EXPOSURE_MYCONTESTS_CACHE_TTL_MS
    ) {
        return cached;
    }
    const rows = await fetchDkMyContestsRows();
    const { byKey, stats } = buildDkExposureContestMetaMap(rows);
    const meta = { by_key: byKey, stats, fetched_at_ms: Date.now() };
    if (sd) sd.dk_exposure_contest_meta = meta;
    return meta;
}

/**
 * Keep only lineup entries whose contest is eligible (present in the /mycontests metadata, which
 * has already been filtered to allowed game types and filled drafts), then rebuild each slate's
 * `total_entries` and `pick_count_by_player_dk_id` from the survivors. The intercept hook computes
 * those aggregates before any filtering, so they must be recomputed or they'd count dropped entries.
 */
function pruneDkLineupsExposureDetailToEligibleContests(detail, contestMetaByKey) {
    const result = { kept_lineups: 0, dropped_lineups: 0, dropped_entries: 0, dropped_slates: [] };
    if (!detail || typeof detail !== 'object') return result;
    const slates = detail.slates;
    if (!slates || typeof slates !== 'object' || Array.isArray(slates)) return result;
    const meta = contestMetaByKey && typeof contestMetaByKey === 'object' ? contestMetaByKey : {};
    const rawByDg =
        detail.raw_lineups_by_draft_group && typeof detail.raw_lineups_by_draft_group === 'object'
            ? detail.raw_lineups_by_draft_group
            : {};

    for (const dgKey of Object.keys(slates)) {
        const lineups = Array.isArray(rawByDg[dgKey]) ? rawByDg[dgKey] : [];
        const kept = [];
        const pickCounts = {};
        let totalEntries = 0;

        for (let i = 0; i < lineups.length; i++) {
            const lu = lineups[i];
            if (!lu || typeof lu !== 'object') continue;
            const entriesIn = Array.isArray(lu.entries) ? lu.entries : [];
            const entriesOut = [];
            for (let ei = 0; ei < entriesIn.length; ei++) {
                const ent = entriesIn[ei];
                const ck = ent && ent.contest_key != null ? String(ent.contest_key).trim() : '';
                if (ck && Object.prototype.hasOwnProperty.call(meta, ck)) {
                    entriesOut.push(ent);
                } else {
                    result.dropped_entries++;
                }
            }
            if (!entriesOut.length) {
                result.dropped_lineups++;
                continue;
            }

            // contest_entries drives both fee math and pick counts; keep it tied to the entries
            // that survived so all three aggregates derive from the same set.
            lu.entries = entriesOut;
            lu.contest_entries = entriesOut.length;
            kept.push(lu);
            result.kept_lineups++;
            totalEntries += entriesOut.length;

            const seenPlayers = new Set();
            const players = Array.isArray(lu.drafted_players) ? lu.drafted_players : [];
            for (let pi = 0; pi < players.length; pi++) {
                const p = players[pi];
                const pdk = p && p.player_dk_id != null ? String(p.player_dk_id).trim() : '';
                if (!pdk || seenPlayers.has(pdk)) continue;
                seenPlayers.add(pdk);
                pickCounts[pdk] = (pickCounts[pdk] || 0) + entriesOut.length;
            }
        }

        if (!kept.length) {
            delete slates[dgKey];
            delete rawByDg[dgKey];
            result.dropped_slates.push(dgKey);
            continue;
        }
        rawByDg[dgKey] = kept;
        const bucket = slates[dgKey];
        if (bucket && typeof bucket === 'object') {
            bucket.total_entries = totalEntries;
            bucket.pick_count_by_player_dk_id = pickCounts;
        }
    }

    detail.raw_lineups_by_draft_group = rawByDg;
    detail.lineups_count = result.kept_lineups;
    // fee_lineups only drove the retired per-contest fee API. A MAIN-world hook from a pre-update
    // tab can still emit it, so drop it rather than forward a stale field.
    if (detail.fee_lineups) delete detail.fee_lineups;
    return result;
}

/**
 * Populate each slate's entry_fees_by_player_dk_id and contests_by_key from the /mycontests
 * metadata gathered once per run. Every surviving lineup entry contributes its contest's entry fee
 * to each drafted player, matching the previous per-entry fee granularity without any API calls.
 */
function applyDkExposureContestMetaToDetail(detail, contestMetaByKey) {
    const slates = detail && detail.slates && typeof detail.slates === 'object' ? detail.slates : null;
    if (!slates) return;
    const meta = contestMetaByKey && typeof contestMetaByKey === 'object' ? contestMetaByKey : {};
    const rawByDg =
        detail.raw_lineups_by_draft_group && typeof detail.raw_lineups_by_draft_group === 'object'
            ? detail.raw_lineups_by_draft_group
            : {};

    let missingFeeContests = 0;
    for (const dgKey of Object.keys(slates)) {
        const slab = slates[dgKey];
        if (!slab || typeof slab !== 'object') continue;
        const lineups = Array.isArray(rawByDg[dgKey]) ? rawByDg[dgKey] : [];
        const feeMap = {};
        const contestsByKey = {};

        for (let i = 0; i < lineups.length; i++) {
            const lu = lineups[i];
            if (!lu || typeof lu !== 'object') continue;

            const playerDkIds = [];
            const seen = new Set();
            const players = Array.isArray(lu.drafted_players) ? lu.drafted_players : [];
            for (let pi = 0; pi < players.length; pi++) {
                const p = players[pi];
                const pdk = p && p.player_dk_id != null ? String(p.player_dk_id).trim() : '';
                if (!pdk || seen.has(pdk)) continue;
                seen.add(pdk);
                playerDkIds.push(pdk);
            }

            const entries = Array.isArray(lu.entries) ? lu.entries : [];
            for (let ei = 0; ei < entries.length; ei++) {
                const ent = entries[ei];
                const ck = ent && ent.contest_key != null ? String(ent.contest_key).trim() : '';
                if (!ck) continue;
                const contest = meta[ck];
                if (!contest) continue;
                // null means "fee unknown" and must not collapse to a free contest via Number(null).
                const fee = contest.entry_fee != null ? Number(contest.entry_fee) : NaN;
                const feeUsable = Number.isFinite(fee) && fee >= 0;

                const prev = contestsByKey[ck];
                if (prev) {
                    prev.entries += 1;
                } else {
                    contestsByKey[ck] = {
                        contest_key: ck,
                        name: contest.name || null,
                        tournament_key: contest.tournament_key || null,
                        entry_fee: feeUsable ? fee : null,
                        entries: 1
                    };
                    if (!feeUsable) missingFeeContests++;
                }

                if (!feeUsable) continue;
                for (let pi = 0; pi < playerDkIds.length; pi++) {
                    const pdk = playerDkIds[pi];
                    feeMap[pdk] = (feeMap[pdk] || 0) + fee;
                }
            }
        }

        slab.entry_fees_by_player_dk_id = Object.keys(feeMap).length ? feeMap : {};
        slab.contests_by_key = Object.keys(contestsByKey).length ? contestsByKey : {};
        if (lineups.length) {
            rawByDg[dgKey] = enrichDkLineupsWithContestDetails(lineups, slab.contests_by_key);
        }
    }
    detail.raw_lineups_by_draft_group = rawByDg;
    if (missingFeeContests) {
    }
}

function resolveDkLineupDraftStatusTarget(lineup) {
    if (!lineup || typeof lineup !== 'object') return null;
    const entries = Array.isArray(lineup.entries) ? lineup.entries : [];
    let contestKeyOnly = null;
    for (let i = 0; i < entries.length; i++) {
        const ent = entries[i];
        if (!ent || typeof ent !== 'object') continue;
        const contestKey = ent.contest_key != null ? String(ent.contest_key).trim() : '';
        if (!contestKey) continue;
        const entryKey = ent.entry_key != null ? String(ent.entry_key).trim() : '';
        if (entryKey) {
            return { contestKey, entryKey };
        }
        if (!contestKeyOnly) contestKeyOnly = contestKey;
    }
    if (contestKeyOnly) {
        return { contestKey: contestKeyOnly, entryKey: null };
    }
    return null;
}

async function loadDkEnteredContestsForExposure() {
    const out = [];
    const seen = new Set();
    const pushEntry = (contestKey, entryKey, draftGroupId) => {
        const ck = contestKey != null ? String(contestKey).trim() : '';
        const ek = entryKey != null ? String(entryKey).trim() : '';
        if (!ck || !ek) return;
        const key = ck + ':' + ek;
        if (seen.has(key)) return;
        seen.add(key);
        out.push({
            contestKey: ck,
            entryKey: ek,
            draftGroupId: draftGroupId != null ? String(draftGroupId).trim() : ''
        });
    };

    const cacheResult = await new Promise((resolve) => {
        chrome.storage.local.get(['draftKingsUserContestIds'], resolve);
    });
    const userContestIds = (cacheResult && cacheResult.draftKingsUserContestIds) || {};
    for (const contestKey of Object.keys(userContestIds)) {
        const row = userContestIds[contestKey];
        if (!row || typeof row !== 'object') continue;
        pushEntry(contestKey, row.userContestId, row.draftGroupId);
    }

    const allStorage = await new Promise((resolve) => {
        chrome.storage.local.get(null, resolve);
    });
    for (const storageKey of Object.keys(allStorage || {})) {
        if (!storageKey.startsWith('dk_user_profile_')) continue;
        const profile = allStorage[storageKey];
        const entered = profile && profile.userProfile && Array.isArray(profile.userProfile.enteredContests)
            ? profile.userProfile.enteredContests
            : [];
        for (let i = 0; i < entered.length; i++) {
            const contest = entered[i];
            if (!contest || typeof contest !== 'object') continue;
            pushEntry(contest.contestKey, contest.entryKey, contest.draftGroupId);
        }
    }
    return out;
}

function buildDkEnteredContestEntryKeysByContest(enteredContests) {
    const byContest = {};
    const rows = Array.isArray(enteredContests) ? enteredContests : [];
    for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        if (!row || typeof row !== 'object') continue;
        const ck = row.contestKey != null ? String(row.contestKey).trim() : '';
        const ek = row.entryKey != null ? String(row.entryKey).trim() : '';
        if (!ck || !ek) continue;
        if (!byContest[ck]) byContest[ck] = [];
        if (!byContest[ck].includes(ek)) byContest[ck].push(ek);
    }
    return byContest;
}

function lineupDraftableIdsForExposureMatch(lineup) {
    const players = lineup && Array.isArray(lineup.drafted_players) ? lineup.drafted_players : [];
    const ids = [];
    for (let i = 0; i < players.length; i++) {
        const p = players[i];
        if (!p || typeof p !== 'object') continue;
        const raw = p.draftable_id != null ? Number(p.draftable_id) : NaN;
        if (Number.isFinite(raw)) ids.push(Math.round(raw));
    }
    ids.sort((a, b) => a - b);
    return ids;
}

function draftStatusLineupDraftableIds(draftStatus) {
    const lineup = draftStatus && Array.isArray(draftStatus.lineup) ? draftStatus.lineup : [];
    const ids = [];
    for (let i = 0; i < lineup.length; i++) {
        const raw = Number(lineup[i]);
        if (Number.isFinite(raw)) ids.push(Math.round(raw));
    }
    ids.sort((a, b) => a - b);
    return ids;
}

function dkLineupMatchesDraftStatusLineup(lineup, draftStatus) {
    const ours = lineupDraftableIdsForExposureMatch(lineup);
    const theirs = draftStatusLineupDraftableIds(draftStatus);
    if (!ours.length || !theirs.length) return false;
    if (ours.length !== theirs.length) return false;
    for (let i = 0; i < ours.length; i++) {
        if (ours[i] !== theirs[i]) return false;
    }
    return true;
}

async function fetchDkDraftStatusForExposure(contestKey, entryKey) {
    const ck = contestKey != null ? String(contestKey).trim() : '';
    const ek = entryKey != null ? String(entryKey).trim() : '';
    if (!ck || !ek) {
        return { ok: false, data: null, reason: 'missing_contest_or_entry_key', contest_key: ck || null, entry_key: ek || null };
    }
    const url = `https://api.draftkings.com/drafts/v1/${encodeURIComponent(ck)}/entries/${encodeURIComponent(ek)}/draftStatus?format=json`;
    try {
        const response = await fetch(url, {
            credentials: 'include',
            headers: {
                Accept: '*/*',
                'Accept-Language': 'en-US,en;q=0.5',
                'Sec-Fetch-Dest': 'empty',
                'Sec-Fetch-Mode': 'cors',
                'Sec-Fetch-Site': 'same-site'
            },
            referrer: 'https://www.draftkings.com/',
            method: 'GET',
            mode: 'cors'
        });
        if (!response.ok) {
            return {
                ok: false,
                data: null,
                reason: 'http_error',
                http_status: response.status,
                contest_key: ck,
                entry_key: ek,
                // 404 is common for cancelled / not-started / removed entries.
                likely_cancelled_or_unavailable: response.status === 404 || response.status === 410
            };
        }
        const data = await response.json();
        if (data && data.errorStatus && typeof data.errorStatus === 'object' && Object.keys(data.errorStatus).length) {
            const errStatus = data.errorStatus;
            const errCode =
                errStatus.code != null
                    ? String(errStatus.code)
                    : errStatus.errorCode != null
                      ? String(errStatus.errorCode)
                      : null;
            const errMsg =
                errStatus.message != null
                    ? String(errStatus.message)
                    : errStatus.errorMessage != null
                      ? String(errStatus.errorMessage)
                      : null;
            const blob = JSON.stringify(errStatus).toLowerCase();
            return {
                ok: false,
                data: null,
                reason: 'error_status',
                http_status: response.status,
                contest_key: ck,
                entry_key: ek,
                error_status: errStatus,
                error_code: errCode,
                error_message: errMsg,
                likely_cancelled_or_unavailable:
                    blob.indexOf('cancel') >= 0 ||
                    blob.indexOf('withdraw') >= 0 ||
                    blob.indexOf('not found') >= 0 ||
                    blob.indexOf('unavailable') >= 0
            };
        }
        return { ok: true, data: data, contest_key: ck, entry_key: ek };
    } catch (err) {
        return {
            ok: false,
            data: null,
            reason: 'fetch_threw',
            contest_key: ck,
            entry_key: ek,
            message: err && err.message ? String(err.message) : String(err)
        };
    }
}

function summarizeDkLineupForSkipLog(lineup) {
    if (!lineup || typeof lineup !== 'object') {
        return { lineup: null };
    }
    const entries = Array.isArray(lineup.entries) ? lineup.entries : [];
    const first = entries[0] && typeof entries[0] === 'object' ? entries[0] : {};
    const players = Array.isArray(lineup.drafted_players) ? lineup.drafted_players : [];
    return {
        lineup_id: lineup.lineup_id != null ? String(lineup.lineup_id) : null,
        draft_group_id: lineup.draft_group_id != null ? String(lineup.draft_group_id) : null,
        contest_key: first.contest_key != null ? String(first.contest_key) : null,
        entry_key: first.entry_key != null ? String(first.entry_key) : null,
        contest_entries: lineup.contest_entries != null ? lineup.contest_entries : null,
        name: lineup.name != null ? String(lineup.name) : null,
        entry_fee: lineup.entry_fee != null ? lineup.entry_fee : null,
        create_date: lineup.create_date != null ? String(lineup.create_date) : null,
        sport: lineup.sport != null ? String(lineup.sport) : null,
        game_type_name: lineup.game_type_name != null ? String(lineup.game_type_name) : null,
        player_count: players.length,
        entry_count: entries.length,
        seat_number: lineup.seat_number != null ? lineup.seat_number : null,
        draft_size: lineup.draft_size != null ? lineup.draft_size : null,
        top_keys: Object.keys(lineup).slice(0, 24)
    };
}

function summarizeDkDraftStatusForSkipLog(draftStatus) {
    if (!draftStatus || typeof draftStatus !== 'object') {
        return null;
    }
    const board = Array.isArray(draftStatus.draftBoard) ? draftStatus.draftBoard : [];
    const users = Array.isArray(draftStatus.users) ? draftStatus.users : [];
    const statusish = {};
    const statusKeys = [
        'status',
        'draftStatus',
        'draftState',
        'state',
        'contestState',
        'contestStatus',
        'entryStatus',
        'entryState',
        'isCancelled',
        'canceled',
        'cancelled',
        'isCanceled'
    ];
    for (let i = 0; i < statusKeys.length; i++) {
        const key = statusKeys[i];
        if (draftStatus[key] != null) statusish[key] = draftStatus[key];
    }
    const blob = JSON.stringify(statusish).toLowerCase();
    return {
        draft_board_len: board.length,
        users_len: users.length,
        lineup_len: Array.isArray(draftStatus.lineup) ? draftStatus.lineup.length : 0,
        status_fields: statusish,
        likely_cancelled:
            blob.indexOf('cancel') >= 0 ||
            (!board.length && !users.length),
        top_keys: Object.keys(draftStatus).slice(0, 30)
    };
}

function findDraftBoardPickForExposurePlayer(draftBoard, player) {
    if (!Array.isArray(draftBoard) || !player || typeof player !== 'object') return null;
    const draftableId = player.draftable_id != null ? Number(player.draftable_id) : NaN;
    const playerId = player.player_id != null ? Number(player.player_id) : NaN;
    let fallback = null;
    for (let i = 0; i < draftBoard.length; i++) {
        const pick = draftBoard[i];
        if (!pick || typeof pick !== 'object') continue;
        const boardDraftableId = pick.draftableId != null ? Number(pick.draftableId) : NaN;
        const boardPlayerId = pick.playerId != null ? Number(pick.playerId) : NaN;
        if (Number.isFinite(draftableId) && Number.isFinite(boardDraftableId) && draftableId === boardDraftableId) {
            return pick;
        }
        if (Number.isFinite(playerId) && Number.isFinite(boardPlayerId) && playerId === boardPlayerId) {
            fallback = pick;
        }
    }
    return fallback;
}

// draftStatus.playerPool.draftablePlayers carries averageDraftPosition; key it by both ids so the
// lookup mirrors findDraftBoardPickForExposurePlayer's draftableId-then-playerId matching.
function buildDkAdpMapFromDraftStatus(draftStatus) {
    const pool =
        draftStatus && draftStatus.playerPool && Array.isArray(draftStatus.playerPool.draftablePlayers)
            ? draftStatus.playerPool.draftablePlayers
            : [];
    const byDraftableId = {};
    const byPlayerId = {};
    for (let i = 0; i < pool.length; i++) {
        const entry = pool[i];
        if (!entry || typeof entry !== 'object') continue;
        const adp = Number(entry.averageDraftPosition);
        if (!Number.isFinite(adp) || adp <= 0) continue;
        const draftableId = entry.draftableId != null ? Number(entry.draftableId) : NaN;
        if (Number.isFinite(draftableId)) byDraftableId[String(Math.round(draftableId))] = adp;
        const playerId = entry.playerId != null ? Number(entry.playerId) : NaN;
        if (Number.isFinite(playerId)) byPlayerId[String(Math.round(playerId))] = adp;
    }
    return { byDraftableId, byPlayerId };
}

function lookupDkAdpForExposurePlayer(adpMap, player) {
    if (!adpMap || !player || typeof player !== 'object') return null;
    const draftableId = player.draftable_id != null ? Number(player.draftable_id) : NaN;
    if (Number.isFinite(draftableId)) {
        const hit = adpMap.byDraftableId[String(Math.round(draftableId))];
        if (Number.isFinite(hit)) return hit;
    }
    const playerId = player.player_id != null ? Number(player.player_id) : NaN;
    if (Number.isFinite(playerId)) {
        const hit = adpMap.byPlayerId[String(Math.round(playerId))];
        if (Number.isFinite(hit)) return hit;
    }
    return null;
}

function logDkLineupSeatSnapshot(label, lineups) {
    const rows = Array.isArray(lineups) ? lineups : [];
    const lineupIds = new Set();
    const entryKeys = new Set();
    const contestKeys = new Set();
    let missingLineupId = 0;
    let missingEntryKey = 0;
    let missingContestKey = 0;
    const summary = rows.map((lu, index) => {
        const entries = Array.isArray(lu && lu.entries) ? lu.entries : [];
        const first = entries[0] && typeof entries[0] === 'object' ? entries[0] : {};
        const players = Array.isArray(lu && lu.drafted_players) ? lu.drafted_players : [];
        const pickNumbers = [];
        for (let i = 0; i < players.length; i++) {
            const pn = players[i] && players[i].pick_number != null ? Number(players[i].pick_number) : null;
            if (Number.isFinite(pn)) pickNumbers.push(pn);
        }
        const lid = lu && lu.lineup_id != null ? String(lu.lineup_id).trim() : '';
        const ek = first.entry_key != null ? String(first.entry_key).trim() : '';
        const ck = first.contest_key != null ? String(first.contest_key).trim() : '';
        if (lid) lineupIds.add(lid);
        else missingLineupId++;
        if (ek) entryKeys.add(ek);
        else missingEntryKey++;
        if (ck) contestKeys.add(ck);
        else missingContestKey++;
        return {
            i: index,
            draft_group_id: lu && lu.draft_group_id != null ? String(lu.draft_group_id) : null,
            lineup_id: lid || null,
            contest_key: ck || null,
            entry_key: ek || null,
            draft_size: lu && lu.draft_size != null ? lu.draft_size : null,
            seat_number: lu && lu.seat_number != null ? lu.seat_number : null,
            players: players.length,
            pick_numbers: pickNumbers
        };
    });
    const identity = {
        lineups: summary.length,
        unique_lineup_ids: lineupIds.size,
        unique_entry_keys: entryKeys.size,
        unique_contest_keys: contestKeys.size,
        missing_lineup_id: missingLineupId,
        missing_entry_key: missingEntryKey,
        missing_contest_key: missingContestKey,
        with_seat: summary.filter((r) => r.seat_number != null).length,
        missing_seat: summary.filter((r) => r.seat_number == null).length,
        would_collapse_on_contest_key:
            summary.length > 0 && contestKeys.size > 0 && contestKeys.size < summary.length,
        would_collapse_on_entry_key:
            summary.length > 0 && entryKeys.size > 0 && entryKeys.size < summary.length
    };
    // Always log identity coverage (prod included). Row dump stays soft-gated.
    const fsm = window.__LEGUP_FSM__;
    if (fsm && typeof fsm._is_dev_or_local_env === 'function' && fsm._is_dev_or_local_env()) {
        const log_data = {
            ...identity,
            rows: summary
        };
    }
}

function dkSeatFromFirstOverallPick(overallPick, draftSize) {
    const pickNum = Number(overallPick);
    const size = Number(draftSize);
    if (!Number.isFinite(pickNum) || pickNum < 1) {
        throw new Error('DK seat: invalid overall pick ' + overallPick);
    }
    if (!Number.isFinite(size) || size < 1) {
        throw new Error('DK seat: invalid draft_size ' + draftSize);
    }
    // Seat is the round-1 overall pick. Do not invent a seat from a later-round pick.
    if (pickNum > size) {
        throw new Error(
            'DK seat: earliest overall pick ' + pickNum + ' is past round 1 for draft_size ' + size
        );
    }
    return Math.round(pickNum);
}

function draftSizeFromDkDraftStatus(draftStatus) {
    if (!draftStatus || typeof draftStatus !== 'object') {
        throw new Error('DK seat: draftStatus missing');
    }
    const users = Array.isArray(draftStatus.users) ? draftStatus.users : null;
    if (!users || !users.length) {
        throw new Error('DK seat: draftStatus.users missing or empty');
    }
    return users.length;
}

function enrichDkLineupWithDraftPickData(lineup, draftStatus) {
    if (!lineup || typeof lineup !== 'object') {
        throw new Error('DK seat: lineup missing');
    }
    if (!draftStatus || typeof draftStatus !== 'object') {
        throw new Error('DK seat: draftStatus missing');
    }
    const board = Array.isArray(draftStatus.draftBoard) ? draftStatus.draftBoard : [];
    if (!board.length) {
        throw new Error('DK seat: draftStatus.draftBoard empty');
    }
    const players = Array.isArray(lineup.drafted_players) ? lineup.drafted_players : [];
    if (!players.length) {
        throw new Error('DK seat: drafted_players empty');
    }

    const draftSize = draftSizeFromDkDraftStatus(draftStatus);
    lineup.draft_size = draftSize;
    const adpByPlayerKey = buildDkAdpMapFromDraftStatus(draftStatus);

    let minPick = null;
    let matched = 0;
    for (let i = 0; i < players.length; i++) {
        const pick = findDraftBoardPickForExposurePlayer(board, players[i]);
        if (!pick || pick.overallSelectionNumber == null) continue;
        const pickNum = Number(pick.overallSelectionNumber);
        if (!Number.isFinite(pickNum) || pickNum <= 0) continue;
        players[i].pick_number = Math.round(pickNum);
        // selection_time and adp ride along on the draftStatus we already fetched; both are
        // optional so a missing value never costs us the lineup.
        const selectionTime = pick.selectionTime != null ? String(pick.selectionTime).trim() : '';
        if (selectionTime) players[i].selection_time = selectionTime;
        const adp = lookupDkAdpForExposurePlayer(adpByPlayerKey, players[i]);
        if (adp != null) players[i].adp = adp;
        matched++;
        if (minPick == null || pickNum < minPick) {
            minPick = pickNum;
        }
    }
    if (matched !== players.length || minPick == null) {
        throw new Error(
            'DK seat: matched ' + matched + '/' + players.length + ' drafted_players to draftBoard'
        );
    }

    lineup.seat_number = dkSeatFromFirstOverallPick(minPick, draftSize);
    const fsm = window.__LEGUP_FSM__;
    if (fsm && typeof fsm._is_dev_or_local_env === 'function' && fsm._is_dev_or_local_env()) {
        const enrichedSeatLog = {
            draft_group_id: lineup.draft_group_id != null ? String(lineup.draft_group_id) : null,
            draft_size: lineup.draft_size,
            seat_number: lineup.seat_number,
            min_overall_pick: minPick,
            players: players.length,
            pick_numbers: players.map((p) => (p && p.pick_number != null ? p.pick_number : null))
        };
    }
}

async function fetchDkUserProfileForExposure(fsm) {
    const usernameHint = await resolve_dk_username(fsm);
    if (usernameHint) {
        const cached = await get_cached_user_profile_dk(usernameHint);
        if (is_valid_dk_user_profile_payload(cached)) {
            return cached;
        }
    }
    const recovered = await fetch_dk_user_profile_with_username_recovery(fsm);
    if (!recovered || !recovered.data) {
        return null;
    }
    await cache_user_profile_dk(recovered.username, recovered.data);
    await extract_and_cache_user_contest_ids(recovered.data, null);
    return recovered.data;
}

async function mapPoolDk(items, concurrency, worker) {
    const list = Array.isArray(items) ? items : [];
    const limit = Math.max(1, Number(concurrency) || 1);
    const results = new Array(list.length);
    let nextIndex = 0;

    async function runOne() {
        while (nextIndex < list.length) {
            const i = nextIndex++;
            results[i] = await worker(list[i], i);
        }
    }

    const runners = [];
    for (let r = 0; r < Math.min(limit, list.length); r++) {
        runners.push(runOne());
    }
    await Promise.all(runners);
    return results;
}

async function prepareDkLineupSeatEnrichmentContext(fsm, detail) {
    const rawByDg = detail && detail.raw_lineups_by_draft_group && typeof detail.raw_lineups_by_draft_group === 'object'
        ? detail.raw_lineups_by_draft_group
        : null;
    if (!rawByDg) {
        throw new Error('DK seat: raw_lineups_by_draft_group missing');
    }

    let enteredContests = await loadDkEnteredContestsForExposure();
    let entryKeysByContest = buildDkEnteredContestEntryKeysByContest(enteredContests);
    const draftStatusCache = {};
    const multiEntryStatusesByContest = {};

    const allLineups = [];
    for (const dgKey of Object.keys(rawByDg)) {
        const lineups = rawByDg[dgKey];
        if (!Array.isArray(lineups)) continue;
        for (let i = 0; i < lineups.length; i++) {
            if (lineups[i] && typeof lineups[i] === 'object') allLineups.push(lineups[i]);
        }
    }
    if (!allLineups.length) {
        throw new Error('DK seat: no lineups to enrich');
    }

    let missingEntryKey = 0;
    for (let i = 0; i < allLineups.length; i++) {
        const target = resolveDkLineupDraftStatusTarget(allLineups[i]);
        if (!target || !target.contestKey) continue;
        if (target.entryKey) continue;
        const candidates = entryKeysByContest[target.contestKey] || [];
        if (!candidates.length) missingEntryKey++;
    }
    if (missingEntryKey > 0 || !Object.keys(entryKeysByContest).length) {
        const profile = await fetchDkUserProfileForExposure(fsm);
        if (profile) {
            enteredContests = await loadDkEnteredContestsForExposure();
            entryKeysByContest = buildDkEnteredContestEntryKeysByContest(enteredContests);
        }
    }

    const getDraftStatusCached = async (contestKey, entryKey) => {
        const ck = contestKey != null ? String(contestKey).trim() : '';
        const ek = entryKey != null ? String(entryKey).trim() : '';
        if (!ck || !ek) {
            return { ok: false, data: null, reason: 'missing_contest_or_entry_key' };
        }
        const cacheKey = ck + ':' + ek;
        if (Object.prototype.hasOwnProperty.call(draftStatusCache, cacheKey)) {
            return draftStatusCache[cacheKey];
        }
        const result = await fetchDkDraftStatusForExposure(ck, ek);
        draftStatusCache[cacheKey] = result || { ok: false, data: null, reason: 'empty_fetch_result' };
        return draftStatusCache[cacheKey];
    };

    // Prefetch multi-entry contest draft statuses once so chunk workers can match locally.
    const multiEntryContestKeys = new Set();
    for (let i = 0; i < allLineups.length; i++) {
        const target = resolveDkLineupDraftStatusTarget(allLineups[i]);
        if (!target || !target.contestKey || target.entryKey) continue;
        const candidates = entryKeysByContest[target.contestKey] || [];
        if (candidates.length > 1) multiEntryContestKeys.add(target.contestKey);
    }
    for (const contestKey of multiEntryContestKeys) {
        const candidates = entryKeysByContest[contestKey] || [];
        const statusByEntry = [];
        await mapPoolDk(candidates, DK_EXPOSURE_SEAT_ENRICH_CONCURRENCY, async (entryKey) => {
            const result = await getDraftStatusCached(contestKey, entryKey);
            if (result && result.ok && result.data) {
                statusByEntry.push({ entryKey, draftStatus: result.data, fetch: result });
            } else if (result) {
                statusByEntry.push({ entryKey, draftStatus: null, fetch: result });
            }
        });
        multiEntryStatusesByContest[contestKey] = statusByEntry;
    }

    return {
        allLineups,
        entryKeysByContest,
        getDraftStatusCached,
        multiEntryStatusesByContest,
        draftStatusCache
    };
}

function throwDkSeatFetchFailed(contestKey, entryKey, fetchResult) {
    const fail = fetchResult && typeof fetchResult === 'object' ? fetchResult : {};
    const parts = [
        'DK seat: draftStatus fetch failed for ' + contestKey + '/' + entryKey,
        fail.reason ? 'reason=' + fail.reason : null,
        fail.http_status != null ? 'http=' + fail.http_status : null,
        fail.error_code ? 'code=' + fail.error_code : null,
        fail.error_message ? 'msg=' + fail.error_message : null,
        fail.likely_cancelled_or_unavailable ? 'likely_cancelled_or_unavailable' : null
    ].filter(Boolean);
    const err = new Error(parts.join(' · '));
    err.dk_seat_skip = {
        kind: 'draft_status_fetch_failed',
        contest_key: contestKey != null ? String(contestKey) : null,
        entry_key: entryKey != null ? String(entryKey) : null,
        fetch: fail
    };
    throw err;
}

async function enrichOneDkLineupSeat(lineup, ctx) {
    const target = resolveDkLineupDraftStatusTarget(lineup);
    if (!target || !target.contestKey) {
        const err = new Error('DK seat: lineup missing contest_key on entries');
        err.dk_seat_skip = { kind: 'missing_contest_key', lineup: summarizeDkLineupForSkipLog(lineup) };
        throw err;
    }

    let draftStatus = null;
    let usedEntryKey = target.entryKey || null;
    if (target.entryKey) {
        const lastFetch = await ctx.getDraftStatusCached(target.contestKey, target.entryKey);
        if (!lastFetch || !lastFetch.ok || !lastFetch.data) {
            throwDkSeatFetchFailed(target.contestKey, target.entryKey, lastFetch);
        }
        draftStatus = lastFetch.data;
    } else {
        const candidates = ctx.entryKeysByContest[target.contestKey] || [];
        if (!candidates.length) {
            const err = new Error('DK seat: no entry_key for contest_key=' + target.contestKey);
            err.dk_seat_skip = {
                kind: 'missing_entry_key',
                contest_key: target.contestKey,
                lineup: summarizeDkLineupForSkipLog(lineup)
            };
            throw err;
        }
        if (candidates.length === 1) {
            usedEntryKey = candidates[0];
            const lastFetch = await ctx.getDraftStatusCached(target.contestKey, candidates[0]);
            if (!lastFetch || !lastFetch.ok || !lastFetch.data) {
                throwDkSeatFetchFailed(target.contestKey, candidates[0], lastFetch);
            }
            draftStatus = lastFetch.data;
        } else {
            const statusByEntry = ctx.multiEntryStatusesByContest[target.contestKey] || [];
            const okStatuses = statusByEntry.filter((row) => row && row.draftStatus);
            if (!okStatuses.length) {
                const failSamples = statusByEntry
                    .filter((row) => row && row.fetch && !row.fetch.ok)
                    .slice(0, 3)
                    .map((row) => ({
                        entry_key: row.entryKey,
                        reason: row.fetch.reason,
                        http_status: row.fetch.http_status,
                        likely_cancelled_or_unavailable: !!row.fetch.likely_cancelled_or_unavailable
                    }));
                const err = new Error(
                    'DK seat: no draftStatus for multi-entry contest_key=' + target.contestKey
                );
                err.dk_seat_skip = {
                    kind: 'multi_entry_all_failed',
                    contest_key: target.contestKey,
                    candidate_count: candidates.length,
                    fail_samples: failSamples,
                    lineup: summarizeDkLineupForSkipLog(lineup)
                };
                throw err;
            }
            for (let si = 0; si < okStatuses.length; si++) {
                if (dkLineupMatchesDraftStatusLineup(lineup, okStatuses[si].draftStatus)) {
                    draftStatus = okStatuses[si].draftStatus;
                    usedEntryKey = okStatuses[si].entryKey;
                    break;
                }
            }
            if (!draftStatus) {
                const err = new Error(
                    'DK seat: could not match lineup to draftStatus for contest_key=' + target.contestKey
                );
                err.dk_seat_skip = {
                    kind: 'multi_entry_no_match',
                    contest_key: target.contestKey,
                    ok_status_count: okStatuses.length,
                    lineup: summarizeDkLineupForSkipLog(lineup)
                };
                throw err;
            }
        }
    }

    try {
        enrichDkLineupWithDraftPickData(lineup, draftStatus);
    } catch (enrichErr) {
        const message = enrichErr && enrichErr.message ? String(enrichErr.message) : String(enrichErr);
        const statusSummary = summarizeDkDraftStatusForSkipLog(draftStatus);
        const err = new Error(message);
        err.dk_seat_skip = {
            kind: 'enrich_failed',
            contest_key: target.contestKey,
            entry_key: usedEntryKey,
            message: message,
            likely_cancelled: !!(statusSummary && statusSummary.likely_cancelled),
            draft_status: statusSummary,
            lineup: summarizeDkLineupForSkipLog(lineup)
        };
        throw err;
    }
    const seat = Number(lineup.seat_number);
    if (!Number.isFinite(seat) || seat < 1) {
        const err = new Error('DK seat: seat_number missing after enrichment');
        err.dk_seat_skip = {
            kind: 'missing_seat_after_enrich',
            contest_key: target.contestKey,
            entry_key: usedEntryKey,
            draft_status: summarizeDkDraftStatusForSkipLog(draftStatus),
            lineup: summarizeDkLineupForSkipLog(lineup)
        };
        throw err;
    }

    // Persist identity keys discovered during seat enrich so processed uploads
    // and sync identity logs do not collapse multi-entry contests.
    if (usedEntryKey) {
        const ek = String(usedEntryKey).trim();
        if (ek) {
            if (!Array.isArray(lineup.entries) || !lineup.entries.length) {
                lineup.entries = [
                    {
                        contest_key: target.contestKey != null ? String(target.contestKey) : null,
                        entry_key: ek
                    }
                ];
            } else {
                let wrote = false;
                for (let ei = 0; ei < lineup.entries.length; ei++) {
                    const ent = lineup.entries[ei];
                    if (!ent || typeof ent !== 'object') continue;
                    const ck = ent.contest_key != null ? String(ent.contest_key).trim() : '';
                    if (target.contestKey && ck && ck !== String(target.contestKey).trim()) continue;
                    if (!ent.entry_key) {
                        ent.entry_key = ek;
                        wrote = true;
                        break;
                    }
                }
                if (!wrote && lineup.entries[0] && typeof lineup.entries[0] === 'object') {
                    if (!lineup.entries[0].entry_key) lineup.entries[0].entry_key = ek;
                }
            }
            if (lineup.lineup_id == null || !String(lineup.lineup_id).trim()) {
                lineup.lineup_id = ek;
            }
        }
    }
}

/**
 * Soft-fail per lineup: enrich seats in chunks with bounded concurrency.
 * Calls onChunk({ seatedLineups, skippedCount, done, total }) after each chunk
 * that gained at least one new seat (and once at the end).
 */
async function enrichDkLineupsSeatsChunked(fsm, detail, onChunk) {
    const ctx = await prepareDkLineupSeatEnrichmentContext(fsm, detail);
    const allLineups = ctx.allLineups;
    logDkLineupSeatSnapshot('before enrichment (seat should be null here)', allLineups);

    const chunkSize =
        typeof DK_EXPOSURE_SEAT_ENRICH_CHUNK_SIZE === 'number' && DK_EXPOSURE_SEAT_ENRICH_CHUNK_SIZE > 0
            ? DK_EXPOSURE_SEAT_ENRICH_CHUNK_SIZE
            : 10;
    const concurrency =
        typeof DK_EXPOSURE_SEAT_ENRICH_CONCURRENCY === 'number' && DK_EXPOSURE_SEAT_ENRICH_CONCURRENCY > 0
            ? DK_EXPOSURE_SEAT_ENRICH_CONCURRENCY
            : 4;

    const seatedLineups = [];
    let skippedCount = 0;
    const total = allLineups.length;

    for (let offset = 0; offset < allLineups.length; offset += chunkSize) {
        const chunk = allLineups.slice(offset, offset + chunkSize);
        const results = await mapPoolDk(chunk, concurrency, async (lineup) => {
            try {
                await enrichOneDkLineupSeat(lineup, ctx);
                return { ok: true, lineup };
            } catch (err) {
                const message = err && err.message ? String(err.message) : String(err);
                const skipDetail = Object.assign(
                    { lineup: summarizeDkLineupForSkipLog(lineup) },
                    (err && err.dk_seat_skip) || { kind: 'unknown', message: message }
                );
                if (typeof fsm._is_dev_or_local_env === 'function' && fsm._is_dev_or_local_env()) {
                    const log_data = {
                        message: message,
                        ...skipDetail
                    };
                }
                return { ok: false, lineup, message, skipDetail };
            }
        });

        let chunkSeated = 0;
        for (let i = 0; i < results.length; i++) {
            if (results[i] && results[i].ok) {
                seatedLineups.push(results[i].lineup);
                chunkSeated++;
            } else {
                skippedCount++;
            }
        }

        const done = Math.min(offset + chunk.length, total);
        if (typeof onChunk === 'function' && (chunkSeated > 0 || done >= total)) {
            await onChunk({
                seatedLineups: seatedLineups.slice(),
                skippedCount,
                chunkSeated,
                done,
                total
            });
        }
    }

    logDkLineupSeatSnapshot('after enrichment', seatedLineups);
    if (typeof fsm._is_dev_or_local_env === 'function' && fsm._is_dev_or_local_env()) {
        const enrichmentOkLog = {
            lineups: total,
            seated: seatedLineups.length,
            skipped: skippedCount,
            draft_status_fetches: Object.keys(ctx.draftStatusCache).length
        };
    }

    return { seatedLineups, skippedCount, total };
}

function buildDkLineupsDetailWithSeatedLineupsOnly(detail, seatedLineups) {
    if (!detail || typeof detail !== 'object') return null;
    const seated = Array.isArray(seatedLineups) ? seatedLineups : [];
    const byDg = {};
    for (let i = 0; i < seated.length; i++) {
        const lu = seated[i];
        if (!lu || typeof lu !== 'object') continue;
        const dg = lu.draft_group_id != null ? String(lu.draft_group_id) : null;
        if (!dg) continue;
        if (!byDg[dg]) byDg[dg] = [];
        byDg[dg].push(lu);
    }
    const slatesIn = detail.slates && typeof detail.slates === 'object' ? detail.slates : {};
    const slatesOut = {};
    for (const dg of Object.keys(byDg)) {
        if (slatesIn[dg] && typeof slatesIn[dg] === 'object') {
            slatesOut[dg] = slatesIn[dg];
        }
    }
    // Only DGs with seated lineups — avoids overwriting other draft groups with empty raw_lineups mid-run.
    return {
        ...detail,
        slates: slatesOut,
        raw_lineups_by_draft_group: byDg,
        lineups_count: seated.length
    };
}

// Helper function to get cached user profile data
const DK_SITE_USERNAME_SYNC_INTERVAL_MS = 30 * 1000;
let _lastDkSiteUsernameSyncAt = 0;

// Standardized header no longer shows username; resolve via background storage or siteNav me.json.
const DK_ME_JSON_URL =
    'https://api.draftkings.com/sites/US-DK/dashes/v1/dashes/siteNav/users/me.json?format=json&includeTickets=true';

function dk_extraction_fail(message) {
    throw new Error(message);
}

function _dk_draft_status_backoff_map(fsm) {
    if (!fsm?.state_data) return null;
    if (!fsm.state_data.dk_draft_status_backoff || typeof fsm.state_data.dk_draft_status_backoff !== 'object') {
        fsm.state_data.dk_draft_status_backoff = {};
    }
    return fsm.state_data.dk_draft_status_backoff;
}

function is_dk_draft_status_backoff_active(fsm, draftId) {
    if (!draftId) return false;
    const map = _dk_draft_status_backoff_map(fsm);
    const entry = map?.[draftId];
    return !!(entry && Number.isFinite(entry.until_ms) && Date.now() < entry.until_ms);
}

function clear_dk_draft_status_backoff(fsm, draftId) {
    if (!draftId) return;
    const map = _dk_draft_status_backoff_map(fsm);
    if (map && Object.prototype.hasOwnProperty.call(map, draftId)) {
        delete map[draftId];
    }
}

// draftStatus 404 usually means the snake contest exists but isn't live yet (waiting / pre-start).
// Soft-skip + exponential backoff instead of extraction-error spam every tick.
function note_dk_draft_status_not_ready(fsm, draftId, status) {
    if (!draftId) return;
    const map = _dk_draft_status_backoff_map(fsm);
    if (!map) return;

    const base = (typeof DK_DRAFT_STATUS_404_BACKOFF_BASE_MS === 'number')
        ? DK_DRAFT_STATUS_404_BACKOFF_BASE_MS
        : 5000;
    const max = (typeof DK_DRAFT_STATUS_404_BACKOFF_MAX_MS === 'number')
        ? DK_DRAFT_STATUS_404_BACKOFF_MAX_MS
        : 60000;
    const prev = map[draftId] || { consecutive: 0 };
    const consecutive = (prev.consecutive || 0) + 1;
    const delay = Math.min(max, base * Math.pow(2, Math.max(0, consecutive - 1)));
    map[draftId] = {
        consecutive,
        until_ms: Date.now() + delay,
        last_status: status != null ? status : 404
    };

    const extractionSource = (typeof EXTRACTION_ERROR_WARNING_SOURCE !== 'undefined')
        ? EXTRACTION_ERROR_WARNING_SOURCE
        : 'extraction_error';
    if (typeof fsm.clear_urgent_warning_notification === 'function') {
        fsm.clear_urgent_warning_notification(extractionSource);
    }
    if (fsm.extraction_error_details) {
        fsm.extraction_error_details = [];
    }
}

var _dk_resolved_username = null;
var _dk_username_resolve_promise = null;

function normalize_dk_username(username) {
    const normalized = typeof username === 'string' ? username.trim() : '';
    if (!normalized || normalized.length >= 50) {
        return null;
    }
    // Reject obvious non-usernames that would otherwise stick in extension storage.
    const lower = normalized.toLowerCase();
    if (lower === 'undefined' || lower === 'null' || lower === 'account' || lower === 'username') {
        return null;
    }
    return normalized;
}

function persist_dk_username(fsm, username, source) {
    const normalized = normalize_dk_username(username);
    if (!normalized) {
        return null;
    }
    _dk_resolved_username = normalized;
    if (fsm && typeof sendFantasySiteUsernameToBackground === 'function') {
        sendFantasySiteUsernameToBackground(fsm, 'draftkings', normalized);
    } else if (fsm && fsm.bg_port && fsm.bg_connected) {
        fsm.send_port_request('STORE_FANTASY_SITE_USERNAME', { site: 'draftkings', username: normalized }).catch(() => { });
    }
    return normalized;
}

async function clear_stored_dk_username(fsm, reason) {
    const previous = _dk_resolved_username;
    _dk_resolved_username = null;
    if (previous) {
        await clear_cached_user_profile_dk(previous);
    }
    if (!fsm || !fsm.bg_port || !fsm.bg_connected) {
        return;
    }
    try {
        await fsm.send_port_request('CLEAR_FANTASY_SITE_USERNAME', { site: 'draftkings' });
    } catch (err) {
    }
}

async function get_stored_dk_username_from_background(fsm) {
    if (!fsm || !fsm.bg_port || !fsm.bg_connected) {
        return null;
    }
    try {
        const resp = await fsm.send_port_request('GET_FANTASY_SITE_USERNAME', { site: 'draftkings' });
        if (resp && resp.status === 'ok') {
            return normalize_dk_username(resp.username);
        }
    } catch (err) {
    }
    return null;
}

async function fetch_dk_username_from_me_json() {
    try {
        const response = await fetch(DK_ME_JSON_URL, {
            credentials: 'include',
            headers: {
                Accept: 'application/json',
                'Accept-Language': 'en-US,en;q=0.5',
                'Sec-Fetch-Dest': 'empty',
                'Sec-Fetch-Mode': 'cors',
                'Sec-Fetch-Site': 'same-site'
            },
            referrer: 'https://www.draftkings.com/',
            method: 'GET',
            mode: 'cors'
        });
        if (!response.ok) {
            console.error('[DK] me.json username fetch failed: HTTP', response.status);
            return null;
        }
        const data = await response.json();
        return normalize_dk_username(data && data.userName);
    } catch (err) {
        console.error('[DK] me.json username fetch error:', err && err.message ? err.message : err);
        return null;
    }
}

async function resolve_dk_username(fsm, options) {
    const forceRefresh = !!(options && options.forceRefresh);
    const skipDom = !!(options && options.skipDom);
    if (!forceRefresh && _dk_resolved_username) {
        return _dk_resolved_username;
    }
    if (_dk_username_resolve_promise) {
        return _dk_username_resolve_promise;
    }
    _dk_username_resolve_promise = (async () => {
        try {
            if (!forceRefresh) {
                const stored = await get_stored_dk_username_from_background(fsm);
                if (stored) {
                    _dk_resolved_username = stored;
                    return stored;
                }
            }

            // Legacy DOM is session-only: never persist it. Bad DOM scrapes used to stick
            // in fantasy:site_usernames until uninstall.
            if (!skipDom) {
                const fromDom = normalize_dk_username(extract_username_from_page_dom());
                if (fromDom) {
                    _dk_resolved_username = fromDom;
                    return fromDom;
                }
            }

            const fetched = await fetch_dk_username_from_me_json();
            if (fetched) {
                return persist_dk_username(fsm, fetched, 'me.json');
            }
            return null;
        } finally {
            _dk_username_resolve_promise = null;
        }
    })();
    return _dk_username_resolve_promise;
}

function maybe_sync_dk_site_username(fsm) {
    if (!fsm || !fsm.bg_port || !fsm.bg_connected) {
        return;
    }
    const now = Date.now();
    if (now - _lastDkSiteUsernameSyncAt < DK_SITE_USERNAME_SYNC_INTERVAL_MS) {
        return;
    }
    _lastDkSiteUsernameSyncAt = now;
    // skipDom: never persist unverified DOM scrapes via the sync path.
    resolve_dk_username(fsm, { skipDom: true }).catch(() => { });
}

async function get_cached_user_profile_dk(username) {
    if (!username) return null;
    try {
        const result = await new Promise(resolve => {
            chrome.storage.local.get([`dk_user_profile_${username}`], resolve);
        });
        return result[`dk_user_profile_${username}`] || null;
    } catch (err) {
        console.error('[DK] Error getting cached user profile:', err);
        return null;
    }
}

async function clear_cached_user_profile_dk(username) {
    if (!username) return;
    try {
        await new Promise(resolve => {
            chrome.storage.local.remove([`dk_user_profile_${username}`], resolve);
        });
    } catch (err) {
    }
}

// Helper function to cache user profile data
async function cache_user_profile_dk(username, userProfile) {
    if (!username || !userProfile) return;
    try {
        await new Promise(resolve => {
            chrome.storage.local.set({ [`dk_user_profile_${username}`]: userProfile }, resolve);
        });
    } catch (err) {
        console.error('[DK] Error caching user profile:', err);
    }
}

function is_valid_dk_user_profile_payload(data) {
    return !!(
        data &&
        data.userProfile &&
        Array.isArray(data.userProfile.enteredContests) &&
        !(data.errorStatus && Object.keys(data.errorStatus).length > 0)
    );
}

async function fetch_dk_user_profile_payload(username) {
    const normalized = normalize_dk_username(username);
    if (!normalized) {
        return { ok: false, reason: 'missing_username' };
    }
    const userApiUrl = `https://api.draftkings.com/contests/v1/users/${encodeURIComponent(normalized)}?format=json`;
    try {
        const response = await fetch(userApiUrl, {
            credentials: 'include',
            headers: {
                Accept: '*/*',
                'Accept-Language': 'en-US,en;q=0.5',
                'Sec-Fetch-Dest': 'empty',
                'Sec-Fetch-Mode': 'cors',
                'Sec-Fetch-Site': 'same-site'
            },
            referrer: 'https://www.draftkings.com/',
            method: 'GET',
            mode: 'cors'
        });
        if (!response.ok) {
            return { ok: false, reason: 'http_' + response.status, status: response.status, username: normalized };
        }
        const data = await response.json();
        if (data && data.errorStatus && Object.keys(data.errorStatus).length > 0) {
            return { ok: false, reason: 'error_status', errorStatus: data.errorStatus, username: normalized, data: data };
        }
        if (!data || !data.userProfile) {
            return { ok: false, reason: 'missing_user_profile', username: normalized, data: data };
        }
        if (!Array.isArray(data.userProfile.enteredContests)) {
            return { ok: false, reason: 'missing_entered_contests', username: normalized, data: data };
        }
        return { ok: true, username: normalized, data: data };
    } catch (err) {
        return {
            ok: false,
            reason: 'fetch_error',
            message: err && err.message ? err.message : String(err),
            username: normalized
        };
    }
}

// Fetch profile; on username-shaped failures clear stored garbage and retry once via me.json.
async function fetch_dk_user_profile_with_username_recovery(fsm) {
    let username = await resolve_dk_username(fsm);
    if (!username) {
        return { username: null, data: null, error: 'Failed to resolve DraftKings username from storage or me.json' };
    }

    let result = await fetch_dk_user_profile_payload(username);
    if (result.ok) {
        persist_dk_username(fsm, username, 'profile-validated');
        return { username: username, data: result.data };
    }

    const retryable =
        result.reason === 'error_status' ||
        result.reason === 'missing_user_profile' ||
        result.reason === 'http_404' ||
        result.reason === 'http_400';
    if (!retryable) {
        return {
            username: username,
            data: null,
            error: result.reason === 'fetch_error'
                ? (result.message || 'fetch_error')
                : (result.reason || 'profile_fetch_failed')
        };
    }

    if (typeof fsm._is_dev_or_local_env === 'function' && fsm._is_dev_or_local_env()) {
        const profileFailLog = {
            username: username,
            reason: result.reason
        };
    }
    await clear_stored_dk_username(fsm, result.reason);

    const refreshed = await resolve_dk_username(fsm, { forceRefresh: true, skipDom: true });
    if (!refreshed) {
        return { username: null, data: null, error: 'User profile API returned error status' };
    }
    if (refreshed === username) {
        // Same bad value from me.json — do not leave it stored.
        await clear_stored_dk_username(fsm, 'me.json_returned_unusable_username');
        return { username: refreshed, data: null, error: 'User profile API returned error status' };
    }

    result = await fetch_dk_user_profile_payload(refreshed);
    if (result.ok) {
        persist_dk_username(fsm, refreshed, 'profile-validated-retry');
        return { username: refreshed, data: result.data };
    }

    await clear_stored_dk_username(fsm, result.reason || 'profile_retry_failed');
    return {
        username: refreshed,
        data: null,
        error: result.reason === 'error_status'
            ? 'User profile API returned error status'
            : (result.message || result.reason || 'profile_fetch_failed')
    };
}

// Helper function to extract and cache all userContestIds from user profile
async function extract_and_cache_user_contest_ids(userProfile, draftId) {
    if (!userProfile || !userProfile.userProfile || !userProfile.userProfile.enteredContests) {
        return null;
    }

    const userContestIds = {};
    const enteredContests = userProfile.userProfile.enteredContests;

    // Extract userContestId for all contests in the profile
    for (const contest of enteredContests) {
        if (contest.contestKey && contest.entryKey) {
            userContestIds[contest.contestKey] = {
                userContestId: contest.entryKey,
                draftGroupId: contest.draftGroupId || null
            };
        }
    }

    // Merge with existing cache
    const existingCache = await new Promise(resolve => {
        chrome.storage.local.get(['draftKingsUserContestIds'], resolve);
    });
    const existingUserContestIds = existingCache.draftKingsUserContestIds || {};

    // Merge new data with existing (preserve tournamentRounds, entryFee, draftRounds if they exist)
    for (const [contestKey, newData] of Object.entries(userContestIds)) {
        if (existingUserContestIds[contestKey]) {
            // Merge: keep existing tournament data, update userContestId and draftGroupId
            existingUserContestIds[contestKey] = {
                ...existingUserContestIds[contestKey],
                userContestId: newData.userContestId,
                draftGroupId: newData.draftGroupId || existingUserContestIds[contestKey].draftGroupId
            };
        } else {
            existingUserContestIds[contestKey] = newData;
        }
    }

    // Save merged cache
    await new Promise(resolve => {
        chrome.storage.local.set({ draftKingsUserContestIds: existingUserContestIds }, resolve);
    });

    // Return userContestId for the requested draftId
    return userContestIds[draftId]?.userContestId || null;
}

let _dk_lineup_exposure_logged_href = null;
let _dk_mycontests_last_streamer_winning = null;

function extract_draft_kings_lineup_exposure_players() {
    const rows = document.querySelectorAll('div[role="row"].PlayerExposureTable_dk-grid-row');
    const players = [];
    rows.forEach((row) => {
        const nameCell = row.querySelector('.PlayerNameCell_player-name-cell');
        if (!nameCell) return;
        const fullName = (nameCell.getAttribute('aria-label') || '').trim();
        const displayEl = nameCell.querySelector('.PlayerNameCell_player-name');
        const displayName = displayEl ? displayEl.textContent.trim() : '';
        let position = '';
        let team = '';
        const ptContainer = nameCell.querySelector('.PlayerNameCell_position-and-team');
        if (ptContainer) {
            const divs = ptContainer.querySelectorAll(':scope > div');
            if (divs.length >= 3) {
                position = divs[0].textContent.trim();
                team = divs[2].textContent.trim();
            }
        }
        const detailCells = row.querySelectorAll('.PlayerExposureTable_detail-cell');
        let dollars = null;
        let exposurePct = null;
        if (detailCells.length >= 2) {
            const rawDollar = detailCells[0].textContent.trim();
            const rawPct = detailCells[1].textContent.trim();
            if (rawDollar.startsWith('$')) {
                const n = parseInt(rawDollar.slice(1), 10);
                dollars = Number.isNaN(n) ? null : n;
            }
            if (rawPct.endsWith('%')) {
                const n = parseFloat(rawPct.slice(0, -1));
                exposurePct = Number.isNaN(n) ? null : n;
            }
        }
        players.push({
            fullName,
            displayName,
            position,
            team,
            dollars,
            exposurePct
        });
    });
    return players;
}

function maybe_extract_and_log_dk_lineup_exposure(pageHref) {
    const key = pageHref.split('#')[0];
    if (_dk_lineup_exposure_logged_href === key) return;
    const players = extract_draft_kings_lineup_exposure_players();
    if (players.length === 0) return;
    _dk_lineup_exposure_logged_href = key;
    const payload = {
        source: 'draftkings_lineup_exposure',
        url: pageHref,
        players
    };
    // Single argument: live object, one console row, expandable in DevTools (no JSON.stringify)
}

function extract_dk_mycontests_currently_winning_value() {
    const header = document.querySelector('.header');
    if (!header) return null;
    const winningBlock = header.querySelector('.winning');
    if (!winningBlock) return null;

    // Keep read-only and don't click "Live"; DraftKings keeps this value in the DOM even when hidden.
    const liveValueEl = winningBlock.querySelector('.live p');
    if (!liveValueEl) return null;

    const raw = String(liveValueEl.textContent || '').trim();
    if (!raw) return null;
    return raw.slice(0, 64);
}

async function maybe_sync_dk_mycontests_streamer_data(fsm, url) {
    if (!fsm?.bg_port || !fsm?.bg_connected) return;
    const env = fsm.state_data?.env_value;
    const streamerEnabled = !!fsm.user_settings?.streamer_overlay_enabled;
    if (!streamerEnabled || !['dev', 'local'].includes(env)) {
        _dk_mycontests_last_streamer_winning = null;
        return;
    }
    const currently_winning = extract_dk_mycontests_currently_winning_value();
    if (!currently_winning) return;
    if (_dk_mycontests_last_streamer_winning === currently_winning) return;

    _dk_mycontests_last_streamer_winning = currently_winning;
    try {
        await fsm.send_port_request('SET_STREAMER_MODE_DATA', {
            data: {
                currently_winning,
                source_site: 'draftkings_mycontests',
                source_url: url
            }
        });
    } catch (err) {
        console.error('[DK] Failed to sync mycontests streamer data', err);
    }
}

const DK_MYCONTESTS_DRAFT_NOW_THROTTLE_MS = 60_000;

function parse_dk_mycontests_contest_ids_from_href(href) {
    if (!href) return null;

    let m = href.match(/\/contest\/draftteam\/(\d+)\?userContestId=(\d+)/);
    if (m) return { contestId: m[1], userContestId: m[2] };

    m = href.match(/\/contest\/gamecenter\/(\d+)\?uc=(\d+)/);
    if (m) return { contestId: m[1], userContestId: m[2] };

    return null;
}

function format_dk_mycontests_draft_now_label(picksAway) {
    if (picksAway === 0) return { number: null, text: 'On the clock' };
    if (picksAway === 1) return { number: '1', text: 'pick away' };
    if (picksAway > 1) return { number: String(picksAway), text: 'picks away' };
    return null;
}

function apply_dk_mycontests_draft_now_button_label(button, labelParts) {
    if (!button || !labelParts) return;

    const labelKey = labelParts.number ? `${labelParts.number} ${labelParts.text}` : labelParts.text;
    if (
        button.getAttribute('data-legup-dk-draft-now') === 'true'
        && button.getAttribute('data-legup-dk-draft-now-label') === labelKey
        && button.querySelector('img[data-legup-dk-draft-now-logo]')
    ) {
        return;
    }

    button.setAttribute('data-legup-dk-draft-now', 'true');
    button.setAttribute('data-legup-dk-draft-now-label', labelKey);
    button.removeAttribute('title');

    // Reclaim space from DK's default bold/all-caps Status button styles.
    button.style.setProperty('display', 'inline-flex', 'important');
    button.style.setProperty('align-items', 'center', 'important');
    button.style.setProperty('justify-content', 'flex-start', 'important');
    button.style.setProperty('gap', '4px', 'important');
    button.style.setProperty('font-weight', '400', 'important');
    button.style.setProperty('text-transform', 'none', 'important');
    button.style.setProperty('letter-spacing', 'normal', 'important');
    button.style.setProperty('line-height', '1.2', 'important');
    button.style.setProperty('white-space', 'nowrap', 'important');
    button.style.setProperty('overflow', 'hidden', 'important');
    button.style.setProperty('padding-left', '4px', 'important');
    button.style.setProperty('padding-right', '0', 'important');
    button.style.setProperty('min-width', '0', 'important');

    const isOnTheClock = !labelParts.number && labelParts.text === 'On the clock';
    if (isOnTheClock) {
        button.style.setProperty('outline', '2px solid #53d337', 'important');
        button.style.setProperty('outline-offset', '1px', 'important');
        button.style.setProperty('box-shadow', '0 0 0 1px rgba(83, 211, 55, 0.45)', 'important');
    } else {
        button.style.removeProperty('outline');
        button.style.removeProperty('outline-offset');
        button.style.removeProperty('box-shadow');
    }

    button.textContent = '';

    const logoImg = document.createElement('img');
    logoImg.src = chrome.runtime.getURL('assets/Sidekick_Favicon-DK.png');
    logoImg.alt = '';
    logoImg.setAttribute('data-legup-dk-draft-now-logo', 'true');
    logoImg.style.height = '11px';
    logoImg.style.width = 'auto';
    logoImg.style.objectFit = 'contain';
    logoImg.style.display = 'block';
    logoImg.style.flexShrink = '0';
    // drop-shadow follows opaque pixels (not the img box), so the S pops off DK yellow
    logoImg.style.filter = 'drop-shadow(0 0 1.5px rgba(0, 0, 0, 0.55)) drop-shadow(0 1px 1px rgba(0, 0, 0, 0.35))';

    const textWrap = document.createElement('span');
    textWrap.setAttribute('data-legup-dk-draft-now-text', 'true');
    textWrap.style.setProperty('display', 'inline-flex', 'important');
    textWrap.style.setProperty('align-items', 'baseline', 'important');
    textWrap.style.setProperty('gap', '3px', 'important');
    textWrap.style.setProperty('font-weight', '400', 'important');
    textWrap.style.setProperty('text-transform', 'none', 'important');
    textWrap.style.setProperty('letter-spacing', 'normal', 'important');
    textWrap.style.setProperty('font-family', 'system-ui, -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif', 'important');
    textWrap.style.setProperty('min-width', '0', 'important');
    textWrap.style.setProperty('overflow', 'hidden', 'important');
    textWrap.style.setProperty('text-overflow', 'clip', 'important');
    textWrap.style.setProperty('white-space', 'nowrap', 'important');
    textWrap.style.setProperty('flex', '1 1 auto', 'important');

    if (labelParts.number) {
        const numberEl = document.createElement('span');
        numberEl.textContent = labelParts.number;
        numberEl.style.setProperty('font-size', '11px', 'important');
        numberEl.style.setProperty('flex-shrink', '0', 'important');
        textWrap.appendChild(numberEl);
    }

    const labelEl = document.createElement('span');
    labelEl.textContent = labelParts.text;
    labelEl.style.setProperty('font-size', '10px', 'important');
    labelEl.style.setProperty('min-width', '0', 'important');
    labelEl.style.setProperty('overflow', 'hidden', 'important');
    labelEl.style.setProperty('text-overflow', 'clip', 'important');
    labelEl.style.setProperty('white-space', 'nowrap', 'important');
    textWrap.appendChild(labelEl);

    button.appendChild(logoImg);
    button.appendChild(textWrap);
}

async function cache_dk_mycontests_user_contest_id(contestId, userContestId) {
    const cacheResult = await new Promise(resolve => {
        chrome.storage.local.get(['draftKingsUserContestIds'], resolve);
    });
    const userContestIds = (cacheResult && cacheResult.draftKingsUserContestIds) || {};
    const existing = userContestIds[contestId];
    const next = (existing && typeof existing === 'object')
        ? { ...existing, userContestId }
        : { userContestId, draftGroupId: null, tournamentRounds: null };

    if (existing && existing.userContestId === userContestId
        && existing.draftGroupId === next.draftGroupId
        && existing.tournamentRounds === next.tournamentRounds) {
        return;
    }

    userContestIds[contestId] = next;
    await new Promise(resolve => {
        chrome.storage.local.set({ draftKingsUserContestIds: userContestIds }, resolve);
    });
}

async function resolve_dk_mycontests_pick_slot(contestId, draftBoard, lineup, draftSize) {
    let pickSlot = null;

    if (Array.isArray(lineup) && lineup.length > 0 && Array.isArray(draftBoard)) {
        draftBoard.slice(0, draftSize).forEach((pick, index) => {
            if (pickSlot === null && lineup.includes(pick.draftableId)) {
                pickSlot = index + 1;
            }
        });
    }

    if (pickSlot != null) {
        const cacheResult = await new Promise(resolve => {
            chrome.storage.local.get(['draftKingsPickSlots'], resolve);
        });
        const pickSlots = (cacheResult && cacheResult.draftKingsPickSlots) || {};
        if (pickSlots[contestId] !== pickSlot) {
            pickSlots[contestId] = pickSlot;
            await new Promise(resolve => {
                chrome.storage.local.set({ draftKingsPickSlots: pickSlots }, resolve);
            });
        }
        return pickSlot;
    }

    const cacheResult = await new Promise(resolve => {
        chrome.storage.local.get(['draftKingsPickSlots'], resolve);
    });
    const pickSlots = (cacheResult && cacheResult.draftKingsPickSlots) || {};
    return pickSlots[contestId] || null;
}

async function get_cached_dk_mycontests_draft_rounds(fsm, contestId) {
    const mem = fsm?.state_data?.draft_kings_tournament_cache?.[contestId]?.draftRounds;
    if (mem != null && Number.isFinite(Number(mem)) && Number(mem) > 0) {
        return Math.round(Number(mem));
    }

    const cacheResult = await new Promise(resolve => {
        chrome.storage.local.get(['draftKingsUserContestIds'], resolve);
    });
    const cached = cacheResult?.draftKingsUserContestIds?.[contestId];
    const stored = cached?.draftRounds;
    if (stored != null && Number.isFinite(Number(stored)) && Number(stored) > 0) {
        return Math.round(Number(stored));
    }
    return null;
}

async function update_dk_mycontests_draft_now_button(fsm, button, draftStatus, contestId) {
    if (!button || !draftStatus) return;

    let draftBoard = Array.isArray(draftStatus.draftBoard) ? draftStatus.draftBoard : null;
    if (!draftBoard) {
        return;
    }

    draftBoard = draftBoard.filter(pick => pick.playerId && pick.draftableId && pick.selectionTime);
    const draftSizeResolved = resolveDkDraftSize({
        contestData: null,
        advancement_structure: null,
        users: draftStatus.users
    });
    const draftSize = draftSizeResolved.draftSize || 12;

    // If we already know draftRounds (typical after visiting a completed draft), stop enriching once full.
    const draftRounds = await get_cached_dk_mycontests_draft_rounds(fsm, contestId);
    if (draftRounds != null && draftBoard.length >= draftSize * draftRounds) {
        return;
    }

    const pickSlot = await resolve_dk_mycontests_pick_slot(
        contestId,
        draftBoard,
        draftStatus.lineup,
        draftSize
    );
    if (pickSlot == null) {
        return;
    }

    const picksAway = calculate_picks_away(draftBoard, pickSlot, draftSize);
    const labelParts = format_dk_mycontests_draft_now_label(picksAway);
    if (!labelParts) return;
    apply_dk_mycontests_draft_now_button_label(button, labelParts);
}

async function enrich_dk_mycontests_draft_now_buttons(fsm) {
    const buttons = document.querySelectorAll('a[href*="/contest/"]');
    if (!buttons.length) return;

    const tasks = [];
    buttons.forEach((button) => {
        if (/edit/i.test((button.textContent || '').trim())) return;

        const ids = parse_dk_mycontests_contest_ids_from_href(button.getAttribute('href'));
        if (!ids) return;

        tasks.push((async () => {
            try {
                await cache_dk_mycontests_user_contest_id(ids.contestId, ids.userContestId);
                const draftStatusResult = await fetchDkDraftStatusForExposure(ids.contestId, ids.userContestId);
                if (!draftStatusResult || !draftStatusResult.ok || !draftStatusResult.data) return;
                await update_dk_mycontests_draft_now_button(fsm, button, draftStatusResult.data, ids.contestId);
            } catch (err) {
                console.error('[DK] mycontests Draft Now enrichment failed', ids.contestId, err);
            }
        })());
    });

    if (!tasks.length) return;
    await Promise.all(tasks);
}

async function maybe_enrich_dk_mycontests_draft_now_buttons(fsm) {
    if (!fsm?.state_data) return;

    const now = Date.now();
    const last = fsm.state_data.last_dk_mycontests_draft_now_api_call || 0;
    if (now - last < DK_MYCONTESTS_DRAFT_NOW_THROTTLE_MS) return;

    // Don't burn the throttle while the mycontests list is still mounting.
    const buttons = document.querySelectorAll('a[href*="/contest/"]');
    let hasContestLink = false;
    for (const button of buttons) {
        if (/edit/i.test((button.textContent || '').trim())) continue;
        if (parse_dk_mycontests_contest_ids_from_href(button.getAttribute('href'))) {
            hasContestLink = true;
            break;
        }
    }
    if (!hasContestLink) return;

    fsm.state_data.last_dk_mycontests_draft_now_api_call = now;
    try {
        await enrich_dk_mycontests_draft_now_buttons(fsm);
    } catch (err) {
        console.error('[DK] mycontests Draft Now enrichment error', err);
    }
}

async function extract_draft_kings_draft_data(fsm) {
    // console.log('[DK] extract_draft_kings_draft_data called');
    const url = window.location.href;

    maybe_sync_dk_site_username(fsm);

    if (!is_draft_kings_lineup_url(url)) {
        _dk_lineup_exposure_logged_href = null;
    } else {
        maybe_extract_and_log_dk_lineup_exposure(url);
        return null;
    }

    if (!fsm || !fsm.state_data) {
        console.error('[DK] FSM not available');
        return null;
    }

    if (!fsm.session_data || !fsm.session_data.user_uuid) {
        return null;
    }

    // console.log('[DK] Current URL:', url);

    // My contests: streamer sync + Draft Now button enrichment (no rankings extraction)
    if (is_draft_kings_my_contests_url(url)) {
        maybe_sync_dk_mycontests_streamer_data(fsm, url);
        maybe_enrich_dk_mycontests_draft_now_buttons(fsm);
        return null;
    }

    // Skip rankings page
    if (url.startsWith("https://www.draftkings.com/draft/rankings/nfl")) {
        return null;
    }

    // Path-only tournament lobby (/draft/tournament/{uuid}) — no snake contest key yet.
    if (typeof is_draft_kings_waiting_room_url === 'function' && is_draft_kings_waiting_room_url(url)) {
        const extractionSource = (typeof EXTRACTION_ERROR_WARNING_SOURCE !== 'undefined')
            ? EXTRACTION_ERROR_WARNING_SOURCE
            : 'extraction_error';
        if (typeof fsm.clear_urgent_warning_notification === 'function') {
            fsm.clear_urgent_warning_notification(extractionSource);
        }
        fsm.extraction_error_details = [];
        return null;
    }

    const draftId = get_draftkings_draft_id_from_url(url);
    // console.log('[DK] Extracted draftId from URL:', draftId);
    if (!draftId) {
        return null;
    }

    // Check if contest is in "Entered" state (lobby - draft hasn't started yet)
    // Look for the "Entered" button which indicates the contest is completed/entered but draft hasn't started
    // The button is inside a div with class "ContestDetails_completed" and has class "DKButtonLegacy_dk-btn-inactive" and is disabled
    const enteredButtonContainer = document.querySelector('.ContestDetails_completed');
    if (enteredButtonContainer) {
        const enteredButton = enteredButtonContainer.querySelector('button.DKButtonLegacy_dk-btn-inactive[disabled]');
        if (enteredButton) {
            const buttonText = enteredButton.textContent.trim();
            if (buttonText.includes('Entered')) {
                return null;
            }
        }
    }

    // draftStatus 404 backoff (pre-start snake rooms, often with ?tournament=).
    // If the DOM already shows on-the-clock, the draft is live — clear backoff and fetch.
    if (typeof get_current_pick_number === 'function' && get_current_pick_number() != null) {
        clear_dk_draft_status_backoff(fsm, draftId);
    } else if (typeof is_dk_draft_status_backoff_active === 'function' && is_dk_draft_status_backoff_active(fsm, draftId)) {
        return null;
    }

    // Initialize state_data variables if needed
    if (fsm.state_data.draft_kings_previous_pick_number === undefined) {
        fsm.state_data.draft_kings_previous_pick_number = null;
    }
    if (!fsm.state_data.draft_kings_cache) {
        fsm.state_data.draft_kings_cache = {};
    }
    if (!fsm.state_data.lastDkSlateApiCall) {
        fsm.state_data.lastDkSlateApiCall = null;
    }

    // Fetch slates if user is whitelisted (rate limited to once per minute)
    const user_uuid = fsm.session_data.user_uuid;
    if (DK_SLATES_WHITELIST.includes(user_uuid)) {
        const now = Date.now();
        if (!fsm.state_data.lastDkSlateApiCall ||
            (now - fsm.state_data.lastDkSlateApiCall) >= DK_SLATE_API_COOLDOWN_MS) {
            fsm.state_data.lastDkSlateApiCall = now;
            // Run slate fetching in background (don't await, don't block extraction)
            fetch_draft_kings_slates(fsm).catch(err => {
                console.error('[DK Slates] Error fetching slates:', err);
            });
        }
    }

    // Check if draft changed
    const lastSent = fsm.state_data.last_sent;
    // Normalize lastSent.draft.draft_id to numeric only (in case it has old format with "-snake")
    const lastSentDraftId = lastSent?.draft?.draft_id ? lastSent.draft.draft_id.split('-')[0] : null;
    const draftChanged = !lastSent || lastSentDraftId !== draftId;

    if (draftChanged) {
        // Draft changed - clear cache and reset pick tracking
        fsm.state_data.draft_kings_cache = {};
        fsm.state_data.draft_kings_previous_pick_number = null;
        // Clear tournament cache for old draft (keep it for new draft if it exists)
        if (fsm.state_data.draft_kings_tournament_cache) {
            // Only clear the old draft's cache entry, not the entire cache
            const oldDraftId = lastSentDraftId;
            if (oldDraftId && fsm.state_data.draft_kings_tournament_cache[oldDraftId]) {
                delete fsm.state_data.draft_kings_tournament_cache[oldDraftId];
            }
        }
    }

    // Check if we have cached data
    const hasCache = fsm.state_data.draft_kings_cache[draftId];

    // Calculate current pick number
    // First try to get from DOM (when someone is on the clock)
    let currentPick = get_current_pick_number();

    // If DOM doesn't have it, calculate from cached API data
    if (currentPick === null && hasCache) {
        const cached = fsm.state_data.draft_kings_cache[draftId];
        const draft = cached.draft;
        if (draft && draft.picks && draft.draft_size && draft.num_rounds) {
            const totalPicks = draft.picks.length;
            const maxPicks = draft.draft_size * draft.num_rounds;
            // If draft is complete, current pick is maxPicks (total number of picks), otherwise it's totalPicks + 1
            currentPick = totalPicks >= maxPicks ? maxPicks : totalPicks + 1;
        }
    }

    const previousPickNumber = fsm.state_data.draft_kings_previous_pick_number;
    // console.log('[DK] Current pick:', currentPick, 'Previous pick:', previousPickNumber);

    // Only fetch if pick number changed (meaning a new pick was made)
    if (currentPick !== null && currentPick !== previousPickNumber) {
        fsm.state_data.draft_kings_previous_pick_number = currentPick;
        return await fetch_draft_status(fsm, draftId);
    } else if (hasCache) {
        // Use cached data if available - return cached extraction result to prevent accidental clears
        // console.log('[DK] Using cached data for draftId:', draftId);
        const cached = fsm.state_data.draft_kings_cache[draftId];

        // Update previous pick number from cache if we don't have it yet
        if (previousPickNumber === null && currentPick !== null) {
            fsm.state_data.draft_kings_previous_pick_number = currentPick;
        }

        const result = {
            draft: cached.draft,
            advancement_structure: cached.advancement_structure,
            tournament_info: cached.tournament_info
        };

        // Cache result for safe skip mechanism (similar to Underdog)
        fsm.state_data.last_extraction_result = result;

        return result;
    } else {
        // No cache - fetch at least once
        return await fetch_draft_status(fsm, draftId);
    }
}

async function fetch_draft_status(fsm, draftId) {
    let draftGroupId = null;
    let tournamentRounds = null;
    let entryFee = null;
    let draftRounds = null;
    let storedDraftId = null;
    let userContestId = null;

    // Check content script memory cache first (reduces background chatter when multiple tabs open)
    if (!fsm.state_data.draft_kings_tournament_cache) {
        fsm.state_data.draft_kings_tournament_cache = {};
    }
    const tournamentCache = fsm.state_data.draft_kings_tournament_cache[draftId];
    if (tournamentCache) {
        tournamentRounds = tournamentCache.tournamentRounds;
        entryFee = tournamentCache.entryFee;
        draftRounds = tournamentCache.draftRounds;
    }

    // Check cache for user contest IDs (shared across tabs via chrome.storage.local)
    const cacheResult = await new Promise(resolve => {
        chrome.storage.local.get(['draftKingsUserContestIds'], resolve);
    });
    const userContestIds = (cacheResult && cacheResult.draftKingsUserContestIds) || {};

    // Lookup cached user contest data
    if (userContestIds[draftId]) {
        const cached = userContestIds[draftId];
        userContestId = cached.userContestId;
        draftGroupId = cached.draftGroupId;
        // Only use from userContestIds if not already in content script cache
        if (!tournamentRounds) tournamentRounds = cached.tournamentRounds;
        if (!entryFee) entryFee = cached.entryFee;
        if (!draftRounds) draftRounds = cached.draftRounds;
        storedDraftId = draftId;

        // Cache tournament summary in content script memory to reduce background requests
        if (tournamentRounds || entryFee || draftRounds) {
            fsm.state_data.draft_kings_tournament_cache[draftId] = {
                tournamentRounds,
                entryFee,
                draftRounds
            };
        }
    }

    // Fetch contest data from background script if needed
    let contestData = null;
    if (!draftGroupId) {
        try {
            contestData = await get_dk_contest_data_from_background(draftId);
            if (contestData) {
                // Note: contestData is fetched from background cache, not stored in content script

                if (contestData.contestDetail?.sport !== "NFL") {
                    return null;
                }

                // Get draftGroupId
                draftGroupId = contestData.contestDetail?.draftGroupId;
                if (!draftGroupId) {
                    console.error("[DK] draftGroupId not found in contestDetail");
                    dk_extraction_fail('draftGroupId not found in contestDetail');
                }
            } else {
                console.error("[DK] Failed to fetch contest data from background script");
                dk_extraction_fail('Failed to fetch contest data from background script');
            }
        } catch (error) {
            console.error(`[DK] Error fetching contest data: ${error}`);
            dk_extraction_fail(`Error fetching contest data: ${error && error.message ? error.message : error}`);
        }
    } else {
        // We have draftGroupId from cache, but we still need contestData for tournament key lookup
        // Fetch from background cache (not stored in content script memory)
        contestData = await get_dk_contest_data_from_background(draftId);
    }

    // Fetch tournament data from background script if needed
    if ((!tournamentRounds || !entryFee || !draftRounds) && contestData) {

        const tournamentKey = contestData.contestDetail?.attributes?.TournamentKey;
        if (tournamentKey) {

            try {
                // Fetch tournament data from background cache (full data stays in background)
                const tournamentData = await get_dk_tournament_data_from_background(draftId, tournamentKey);
                if (tournamentData) {
                    // Extract only what we need - store trimmed summary in content script cache to reduce background chatter
                    tournamentRounds = tournamentRounds || tournamentData.tournamentDetail?.rounds || null;
                    entryFee = entryFee || tournamentData.tournamentDetail?.entryFee || null;
                    draftRounds = draftRounds || tournamentData.tournamentDetail?.draftRounds || null;

                    // Cache trimmed tournament summary in content script memory (reduces background requests for multiple tabs)
                    if (!fsm.state_data.draft_kings_tournament_cache) {
                        fsm.state_data.draft_kings_tournament_cache = {};
                    }
                    fsm.state_data.draft_kings_tournament_cache[draftId] = {
                        tournamentRounds,
                        entryFee,
                        draftRounds
                    };

                    if (draftRounds === null || draftRounds === undefined) {
                    }
                } else {
                    console.error("[DK] Failed to fetch tournament data from background script");
                }
            } catch (err) {
                console.error("[DK] Error fetching tournament data from background script:", err);
            }
        }
    }

    // Persist user contest data if we have new information
    if (draftGroupId && (!userContestIds[draftId] || !userContestIds[draftId].draftGroupId)) {
        userContestIds[storedDraftId || draftId] = {
            userContestId: userContestId || null,
            draftGroupId,
            tournamentRounds,
            entryFee,
            draftRounds
        };
        await new Promise(resolve => {
            chrome.storage.local.set({ draftKingsUserContestIds: userContestIds }, resolve);
        });
        rememberDkDraftGroupIdForExposure(fsm, storedDraftId || draftId, draftGroupId);
    }

    // Fetch userContestId if still missing
    if (!userContestId) {
        const usernameHint = await resolve_dk_username(fsm);
        if (!usernameHint) {
            console.error("[DK] Failed to resolve DraftKings username from storage or me.json.");
            dk_extraction_fail('Failed to resolve DraftKings username from storage or me.json');
        }


        // First, try to get from cached user profile (stored on disk, not in content script memory)
        let userProfile = await get_cached_user_profile_dk(usernameHint);
        if (userProfile && !is_valid_dk_user_profile_payload(userProfile)) {
            await clear_cached_user_profile_dk(usernameHint);
            userProfile = null;
        }

        if (userProfile) {

            // Extract userContestId from cached profile
            userContestId = await extract_and_cache_user_contest_ids(userProfile, draftId);

            if (userContestId) {
                storedDraftId = draftId;
                // Update userContestIds cache with the found userContestId
                const updatedCache = await new Promise(resolve => {
                    chrome.storage.local.get(['draftKingsUserContestIds'], resolve);
                });
                const updatedUserContestIds = updatedCache.draftKingsUserContestIds || {};
                if (updatedUserContestIds[draftId]) {
                    draftGroupId = draftGroupId || updatedUserContestIds[draftId].draftGroupId;
                }
            }
        }

        // If we still don't have userContestId, fetch user profile from API
        // (invalidates stored garbage usernames and retries once via me.json).
        if (!userContestId) {
            try {
                const recovered = await fetch_dk_user_profile_with_username_recovery(fsm);
                if (!recovered || !recovered.data) {
                    console.error("[DK] Failed to fetch user profile:", recovered && recovered.error);
                    dk_extraction_fail(
                        recovered && recovered.error
                            ? `Error fetching user profile: ${recovered.error}`
                            : 'Error fetching user profile: User profile API returned error status'
                    );
                }

                const username = recovered.username;
                const data = recovered.data;

                await cache_user_profile_dk(username, data);
                userContestId = await extract_and_cache_user_contest_ids(data, draftId);

                if (userContestId) {
                    storedDraftId = draftId;
                    const updatedCache = await new Promise(resolve => {
                        chrome.storage.local.get(['draftKingsUserContestIds'], resolve);
                    });
                    const updatedUserContestIds = updatedCache.draftKingsUserContestIds || {};
                    if (updatedUserContestIds[draftId]) {
                        draftGroupId = draftGroupId || updatedUserContestIds[draftId].draftGroupId;
                    }
                } else {
                    console.error("[DK] Failed to find the matching contestKey in the entered contests.");
                    dk_extraction_fail('Failed to find matching contestKey in entered contests');
                }
            } catch (error) {
                console.error(`[DK] Error fetching user profile: ${error}`);
                dk_extraction_fail(`Error fetching user profile: ${error && error.message ? error.message : error}`);
            }
        }
    }

    if (!userContestId) {
        console.error('[DK] userContestId still missing after profile lookup');
        dk_extraction_fail('userContestId missing after profile lookup');
    }

    // Now grab the live draft status
    const draftStatusApiUrl = `https://api.draftkings.com/drafts/v1/${storedDraftId}/entries/${userContestId}/draftStatus?format=json`;

    try {
        const response = await fetch(draftStatusApiUrl, {
            credentials: 'include',
            headers: {
                "Accept": "*/*",
                "Accept-Language": "en-US,en;q=0.5",
                "Sec-Fetch-Dest": "empty",
                "Sec-Fetch-Mode": "cors",
                "Sec-Fetch-Site": "same-site"
            },
            referrer: "https://www.draftkings.com/",
            method: "GET",
            mode: "cors"
        });

        if (!response.ok) {
            console.error(`[DK] Failed to fetch draft status: ${response.status}`);
            if (response.status === 404) {
                note_dk_draft_status_not_ready(fsm, draftId, 404);
                return null;
            }
            dk_extraction_fail(`draftStatus HTTP ${response.status}`);
        }

        const data = await response.json();
        clear_dk_draft_status_backoff(fsm, draftId);

        // Process the draft data and return draft state object
        // Note: rawApiResponses are no longer passed/stored - data stays in background cache only
        rememberDkDraftGroupIdForExposure(fsm, draftId, draftGroupId);
        return process_draft_data(
            fsm,
            data,
            draftGroupId,
            draftId,
            tournamentRounds,
            entryFee,
            userContestId,
            draftRounds,
            contestData
        );
    } catch (err) {
        // Soft not-ready path already returned null; don't wrap as a hard extraction failure.
        if (err && /draftStatus HTTP 404/i.test(err.message || '')) {
            note_dk_draft_status_not_ready(fsm, draftId, 404);
            return null;
        }
        console.error("[DK] Error fetching draft status data:", err?.message || err);
        dk_extraction_fail(`Error fetching draft status: ${err && err.message ? err.message : err}`);
    }
}

async function process_draft_data(
    fsm,
    data,
    draftGroupId,
    draftId,
    tournamentRounds,
    entryFee,
    userContestId,
    draftRounds = null,
    contestData = null
) {

    // Parse advancement structure from tournament rounds
    let advancement_structure = parse_draft_kings_advancement(tournamentRounds) || null;

    // Parse payout structure from tournament rounds
    const payout_structure = parse_draft_kings_payouts(tournamentRounds);

    // Create tournament_info object
    const contest_detail = contestData?.contestDetail || {};
    const contest_title = contest_detail.contestName ||
        contest_detail.name ||
        contest_detail.contestTitle ||
        contest_detail.attributes?.ContestName ||
        null;
    const contest_type = contest_detail.contestType || contest_detail.gameTypeName || null;

    const tournament_info = {
        "id": userContestId,
        "title": contest_title,
        "contest_type": contest_type,
        "advancement_structure": advancement_structure,
        "payout_structure": payout_structure,
        "entry_fee": entryFee,
        "draft_size": null
    };

    const clonedData = JSON.parse(JSON.stringify(data));
    let { draftBoard, users, playerPool, lineup, lineupTemplate, draftStartTime } = clonedData;

    // Filter draft board to only include valid picks
    draftBoard = draftBoard.filter(pick => pick.playerId && pick.draftableId && pick.selectionTime);

    // Draft size: tournament round 1 contestSize, contest maximumEntries, DOM seat count, then users.length.
    const dkDraftSizeResolved = resolveDkDraftSize({ contestData, advancement_structure, users });
    const draftSize = dkDraftSizeResolved.draftSize;
    if (!draftSize) {
        dk_extraction_fail('Unable to determine draft size');
    }

    if (fsm && typeof fsm._is_dev_or_local_env === 'function' && fsm._is_dev_or_local_env()) {
        const s = dkDraftSizeResolved.sources;
        const mismatchCandidates = [s.advancement, s.contest, s.dom, s.users].filter((v) => v != null);
        const mismatchUnique = Array.from(new Set(mismatchCandidates));
        if (mismatchUnique.length > 1) {
            const dkDraftSizeMismatchDbg = {
                advancement: s.advancement,
                contest: s.contest,
                dom: s.dom,
                users: s.users
            };
        }
    }

    if (!advancement_structure) {
        advancement_structure = { regular_season_denom: draftSize, raw_string: null };
    } else if (advancement_structure.regular_season_denom == null) {
        advancement_structure = { ...advancement_structure, regular_season_denom: draftSize };
    }

    tournament_info.advancement_structure = advancement_structure;
    tournament_info.draft_size = draftSize;

    // Determine pick slot
    let pickSlot = null;

    if (lineup && lineup.length > 0) {
        draftBoard.slice(0, draftSize).forEach((pick, index) => {
            if (pickSlot === null && lineup.includes(pick.draftableId)) {
                pickSlot = index + 1;
            }
        });
    }

    if (pickSlot === null) {
        const firstUserCard = document.querySelector('.UserCard_is-active-user');
        if (firstUserCard) {
            const pickNumberElement = firstUserCard.querySelector('.UserCard_information-top');
            if (pickNumberElement) {
                const match = pickNumberElement.textContent.match(/\d+/);
                if (match) {
                    const pickNumber = parseInt(match[0]);
                    pickSlot = pickNumber % draftSize || draftSize;

                    // Store the pickSlot in local storage
                    chrome.storage.local.get(['draftKingsPickSlots'], (result) => {
                        const pickSlots = result.draftKingsPickSlots || {};
                        pickSlots[draftId] = pickSlot;
                        chrome.storage.local.set({ draftKingsPickSlots: pickSlots }, () => {
                        });
                    });
                }
            }
        }
    }

    if (pickSlot === null) {
        // Try to get from cache synchronously
        const cacheResult = await new Promise(resolve => {
            chrome.storage.local.get(['draftKingsPickSlots'], resolve);
        });
        const pickSlots = cacheResult.draftKingsPickSlots || {};
        pickSlot = pickSlots[draftId] || null;
        if (pickSlot) {
        }
    }

    if (pickSlot === null) {
        dk_extraction_fail('Unable to determine pick slot');
    }

    // Calculate picks away
    const picksAway = calculate_picks_away(draftBoard, pickSlot, draftSize);

    if (picksAway === null) {
        dk_extraction_fail('Unable to determine picks away from draft board');
    }

    // Get number of rounds from tournament API response
    if (draftRounds === null || draftRounds === undefined) {
        console.error("[DK] draftRounds not available from tournament API");
        if (rawApiResponses?.tournament) {
        } else {
        }
        dk_extraction_fail('draftRounds not available from tournament API');
    }
    const numRounds = draftRounds;

    // Build picks array in the format expected by the system
    const picks = draftBoard.map(pick => ({
        dk_id: pick.playerId
    }));

    // Build draft object
    const draft = {
        draft_id: draftId,
        custom_title: document.querySelector('.Header_subtitle-text[data-testid="snake-draft-header-children"]')?.innerText.trim() || null,
        site_name: 'DraftKings',
        draft_size: draftSize,
        num_rounds: numRounds,
        pick_slot: pickSlot,
        picks: picks
    };

    // Cache only trimmed data (rawApiResponses stay in background cache, not stored in content script)
    // Note: tournament can be null if there's no tournament key, which is valid
    fsm.state_data.draft_kings_cache[draftId] = {
        draft,
        advancement_structure,
        tournament_info
    };


    // Calculate and update current pick number from API data
    const totalPicks = draftBoard.length;
    const maxPicks = draftSize * numRounds;
    // If draft is complete, current pick is maxPicks (total number of picks), otherwise it's totalPicks + 1
    const calculatedCurrentPick = totalPicks >= maxPicks ? maxPicks : totalPicks + 1;
    fsm.state_data.draft_kings_previous_pick_number = calculatedCurrentPick;

    // Update document title based on picks away
    if (picksAway === 0) {
        document.title = "On the clock";
    } else if (picksAway === 1) {
        document.title = `${picksAway} Pick away`;
    } else if (picksAway !== null) {
        document.title = `${picksAway} Picks away`;
    }


    const result = {
        draft: draft,
        advancement_structure: advancement_structure,
        tournament_info: tournament_info
    };

    // Cache result for safe skip mechanism (similar to Underdog)
    fsm.state_data.last_extraction_result = result;

    return result;
}

function get_current_pick_number() {
    const onTheClockPickNumberElement = document.querySelector('.UserCard_user-card.UserCard_on-the-clock .UserCard_information-top');
    let currentPick = null;
    if (onTheClockPickNumberElement) {
        const match = onTheClockPickNumberElement.textContent.match(/\d+/);
        if (match) {
            currentPick = parseInt(match[0]);
        }
    }
    return currentPick;
}

function extract_username_from_page_dom() {
    // Legacy account bar only — standardized header no longer exposes username in the DOM.
    const accountMenu =
        document.querySelector('[data-testid="standardized-header-account-menu"]') ||
        document.querySelector('#standardized-header-account-menu');
    if (accountMenu) {
        return null;
    }

    const accountContainer = document.querySelector('#account-container');
    if (!accountContainer) {
        return null;
    }

    // Find the account dropdown button
    const accountDropdown = accountContainer.querySelector('[data-test-id="account-dropdown"]');
    if (!accountDropdown) {
        return null;
    }

    // First try: extract from aria-label (most reliable)
    // Format is: "username account dropdown"
    const ariaLabel = accountDropdown.getAttribute('aria-label');
    if (ariaLabel) {
        const match = ariaLabel.match(/^([^\s]+)\s+account dropdown$/i);
        if (match && match[1]) {
            const username = match[1];
            return username;
        }
    }

    // Fallback: find the first direct child span with text content
    // The username span is a direct child of the account dropdown (after the img)
    const directChildren = Array.from(accountDropdown.children);
    for (const child of directChildren) {
        if (child.tagName === 'SPAN') {
            const text = child.textContent.trim();
            // Skip empty spans and spans that contain nested elements (icons)
            if (text && text.length > 0 && text.length < 50 && !child.querySelector('span')) {
                const username = text;
                return username;
            }
        }
    }

    return null;
}

function extract_username_from_page() {
    return _dk_resolved_username || extract_username_from_page_dom();
}

function calculate_picks_away(draftBoard, pickSlot, draftSize) {
    if (!pickSlot || !draftSize) return null;

    const lastPick = draftBoard[draftBoard.length - 1];
    const lastPickNumber = lastPick ? lastPick.overallSelectionNumber : 0;

    let currentRound = Math.ceil(lastPickNumber / draftSize);
    const picksInCurrentRound = lastPickNumber % draftSize;
    if (picksInCurrentRound === 0) {
        currentRound++;
    }

    let picksAway;
    const evenPickSlot = draftSize + 1 - pickSlot;

    if (currentRound % 2 !== 0) {
        if (picksInCurrentRound < pickSlot) {
            picksAway = pickSlot - picksInCurrentRound - 1;
        } else {
            picksAway = (draftSize - picksInCurrentRound) + (draftSize - pickSlot);
        }
    } else {
        if (picksInCurrentRound < evenPickSlot) {
            picksAway = evenPickSlot - picksInCurrentRound - 1;
        } else {
            picksAway = (draftSize - picksInCurrentRound) + (pickSlot - 1);
        }
    }

    return picksAway;
}

function build_player_data_map(lineupTemplate, playerPool, teamNames) {
    // Map DraftKings roster slot IDs to positions
    const dkPosMap = lineupTemplate.reduce((map, item) => {
        const { id, name } = item.rosterSlot;
        if (["QB", "RB", "WR", "TE"].includes(name)) {
            map[id] = name;
        }
        return map;
    }, {});

    // Build a mapping of player data
    const playerDataMap = playerPool.draftablePlayers.reduce((acc, player) => {
        const position = player.draftableRosterPositions
            .map(pos => dkPosMap[pos.rosterPositionId] || null)
            .filter(pos => pos !== null)[0] || null;

        let team = "Unknown Team";
        const teamEntry = Object.keys(teamNames).find(key => teamNames[key].dkId === player.teamId);
        if (teamEntry) {
            team = teamEntry;
        } else {
            team = player.teamId;
        }

        acc[player.playerId] = {
            displayName: player.displayName,
            firstName: player.firstName,
            lastName: player.lastName,
            shortName: player.shortName,
            team: team,
            position: position,
            adp: player.averageDraftPosition
        };

        return acc;
    }, {});

    return playerDataMap;
}

// parse_draft_kings_advancement / parse_draft_kings_payouts moved to
// shared_dk_tournament_parsers.js (loaded in both content-script and
// background contexts via manifest.json).

function is_draft_kings_my_contests_url(url) {
    return /draftkings\.com\/mycontests/i.test(url);
}

async function fetch_draft_kings_slates(fsm) {
    if (!fsm || !fsm.state_data || !fsm.bg_port || !fsm.bg_connected) {
        console.error('[DK Slates] FSM or background port not available');
        return;
    }

    try {
        // Step 1: Fetch lobbies summary to discover draft groups
        const summaryResponse = await fetch("https://api.draftkings.com/lobbies/v1/lobbies/summary?format=json", {
            credentials: "same-origin",
            headers: {
                "Accept": "*/*",
                "Accept-Language": "en-US,en;q=0.5",
                "Sec-Fetch-Dest": "empty",
                "Sec-Fetch-Mode": "cors",
                "Sec-Fetch-Site": "same-site"
            },
            referrer: "https://www.draftkings.com/",
            method: "GET",
            mode: "cors"
        });

        if (!summaryResponse.ok) {
            throw new Error(`Failed to fetch lobbies summary: ${summaryResponse.status}`);
        }

        const summaryData = await summaryResponse.json();
        logDkSlatesRawPayload('lobbies-summary', summaryData);
        const nflSport = summaryData.Sports?.find(sport => sport.Name === "NFL");

        if (!nflSport) {
            console.error("[DK Slates] NFL section not found in summary data");
            return;
        }

        // Filter for NFL Best Ball and NFL Snake draft groups
        const nflDraftGroups = nflSport.DraftGroups?.filter(draftGroup =>
            draftGroup.LeagueNameOverride &&
            (draftGroup.LeagueNameOverride.includes("NFL Best Ball") ||
                draftGroup.LeagueNameOverride.includes("NFL Snake"))
        ) || [];

        logDkSlatesRawPayload('nfl-draft-groups', nflDraftGroups);

        if (nflDraftGroups.length === 0) {
            return;
        }


        // Step 2: For each draft group, fetch player pool, rules, and details
        const slateDataPromises = nflDraftGroups.map(async (draftGroup) => {
            const draftGroupId = draftGroup.DraftGroupId;
            const gameTypeId = draftGroup.GameTypeId;

            if (!draftGroupId || !gameTypeId) {
                return null;
            }

            try {
                // Fetch player pool
                const playerPoolUrl = `https://api.draftkings.com/rankings/v1/draftgroups/${draftGroupId}/playerpool?format=json`;
                const playerPoolResponse = await fetch(playerPoolUrl, {
                    credentials: 'include',
                    headers: {
                        "Accept": "*/*",
                        "Accept-Language": "en-US,en;q=0.5",
                        "Sec-Fetch-Dest": "empty",
                        "Sec-Fetch-Mode": "cors",
                        "Sec-Fetch-Site": "same-site"
                    },
                    referrer: "https://www.draftkings.com/",
                    method: "GET",
                    mode: "cors"
                });

                if (!playerPoolResponse.ok) {
                    throw new Error(`Failed to fetch player pool: ${playerPoolResponse.status}`);
                }

                const playerPool = await playerPoolResponse.json();
                logDkSlatesRawPayload('player-pool-' + draftGroupId, playerPool);

                const draftablesUrl = `https://api.draftkings.com/draftgroups/v1/draftgroups/${draftGroupId}/draftables?format=json`;
                const draftablesResponse = await fetch(draftablesUrl, {
                    // Draftables responds with ACAO *; credentialed fetches are blocked by the browser.
                    credentials: 'omit',
                    headers: {
                        "Accept": "*/*",
                        "Accept-Language": "en-US,en;q=0.5",
                        "Sec-Fetch-Dest": "empty",
                        "Sec-Fetch-Mode": "cors",
                        "Sec-Fetch-Site": "same-site"
                    },
                    referrer: "https://www.draftkings.com/",
                    method: "GET",
                    mode: "cors"
                });

                if (!draftablesResponse.ok) {
                    throw new Error(`Failed to fetch draftables: ${draftablesResponse.status}`);
                }

                const draftablesData = await draftablesResponse.json();
                logDkSlatesRawPayload('draftables-' + draftGroupId, draftablesData);
                const playerIdToDkMap = buildPlayerIdToPlayerDkIdMapFromDraftables(draftablesData);
                logDkSlatesRawPayload('player-id-to-dk-map-' + draftGroupId, playerIdToDkMap);

                // Fetch rules data using GameTypeId
                const rulesUrl = `https://api.draftkings.com/lineups/v1/gametypes/${gameTypeId}/rules?format=json`;
                const rulesResponse = await fetch(rulesUrl, {
                    credentials: "same-origin",
                    headers: {
                        "Accept": "*/*",
                        "Accept-Language": "en-US,en;q=0.5",
                        "Sec-Fetch-Dest": "empty",
                        "Sec-Fetch-Mode": "cors",
                        "Sec-Fetch-Site": "same-site"
                    },
                    referrer: "https://www.draftkings.com/",
                    method: "GET",
                    mode: "cors"
                });

                if (!rulesResponse.ok) {
                    throw new Error(`Failed to fetch rules: ${rulesResponse.status}`);
                }

                const rulesData = await rulesResponse.json();
                logDkSlatesRawPayload('rules-' + draftGroupId, rulesData);

                // Fetch draft group details
                const draftGroupDetailsUrl = `https://api.draftkings.com/sites/US-DK/draftgroups/v3/draftgroups/${draftGroupId}?format=json`;
                const draftGroupResponse = await fetch(draftGroupDetailsUrl, {
                    credentials: 'same-origin',
                    headers: {
                        "Accept": "*/*",
                        "Accept-Language": "en-US,en;q=0.5",
                        "Sec-Fetch-Dest": "empty",
                        "Sec-Fetch-Mode": "cors",
                        "Sec-Fetch-Site": "same-site"
                    },
                    referrer: "https://www.draftkings.com/",
                    method: "GET",
                    mode: "cors"
                });

                if (!draftGroupResponse.ok) {
                    throw new Error(`Failed to fetch draft group details: ${draftGroupResponse.status}`);
                }

                const draftGroupData = await draftGroupResponse.json();
                logDkSlatesRawPayload('draftgroup-details-' + draftGroupId, draftGroupData);
                const flattenedDraftGroup = { ...draftGroupData.draftGroups?.[0] };

                // Merge rulesData and playerPool into the draftGroup object
                const mergedSlateData = {
                    ...flattenedDraftGroup,
                    ...rulesData,
                    ...playerPool
                };
                logDkSlatesRawPayload('merged-slate-' + draftGroupId, mergedSlateData);

                return { slateData: mergedSlateData, playerIdToDkMap };
            } catch (error) {
                console.error(`[DK Slates] Error fetching data for Draft Group ID ${draftGroupId}:`, error);
                return null;
            }
        });

        // Wait for all draft groups to be fetched
        const slateDataArray = await Promise.all(slateDataPromises);
        const validSlateResults = slateDataArray.filter(data => data !== null);

        if (validSlateResults.length === 0) {
            return;
        }

        // Step 3: Create dictionary where keys are draftGroupIds
        const slateDataDict = {};
        const mapsByDraftGroup = {};
        validSlateResults.forEach(result => {
            const slateData = result.slateData;
            const draftGroupId = slateData.DraftGroupId || slateData.draftGroupId;
            if (draftGroupId) {
                slateDataDict[draftGroupId] = slateData;
                mapsByDraftGroup[draftGroupId] = result.playerIdToDkMap || {};
            }
        });

        logDkSlatesRawPayload('slate-data-dict', slateDataDict);
        logDkSlatesRawPayload('player-id-to-dk-maps-by-draft-group', mapsByDraftGroup);


        let slatePayload;
        try {
            slatePayload = addPlayerDkIdToSlateData(slateDataDict, mapsByDraftGroup);
        } catch (e) {
            console.error('[DK Slates]', e && e.message ? e.message : e);
            throw e;
        }

        logDkSlatesRawPayload('slate-payload', slatePayload);

        // Send to backend through background script with JWT authentication
        try {
            const response = await fsm.send_port_request('DKSLATES_REQUEST', {
                slate_data: slatePayload
            }, DK_SLATES_PORT_TIMEOUT_MS);

            if (response && response.status === 'success') {
            } else {
                throw new Error(response?.message || 'Unknown error from background script');
            }
        } catch (error) {
            console.error("[DK Slates] Error sending slate data via background script:", error);
            throw error;
        }

    } catch (error) {
        console.error("[DK Slates] Error fetching DraftKings slate data:", error);
    }
}

function observe_draft_kings_queue(fsm) {
    if (!fsm || !fsm.state_data) {
        return;
    }

    const url = window.location.href;
    if (!is_draft_kings_draft_url(url)) {
        return;
    }

    // Find queue list wrapper for DraftKings
    const queue_list_wrapper = document.querySelector('.AutoDraftQueue_queue-body .BaseTable__body');

    // When queue is not visible (e.g. draft board open and covering it), don't overwrite state so stars stay
    if (!queue_list_wrapper) {
        return;
    }

    let queue_players = [];
    const queue_detected = true; // Wrapper exists, so queue is detected (even if empty)

    // Extract player name and position from queue rows (position used for star matching to avoid collisions e.g. two "J. Williams")
    const player_rows = queue_list_wrapper.querySelectorAll('.BaseTable__row');
    queue_players = Array.from(player_rows).map(row => {
        const name_element = row.querySelector('.PlayerCell_player-name');
        const position_element = row.querySelector('.player-position');
        const name = name_element ? name_element.textContent.trim() : null;
        const position = position_element ? position_element.textContent.trim() : undefined;
        if (!name) return null;
        return { name, position };
    }).filter(entry => entry !== null);

    const current_state = {
        detected: queue_detected,
        players: queue_players,
        count: queue_players.length
    };

    const state_changed = JSON.stringify(current_state) !== JSON.stringify(fsm.state_data.queue.last_logged_queue_state);

    fsm.state_data.queue.is_detected = queue_detected;
    fsm.state_data.queue.players = queue_players;

    if (state_changed) {
        if (!queue_detected) {
            // console.log('[DraftKings Queue] Queue not detected');
        } else {
            // console.log('[DraftKings Queue] Queue updated', queue_players.length, queue_players);
        }
        fsm.state_data.queue.last_logged_queue_state = current_state;

        if (fsm.overlay_manager && fsm.overlay_manager.update_stars_from_queue) {
            fsm.overlay_manager.update_stars_from_queue();
        }
    }
}

// Draftables API: per-slate playerId -> playerDkId (playerDkId is slate-scoped; playerId is stable).
function logDkSlatesRawPayload(label, data) {
}

function buildPlayerIdToPlayerDkIdMapFromDraftables(parsed) {
    const list = parsed && parsed.draftables;
    const map = {};
    if (!Array.isArray(list) || !list.length) {
        return map;
    }
    for (let i = 0; i < list.length; i++) {
        const d = list[i];
        if (!d || typeof d !== 'object') {
            continue;
        }
        const pdk = d.playerDkId != null ? d.playerDkId : null;
        const pid = d.playerId != null ? d.playerId : null;
        if (pdk == null || pid == null) {
            continue;
        }
        const pidKey = String(pid).trim();
        if (!pidKey) {
            continue;
        }
        const dkStr = String(pdk).trim();
        if (dkStr) {
            map[pidKey] = dkStr;
        }
    }
    return map;
}

function addPlayerDkIdToSlateData(slateDataDict, mapsByDraftGroup) {
    const maps = mapsByDraftGroup && typeof mapsByDraftGroup === 'object' ? mapsByDraftGroup : null;
    if (!maps || Object.keys(maps).length === 0) {
        throw new Error('[DK Slates] playerId→playerDkId maps missing for slate upload');
    }
    const dict = JSON.parse(JSON.stringify(slateDataDict));
    const slateKeys = Object.keys(dict || {});
    let skippedCount = 0;
    for (let s = 0; s < slateKeys.length; s++) {
        const sk = slateKeys[s];
        const copy = dict[sk];
        if (!copy || typeof copy !== 'object') {
            continue;
        }
        const map = maps[sk] || maps[String(sk)];
        const pool = copy.playerPool;
        const players = pool && pool.draftablePlayers;
        if (!Array.isArray(players)) {
            continue;
        }
        if (!map || typeof map !== 'object' || Object.keys(map).length === 0) {
            skippedCount += players.length;
            pool.draftablePlayers = [];
            continue;
        }
        const kept = [];
        for (let i = 0; i < players.length; i++) {
            const p = players[i];
            if (!p || typeof p !== 'object') {
                continue;
            }
            const pid = p.playerId != null ? p.playerId : null;
            if (pid == null) {
                skippedCount++;
                continue;
            }
            const pidKey = String(pid).trim();
            const pdk = map[pidKey];
            if (pdk == null || String(pdk).trim() === '') {
                skippedCount++;
                continue;
            }
            p.playerDkId = String(pdk).trim();
            kept.push(p);
        }
        pool.draftablePlayers = kept;
    }
    if (skippedCount > 0) {
    }
    return dict;
}

// Remote `exposure_id_map.map`: playerDkId -> canonical Underdog id. DK exposure rows come from lineups intercept (per draftGroupId).
function buildDkExposureLabelFromLineupsSeed(seed) {
    if (!seed || typeof seed !== 'object') {
        return '';
    }
    const parts = [];
    const gt = seed.game_type_name != null ? String(seed.game_type_name).trim() : '';
    const suf = seed.suffix != null ? String(seed.suffix).trim() : '';
    const sd = seed.start_date != null ? String(seed.start_date).trim() : '';
    const hasSport = seed.sport != null && String(seed.sport).trim();
    if (hasSport) parts.push('DraftKings');
    if (gt) parts.push(gt);
    if (suf) {
        const cleaned = suf.replace(/^\s*\(/, '').replace(/\)\s*$/, '').trim();
        if (cleaned) parts.push(cleaned);
    }
    if (sd && parts.length < 2) parts.push(sd.length > 16 ? sd.slice(0, 16) + '…' : sd);
    return parts.filter(Boolean).join(' · ').replace(/\bTournament\b/gi, 'Best Ball');
}

function enrichDkLineupsWithContestDetails(lineups, contestsByKey) {
    if (!Array.isArray(lineups) || !lineups.length) {
        return [];
    }
    const contests = contestsByKey && typeof contestsByKey === 'object' ? contestsByKey : {};
    const out = [];
    for (let i = 0; i < lineups.length; i++) {
        const lu = lineups[i];
        if (!lu || typeof lu !== 'object') continue;
        let next;
        try {
            next = JSON.parse(JSON.stringify(lu));
        } catch (eClone) {
            next = { ...lu };
        }
        const entriesIn = Array.isArray(next.entries) ? next.entries : [];
        const entriesOut = [];
        let lineupName = null;
        let lineupFee = null;
        let lineupTournamentKey = null;
        for (let ei = 0; ei < entriesIn.length; ei++) {
            const ent = entriesIn[ei];
            if (!ent || typeof ent !== 'object') continue;
            const ck = ent.contest_key != null ? String(ent.contest_key).trim() : '';
            const entryOut = { ...ent };
            if (ck && contests[ck] && typeof contests[ck] === 'object') {
                const c = contests[ck];
                const nameRaw = c.name != null ? String(c.name).trim() : '';
                if (nameRaw) entryOut.name = nameRaw;
                const fee = Number(c.entry_fee);
                if (Number.isFinite(fee) && fee >= 0) entryOut.entry_fee = fee;
                const tk = c.tournament_key != null ? String(c.tournament_key).trim() : '';
                if (tk) entryOut.tournament_key = tk;
            }
            if (lineupName == null && entryOut.name) lineupName = entryOut.name;
            if (lineupFee == null && entryOut.entry_fee != null) lineupFee = entryOut.entry_fee;
            if (lineupTournamentKey == null && entryOut.tournament_key) lineupTournamentKey = entryOut.tournament_key;
            entriesOut.push(entryOut);
        }
        next.entries = entriesOut;
        if (lineupName) next.name = lineupName;
        if (lineupFee != null) next.entry_fee = lineupFee;
        if (lineupTournamentKey) next.tournament_key = lineupTournamentKey;
        out.push(next);
    }
    return out;
}

function buildDkExposureSlatesPayloadFromLineupsDetail(fsm, detail) {
    const slatesIn = detail && detail.slates && typeof detail.slates === 'object' ? detail.slates : null;
    if (!slatesIn || !Object.keys(slatesIn).length) {
        return null;
    }
    const exposureIdMap =
        fsm && fsm.datasets && fsm.datasets.exposure_id_map && fsm.datasets.exposure_id_map.map
            ? fsm.datasets.exposure_id_map.map
            : null;
    const idMap =
        fsm && fsm.datasets && fsm.datasets.id_map && fsm.datasets.id_map.map
            ? fsm.datasets.id_map.map
            : {};
    if (!exposureIdMap || typeof exposureIdMap !== 'object' || !Object.keys(exposureIdMap).length) {
        // Allow id_map-only when player_dk_id is already a stable DK id.
        if (!idMap || typeof idMap !== 'object' || !Object.keys(idMap).length) {
            return null;
        }
    }
    const infoById =
        fsm && fsm.datasets && fsm.datasets.player_map_ud && fsm.datasets.player_map_ud.player_info_by_id
            ? fsm.datasets.player_map_ud.player_info_by_id
            : null;

    function looksLikeUdUuid(value) {
        const text = value != null ? String(value).trim() : '';
        return text.length >= 32 && text.indexOf('-') >= 0;
    }

    function resolveCanonical(playerDkId) {
        const key = playerDkId != null ? String(playerDkId).trim() : '';
        if (!key) return null;
        const exp = exposureIdMap || {};
        const ids = idMap || {};
        const dkNative = exp[key];
        if (dkNative != null && String(dkNative).trim()) {
            const nativeKey = String(dkNative).trim();
            const hop2 = ids[nativeKey];
            if (hop2) return String(hop2);
            // Legacy exposure_id_map values are already Underdog UUIDs.
            if (looksLikeUdUuid(nativeKey)) return nativeKey;
        }
        if (ids[key]) return String(ids[key]);
        return null;
    }

    const outSlates = {};
    const rawByDg =
        detail && detail.raw_lineups_by_draft_group && typeof detail.raw_lineups_by_draft_group === 'object'
            ? detail.raw_lineups_by_draft_group
            : null;
    const draftGroupIds = Object.keys(slatesIn);
    for (let i = 0; i < draftGroupIds.length; i++) {
        const dgId = draftGroupIds[i];
        const slab = slatesIn[dgId];
        if (!slab || typeof slab !== 'object') continue;
        const pickMap = slab.pick_count_by_player_dk_id;
        const feeMap = slab.entry_fees_by_player_dk_id;
        const te = Number(slab.total_entries);
        if (!pickMap || typeof pickMap !== 'object' || !Object.keys(pickMap).length) continue;
        if (!Number.isFinite(te) || te <= 0) continue;
        const labelSeed = slab.label_seed && typeof slab.label_seed === 'object' ? slab.label_seed : null;
        let label = buildDkExposureLabelFromLineupsSeed(labelSeed);
        if (!label) label = 'Draft Group ' + dgId;
        const rows = [];
        for (const dkKey of Object.keys(pickMap)) {
            if (!dkKey) continue;
            const canonical = resolveCanonical(dkKey);
            if (!canonical) continue;
            const pickCount = Math.round(Number(pickMap[dkKey]));
            if (!Number.isFinite(pickCount) || pickCount < 0) continue;
            const entry = { id: canonical, dk_pick_count: pickCount };
            if (feeMap && typeof feeMap === 'object') {
                const f = Number(feeMap[dkKey]);
                if (Number.isFinite(f)) entry.dk_entry_fees = f;
            }
            if (infoById && typeof infoById === 'object') {
                const info = infoById[canonical];
                if (info && typeof info === 'object') {
                    if (info.full_name) entry.full_name = String(info.full_name).trim();
                    if (info.team) entry.team = String(info.team).trim();
                    if (info.position) entry.position = String(info.position).trim();
                }
            }
            rows.push(entry);
        }
        if (!rows.length) continue;
        const rawLineups = rawByDg && Array.isArray(rawByDg[dgId]) ? rawByDg[dgId] : [];
        const slateEntry = { rows: rows, total_entries: Math.round(te), label: label };
        if (rawLineups.length) {
            slateEntry.lineups = rawLineups;
        }
        outSlates[dgId] = slateEntry;
    }
    if (!Object.keys(outSlates).length) return null;
    return { slates: outSlates };
}

const DK_EXPOSURE_PROGRESS_TOAST_MESSAGE = 'Getting exposure data. This can take a few minutes, please wait.';
/** Long enough to stay visible through fee resolution; progress updates replace via show_exposure_saved_toast. */
const DK_EXPOSURE_PROGRESS_TOAST_DURATION_MS = 300000;

function queueDkExposureToast(fsm, message, durationMs) {
    if (!fsm || !fsm.state_data || !message) {
        return;
    }
    fsm.state_data.pending_exposure_toast = {
        message,
        durationMs: Number.isFinite(durationMs) && durationMs >= 0 ? durationMs : 5000
    };
}

function showDkExposureToast(fsm, message, durationMs) {
    const om = fsm && fsm.overlay_manager;
    if (om && typeof om.show_exposure_saved_toast === 'function') {
        om.show_exposure_saved_toast(
            message,
            Number.isFinite(durationMs) && durationMs >= 0 ? durationMs : 5000
        );
        return;
    }
    queueDkExposureToast(fsm, message, durationMs);
}

function tryShowDkExposureProgressToast(fsm, done, total) {
    const hasCounts = Number.isFinite(done) && Number.isFinite(total) && total > 0;
    const message = hasCounts
        ? 'DK exposure ' + done + '/' + total + ' lineups'
        : DK_EXPOSURE_PROGRESS_TOAST_MESSAGE;
    showDkExposureToast(fsm, message, DK_EXPOSURE_PROGRESS_TOAST_DURATION_MS);
}

function tryDismissDkExposureProgressToast(fsm) {
    if (fsm && fsm.state_data) {
        delete fsm.state_data.pending_exposure_toast;
    }
    const om = fsm && fsm.overlay_manager;
    if (!om || typeof om.dismiss_exposure_saved_toast !== 'function') {
        return;
    }
    om.dismiss_exposure_saved_toast();
}

async function sendDkLineupsExposureMerge(fsm, payload, options) {
    const quiet = !!(options && options.quiet);
    if (!payload || !payload.slates || typeof payload.slates !== 'object' || !Object.keys(payload.slates).length) {
        if (!quiet) tryDismissDkExposureProgressToast(fsm);
        return { status: 'skipped', message: 'empty payload' };
    }
    if (!fsm || !fsm.bg_port || !fsm.bg_connected || typeof fsm.send_port_request !== 'function') {
        if (!quiet) tryDismissDkExposureProgressToast(fsm);
        return { status: 'error', message: 'background port not ready' };
    }
    try {
        const res = await fsm.send_port_request('MERGE_DK_EXPOSURE_FROM_LINEUPS', payload);
        if (!res || res.status !== 'ok') {
            if (!quiet) tryDismissDkExposureProgressToast(fsm);
            return res || { status: 'error', message: 'merge failed' };
        }
        if (!quiet) {
            showDkExposureToast(fsm, 'Exposure data saved · DraftKings', 5000);
        }
        return res;
    } catch (err) {
        if (!quiet) tryDismissDkExposureProgressToast(fsm);
        throw err;
    }
}

/**
 * `__legup_dk_lineups_json` is dispatched from the page MAIN world; on Firefox, `ev.detail`
 * is wrapped in an XrayWrapper. Mutating nested objects (e.g. assigning `entry_fees_by_player_dk_id`)
 * from the isolated content script throws: "Not allowed to define cross-origin object as property
 * on [Object] or [Array] XrayWrapper". Clone into this realm before any mutation.
 */
function cloneDkLineupsDetailForContentScriptScope(detailIn) {
    if (!detailIn || typeof detailIn !== 'object') {
        return null;
    }
    try {
        return JSON.parse(JSON.stringify(detailIn));
    } catch (e) {
        return null;
    }
}

// Serialize merges across both the live listener and the pending-flush path so they
// can't race when datasets become ready mid-merge.
var _dk_lineups_exposure_chain = Promise.resolve();

function scheduleDkLineupsExposureMerge(fsm, detail, source) {
    _dk_lineups_exposure_chain = _dk_lineups_exposure_chain
        .then(() => processDkLineupsExposureDetailIfReady(fsm, detail))
        .catch((err) => {
            tryDismissDkExposureProgressToast(fsm);
            const message = err && err.message ? String(err.message) : String(err);
            console.error(`[LegUp exposure][DK] ${source} lineups merge FAILED — DK data will not update`, message, err);
            const om = fsm && fsm.overlay_manager;
            if (om && typeof om.show_exposure_saved_toast === 'function') {
                om.show_exposure_saved_toast('DK exposure failed: ' + message, 12000);
            } else if (fsm && fsm.state_data) {
                queueDkExposureToast(fsm, 'DK exposure failed: ' + message, 12000);
            }
        });
}

function tryFlushPendingDkLineupsExposureMerge(fsm) {
    const detail = fsm && fsm.state_data && fsm.state_data.pending_dk_lineups_exposure_detail;
    if (!detail) return;
    scheduleDkLineupsExposureMerge(fsm, detail, 'pending');
}

async function processDkLineupsExposureDetailIfReady(fsm, detailIn) {
    const detail = cloneDkLineupsDetailForContentScriptScope(detailIn);
    if (!detail) {
        return;
    }
    const slates = detail && typeof detail === 'object' ? detail.slates : null;
    const nSlates = slates && typeof slates === 'object' ? Object.keys(slates).length : 0;
    if (!fsm || !fsm.state_data || !nSlates) {
        return;
    }
    tryShowDkExposureProgressToast(fsm);

    // Contest metadata gates everything downstream (eligibility, fill state, fees). If the scrape
    // fails, abort rather than merge an empty payload over good stored exposure.
    let contestMeta = null;
    try {
        contestMeta = await loadDkExposureContestMeta(fsm);
    } catch (eMeta) {
        tryDismissDkExposureProgressToast(fsm);
        showDkExposureToast(fsm, 'DK exposure: could not read your contest list. Try again shortly.', 10000);
        return;
    }

    const pruned = pruneDkLineupsExposureDetailToEligibleContests(detail, contestMeta.by_key);
    if (!Object.keys(detail.slates || {}).length) {
        tryDismissDkExposureProgressToast(fsm);
        showDkExposureToast(fsm, 'DK exposure: no filled Best Ball drafts found.', 10000);
        return;
    }

    const exposureIdMap =
        fsm.datasets && fsm.datasets.exposure_id_map && fsm.datasets.exposure_id_map.map
            ? fsm.datasets.exposure_id_map.map
            : null;
    const idMap =
        fsm.datasets && fsm.datasets.id_map && fsm.datasets.id_map.map
            ? fsm.datasets.id_map.map
            : null;
    const exposureReady =
        (exposureIdMap && typeof exposureIdMap === 'object' && Object.keys(exposureIdMap).length > 0) ||
        (idMap && typeof idMap === 'object' && Object.keys(idMap).length > 0);

    // Need exposure_id_map and/or id_map before we can merge; stash and wait for datasets.
    if (!exposureReady) {
        fsm.state_data.pending_dk_lineups_exposure_detail = detail;
        tryDismissDkExposureProgressToast(fsm);
        return;
    }
    if (!fsm.bg_port || !fsm.bg_connected) {
        fsm.state_data.pending_dk_lineups_exposure_detail = detail;
        tryDismissDkExposureProgressToast(fsm);
        return;
    }

    try {
        applyDkExposureContestMetaToDetail(detail, contestMeta.by_key);
    } catch (eFee) {
    }

    // Serialize chunk merges so each overwrite sees prior seated accumulation in storage,
    // but do not wait for /exposure/sync HTTP — that runs in the background immediately.
    let mergeChain = Promise.resolve();
    const enqueueMerge = (payload) => {
        mergeChain = mergeChain
            .then(() => sendDkLineupsExposureMerge(fsm, payload, { quiet: true }))
            .catch((err) => {
            });
        return mergeChain;
    };

    const { seatedLineups, skippedCount, total } = await enrichDkLineupsSeatsChunked(
        fsm,
        detail,
        async ({ seatedLineups: seatedSoFar, skippedCount: skippedSoFar, chunkSeated, done, total: tot }) => {
            tryShowDkExposureProgressToast(fsm, seatedSoFar.length, tot);
            if (!chunkSeated && done < tot) return;

            const detailForMerge = buildDkLineupsDetailWithSeatedLineupsOnly(detail, seatedSoFar);
            const payload = buildDkExposureSlatesPayloadFromLineupsDetail(fsm, detailForMerge);
            if (!payload) {
                if (typeof fsm._is_dev_or_local_env === 'function' && fsm._is_dev_or_local_env()) {
                    const noMergeRowsLog = {
                        seated: seatedSoFar.length,
                        skipped: skippedSoFar,
                        done,
                        total: tot
                    };
                }
                return;
            }
            logDkLineupSeatSnapshot('sending MERGE_DK_EXPOSURE_FROM_LINEUPS (chunk)', seatedSoFar);
            if (typeof fsm._is_dev_or_local_env === 'function' && fsm._is_dev_or_local_env()) {
                const chunkMergeLog = {
                    seated: seatedSoFar.length,
                    skipped: skippedSoFar,
                    done,
                    total: tot,
                    slates: Object.keys(payload.slates).length
                };
            }
            // Fire merge (awaited on chain) while the next enrich chunk can start after onChunk returns.
            // We await the chain slot so local overwrite order is preserved across chunks.
            await enqueueMerge(payload);
        }
    );

    await mergeChain;

    if (fsm.state_data) {
        delete fsm.state_data.pending_dk_lineups_exposure_detail;
    }

    if (!seatedLineups.length) {
        tryDismissDkExposureProgressToast(fsm);
        const msg =
            'DK exposure: 0/' + total + ' lineups' + (skippedCount ? ' (' + skippedCount + ' skipped)' : '');
        showDkExposureToast(fsm, msg, 12000);
        if (typeof fsm._is_dev_or_local_env === 'function' && fsm._is_dev_or_local_env()) {
            const noSeatedLog = {
                total,
                skipped: skippedCount
            };
        }
        return;
    }

    const finalMsg =
        'Exposure data saved · DraftKings · ' +
        seatedLineups.length +
        '/' +
        total +
        ' lineups' +
        (skippedCount ? ' · ' + skippedCount + ' skipped' : '');
    showDkExposureToast(fsm, finalMsg, 8000);
    if (typeof fsm._is_dev_or_local_env === 'function' && fsm._is_dev_or_local_env()) {
        const exposureReadyLog = {
            seated: seatedLineups.length,
            skipped: skippedCount,
            total
        };
    }
}

(function register_legup_dk_lineups_listener() {
    if (typeof window === 'undefined' || window.__legupDkLineupsListenerInstalled) {
        return;
    }
    window.__legupDkLineupsListenerInstalled = true;
    window.addEventListener('__legup_dk_lineups_json', (ev) => {
        const fsm = window.__LEGUP_FSM__;
        const detail = ev.detail;
        const slates = detail && typeof detail === 'object' ? detail.slates : null;
        const nSlates = slates && typeof slates === 'object' ? Object.keys(slates).length : 0;
        const rawByDg =
            detail && detail.raw_lineups_by_draft_group && typeof detail.raw_lineups_by_draft_group === 'object'
                ? detail.raw_lineups_by_draft_group
                : null;
        let lineupCount = 0;
        if (rawByDg) {
            for (const dgKey of Object.keys(rawByDg)) {
                const arr = rawByDg[dgKey];
                if (Array.isArray(arr)) lineupCount += arr.length;
            }
        }
        if (fsm && typeof fsm._is_dev_or_local_env === 'function' && fsm._is_dev_or_local_env()) {
            const log_data = {
                slates: nSlates,
                lineups: lineupCount,
                fsm: !!(fsm && fsm.state_data)
            };
        }
        if (!fsm || !fsm.state_data || !nSlates) {
            return;
        }
        scheduleDkLineupsExposureMerge(fsm, detail, 'listener');
    });
})();

// Expose manual slate update for overlay sidecar (respects DK_SLATES_WHITELIST)
(function attachDkSlateTrigger() {
    function attach() {
        const fsm = window.__LEGUP_FSM__;
        if (!fsm || !fsm.state_data) return false;
        if (fsm.trigger_dk_slate_update) return true;
        fsm.trigger_dk_slate_update = function () {
            const user_uuid = (fsm.session_data && fsm.session_data.user_uuid) || null;
            if (!user_uuid || !DK_SLATES_WHITELIST.includes(user_uuid)) {
                return Promise.resolve();
            }
            return fetch_draft_kings_slates(fsm);
        };
        return true;
    }
    if (!attach()) {
        const t = setInterval(() => {
            if (attach()) clearInterval(t);
        }, 100);
        setTimeout(() => clearInterval(t), 10000);
    }
})();

function extract_test_draft_data(fsm) {
    if (!fsm || !fsm.state_data) {
        return null;
    }
    
    const draft_state_element = document.getElementById('draftStateJsonMirror');
    if (!draft_state_element) {
        // console.warn('Draft state element not found');
        return null;
    }
    
    try {
        const draft_state = JSON.parse(draft_state_element.textContent);
        
        const draft_id = draft_state.draft?.draft_id;
        const site_name = draft_state.draft?.site_name;
        
        if (!draft_id || !site_name) {
            // console.warn('Draft data rejected: missing required fields', draft_id, site_name);
            return null;
        }
        
        const draft = draft_state.draft || {};
        
        // Parse advancement structure from textarea. Blank field means an explicit empty {}.
        let advancement_structure = null;
        const advancement_structure_element = document.getElementById('advancementStructure');
        if (advancement_structure_element) {
            const raw = (advancement_structure_element.value || '').trim();
            if (!raw) {
                advancement_structure = {};
            } else {
                try {
                    advancement_structure = JSON.parse(raw);
                } catch (error) {
                }
            }
        }

        let scoring = null;
        const scoring_element = document.getElementById('scoringSelect');
        if (scoring_element) {
            const rawScoring = (scoring_element.value || '').trim();
            if (rawScoring) {
                scoring = rawScoring.toLowerCase();
            }
        }
        
        return {
            draft: draft,
            advancement_structure: advancement_structure,
            scoring: scoring
        };
    } catch (error) {
        console.error('Error parsing test draft state:', error);
        return null;
    }
}


let ghostJwksCache = { url: null, data: null, expires: 0 };
const textDecoder = new TextDecoder();
const textEncoder = new TextEncoder();

function base64UrlToUint8Array(base64Url) {
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    const pad = base64.length % 4;
    const padded = base64 + (pad ? '='.repeat(4 - pad) : '');
    const binary = atob(padded);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i += 1) {
        bytes[i] = binary.charCodeAt(i);
    }
    return bytes;
}

async function getGhostJwks(env) {
    const url = GHOST_JWKS_BY_ENV[env] || GHOST_JWKS_BY_ENV.prod;
    const now = Date.now();
    if (ghostJwksCache.data && ghostJwksCache.url === url && now < ghostJwksCache.expires) {
        return ghostJwksCache.data;
    }
    const res = await fetch(url, { method: 'GET', cache: 'no-store' });
    if (!res.ok) throw new Error(`Failed to fetch Ghost JWKS (${res.status})`);
    const data = await res.json();
    ghostJwksCache = { url, data, expires: now + GHOST_JWKS_CACHE_MS };
    return data;
}

function normalizeAudience(aud) {
    if (!aud) return [];
    return Array.isArray(aud) ? aud : [aud];
}

async function verifyGhostJwt(token, expectedEmail, env) {
    if (!token) throw new Error('Missing JWT');
    const segments = token.split('.');
    if (segments.length !== 3) throw new Error('Invalid JWT format');
    const [encodedHeader, encodedPayload, encodedSignature] = segments;

    const header = JSON.parse(textDecoder.decode(base64UrlToUint8Array(encodedHeader)));
    const payloadBytes = base64UrlToUint8Array(encodedPayload);
    const payload = JSON.parse(textDecoder.decode(payloadBytes));

    const jwks = await getGhostJwks(env);
    const kid = header.kid;
    const jwk = (jwks?.keys || []).find(key => key.kid === kid);
    if (!jwk) throw new Error('JWKS key not found for token');

    const cryptoKey = await crypto.subtle.importKey(
        'jwk',
        { kty: jwk.kty, e: jwk.e, n: jwk.n, alg: 'RS512', ext: true },
        { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-512' },
        false,
        ['verify']
    );

    const data = textEncoder.encode(`${encodedHeader}.${encodedPayload}`);
    const signature = base64UrlToUint8Array(encodedSignature);
    const valid = await crypto.subtle.verify({ name: 'RSASSA-PKCS1-v1_5' }, cryptoKey, signature, data);
    if (!valid) throw new Error('JWT signature invalid');

    const nowSec = Math.floor(Date.now() / 1000);
    if (payload.exp && nowSec > Number(payload.exp)) {
        throw new Error('JWT expired');
    }

    if (payload.iss && payload.iss !== GHOST_JWT_ISSUER) {
        throw new Error('JWT issuer mismatch');
    }

    const audList = normalizeAudience(payload.aud);
    if (audList.length && !audList.includes(GHOST_JWT_AUDIENCE)) {
        throw new Error('JWT audience mismatch');
    }

    if (expectedEmail && payload.sub && payload.sub.toLowerCase() !== expectedEmail.toLowerCase()) {
        throw new Error('JWT subject mismatch');
    }

    return payload;
}

function detectEnvironment() {
    try {
        const envTag = document.querySelector('meta[name="legup-environment"]');
        if (envTag?.content) {
            // Normalize legacy/unexpected tags back to prod.
            const tag = typeof envTag.content === 'string' ? envTag.content.toLowerCase() : '';
            if (tag === 'dev' || tag === 'local' || tag === 'prod') return tag;
            return 'prod';
        }
    } catch {}
    const host = window.location.hostname || '';
    if (host.includes('localhost') || host.includes('dev')) return 'dev';
    return 'prod';
}

function check_and_fetch_member_data(callback) {
    const fsm = window.__LEGUP_FSM__;
    if (!fsm || !fsm.bg_port || !fsm.bg_connected) {
        console.error("[ghost] FSM not available or port not connected");
        if (callback) callback(false);
        return;
    }
    
    fsm.send_port_request('GET_SESSION_DATA')
        .then(response => {
            const storedUuid = response?.session_data?.user_uuid || null;
            fetch_member_profile(storedUuid, callback);
        })
        .catch(err => {
            console.error("[ghost] Failed to get session data:", err);
            if (callback) callback(false);
        });
}

function fetch_member_profile(storedUuid, callback) {
    let memberData;
    const env = detectEnvironment();

    fetch("https://www.legendaryupside.com/members/api/member/")
        .then(response => {
            if (!response.ok) {
                throw new Error("Failed to fetch member data");
            }
            return response.json();
        })
        .then(data => {
            memberData = data;


            const subscriptions = memberData.subscriptions
                .filter(sub => sub.tier)
                .map(sub => ({
                    status: sub.status,
                    tier_name: sub.tier.name,
                    start_date: sub.start_date
                }));

            if (subscriptions.length === 0) {
            }

            return fetch("https://www.legendaryupside.com/members/api/session/")
                .then(resp => resp.text())
                .then(jwt => {
                    if (!jwt) {
                        throw new Error("Empty JWT");
                    }
                    return { jwt, subscriptions };
                });
        })
        .then(({ jwt, subscriptions }) => {
            const email = memberData?.email || memberData?.primary_email || null;
            return verifyGhostJwt(jwt, email, env).then(() => ({ jwt, email, subscriptions }));
        })
        .then(({ jwt, email, subscriptions }) => {
            const session_data = {
                user_uuid: storedUuid || memberData.uuid,
                email,
                subscriptions,
                last_validated: Math.floor(Date.now() / 1000),
                jwt
            };

            const fsm = window.__LEGUP_FSM__;
            if (!fsm || !fsm.bg_port || !fsm.bg_connected) {
                console.error("[ghost] FSM not available or port not connected");
                if (callback) callback(false);
                return;
            }
            
            fsm.send_port_request('SET_SESSION_DATA', { session_data })
                .then((resp) => {
                    if (callback) callback(resp?.status === 'ok');
                })
                .catch(err => {
                    console.error("[ghost] Failed to set session data:", err);
                    if (callback) callback(false);
                });
        })
        .catch(error => {
            console.error("Error:", error);
            const fsm = window.__LEGUP_FSM__;
            if (fsm && fsm.bg_port && fsm.bg_connected) {
                fsm.send_port_request('CLEAR_SESSION_DATA')
                    .catch(err => {
                        console.error("[ghost] Failed to clear session data:", err);
                    });
            }
            if (callback) callback(false);
        });
}

class QueueClickHandler {
    constructor(site_type = 'draftkings') {
        this.site_type = site_type;
    }

    _normalizeNameTokenForCompare(s) {
        if (!s) return '';
        return String(s)
            .toLowerCase()
            .replace(/[^a-z]/g, '');
    }

    _splitFullName(fullName) {
        const parts = String(fullName || '')
            .trim()
            .split(/\s+/)
            .filter(Boolean);
        if (parts.length < 2) {
            return { first: parts[0] || '', last: '' };
        }
        return { first: parts[0], last: parts.slice(1).join(' ') };
    }

    _parseDraftKingsDisplayName(displayName) {
        const parts = String(displayName || '')
            .trim()
            .split(/\s+/)
            .filter(Boolean);
        if (parts.length < 2) {
            return { firstToken: parts[0] || '', last: '' };
        }
        // DK format is typically like "Kay. Allen" (first token, then last name).
        return { firstToken: parts[0], last: parts.slice(1).join(' ') };
    }

    _isDraftKingsNameMatch(dkDisplayName, targetFullName) {
        const dk = String(dkDisplayName || '').trim();
        const target = String(targetFullName || '').trim();
        if (!dk || !target) return false;

        // Fast path: exact match
        if (dk === target) return true;

        const { first: targetFirst, last: targetLast } = this._splitFullName(target);
        const { firstToken: dkFirstToken, last: dkLast } = this._parseDraftKingsDisplayName(dk);
        if (!targetFirst || !targetLast || !dkFirstToken || !dkLast) return false;

        const targetLastNorm = this._normalizeNameTokenForCompare(targetLast);
        const dkLastNorm = this._normalizeNameTokenForCompare(dkLast);
        if (!targetLastNorm || targetLastNorm !== dkLastNorm) return false;

        // DK uses a variable-length first-name prefix (usually 1–3 letters) plus optional dot.
        // Example: "Kay. Allen" for "Kaytron Allen".
        const dkPrefixNorm = this._normalizeNameTokenForCompare(dkFirstToken.replace(/\.+$/, ''));
        const targetFirstNorm = this._normalizeNameTokenForCompare(targetFirst);
        if (!dkPrefixNorm || !targetFirstNorm) return false;

        if (dkPrefixNorm.length < 1 || dkPrefixNorm.length > 3) return false;
        return targetFirstNorm.startsWith(dkPrefixNorm);
    }

    async handleClick(playerName, team, position) {

        this.ensureQueueVisible();

        await this.preparePage();

        await this.findAndClickPlayer(playerName, team, position);
    }

    ensureQueueVisible() {
        if (this.site_type === 'underdog') {
            this.ensureUnderdogQueueVisible();
        } else if (this.site_type === 'draftkings') {
            this.ensureDraftKingsQueueVisible();
        }
    }

    ensureUnderdogQueueVisible() {
        if (!is_active_url(window.location.href)) {
            return;
        }

        const queueButton =
            typeof find_underdog_active_queue_toggle_button === 'function'
                ? find_underdog_active_queue_toggle_button()
                : null;

        if (!queueButton) {
            return;
        }

        if (queueButton.classList.contains('styles__selected__')) {
            return;
        }

        queueButton.click();

        // Reset queue_size_changed flag when queue is manually opened
        const fsm = window.__LEGUP_FSM__;
        if (fsm && fsm.state_data) {
            fsm.state_data.queue_size_changed = false;
        }
    }

    ensureDraftKingsQueueVisible() {
        if (is_draft_kings_draft_url(window.location.href)) {
            const playerTabButton = document.querySelector('button[data-test-id="dk-tab-players"]');
            if (playerTabButton) {
                playerTabButton.click();
            }
        }
    }

    async preparePage() {
        if (this.site_type === 'underdog') {
            await this.prepareUnderdogPage();
        } else if (this.site_type === 'draftkings') {
            await this.prepareDraftKingsPage();
        }
    }

    async prepareUnderdogPage() {
        await this.closeDraftBoard();
        await this.closePlayerCard();
        await this.clickFilterButtons();
        await this.clearUnderdogFilters();
    }

    async prepareDraftKingsPage() {
        await this.clearDraftKingsFilters();
    }

    async closeDraftBoard() {
        const draftBoard = document.querySelector('div[class^="styles__draftBoardWrapper__"]');
        if (!draftBoard) {
            return;
        }

        let closeButton = draftBoard.querySelector('button[data-testid="close-board-button"]');
        if (!closeButton) {
            const clearIconUse = draftBoard.querySelector('svg use[href="#clearFilled__gen"]');
            if (clearIconUse) {
                closeButton = clearIconUse.closest('button');
            }
        }

        if (closeButton) {
            closeButton.click();
            await new Promise(resolve => setTimeout(resolve, 100));
        }
    }

    async closePlayerCard() {
        const playerCard = document.querySelector('[class*="styles__playerCard__"]');
        if (playerCard) {
            const collapseButton = playerCard.querySelector('[class*="styles__playerNameRow__"]');
            if (collapseButton) {
                collapseButton.click();
                await new Promise(r => setTimeout(r, 100));
            }
        }
    }

    async clickFilterButtons() {
        // Enable all position filter buttons that are inactive
        const filterComponent = document.querySelector('[class*="styles__filterComponent__"]');
        if (!filterComponent) {
            return;
        }

        const filterButtons = Array.from(
            filterComponent.querySelectorAll('button[class*="styles__filterButton__"]')
        );

        if (filterButtons.length === 0) {
            console.error('[Queue Click] No position filter buttons found.');
            return;
        }

        for (const button of filterButtons) {
            // Check for inactive state: look for "inactive" in className
            const isInactive = button.className.includes('inactive');
            
            // Secondary check: if button has no background-color in inline style, consider it inactive
            // (for robustness, in case className check doesn't catch all cases)
            const hasBackgroundColor = button.style.backgroundColor && button.style.backgroundColor.trim() !== '';
            const isInactiveByStyle = !hasBackgroundColor && !isInactive;

            if (isInactive || isInactiveByStyle) {
                button.click();
                await new Promise(r => setTimeout(r, 100));
            }
        }
    }

    async clearUnderdogFilters() {
        const filterComponent = document.querySelector('[class*="styles__filterComponent__"]');
        const clearButton = filterComponent?.querySelector('button[data-testid="clear-button"]');
        if (clearButton) {
            clearButton.click();
            await new Promise(r => setTimeout(r, 100));
        }
    }

    async clearDraftKingsFilters() {
        const allTabButton = document.querySelector('#dk-tab-ALL');
        const textField = document.querySelector('input.DKInput_input');

        if (allTabButton) {
            allTabButton.click();
        }

        if (textField) {
            textField.value = '';
            const event = new Event('input', { bubbles: true });
            textField.dispatchEvent(event);
        }
    }

    async findAndClickPlayer(playerName, team, position) {
        if (this.site_type === 'underdog') {
            await this.findAndClickPlayerUnderdog(playerName);
        } else if (this.site_type === 'draftkings') {
            const initializedName = this.convertToInitializedFormat(playerName);
            await this.findAndClickPlayerDraftKings(playerName, initializedName, position);
        }
    }

    convertToInitializedFormat(fullName) {
        const [firstName, ...lastNameParts] = fullName.split(' ');
        const lastName = lastNameParts.join(' ');
        return `${firstName.charAt(0)}. ${lastName}`;
    }

    async findAndClickPlayerUnderdog(playerName) {
        const targetName = playerName.trim();
        const findPlayerGrid = async (retryCount = 0) => {
            const grid = document.querySelector('.ReactVirtualized__Grid.ReactVirtualized__List');
            if (!grid) {
                if (retryCount < 10) {
                    await new Promise(resolve => setTimeout(resolve, 100));
                    return findPlayerGrid(retryCount + 1);
                } else {
                    console.error('[Queue Click] Player grid not found after multiple attempts.');
                    return;
                }
            }

            let startTime = new Date().getTime();

            const scrollAndFindPlayer = async () => {
                const currentTime = new Date().getTime();
                if (currentTime - startTime >= 3000) {
                    console.error(`[Queue Click] Player ${playerName} not found within timeout.`);
                    this.scrollToTop(grid);
                    return;
                }

                const playerCells = grid.querySelectorAll('[class*="styles__playerCell__"][class*="styles__playerCell__"]');
                let targetPlayerCell = null;

                playerCells.forEach(cell => {
                    const nameElement = cell.querySelector('[class^="styles__playerName__"]');
                    if (!nameElement) {
                        return;
                    }
                    const cellName = nameElement.textContent.trim();
                    if (cellName === targetName) {
                        targetPlayerCell = cell;
                    }
                });

                if (targetPlayerCell) {
                    let queueButton =
                        targetPlayerCell.querySelector('[class^="styles__queuedStar__"]') ||
                        targetPlayerCell.querySelector('svg use[href="#starOutlined__gen"]')?.closest('button') ||
                        targetPlayerCell.querySelector('svg use[href="#starFilled__gen"]')?.closest('button');

                    if (queueButton) {
                        queueButton.click();
                        this.scrollToTop(grid);
                    } else {
                        console.error('[Queue Click] Queue button not found in player cell.');
                        this.scrollToTop(grid);
                    }
                } else {
                    grid.scrollTop += grid.clientHeight;
                    await new Promise(resolve => setTimeout(resolve, 100));
                    scrollAndFindPlayer();
                }
            };

            this.scrollToTop(grid);
            await new Promise(resolve => setTimeout(resolve, 100));
            scrollAndFindPlayer();
        };
        await findPlayerGrid();
    }

    getDraftKingsAcceptedNames(fullName, initializedName) {
        const targetName = fullName.trim();
        const initializedTargetName = initializedName.trim();
        return new Set([targetName, initializedTargetName]);
    }

    async findAndClickPlayerDraftKings(playerName, initializedName, playerPosition) {
        const acceptedNames = this.getDraftKingsAcceptedNames(playerName, initializedName);

        const findPlayerGrid = async (retryCount = 0) => {
            const grid = document.querySelector('.BaseTable__body');
            if (!grid) {
                if (retryCount < 10) {
                    await new Promise(resolve => setTimeout(resolve, 100));
                    return findPlayerGrid(retryCount + 1);
                } else {
                    console.error('[Queue Click] Player grid not found after multiple attempts.');
                    return;
                }
            }

            let startTime = new Date().getTime();

            const scrollAndFindPlayer = async () => {
                const currentTime = new Date().getTime();
                if (currentTime - startTime >= 2000) {
                    console.error(`[Queue Click] Player ${playerName} not found within timeout.`);
                    this.scrollToTop(grid);
                    return;
                }

                const playerRows = grid.querySelectorAll('.BaseTable__row');
                let targetPlayerRow = null;

                for (const row of playerRows) {
                    const nameElement = row.querySelector('.PlayerCell_player-name');
                    const positionElement = row.querySelector('.player-position');

                    if (nameElement && positionElement) {
                        const fullName = nameElement.textContent.trim();
                        const position = positionElement.textContent.trim();

                        const nameMatch =
                            acceptedNames.has(fullName) ||
                            this._isDraftKingsNameMatch(fullName, playerName);

                        if (nameMatch && position === playerPosition) {
                            targetPlayerRow = row;
                            break;
                        }
                    }
                }

                if (targetPlayerRow) {
                    const queueButton = targetPlayerRow.querySelector('.QueueIcon_queue-button');
                    if (queueButton) {
                        queueButton.click();
                        this.scrollToTop(grid);
                    } else {
                        console.error('[Queue Click] Queue button not found in player row.');
                        this.scrollToTop(grid);
                    }
                } else {
                    grid.scrollTop += grid.clientHeight;
                    await new Promise(resolve => setTimeout(resolve, 100));
                    scrollAndFindPlayer();
                }
            };

            this.scrollToTop(grid);
            await new Promise(resolve => setTimeout(resolve, 100));
            scrollAndFindPlayer();
        };
        await findPlayerGrid();
    }

    scrollToTop(grid) {
        if (grid) {
            grid.scrollTop = 0;
        }
    }
}


function playersListFromDoc(doc) {
    const raw = doc?.players;
    if (!raw) return [];
    if (Array.isArray(raw)) return raw;
    if (typeof raw === 'object') {
        return Object.entries(raw).map(([k, v]) => {
            if (!v || typeof v !== 'object') return null;
            const hasId = v.id ?? v.dk_id ?? v.dkID ?? v.ud_id ?? v.udId;
            return hasId ? v : { ...v, id: k };
        }).filter(Boolean);
    }
    return [];
}

function getPos(player) {
    const raw = player?.pos ?? player?.slot ?? player?.position;
    if (raw == null || raw === '') return '';
    return String(raw).trim().toLowerCase();
}

function byePosBucket(pos) {
    let bucket = getPos({ pos });
    if (bucket === 'fb') bucket = 'rb';
    if (bucket === 'qb' || bucket === 'rb' || bucket === 'wr' || bucket === 'te') {
        return bucket;
    }
    return null;
}

function coerceByeWeek(raw) {
    const n = parseInt(raw, 10);
    return Number.isFinite(n) ? n : 0;
}

function effectiveTeam(player, teamOverrideMap) {
    const map = teamOverrideMap || {};
    const keys = [player?.ud_id, player?.udId, player?.dk_id, player?.dkID, player?.id]
        .filter((v) => v != null && v !== '')
        .map(String);
    for (let i = 0; i < keys.length; i++) {
        const override = map[keys[i]];
        if (override) return override;
    }
    const team = player?.team;
    return team != null && team !== '' ? String(team) : null;
}

function buildTeamOverrideMap(teamOverrideDoc) {
    const map = {};
    const entries = teamOverrideDoc?.players;
    if (!Array.isArray(entries)) return map;
    for (let i = 0; i < entries.length; i++) {
        const entry = entries[i];
        const val = entry?.teamOverride;
        if (!val) continue;
        const ud = entry.ud_id ?? entry.udId;
        const dk = entry.dk_id ?? entry.dkId;
        if (ud != null && ud !== '') map[String(ud)] = val;
        if (dk != null && dk !== '') map[String(dk)] = val;
    }
    return map;
}

function applyTeamOverrideToPlayers(players, overrideMap) {
    const map = overrideMap || {};
    if (!Array.isArray(players)) return [];
    return players.map((p) => {
        const keys = [p?.ud_id, p?.udId, p?.dk_id, p?.dkID, p?.id]
            .filter((v) => v != null && v !== '')
            .map(String);
        let override = null;
        for (let i = 0; i < keys.length; i++) {
            if (map[keys[i]]) {
                override = map[keys[i]];
                break;
            }
        }
        if (!override) return p;
        return { ...p, real_team: p.team, team: override };
    });
}

function extractBbmTeams(bbmTeamsDoc) {
    const teamData = bbmTeamsDoc?.teamData;
    if (!teamData || typeof teamData !== 'object' || Array.isArray(teamData)) {
        return {};
    }
    return teamData;
}

function rosterByeBucketKey(team, bbmTeams) {
    if (!team || team === 'FA') return null;
    if (!bbmTeams || !Object.prototype.hasOwnProperty.call(bbmTeams, team)) {
        return 'NA';
    }
    const bye = coerceByeWeek(bbmTeams[team]?.bye);
    return String(bye);
}

function buildRosterByeHistograms(currentRoster, teamOverrideMap, bbmTeams) {
    const histograms = {
        qb: {},
        rb: {},
        wr: {},
        te: {}
    };
    const roster = Array.isArray(currentRoster) ? currentRoster : [];
    for (let i = 0; i < roster.length; i++) {
        const r = roster[i];
        const bucket = byePosBucket(getPos(r));
        if (!bucket) continue;
        const team = effectiveTeam(r, teamOverrideMap);
        const byeKey = rosterByeBucketKey(team, bbmTeams);
        if (byeKey == null) continue;
        histograms[bucket][byeKey] = (histograms[bucket][byeKey] || 0) + 1;
    }
    return histograms;
}

function applyRegularSeasonSimTags(players, currentRoster, options) {
    const opts = options || {};
    const scheduleCalcsEnabled = !!opts.scheduleCalcsEnabled;
    const bbmTeams = opts.bbmTeams && typeof opts.bbmTeams === 'object' ? opts.bbmTeams : {};
    const teamOverrideMap = opts.teamOverrideMap || {};
    const useSchedule = scheduleCalcsEnabled && Object.keys(bbmTeams).length > 0;

    const roster = Array.isArray(currentRoster) ? currentRoster : [];
    const candidates = Array.isArray(players) ? players : [];

    const qbTeams = new Set();
    const nonQbTeamCounts = {};

    for (let i = 0; i < roster.length; i++) {
        const r = roster[i];
        const pos = getPos(r);
        const team = effectiveTeam(r, teamOverrideMap);
        if (!team || team === 'FA') continue;
        if (pos === 'qb') {
            qbTeams.add(team);
        } else {
            nonQbTeamCounts[team] = (nonQbTeamCounts[team] || 0) + 1;
        }
    }

    const rosterByeHistograms = useSchedule
        ? buildRosterByeHistograms(roster, teamOverrideMap, bbmTeams)
        : null;

    return candidates.map((player) => {
        const tags = [];
        const team = effectiveTeam(player, teamOverrideMap);
        const pos = getPos(player);

        if (team && team !== 'FA' && pos !== 'qb' && qbTeams.has(team)) {
            tags.push('QB');
        }

        if (team && team !== 'FA') {
            const tmCount = nonQbTeamCounts[team] || 0;
            if (tmCount > 0) {
                tags.push(`TMx${tmCount}`);
            }
        }

        if (useSchedule && team && team !== 'FA') {
            const teamData = bbmTeams[team];
            if (teamData && teamData.w17) {
                const w17Opp = String(teamData.w17);
                let w17Count = 0;
                for (let ri = 0; ri < roster.length; ri++) {
                    const rosterTeam = effectiveTeam(roster[ri], teamOverrideMap);
                    if (rosterTeam === w17Opp) w17Count++;
                }
                if (w17Count > 0) {
                    tags.push(`W17x${w17Count}`);
                }
            }

            const posBucket = byePosBucket(pos);
            if (posBucket && rosterByeHistograms) {
                const candidateByeKey = rosterByeBucketKey(team, bbmTeams);
                if (candidateByeKey != null && candidateByeKey !== 'NA') {
                    const byeCount = rosterByeHistograms[posBucket][candidateByeKey] || 0;
                    if (byeCount > 0) {
                        tags.push(`Byex${byeCount}`);
                    }
                }
            }
        }

        return { ...player, tags };
    });
}

function siteOverlayKeyFromSiteName(siteName) {
    const s = (siteName || '').trim().toLowerCase();
    if (s.includes('underdog')) return 'underdog';
    return 'draftkings';
}

function coerceAdpValue(value) {
    if (value == null || value === '') return null;
    if (typeof value === 'boolean') return null;
    if (typeof value === 'number') return Number.isFinite(value) ? value : null;
    const n = parseFloat(String(value).trim());
    return Number.isFinite(n) ? n : null;
}

function playerIdForAdpOverride(player, siteCode) {
    const useUd = siteCode === 'ud';
    if (useUd) {
        const id = player?.ud_id ?? player?.udId ?? player?.id;
        return id != null && id !== '' ? String(id) : '';
    }
    const id = player?.dk_id ?? player?.dkID ?? player?.id;
    return id != null && id !== '' ? String(id) : '';
}

function draftSelectionMapForDraft(draftSelections, draftId) {
    if (!draftSelections || typeof draftSelections !== 'object') return {};
    const draftKey = draftId != null && draftId !== '' ? String(draftId) : null;
    if (draftKey && draftSelections[draftKey] && typeof draftSelections[draftKey] === 'object') {
        const nested = draftSelections[draftKey];
        const sample = Object.values(nested)[0];
        if (sample && typeof sample === 'object' && sample.adp_override !== undefined) {
            return nested;
        }
    }
    return draftSelections;
}

function lookupSavedAdpOverride(draftSelections, draftId, playerId) {
    if (!playerId) return undefined;
    const map = draftSelectionMapForDraft(draftSelections, draftId);
    const entry = map?.[String(playerId)];
    if (entry && typeof entry === 'object' && entry.adp_override !== undefined) {
        return entry.adp_override;
    }
    if (map?.[String(playerId)] != null && typeof map[String(playerId)] !== 'object') {
        return map[String(playerId)];
    }
    return undefined;
}

function mergeAdpOverrides(players, draftSelections, siteCode, draftId) {
    const list = Array.isArray(players) ? players : [];
    return list.map((player) => {
        const pid = playerIdForAdpOverride(player, siteCode);
        const saved = lookupSavedAdpOverride(draftSelections, draftId, pid);
        if (saved == null) {
            const copy = { ...player };
            delete copy.adp_override;
            return copy;
        }
        return { ...player, adp_override: saved };
    });
}

function applyAdpOverrideToPlayers(players) {
    const list = Array.isArray(players) ? players : [];
    return list.map((player) => {
        const copy = { ...player };
        delete copy.real_adp;
        const delta = coerceAdpValue(copy.adp_override);
        if (delta == null) return copy;
        const baseAdp = coerceAdpValue(copy.base_adp ?? copy.adp);
        if (baseAdp == null) return copy;
        copy.real_adp = baseAdp;
        copy.adp = baseAdp + delta;
        return copy;
    });
}

function applyAdpOverridesForEnv(players, draftSelections, siteCode, draftId, enabled) {
    if (!enabled) return Array.isArray(players) ? players : [];
    const withMerged = mergeAdpOverrides(players, draftSelections, siteCode, draftId);
    return applyAdpOverrideToPlayers(withMerged);
}

function resetPlayerToBaseAdp(player) {
    const copy = { ...player };
    delete copy.real_adp;
    delete copy.adp_override;
    if (copy.base_adp != null) {
        copy.adp = copy.base_adp;
    }
    return copy;
}

const FALLBACK_ADP_SENTINEL = 999;
const FALLBACK_USER_RANK = 999;

const FORMAT_FORCED_ADP_RANKING = new Set([
    'superflex',
    'weekly_winners',
    'eliminator',
    'marathon',
    'sprint'
]);

const ALL_LEGUP_RANKING_SETS = ['legup', 'adp', 'custom'];

// Ranking sets allowed per scoring override (mirrors backend enrichment.SCORING_RANKING_SET_POLICY).
// First entry is the fallback when the selected set is not allowed. fppr ranks like standard
// hppr so LegUp ranks stay usable; tep is ADP-only.
const SCORING_RANKING_SET_POLICY = {
    fppr: ['legup', 'adp'],
    tep: ['adp']
};

function allowedLegUpRankingSets(formatType, scoring) {
    if (FORMAT_FORCED_ADP_RANKING.has(normalizeFormatType(formatType))) {
        return ['adp'];
    }
    const policy = SCORING_RANKING_SET_POLICY[normalizeScoring(scoring)];
    return policy ? [...policy] : [...ALL_LEGUP_RANKING_SETS];
}

function isAdpOnlyFormatType(formatType, scoring) {
    const allowed = allowedLegUpRankingSets(formatType, scoring);
    return allowed.length === 1 && allowed[0] === 'adp';
}

function normalizeScoring(scoring) {
    if (scoring == null) return '';
    return String(scoring).trim().toLowerCase();
}

// Scoring-variant Underdog slates keep format_type=standard; a recognized scoring
// value overrides the format's ADP column (mirrors backend enrichment.SCORING_TO_UD_ADP_KEY).
const SCORING_UD_ADP_FIELDS = {
    fppr: ['ud_ppr_adp'],
    tep: ['ud_tep_adp']
};
const SCORING_UD_ADP_RANK_FIELDS = {
    fppr: ['ud_ppr_adp_rank'],
    tep: ['ud_tep_adp_rank']
};
const FORMAT_UD_ADP_RANK_FIELDS = {
    standard: ['ud_bbm_adp_rank'],
    eliminator: ['ud_eli_adp_rank'],
    weekly_winners: ['ud_ww_adp_rank'],
    superflex: ['ud_sf_adp_rank'],
    sprint: ['ud_spr_adp_rank'],
    marathon: ['ud_mar_adp_rank'],
    playoff: ['ud_bbm_adp_rank']
};

function resolveLegUpRankingSet(rankingSet, formatType, scoring) {
    // Effective sort mode only — does not change the persisted ranking_set selection.
    const allowed = allowedLegUpRankingSets(formatType, scoring);
    const requested = normalizeLegUpRankingSet(rankingSet);
    return allowed.includes(requested) ? requested : allowed[0];
}

function resolveLegUpSiteCode(siteName) {
    if (siteName === 'ud' || siteName === 'dk') return siteName;
    const s = (siteName || '').trim().toLowerCase();
    if (s.includes('underdog')) return 'ud';
    return 'dk';
}

function normalizeFormatType(formatType) {
    const s = formatType != null ? String(formatType).trim().toLowerCase() : 'standard';
    return s || 'standard';
}

function normalizeLegUpRankingSet(rankingSet) {
    const s = rankingSet != null ? String(rankingSet).trim().toLowerCase() : 'legup';
    if (s === 'adp' || s === 'custom') return s;
    return 'legup';
}

function formatLegUpRankingSetLabel(rankingSet) {
    const normalized = normalizeLegUpRankingSet(rankingSet);
    if (normalized === 'adp') return 'ADP';
    if (normalized === 'custom') return 'Custom Rank';
    return 'LegUp Rank';
}

function getEffectiveRankingSet(rankingSet, formatType, scoring) {
    return resolveLegUpRankingSet(rankingSet, formatType, scoring);
}

function udAdpFieldsForFormatType(formatType, scoring) {
    const scoringFields = SCORING_UD_ADP_FIELDS[normalizeScoring(scoring)];
    if (scoringFields) {
        return scoringFields;
    }
    const fmt = normalizeFormatType(formatType);
    if (fmt === 'eliminator') {
        return ['ud_eli_adp', 'ud_elim_adp'];
    }
    const map = {
        standard: ['ud_bbm_adp'],
        weekly_winners: ['ud_ww_adp'],
        superflex: ['ud_sf_adp'],
        sprint: ['ud_spr_adp'],
        marathon: ['ud_mar_adp'],
        playoff: ['ud_bbm_adp']
    };
    return map[fmt] || ['ud_bbm_adp'];
}

function udAdpRankFieldsForFormatType(formatType, scoring) {
    const scoringFields = SCORING_UD_ADP_RANK_FIELDS[normalizeScoring(scoring)];
    if (scoringFields) {
        return scoringFields;
    }
    return FORMAT_UD_ADP_RANK_FIELDS[normalizeFormatType(formatType)] || ['ud_bbm_adp_rank'];
}

function coerceNumericField(raw, missing = FALLBACK_ADP_SENTINEL) {
    if (raw == null || raw === '') return missing;
    const n = Number(raw);
    return Number.isFinite(n) ? n : missing;
}

function firstNumericField(player, fieldNames, missing = FALLBACK_ADP_SENTINEL) {
    const names = Array.isArray(fieldNames) ? fieldNames : [fieldNames];
    for (let i = 0; i < names.length; i++) {
        const val = coerceNumericField(player?.[names[i]], null);
        if (val != null) return val;
    }
    return missing;
}

function copyPlayerFieldsForRanking(player, site, formatType, scoring) {
    if (!player || typeof player !== 'object') {
        return { adp: FALLBACK_ADP_SENTINEL };
    }

    const siteCode = resolveLegUpSiteCode(site);
    const out = { ...player };
    delete out.real_adp;

    const fullName = player.full_name ?? player.fullName ?? player.name;
    if (fullName) {
        out.full_name = String(fullName).trim();
        out.fullName = out.full_name;
    }

    const udId = player.ud_id ?? player.udId;
    const dkId = player.dk_id ?? player.dkID;
    if (!out.id) {
        out.id = player.id ?? (siteCode === 'ud' ? udId : dkId) ?? udId ?? dkId;
    }
    if (udId != null && udId !== '') out.ud_id = udId;
    if (dkId != null && dkId !== '') out.dk_id = dkId;

    if (siteCode === 'ud') {
        out.adp = firstNumericField(player, udAdpFieldsForFormatType(formatType, scoring));
        const udRank = firstNumericField(player, udAdpRankFieldsForFormatType(formatType, scoring), null);
        if (udRank != null) {
            out.adp_rank = udRank;
        }
    } else {
        out.adp = firstNumericField(player, ['adp', 'dk_adp']);
        const adpRank = firstNumericField(player, ['adp_rank', 'dk_adp_rank'], null);
        if (adpRank != null) {
            out.adp_rank = adpRank;
        }
    }

    const canonicalAdp = coerceAdpValue(out.adp);
    if (canonicalAdp != null) {
        out.base_adp = canonicalAdp;
        out.adp = canonicalAdp;
    }

    return out;
}

// Compact custom-rankings diagnostics (Kickstand Custom vs LegUp order). Throttled by signature.
let _customRankDebugSig = '';

function inspectCustomRankingsEntries(customRankings, useUd) {
    const list = Array.isArray(customRankings) ? customRankings : [];
    let mappedCount = 0;
    let idOnlyCount = 0;
    let missingIdCount = 0;
    let sampleEntryKeys = null;
    const sampleMappedIds = [];
    const sampleIdOnly = [];

    for (let i = 0; i < list.length; i++) {
        const entry = list[i];
        if (!entry || typeof entry !== 'object') {
            missingIdCount += 1;
            continue;
        }
        if (sampleEntryKeys == null) {
            sampleEntryKeys = Object.keys(entry).slice(0, 12);
        }
        const siteId = useUd ? (entry.ud_id ?? entry.udId) : (entry.dk_id ?? entry.dkId);
        const genericId = entry.id ?? entry.uuid;
        if (siteId != null && siteId !== '') {
            mappedCount += 1;
            if (sampleMappedIds.length < 3) sampleMappedIds.push(String(siteId));
        } else if (genericId != null && genericId !== '') {
            idOnlyCount += 1;
            if (sampleIdOnly.length < 3) sampleIdOnly.push(String(genericId));
        } else {
            missingIdCount += 1;
        }
    }

    return {
        entryCount: list.length,
        mappedCount,
        idOnlyCount,
        missingIdCount,
        sampleEntryKeys: sampleEntryKeys || [],
        sampleMappedIds,
        sampleIdOnly,
    };
}

function logCustomRankingsApplyDebug({ useUd, customRankings, players, customRankMap }) {
    const inspect = inspectCustomRankingsEntries(customRankings, useUd);
    const mapSize = customRankMap && typeof customRankMap === 'object'
        ? Object.keys(customRankMap).length
        : 0;
    const list = Array.isArray(players) ? players : [];
    let matched = 0;
    let fallback = 0;
    for (let i = 0; i < list.length; i++) {
        if (customUserRankForPlayer(list[i], customRankMap || {}, useUd) === FALLBACK_USER_RANK) {
            fallback += 1;
        } else {
            matched += 1;
        }
    }
    const topPlayerIds = list.slice(0, 5).map((p) => {
        const id = useUd ? (p?.ud_id ?? p?.udId) : (p?.dk_id ?? p?.dkID);
        return id != null ? String(id) : null;
    });
    const payload = {
        site: useUd ? 'ud' : 'dk',
        ...inspect,
        mapSize,
        playerCount: list.length,
        matched,
        fallback,
        topPlayerIds,
        likelyIdFieldMismatch: inspect.entryCount > 0 && mapSize === 0,
        likelyEmptyDataset: inspect.entryCount === 0,
    };
    // Re-log when shape/match health changes (not on every pick filter).
    const sig = [
        payload.site,
        payload.entryCount,
        payload.mappedCount,
        payload.idOnlyCount,
        payload.mapSize,
        matched === 0 ? 'zero_match' : 'has_match',
        payload.likelyIdFieldMismatch ? 'id_mismatch' : '',
    ].join('|');
    if (sig === _customRankDebugSig) return;
    _customRankDebugSig = sig;
}

function customRankEntryId(entry, useUd) {
    if (!entry || typeof entry !== 'object') return null;
    const siteId = useUd ? (entry.ud_id ?? entry.udId) : (entry.dk_id ?? entry.dkId);
    if (siteId != null && siteId !== '') return String(siteId);
    // CSV upload / config datasets often use generic `id` (site slate id).
    const genericId = entry.id ?? entry.uuid;
    if (genericId != null && genericId !== '') return String(genericId);
    return null;
}

function buildCustomUserRankMap(customRankings, useUd) {
    const rankMap = {};
    const list = Array.isArray(customRankings) ? customRankings : [];
    for (let i = 0; i < list.length; i++) {
        const id = customRankEntryId(list[i], useUd);
        if (id == null) continue;
        rankMap[id] = i + 1;
    }
    return rankMap;
}

function customUserRankForPlayer(player, rankMap, useUd) {
    const map = rankMap || {};
    const keys = [];
    const primary = useUd ? (player?.ud_id ?? player?.udId) : (player?.dk_id ?? player?.dkID);
    if (primary != null && primary !== '') keys.push(String(primary));
    if (player?.id != null && player.id !== '') keys.push(String(player.id));
    const alt = useUd ? (player?.dk_id ?? player?.dkID) : (player?.ud_id ?? player?.udId);
    if (alt != null && alt !== '') keys.push(String(alt));
    for (let i = 0; i < keys.length; i++) {
        if (map[keys[i]] !== undefined) return map[keys[i]];
    }
    return FALLBACK_USER_RANK;
}

function setUserRankOnPlayer(player, effectiveRankingSet, siteCode, formatType, customRankMap, scoring) {
    const fmt = normalizeFormatType(formatType);
    const useUd = siteCode === 'ud';
    let userRank = FALLBACK_USER_RANK;

    if (effectiveRankingSet === 'legup') {
        const key = useUd ? 'ud_leg_up_rank' : 'dk_leg_up_rank';
        userRank = firstNumericField(player, [key], FALLBACK_USER_RANK);
    } else if (effectiveRankingSet === 'custom') {
        userRank = customUserRankForPlayer(player, customRankMap || {}, useUd);
    } else if (effectiveRankingSet === 'adp') {
        if (useUd) {
            if (fmt === 'standard') {
                userRank = firstNumericField(player, udAdpRankFieldsForFormatType(fmt, scoring), FALLBACK_USER_RANK);
            } else {
                userRank = coerceAdpValue(player.adp) ?? FALLBACK_USER_RANK;
            }
        } else if (fmt === 'standard') {
            const fromRank = coerceAdpValue(player.adp_rank);
            userRank = fromRank != null ? fromRank : (coerceAdpValue(player.adp) ?? FALLBACK_USER_RANK);
        } else {
            userRank = coerceAdpValue(player.adp) ?? FALLBACK_USER_RANK;
        }
    }

    return { ...player, user_rank: userRank };
}

function applyUserRanksWithoutSort(players, rankingSet, formatType, siteCode, customRankings, scoring) {
    const effective = getEffectiveRankingSet(rankingSet, formatType, scoring);
    const useUd = siteCode === 'ud';
    const customRankMap =
        effective === 'custom' ? buildCustomUserRankMap(customRankings, useUd) : null;
    if (effective === 'custom') {
        logCustomRankingsApplyDebug({
            useUd,
            customRankings,
            players,
            customRankMap,
        });
    }
    return (Array.isArray(players) ? players : []).map((p) =>
        setUserRankOnPlayer(p, effective, siteCode, formatType, customRankMap, scoring)
    );
}

function applyUserRanksAndSort(players, rankingSet, formatType, siteCode, customRankings, scoring) {
    const effective = getEffectiveRankingSet(rankingSet, formatType, scoring);
    const useUd = siteCode === 'ud';
    const customRankMap =
        effective === 'custom' ? buildCustomUserRankMap(customRankings, useUd) : null;
    if (effective === 'custom') {
        logCustomRankingsApplyDebug({
            useUd,
            customRankings,
            players,
            customRankMap,
        });
    }
    const withRanks = (Array.isArray(players) ? players : []).map((p) =>
        setUserRankOnPlayer(p, effective, siteCode, formatType, customRankMap, scoring)
    );
    return sortPlayersByUserRank(withRanks);
}

function sortPlayersByUserRank(players) {
    return [...players].sort((a, b) => {
        const ar = coerceNumericField(a?.user_rank, FALLBACK_USER_RANK);
        const br = coerceNumericField(b?.user_rank, FALLBACK_USER_RANK);
        return ar - br;
    });
}

function buildPlayerIndex(mergedDoc, site, formatType, scoring) {
    const siteCode = resolveLegUpSiteCode(site);
    const rawPlayers = playersListFromDoc(mergedDoc);
    const players = rawPlayers.map((p) => copyPlayerFieldsForRanking(p, siteCode, formatType, scoring));
    const byUdId = {};
    const byDkId = {};
    const byId = {};

    for (let i = 0; i < players.length; i++) {
        const p = players[i];
        const id = p?.id ?? p.ud_id ?? p.udId ?? p.dk_id ?? p.dkID;
        if (id != null && id !== '') byId[String(id)] = p;
        const ud = p?.ud_id ?? p.udId;
        const dk = p?.dk_id ?? p.dkID;
        if (ud != null && ud !== '') byUdId[String(ud)] = p;
        if (dk != null && dk !== '') byDkId[String(dk)] = p;
    }

    return { players, byUdId, byDkId, byId, siteCode };
}

function lookupPlayerFromIndex(ref, index, useUd) {
    if (!ref || typeof ref !== 'object' || !index) return null;
    const keys = [];
    if (useUd) {
        if (ref.ud_id != null && ref.ud_id !== '') keys.push(String(ref.ud_id));
        if (ref.udId != null && ref.udId !== '') keys.push(String(ref.udId));
    } else {
        if (ref.dk_id != null && ref.dk_id !== '') keys.push(String(ref.dk_id));
        if (ref.dkId != null && ref.dkId !== '') keys.push(String(ref.dkId));
    }
    if (ref.id != null && ref.id !== '') keys.push(String(ref.id));
    if (!useUd) {
        if (ref.ud_id != null && ref.ud_id !== '') keys.push(String(ref.ud_id));
        if (ref.udId != null && ref.udId !== '') keys.push(String(ref.udId));
    } else {
        if (ref.dk_id != null && ref.dk_id !== '') keys.push(String(ref.dk_id));
        if (ref.dkId != null && ref.dkId !== '') keys.push(String(ref.dkId));
    }

    for (let i = 0; i < keys.length; i++) {
        const k = keys[i];
        if (index.byUdId[k]) return { ...index.byUdId[k] };
        if (index.byDkId[k]) return { ...index.byDkId[k] };
        if (index.byId[k]) return { ...index.byId[k] };
    }
    return null;
}

function enrichPlayerRefs(refs, index, siteCode, formatType, scoring) {
    const useUd = siteCode === 'ud';
    const list = Array.isArray(refs) ? refs : [];
    const out = [];
    for (let i = 0; i < list.length; i++) {
        const ref = list[i];
        const enriched = lookupPlayerFromIndex(ref, index, useUd);
        if (enriched) {
            out.push(enriched);
        } else if (ref && typeof ref === 'object') {
            out.push(copyPlayerFieldsForRanking(ref, siteCode, formatType, scoring));
        } else {
            out.push(ref);
        }
    }
    return out;
}

function playerIdentityKeys(player, useUd) {
    const keys = new Set();
    if (!player || typeof player !== 'object') return keys;
    const primary = useUd ? (player.ud_id ?? player.udId) : (player.dk_id ?? player.dkID);
    if (primary != null && primary !== '') keys.add(String(primary));
    if (player.id != null && player.id !== '') keys.add(`id:${String(player.id)}`);
    const ud = player.ud_id ?? player.udId;
    const dk = player.dk_id ?? player.dkID;
    if (ud != null && ud !== '') keys.add(`ud:${String(ud)}`);
    if (dk != null && dk !== '') keys.add(`dk:${String(dk)}`);
    return keys;
}

function collectDraftedKeySet(picks, index, useUd) {
    const drafted = new Set();
    const list = Array.isArray(picks) ? picks : [];
    for (let i = 0; i < list.length; i++) {
        const enriched = lookupPlayerFromIndex(list[i], index, useUd) || list[i];
        const keys = playerIdentityKeys(enriched, useUd);
        keys.forEach((k) => drafted.add(k));
    }
    return drafted;
}

function isPlayerDrafted(player, draftedKeys, useUd) {
    const keys = playerIdentityKeys(player, useUd);
    for (const k of keys) {
        if (draftedKeys.has(k)) return true;
    }
    return false;
}

function mergedDatasetKeyForSite(siteName) {
    const s = (siteName || '').trim().toLowerCase();
    if (s.includes('underdog')) return 'merged_ud_bbm';
    return 'merged_dk_bbm';
}

function siteUsesUnderdogIds(siteName) {
    return mergedDatasetKeyForSite(siteName) === 'merged_ud_bbm';
}

function userRankingsDatasetKeyForSite(siteName) {
    const s = (siteName || '').trim().toLowerCase();
    if (s.includes('underdog')) return 'ud_bbm';
    if (s.includes('draftking')) return 'dk_bbm';
    return null;
}

const LEGUP_RANKING_SETS = ['legup', 'adp', 'custom'];

function formatPlayerDisplayName(player) {
    const full = player?.full_name ?? player?.fullName ?? player?.name;
    if (full) return String(full).trim();
    const first = player?.first_name ?? player?.firstName ?? '';
    const last = player?.last_name ?? player?.lastName ?? '';
    const joined = `${first} ${last}`.trim();
    return joined || 'Unknown Player';
}

function playerToOverlayPick(player) {
    const posRaw = getPos(player);
    const pos = posRaw ? posRaw.toUpperCase() : '';
    const name = formatPlayerDisplayName(player);
    return {
        ...player,
        full_name: name,
        name,
        pos,
        position: pos,
        tags: Array.isArray(player.tags) ? player.tags : []
    };
}

function legUpListCacheKey(rankingSet, formatType, scoring) {
    const resolved = resolveLegUpRankingSet(rankingSet, formatType, scoring);
    const scoringKey = normalizeScoring(scoring) || '_';
    return `${resolved}::${normalizeFormatType(formatType)}::${scoringKey}`;
}

function shouldRebuildLegUpListEntry(cachedEntry, draft, formatType, scoring) {
    if (!cachedEntry || !Array.isArray(cachedEntry.remaining_players)) return true;
    if (!draft) return true;
    const draftId = draft.draft_id != null ? String(draft.draft_id) : null;
    if (!draftId || cachedEntry.draft_id !== draftId) return true;
    if (cachedEntry.format_type !== normalizeFormatType(formatType)) return true;
    if ((cachedEntry.scoring || '') !== (normalizeScoring(scoring) || '')) return true;
    return false;
}

function syncLegUpListCachesAfterPick(listCaches, draftedKeys, useUd, numPicks) {
    if (!listCaches || typeof listCaches !== 'object') return listCaches || {};
    const next = { ...listCaches };
    const keys = Object.keys(next);
    for (let i = 0; i < keys.length; i++) {
        const key = keys[i];
        const entry = next[key];
        if (!entry || !Array.isArray(entry.remaining_players)) continue;
        next[key] = {
            ...entry,
            num_picks: numPicks,
            remaining_players: filterRemainingAfterPicks(entry.remaining_players, draftedKeys, useUd).map(
                resetPlayerToBaseAdp
            )
        };
    }
    return next;
}

function finalizeLegUpRemainingPlayers({
    remainingPlayers,
    draftSelections,
    draftId,
    siteCode,
    resolvedRankingSet,
    formatType,
    scoring,
    customRankings,
    rosterWithOverrides,
    teamOverrideMap,
    bbmTeams,
    scheduleCalcsEnabled,
    adpOverrideEnabled
}) {
    let withOverrides = applyAdpOverridesForEnv(
        remainingPlayers,
        draftSelections,
        siteCode,
        draftId,
        adpOverrideEnabled === true
    );
    withOverrides = applyUserRanksWithoutSort(
        withOverrides,
        resolvedRankingSet,
        formatType,
        siteCode,
        resolvedRankingSet === 'custom' ? customRankings : null,
        scoring
    );

    const taggedRemaining = applyRegularSeasonSimTags(withOverrides, rosterWithOverrides, {
        scheduleCalcsEnabled: scheduleCalcsEnabled !== false,
        bbmTeams,
        teamOverrideMap
    });

    return taggedRemaining.map((p) => playerToOverlayPick(p));
}

function filterRemainingAfterPicks(remainingPlayers, draftedKeys, useUd) {
    const list = Array.isArray(remainingPlayers) ? remainingPlayers : [];
    return list.filter((p) => !isPlayerDrafted(p, draftedKeys, useUd));
}

function buildRemainingPlayersAvailable(allPlayers, draftedKeys, useUd) {
    return (Array.isArray(allPlayers) ? allPlayers : []).filter(
        (p) => !isPlayerDrafted(p, draftedKeys, useUd)
    );
}

function buildLegUpTaggedPicks({
    draft,
    rankingSet,
    formatType,
    scoring,
    mergedDoc,
    bbmTeamsDoc,
    teamOverrideDoc,
    scheduleCalcsEnabled,
    customRankings,
    draftSelections,
    resortForAdpOverride,
    adpOverrideEnabled,
    cachedState
}) {
    if (!draft || !mergedDoc) {
        return { picks: [], cachedState: null };
    }

    const siteName = draft.site_name || '';
    const fmt = normalizeFormatType(formatType);
    const scoringNorm = normalizeScoring(scoring) || null;
    const resolvedRankingSet = resolveLegUpRankingSet(rankingSet, fmt, scoringNorm);
    const index = buildPlayerIndex(mergedDoc, siteName, fmt, scoringNorm);
    const siteCode = index.siteCode;
    const useUd = siteCode === 'ud';
    const teamOverrideMap = buildTeamOverrideMap(teamOverrideDoc);
    const bbmTeams = extractBbmTeams(bbmTeamsDoc);
    const selections = draftSelections || {};
    const draftId = draft.draft_id != null ? String(draft.draft_id) : null;
    const adpOverridesOn = adpOverrideEnabled === true;
    const shouldResort = adpOverridesOn && resortForAdpOverride === true;

    const picks = Array.isArray(draft.picks) ? draft.picks : [];
    const enrichedPicks = enrichPlayerRefs(picks, index, siteCode, fmt, scoringNorm);
    const rosterSource = Array.isArray(draft.current_roster) ? draft.current_roster : [];
    const enrichedRoster = enrichPlayerRefs(rosterSource, index, siteCode, fmt, scoringNorm);
    const rosterWithOverrides = applyTeamOverrideToPlayers(enrichedRoster, teamOverrideMap);

    const draftedKeys = collectDraftedKeySet(enrichedPicks, index, useUd);
    const numPicks = picks.length;
    const cacheKey = legUpListCacheKey(resolvedRankingSet, fmt, scoringNorm);

    let listCaches = cachedState && typeof cachedState === 'object' && !Array.isArray(cachedState)
        ? { ...cachedState }
        : {};
    if (listCaches.remaining_players) {
        listCaches = {};
    }
    const cachedEntry = listCaches[cacheKey];
    const rebuild = shouldRebuildLegUpListEntry(cachedEntry, draft, fmt, scoringNorm) || shouldResort;

    let remainingPlayers;
    if (rebuild) {
        const available = buildRemainingPlayersAvailable(index.players, draftedKeys, useUd);
        const withTeam = applyTeamOverrideToPlayers(available, teamOverrideMap);
        const withAdp = applyAdpOverridesForEnv(withTeam, selections, siteCode, draftId, adpOverridesOn);
        remainingPlayers = applyUserRanksAndSort(
            withAdp,
            resolvedRankingSet,
            fmt,
            siteCode,
            resolvedRankingSet === 'custom' ? customRankings : null,
            scoringNorm
        );
        listCaches[cacheKey] = {
            draft_id: draftId,
            format_type: fmt,
            scoring: scoringNorm || '',
            num_picks: numPicks,
            remaining_players: remainingPlayers.map(resetPlayerToBaseAdp)
        };
        remainingPlayers = listCaches[cacheKey].remaining_players;
    } else {
        listCaches = syncLegUpListCachesAfterPick(listCaches, draftedKeys, useUd, numPicks);
        remainingPlayers = (listCaches[cacheKey]?.remaining_players || []).map(resetPlayerToBaseAdp);
        if (shouldResort && remainingPlayers.length) {
            const withTeam = applyTeamOverrideToPlayers(remainingPlayers, teamOverrideMap);
            const withAdp = applyAdpOverridesForEnv(withTeam, selections, siteCode, draftId, adpOverridesOn);
            const resorted = applyUserRanksAndSort(
                withAdp,
                resolvedRankingSet,
                fmt,
                siteCode,
                resolvedRankingSet === 'custom' ? customRankings : null,
                scoringNorm
            );
            listCaches[cacheKey] = {
                ...listCaches[cacheKey],
                remaining_players: resorted.map(resetPlayerToBaseAdp)
            };
            remainingPlayers = listCaches[cacheKey].remaining_players;
        }
    }

    const overlayPicks = finalizeLegUpRemainingPlayers({
        remainingPlayers,
        draftSelections: selections,
        draftId,
        siteCode,
        resolvedRankingSet,
        formatType: fmt,
        scoring: scoringNorm,
        customRankings,
        rosterWithOverrides,
        teamOverrideMap,
        bbmTeams,
        scheduleCalcsEnabled,
        adpOverrideEnabled: adpOverridesOn
    });

    return { picks: overlayPicks, cachedState: listCaches };
}

class Overlay_Model {
    constructor() {
        this._picks = [];
        this._top_bar_message = { main_text: '', hover_text: '' };
        this._ranking_set = 'legup';
        this._algo_type = 'sim';
        this._format_type = 'standard';
        this._scoring = null; // Resolved by FSM from the draft (e.g. 'fppr' / 'tep'); null = site default
        this._advancement_structure = null;
        this._sound_enabled = false;
        this._rankings_loading = false; // Synced from fsm.state_data.rankings_loading (FSM is source of truth)
        this._icon_button_state = null; // Store icon URL or state
        this._show_notch_hover_area = false;
        this._show_notch_refresh = false; // Default to false - notch only shows when loading
        this._user_otc = false; // On-the-clock notification enabled flag
        this._picked_ids = []; // IDs of players already picked in current draft (dk_id or ud_id) for overlay opacity hint

        // Event emitter pattern
        this._listeners = {};
        
        // Store reference to FSM for validation (will be set by overlay_manager)
        this._fsm = null;
    }
    
    
    static get_valid_algo_types(env_value) {
        const baseTypes = ['sim'];
        if (['dev', 'local'].includes(env_value)) {
            return [...baseTypes, 'pure_sim', 'dev_sim'];
        }
        return baseTypes;
    }
    
    
    static validate_algo_type(value, env_value) {
        if (!value || typeof value !== 'string') {
            return 'sim';
        }
        const validTypes = Overlay_Model.get_valid_algo_types(env_value);
        return validTypes.includes(value) ? value : 'sim';
    }

    subscribe(event, callback) {
        if (!this._listeners[event]) {
            this._listeners[event] = [];
        }
        this._listeners[event].push(callback);
    }

    unsubscribe(event, callback) {
        if (!this._listeners[event]) return;
        const index = this._listeners[event].indexOf(callback);
        if (index > -1) {
            this._listeners[event].splice(index, 1);
        }
    }

    _emit(event, data = null) {
        if (this._listeners[event]) {
            this._listeners[event].forEach(callback => {
                try {
                    callback(data);
                } catch (error) {
                    console.error(`Error in ${event} listener:`, error);
                }
            });
        }
        // Also emit generic 'change' event
        if (event !== 'change' && this._listeners['change']) {
            this._listeners['change'].forEach(callback => {
                try {
                    callback({ event, data });
                } catch (error) {
                    console.error('Error in change listener:', error);
                }
            });
        }
    }

    get(property) {
        return this[`_${property}`];
    }

    set(property, value) {
        const oldValue = this[`_${property}`];
        
        // Validate algo_type before setting
        if (property === 'algo_type') {
            const env_value = this._fsm?.state_data?.env_value || 'prod';
            value = Overlay_Model.validate_algo_type(value, env_value);
        }
        
        if (oldValue === value) {
            if (property === 'rankings_loading') {
                const unchangedLogData = {
                    value: value,
                    stack: new Error().stack.split('\n').slice(1, 5).join('\n')
                };
            }
            return; // No change
        }
        
        if (property === 'rankings_loading') {
            // const changingLogData = {
            //     from: oldValue,
            //     to: value,
            //     stack: new Error().stack.split('\n').slice(1, 5).join('\n')
            // };
            // console.log('[Model] rankings_loading changing', changingLogData);
        }
        
        this[`_${property}`] = value;
        
        const eventName = `${property}Changed`;
        this._emit(eventName, { oldValue, newValue: value });
    }

    update(partial) {
        const changes = {};
        for (const [key, value] of Object.entries(partial)) {
            const oldValue = this[`_${key}`];
            if (oldValue !== value) {
                this[`_${key}`] = value;
                changes[key] = { oldValue, newValue: value };
            }
        }
        
        for (const [key, change] of Object.entries(changes)) {
            const eventName = `${key}Changed`;
            this._emit(eventName, change);
        }
    }

    // Note: picks is intentionally last to keep other keys visible first
    toJSON() {
        return {
            top_bar_message: this._top_bar_message,
            ranking_set: this._ranking_set,
            algo_type: this._algo_type,
            format_type: this._format_type,
            scoring: this._scoring,
            advancement_structure: this._advancement_structure,
            sound_enabled: this._sound_enabled,
            rankings_loading: this._rankings_loading,
            icon_button_state: this._icon_button_state,
            show_notch_hover_area: this._show_notch_hover_area,
            show_notch_refresh: this._show_notch_refresh,
            user_otc: this._user_otc,
            picks: this._picks
        };
    }
}


class Top_Bar {
    constructor(fsm, overlay_manager, model) {
        this.fsm = fsm;
        this.overlay_manager = overlay_manager;
        this.model = model;
        this.element = document.createElement('div');
        this.element.id = 'resizeTopBar';

        this.legup_button = new Legup_Button(fsm, overlay_manager, model);
        this.sound_button = new Sound_Button(fsm, overlay_manager, model);

        this.message_box = document.createElement('div');
        this.message_box.id = 'top_bar_message_box';
        this.message_box.className = 'top_bar_message_box';

        this.message_chip = document.createElement('div');
        this.message_chip.className = 'top_bar_message_chip';
        this.message_chip.textContent = '';
        this.message_box.appendChild(this.message_chip);

        this.element.appendChild(this.legup_button.element);
        this.element.appendChild(this.message_box);
        this.element.appendChild(this.sound_button.element);
        
        this._setup_model_subscriptions();
        
        this._update_from_model();
    }
    
    _setup_model_subscriptions() {
        this.model.subscribe('top_bar_messageChanged', () => {
            this._update_message();
        });
        
        this.model.subscribe('sound_enabledChanged', () => {
            this.sound_button.update_icon();
        });
    }
    
    _update_from_model() {
        this._update_message();
        this.sound_button.update_icon();
    }
    
    _update_message() {
        const message = this.model.get('top_bar_message') || { main_text: '', hover_text: '' };
        this.set_message(message);
    }

    set_message(message = { main_text: '', hover_text: '' }) {
        if (!this.message_chip) return;
        
        // Handle both dict format and legacy string format for backward compatibility
        let main_text = '';
        let hover_text = '';
        let segments = null;
        
        if (typeof message === 'string') {
            main_text = message;
            hover_text = message;
        } else if (message && typeof message === 'object') {
            main_text = message.main_text || '';
            hover_text = message.hover_text || '';
            segments = Array.isArray(message.segments) ? message.segments : null;
        }
        
        if (!segments && main_text) {
            // Parse "Round Advancement: " messages to split prefix from details
            if (main_text.startsWith('Round Advancement: ')) {
                const prefix = 'Round Advancement: ';
                const suffix = main_text.substring(prefix.length);
                main_text = prefix + '\n' + suffix;
            }
            if (main_text.includes('\n')) {
                segments = this._segments_from_multiline_text(main_text);
                main_text = '';
            }
        }
        
        if (segments?.length) {
            this._render_message_segments(segments);
        } else {
            this.message_chip.replaceChildren();
            if (main_text) {
                this.message_chip.appendChild(document.createTextNode(main_text));
            }
        }
        this.message_chip.title = hover_text || '';
        
        const has_content = segments?.length
            ? segments.some((segment) => segment.text || segment.type === 'linebreak')
            : !!main_text;
        this.message_chip.style.display = has_content ? 'flex' : 'none';
        this.message_chip.classList.toggle('top_bar_message_chip--rich', has_content);
    }

    _segments_from_multiline_text(text) {
        const lines = String(text).split('\n');
        const segments = [];
        lines.forEach((line, index) => {
            if (index > 0) {
                segments.push({ type: 'linebreak' });
            }
            if (line) {
                segments.push({ type: 'text', text: line });
            }
        });
        return segments;
    }

    _render_message_segments(segments) {
        this.message_chip.replaceChildren();
        const content = document.createElement('span');
        content.className = 'top_bar_message_content';

        for (const segment of segments) {
            if (segment.type === 'linebreak') {
                content.appendChild(document.createElement('br'));
                continue;
            }
            if (segment.type === 'link' && segment.href && segment.text) {
                const link = document.createElement('a');
                link.href = segment.href;
                link.textContent = segment.text;
                link.target = '_blank';
                link.rel = 'noopener noreferrer';
                link.addEventListener('click', (event) => event.stopPropagation());
                content.appendChild(link);
                continue;
            }
            if (segment.text) {
                if (segment.emphasis || segment.muted) {
                    const span = document.createElement('span');
                    span.className = segment.emphasis
                        ? 'top_bar_message_emphasis'
                        : 'top_bar_message_muted';
                    span.textContent = segment.text;
                    content.appendChild(span);
                } else {
                    content.appendChild(document.createTextNode(segment.text));
                }
            }
        }

        this.message_chip.appendChild(content);
    }

    clear_message() {
        this.set_message({ main_text: '', hover_text: '' });
    }
}

class Top_Bar_Button {
    constructor(fsm, overlay_manager, model, button_id) {
        this.fsm = fsm;
        this.overlay_manager = overlay_manager;
        this.model = model;
        this.element = document.createElement('button');
        this.element.id = button_id;
        this.element.className = 'top_bar_button';

        this.icon = document.createElement('img');
        this.element.appendChild(this.icon);

        this.setup_event_listeners();
    }

    setup_event_listeners() {
        this.element.addEventListener('mouseup', (e) => {
            if (!this.overlay_manager.drag_occurred) {
                this.handle_click(e);
            }
        });

        this.element.addEventListener('contextmenu', (e) => {
            e.preventDefault();
        });
    }

    handle_click() {
        // To be implemented in child classes
    }
}

class Legup_Button extends Top_Bar_Button {
    constructor(fsm, overlay_manager, model) {
        super(fsm, overlay_manager, model, 'legup_icon_button');
        this.set_icon_based_on_site();
        this._setup_draft_state_listener();
    }

    set_icon_based_on_site() {
        this.overlay_manager?._sync_legup_button_icon?.();
    }

    _setup_draft_state_listener() {
        const draft_test_page = document.getElementById('draftTestPage');
        if (!draft_test_page) return;

        const getDraftStateElement = () => {
            return document.getElementById('draftStateJsonMirror');
        };

        const setupEventListener = () => {
            const draft_state_element = getDraftStateElement();
            if (draft_state_element) {
                draft_state_element.addEventListener('draft:minimalStateChanged', () => {
                    this.set_icon_based_on_site();
                });
                return true;
            }
            return false;
        };

        if (!setupEventListener()) {
            let retryCount = 0;
            const maxRetries = 10;
            const retryInterval = 100; // 100ms

            const retryTimer = setInterval(() => {
                if (setupEventListener() || retryCount >= maxRetries) {
                    clearInterval(retryTimer);
                }
                retryCount++;
            }, retryInterval);
        }
    }

    handle_click() { }
}

class Sound_Button extends Top_Bar_Button {
    constructor(fsm, overlay_manager, model) {
        super(fsm, overlay_manager, model, 'sound_icon_button');
        this.update_icon();  // Will be refreshed again when settings load/push
    }

    handle_click() {
        // Update model (which will trigger UI update via subscription)
        const newValue = !this.model.get('sound_enabled');
        this.model.set('sound_enabled', newValue);
        
        // Also update FSM for backward compatibility
        this.fsm.user_settings.user_sound_enabled = newValue;

        if (this.fsm && this.fsm.bg_port && this.fsm.bg_connected) {
            this.fsm.send_port_request('SET_SETTINGS', {
                settings: { user_sound_enabled: newValue }
            }).catch((err) => {
                console.error('[overlay_top_bar] set_settings failed', err);
            });
        }
    }

    update_icon() {
        const on = !!this.model.get('sound_enabled');   // <-- single source of truth from model
        const icon_name = on ? 'sound_loud' : 'sound_mute';
        this.icon.src = chrome.runtime.getURL(`assets/${icon_name}.png`);
        this.element.style.backgroundColor = on ? '#53d337' : '';
    }
}
class Bottom_Bar {
    constructor(fsm, model) {
        this.fsm = fsm;
        this.model = model;
        this.element = document.createElement('div');
        this.element.id = 'bottomBar';
        this.element.className = 'bottom_bar';

        this.dropdowns = {
            ranking_set: null,
            algo_type: null,
            format_type: null
        };

        this.trailing_container = null;

        this._setup_model_subscriptions();

        this.ready = this.create_controls().then(() => {
            this._sync_dropdowns_from_model();
            // optional event that happens here: this.element.dispatchEvent(new CustomEvent('bottom-bar-ready', { bubbles: true }));
        });
    }
    
    _setup_model_subscriptions() {
        this.model.subscribe('ranking_setChanged', () => {
            if (this.dropdowns.ranking_set) {
                this.dropdowns.ranking_set.value = this.model.get('ranking_set');
            }
        });
        
        this.model.subscribe('algo_typeChanged', () => {
            if (this.dropdowns.algo_type) {
                const modelValue = this.model.get('algo_type');
                // Validate that the model value is in the dropdown options
                const validOptions = Array.from(this.dropdowns.algo_type.options).map(opt => opt.value);
                if (validOptions.includes(modelValue)) {
                    this.dropdowns.algo_type.value = modelValue;
                } else {
                    // If model value is invalid, set dropdown to first valid option and update model
                    const defaultValue = this.dropdowns.algo_type.options[0]?.value || 'sim';
                    this.dropdowns.algo_type.value = defaultValue;
                    // Model will validate this, but we ensure dropdown is never blank
                    if (modelValue !== defaultValue) {
                        this.model.set('algo_type', defaultValue);
                    }
                }
            }
        });
        
        this.model.subscribe('format_typeChanged', () => {
            if (this.dropdowns.format_type) {
                this.dropdowns.format_type.value = this.model.get('format_type');
            }
            this._update_ranking_set_visibility();
        });

        this.model.subscribe('scoringChanged', () => {
            this._update_ranking_set_visibility();
        });
    }
    
    _sync_dropdowns_from_model() {
        if (this.dropdowns.ranking_set) {
            this.dropdowns.ranking_set.value = this.model.get('ranking_set');
        }
        if (this.dropdowns.algo_type) {
            this.dropdowns.algo_type.value = this.model.get('algo_type');
        }
        if (this.dropdowns.format_type) {
            this.dropdowns.format_type.value = this.model.get('format_type');
        }
        this._update_ranking_set_visibility();
        this._update_sidekick_controls_visibility();
    }

    _allowed_ranking_sets() {
        const formatType = this.model.get('format_type') || 'standard';
        const scoring = this.model.get('scoring') || null;
        return typeof allowedLegUpRankingSets === 'function'
            ? allowedLegUpRankingSets(formatType, scoring)
            : ['legup', 'adp', 'custom'];
    }

    _should_hide_ranking_set_for_format() {
        if (this.fsm.state_data.season_stage === 'playoffs') {
            return true;
        }
        const allowed = this._allowed_ranking_sets();
        return allowed.length === 1 && allowed[0] === 'adp';
    }

    _update_ranking_set_visibility() {
        const dropdown = this.dropdowns.ranking_set;
        const container = dropdown?.closest('#ranking_set_container');
        if (!container) return;
        const hidden = this._should_hide_ranking_set_for_format();
        container.style.display = hidden ? 'none' : '';
        if (hidden) return;

        // Disallowed sets (e.g. custom on a PPR draft) are hidden rather than removed so the
        // persisted selection survives for drafts where it is allowed; the dropdown shows the
        // effective set the rankings actually use.
        const allowed = this._allowed_ranking_sets();
        Array.from(dropdown.options).forEach((option) => {
            const ok = allowed.includes(option.value);
            option.disabled = !ok;
            option.hidden = !ok;
        });
        if (typeof resolveLegUpRankingSet === 'function') {
            dropdown.value = resolveLegUpRankingSet(
                this.model.get('ranking_set'),
                this.model.get('format_type') || 'standard',
                this.model.get('scoring') || null
            );
        }
    }

    _should_hide_sidekick_controls() {
        if (this.fsm?.is_legup_lite_mode) {
            return this.fsm.is_legup_lite_mode();
        }
        return is_legup_lite_mode(this.fsm?.session_data, this.fsm?.user_settings);
    }

    _update_sidekick_controls_visibility() {
        const hide = this._should_hide_sidekick_controls();
        const display = hide ? 'none' : '';
        const algoContainer = this.dropdowns.algo_type?.closest('#algo_type_container');
        if (algoContainer) {
            algoContainer.style.display = display;
        }
        if (this.reload_button) {
            this.reload_button.style.display = display;
        }
    }


    async waitForEnvReady(timeoutMs = 3000) {
        const start = Date.now();
        while (!['dev', 'local', 'prod'].includes(this.fsm.state_data.env_value || '') &&
            Date.now() - start < timeoutMs) {
            await new Promise(r => setTimeout(r, 50));
        }
    }

    async waitForSettingsReady(timeoutMs = 3000) {
        const start = Date.now();
        while (!this.fsm.state_data.settings_ready &&
            Date.now() - start < timeoutMs) {
            await new Promise(r => setTimeout(r, 50));
        }
    }

    async create_controls() {
        if (this.element.children.length > 0) {
            this._update_sidekick_controls_visibility();
            return;
        }
        await this.waitForEnvReady();
        await this.waitForSettingsReady();

        this.create_reload_button();

        this.create_algo_type_container();
        this.create_ranking_set_container();
        this.create_format_container();

        this.trailing_container = document.createElement('div');
        this.trailing_container.className = 'bottom_bar_trailing';
        this.element.appendChild(this.trailing_container);

        this.create_open_settings_page_button();
        await this.create_environment_tag();

        if (['dev', 'local'].includes(this.fsm.state_data.env_value)) {
            this.create_reset_seed_button();
        }

        // Populate all dropdowns in parallel
        const populatePromises = [
            this.populate_algo_type_dropdown(),
            this.populate_ranking_set_dropdown(),
            this.populate_format_dropdown()
        ];
        
        await Promise.all(populatePromises);
        this._update_sidekick_controls_visibility();
    }

    _trailing_parent() {
        return this.trailing_container || this.element;
    }

    create_open_settings_page_button() {
        const button = document.createElement('button');
        button.id = 'bottom_bar_open_settings_page_button';
        button.type = 'button';
        button.className = 'reload_button bottom_bar_open_settings_page_button';
        button.title = 'Open settings';
        button.setAttribute('aria-label', 'Open settings');

        const gear = document.createElement('img');
        gear.className = 'bottom_bar_settings_gear_icon';
        gear.src = chrome.runtime.getURL('assets/gear.svg');
        gear.alt = '';
        button.appendChild(gear);

        button.addEventListener('click', () => {
            if (!this.fsm?.send_port_request) return;
            const url = chrome.runtime.getURL('settings.html');
            this.fsm.send_port_request('OPEN_NEW_TAB', { url, active: true }).catch((err) => {
                console.error('[Bottom_Bar] open settings page failed', err);
            });
        });

        this._trailing_parent().appendChild(button);
    }

    create_ranking_set_container() {
        const container = document.createElement('div');
        container.id = 'ranking_set_container';

        const dropdown = document.createElement('select');
        dropdown.id = 'ranking_set_dropdown';
        dropdown.className = 'bottom_bar_dropdown';
        
        this.dropdowns.ranking_set = dropdown;

        container.appendChild(dropdown);
        
        if (this.fsm.state_data.season_stage === 'playoffs') {
            container.style.display = 'none';
        }
        
        this.element.appendChild(container);
    }

    async populate_ranking_set_dropdown() {
        const dropdown = this.dropdowns.ranking_set;
        if (!dropdown) return;

        // Clear existing options
        dropdown.innerHTML = '';

        const groupLabel = BOTTOM_BAR_RANKING_SET_GROUP_LABEL;
        dropdown.title = groupLabel;

        const optgroup = document.createElement('optgroup');
        optgroup.label = groupLabel;

        const season_stage = this.fsm.state_data.season_stage;
        this._update_ranking_set_visibility();

        const options = [
            { value: 'legup', text: 'LegUp' },
            { value: 'adp', text: 'ADP' }
        ];

        // Only add custom option during regular season
        if (season_stage !== 'playoffs') {
            options.push({ value: 'custom', text: 'Custom' });
        }

        options.forEach(({ value, text }) => {
            const option = document.createElement('option');
            option.value = value;
            option.text = text;
            optgroup.appendChild(option);
        });
        dropdown.appendChild(optgroup);

        let initial = this.model.get('ranking_set');
        
        // If custom is selected during playoffs, reset to legup
        if (initial === 'custom' && this.fsm.state_data.season_stage === 'playoffs') {
            initial = 'legup';
            this.model.set('ranking_set', initial);
            const site = detect_site_key();
            set_overlay_for_site(site, { ui: { selected_ranking_set: initial } });
        }
        
        dropdown.value = initial;
        this._autosize_dropdown_to_options(dropdown);

        dropdown.addEventListener('change', () => {
            // Update model immediately (model is source of truth)
            this.model.set('ranking_set', dropdown.value);
            
            // Persist to storage using model value
            const newValue = this.model.get('ranking_set');
            const site = detect_site_key();
            set_overlay_for_site(site, { ui: { selected_ranking_set: newValue } });
            
            if (this.fsm?.on_overlay_event) {
                this.fsm.on_overlay_event({
                    type: 'ranking_set_changed',
                    value: newValue
                });
            }
        });
    }

    create_algo_type_container() {
        const container = document.createElement('div');
        container.id = 'algo_type_container';

        const dropdown = document.createElement('select');
        dropdown.id = 'algo_type_dropdown';
        dropdown.className = 'bottom_bar_dropdown';
        
        this.dropdowns.algo_type = dropdown;

        container.appendChild(dropdown);
        this.element.appendChild(container);
    }

    async populate_algo_type_dropdown() {
        const dropdown = this.dropdowns.algo_type;
        if (!dropdown) return;

        dropdown.innerHTML = '';

        const groupLabel = BOTTOM_BAR_ALGO_TYPE_GROUP_LABEL;
        dropdown.title = groupLabel;

        const optgroup = document.createElement('optgroup');
        optgroup.label = groupLabel;

        const options = [
            { value: 'sim', text: 'Sim', selected: true }
        ];

        // Add dev-only options
        if (['dev', 'local'].includes(this.fsm.state_data.env_value)) {
            options.push(
                { value: 'pure_sim', text: 'pure_sim' },
                { value: 'dev_sim', text: 'dev_sim' }
            );
        }

        options.forEach(opt => {
            const option = document.createElement('option');
            option.value = opt.value;
            option.text = opt.text;
            if (opt.selected) option.selected = true;
            optgroup.appendChild(option);
        });
        dropdown.appendChild(optgroup);

        // Get initial value from model and validate it's in available options
        const initialAlgo = this.model.get('algo_type');
        const validOptions = options.map(opt => opt.value);
        const validAlgo = validOptions.includes(initialAlgo) ? initialAlgo : 'sim';
        
        // Ensure model has valid value (model will validate, but we ensure dropdown is never blank)
        if (validAlgo !== initialAlgo) {
            this.model.set('algo_type', validAlgo);
        }
        
        // Always set dropdown to a valid value (never blank)
        dropdown.value = validAlgo;
        
        // Double-check: if dropdown value is somehow blank, force it to first option
        if (!dropdown.value && dropdown.options.length > 0) {
            dropdown.value = dropdown.options[0].value;
            this.model.set('algo_type', dropdown.value);
        }
        this._autosize_dropdown_to_options(dropdown);

        dropdown.addEventListener('change', async () => {
            // Validate dropdown value before setting in model
            const selectedValue = dropdown.value;
            const validOptions = Array.from(dropdown.options).map(opt => opt.value);

            // If dropdown value is invalid or blank, reset to first valid option
            if (!selectedValue || !validOptions.includes(selectedValue)) {
                const defaultValue = dropdown.options[0]?.value || 'sim';
                dropdown.value = defaultValue;
                this.model.set('algo_type', defaultValue);
                return;
            }

            // Update model immediately (model is source of truth, will validate internally)
            this.model.set('algo_type', selectedValue);

            // Use model value for all subsequent operations (model ensures it's valid)
            const newValue = this.model.get('algo_type');

            // Ensure dropdown still matches model value (in case model normalized it)
            if (dropdown.value !== newValue && validOptions.includes(newValue)) {
                dropdown.value = newValue;
            }

            const site = detect_site_key();
            set_overlay_for_site(site, { ui: { selected_algo_type: newValue } });

            const is_sim_like = newValue === 'sim' || newValue === 'dev_sim' || newValue === 'pure_sim';
            if (is_sim_like) {
                this.fsm.system_sound_enabled = false;
                this.fsm.last_recommended = null;
                // Sim-like algos: clear displayed picks in fsm/model, delete the
                // backend draft state for the prior request_identifier, wait for
                // the delete to complete, then fire a fresh rankings request.
                // reset_draft_state() performs all of those steps internally
                // (same path as the reload button).
                if (this.fsm?.reset_draft_state) {
                    try {
                        await this.fsm.reset_draft_state();
                    } catch (err) {
                        console.error('[Bottom_Bar] reset_draft_state failed on algo_type change', err);
                    }
                }
            } else if (this.fsm?.overlay_manager?.trigger_rankings_refresh) {
                // Non-sim algos: classic picks no longer ride along with sim
                // responses, so just fire a fresh rankings request.
                this.fsm.overlay_manager.trigger_rankings_refresh();
            }
        });
    }

    create_format_container() {
        const container = document.createElement('div');
        container.id = 'format_container';

        const dropdown = document.createElement('select');
        dropdown.id = 'format_dropdown';
        dropdown.className = 'bottom_bar_dropdown';
        
        this.dropdowns.format_type = dropdown;

        container.appendChild(dropdown);
        if (this.fsm.state_data.env_value === 'prod') {
            container.style.display = 'none';
        }
        this.element.appendChild(container);
    }

    async populate_format_dropdown() {
        const dropdown = this.dropdowns.format_type;
        if (!dropdown) return;

        // Clear existing options
        dropdown.innerHTML = '';

        let contest_types = [];

        // Different format options based on season stage
        const season_stage = this.fsm.state_data.season_stage;
        if (season_stage === 'playoffs') {
            contest_types = [
                { value: 'playoff', text: 'Playoff' }
            ];
        } else {
            // Regular season formats
            contest_types = [
                { value: 'standard', text: 'Standard' },
                { value: 'marathon', text: 'Marathon' },
                { value: 'sprint', text: 'Sprint' },
                { value: 'eliminator', text: 'Eliminator' },
                { value: 'weekly_winners', text: 'Weekly Winners' },
                { value: 'superflex', text: 'Superflex' }
            ];
        }

        contest_types.forEach(({ value, text }) => {
            const option = document.createElement('option');
            option.value = value;
            option.text = text;
            dropdown.appendChild(option);
        });
        const validOptions = Array.from(dropdown.options).map(opt => opt.value);
        let nextValue = this.model.get('format_type');
        const seasonDefault = season_stage === 'playoffs' ? 'playoff' : 'standard';
        if (!validOptions.includes(nextValue)) {
            nextValue = seasonDefault;
            this.model.set('format_type', nextValue);
        }
        dropdown.value = nextValue;
        // Live drafts: display-only (inferred). Test draft: editable for manual format selection.
        const onTestDraft =
            typeof is_test_draft_url === 'function' && is_test_draft_url(window.location.href);
        dropdown.disabled = !onTestDraft;
        this._autosize_dropdown_to_options(dropdown);

        if (onTestDraft && !dropdown.dataset.formatChangeBound) {
            dropdown.dataset.formatChangeBound = '1';
            dropdown.addEventListener('change', () => {
                const selected = dropdown.value;
                const optionValues = Array.from(dropdown.options).map((opt) => opt.value);
                if (!selected || !optionValues.includes(selected)) {
                    dropdown.value = this.model.get('format_type') || seasonDefault;
                    return;
                }
                this.model.set('format_type', selected);
                if (this.fsm?.state_data) {
                    this.fsm.state_data.legup_player_lists = null;
                }
                if (this.fsm?.is_legup_lite_mode?.() && this.fsm?.on_overlay_event) {
                    this.fsm.on_overlay_event({
                        type: 'format_type_changed',
                        value: selected
                    });
                } else if (this.fsm?.overlay_manager?.trigger_rankings_refresh) {
                    this.fsm.overlay_manager.trigger_rankings_refresh();
                }
            });
        }
    }

    async create_environment_tag() {
        if (!['dev', 'local'].includes(this.fsm.state_data.env_value)) {
            return;
        }

        const container = document.createElement('div');
        container.id = 'env_tag_container';
        container.className = 'env_tag';
        container.textContent = this.fsm.state_data.env_value.toUpperCase();

        container.addEventListener('click', () => {
            this.fsm.play_on_the_clock_sound(true);
        });

        this._trailing_parent().appendChild(container);
    }

    create_reload_button() {
        const button = document.createElement('button');
        button.id = 'reload_button';
        button.className = 'reload_button';
        
        const refresh_icon = document.createElement('div');
        refresh_icon.className = 'refresh-icon';
        button.appendChild(refresh_icon);
        
        this.reload_button = button;
        this.reload_icon = refresh_icon;
        
        button.addEventListener('click', async () => {
            if (this.reload_icon) {
                this.reload_icon.classList.add('is-rotating');
                setTimeout(() => {
                    this.reload_icon.classList.remove('is-rotating');
                }, 600);
            }
            
            // reset_draft_state() will trigger rankings refresh internally
            if (this.fsm?.reset_draft_state) {
                await this.fsm.reset_draft_state();
            }
        });

        this.element.appendChild(button);
    }

    create_reset_seed_button() {
        const button = document.createElement('button');
        button.id = 'reset_seed_button';
        button.className = 'reset_seed_button';
        button.textContent = 'Reset Seed';

        button.addEventListener('click', () => {
            this.fsm.reset_draft_seed();
        });

        this._trailing_parent().appendChild(button);
    }

    get_dropdown_values() {
        // Return values from model (single source of truth)
        // This method is kept for backward compatibility but now reads from model
        return {
            ranking_set: this.model.get('ranking_set') || 'legup',
            algo_type: this.model.get('algo_type') || 'sim',
            format_type: this.model.get('format_type') || 'standard'
        };
    }

    /**
     * Chrome applies a built-in minimum inline size to <select> controls that can ignore
     * CSS like width:max-content. To keep Firefox-like behavior (size to widest option),
     * measure option text and set an explicit pixel width.
     */
    _autosize_dropdown_to_options(dropdown) {
        try {
            if (!dropdown || !(dropdown instanceof HTMLSelectElement)) return;

            const style = window.getComputedStyle(dropdown);
            const font = style.font || `${style.fontSize} ${style.fontFamily}`;

            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            if (!ctx) return;
            ctx.font = font;

            // Measure widest option label (optgroups don’t render as selectable text).
            let maxText = 0;
            for (const opt of Array.from(dropdown.options || [])) {
                const text = (opt?.textContent || opt?.label || '').trim();
                if (!text) continue;
                const w = ctx.measureText(text).width;
                if (w > maxText) maxText = w;
            }

            const padL = parseFloat(style.paddingLeft || '0') || 0;
            const padR = parseFloat(style.paddingRight || '0') || 0;
            // Space for the dropdown arrow / chrome affordance (varies by OS/theme).
            // If we’ve disabled native styling, we can keep this small.
            const appearanceNone = (style.appearance === 'none' || style.webkitAppearance === 'none' || style.MozAppearance === 'none');
            const arrowAllowance = appearanceNone ? 8 : 26;
            const borderL = parseFloat(style.borderLeftWidth || '0') || 0;
            const borderR = parseFloat(style.borderRightWidth || '0') || 0;

            const widthPx = Math.ceil(maxText + padL + padR + borderL + borderR + arrowAllowance);
            // Guard against weird 0-width due to missing options.
            if (widthPx > 0) {
                dropdown.style.setProperty('min-width', '0px', 'important');
                dropdown.style.setProperty('width', `${widthPx}px`, 'important');
            }
        } catch (e) {
            // Best-effort; never break the overlay if measurement fails.
        }
    }
}
class Sidecar {
    constructor(overlay_manager, opts = {}) {
        this.overlay_manager = overlay_manager;
        this.width = opts.width ?? 360;

        this.element = null;
        this._msgInput = null;
        this._setBtn = null;
        this._use_cached_rankings_checkbox = null;
        this._force_lite_mode_checkbox = null;
    }

    static _on_force_lite_mode_changed(overlay_manager, new_value) {
        const fsm = overlay_manager?.fsm;
        if (!fsm?.session_data?.user_uuid) {
            return;
        }
        if (fsm.user_settings) {
            fsm.user_settings.force_lite_mode = new_value;
        }
        if (fsm.bg_port && fsm.bg_connected) {
            fsm.send_port_request('SET_SETTINGS', {
                settings: { force_lite_mode: new_value }
            }).catch((err) => {
                console.error('[overlay_sidecar] set_settings failed', err);
            });
        }
        overlay_manager?.refresh_legup_button_icon?.();
        if (new_value && fsm.current_state === STATE.EXTRACTION) {
            fsm._refresh_legup_local_rankings(false).catch((err) => {
                console.error('[Sidecar] LegUp local rankings refresh after force lite mode failed', err);
            });
        } else if (!new_value && fsm.get_session_access_level() === SUBSCRIPTION_TIER_SIDEKICK) {
            overlay_manager?.trigger_rankings_refresh?.();
        }
    }

    static replayUdDraftXhrFromBackground(overlay_manager) {
        if (!/\/\/app\.(?:underdogfantasy|underdogsports)\.com\//i.test(window.location.href)) {
            return;
        }
        const fsm = overlay_manager?.fsm;
        const draft_id = fsm?.state_data?.current_draft_context?.draft_id;
        if (!draft_id) {
            return;
        }
        if (!fsm.bg_port || !fsm.bg_connected) {
            return;
        }
        if (fsm.user_settings?.ud_xhr_replay_disabled) {
            return;
        }
        // Isolated-world CustomEvents do not reach MAIN-world listeners; background runs
        // chrome.scripting.executeScript(world: MAIN) to dispatch on the page window.
        fsm.send_port_request('DISPATCH_UD_DRAFT_XHR_REPLAY', { draft_id: draft_id })
            .then((resp) => {
                if (resp?.status === 'ok') {
                } else {
                }
            })
            .catch((err) => {
                console.error('[Sidecar] Replay draft XHR failed', err);
            });
    }

    _createElement() {
        if (this.element) return this.element;

        const sc = document.createElement('div');
        sc.id = 'sidecar';                       // CSS targets this id
        sc.style.width = `${this.width}px`;      // allow override by opts

        // --- Close Row ---
        const closeRow = document.createElement('div');
        closeRow.className = 'sidecar-row sidecar-close-row';
        sc.appendChild(closeRow);

        const closeBtn = document.createElement('button');
        closeBtn.id = 'sidecar_close_btn';
        closeBtn.type = 'button';
        closeBtn.className = 'sidecar-btn sidecar-close-btn';
        closeBtn.setAttribute('aria-label', 'Close sidecar');
        closeBtn.textContent = 'X';
        closeBtn.addEventListener('click', () => {
            if (this.overlay_manager?.disable_sidecar_from_ui) {
                this.overlay_manager.disable_sidecar_from_ui();
            } else if (this.overlay_manager?.close_sidecar) {
                this.overlay_manager.close_sidecar();
            } else {
                this.destroy();
                if (this.overlay_manager) {
                    this.overlay_manager.sidecar = null;
                }
            }
        });
        closeRow.appendChild(closeBtn);

        // --- Row: input + button ---
        const row = document.createElement('div');
        row.className = 'sidecar-row';
        sc.appendChild(row);

        const msgInput = document.createElement('input');
        msgInput.type = 'text';
        msgInput.id = 'sidecar_message_input';
        msgInput.className = 'sidecar-input';
        msgInput.placeholder = 'Top bar message';
        row.appendChild(msgInput);

        const setBtn = document.createElement('button');
        setBtn.id = 'sidecar_set_message_btn';
        setBtn.className = 'sidecar-btn';
        setBtn.textContent = 'Set Custom';
        row.appendChild(setBtn);

        const applyMessage = () => {
            const text = (msgInput.value || '').trim();
            // Update model (which will trigger top bar update via subscription)
            if (this.overlay_manager?.model) {
                this.overlay_manager.model.set('top_bar_message', {
                    main_text: text,
                    hover_text: text
                });
            } else {
                // Fallback if model not available
                this.overlay_manager.top_bar?.set_message?.({
                    main_text: text,
                    hover_text: text
                });
            }
            // keep text; if you want to clear: msgInput.value = '';
        };

        setBtn.addEventListener('click', applyMessage);
        msgInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') applyMessage();
        });

        // --- Auth Error Test Buttons (2 buttons per row) ---
        const authErrorTests = [
            {
                text: 'Session Window',
                message: "It's been a while since you went to legendaryupside.com. Click the button to refresh your session.",
                type: 'auth_error'
            },
            {
                text: 'App JWT Expired',
                message: 'Your Sidekick session timed out. Click the button to renew it at legendaryupside.com.',
                type: 'auth_error'
            },
            {
                text: 'Refresh Failed',
                message: 'Sidekick could not refresh your session. Click the button to try again, or restart the background script if this keeps happening.',
                type: 'auth_error'
            },
            {
                text: 'Tokens Missing',
                message: 'Sidekick needs you to sign in at legendaryupside.com. Click the button to continue.',
                type: 'auth_error'
            },
            {
                text: 'No Subscription',
                message: "You do not have Sidekick access. Subscribe to the LegUp + Sidekick tier at <a href='https://www.legendaryupside.com/#/portal/account' target='_blank'>Legendary Upside</a> and then press the button to refresh your session.",
                type: 'auth_error'
            },
            {
                text: 'Not Signed In',
                message: "Please sign in to Legendary Upside to use Sidekick. Press the button to sign in.",
                type: 'auth_error'
            },
            {
                text: 'Unknown Issue',
                message: 'Unknown issue. Please contact support.',
                type: 'auth_error'
            }
        ];

        // Create rows with 2 buttons each
        for (let i = 0; i < authErrorTests.length; i += 2) {
            const row = document.createElement('div');
            row.className = 'sidecar-row';
            
            // Add first button of the pair
            const btn1 = document.createElement('button');
            btn1.id = `sidecar_auth_${i}`;
            btn1.className = 'sidecar-btn';
            btn1.textContent = authErrorTests[i].text;
            btn1.title = authErrorTests[i].text; // Full text for hover
            btn1.setAttribute('data-message', authErrorTests[i].message);
            btn1.setAttribute('data-message-type', authErrorTests[i].type);
            btn1.style.overflow = 'hidden';
            btn1.style.textOverflow = 'ellipsis';
            btn1.style.whiteSpace = 'nowrap';
            btn1.addEventListener('click', () => {
                this.overlay_manager?.fsm?.set_sidecar_notification_preview?.(
                    authErrorTests[i].message,
                    authErrorTests[i].type
                );
            });
            row.appendChild(btn1);
            
            // Add second button if it exists
            if (i + 1 < authErrorTests.length) {
                const btn2 = document.createElement('button');
                btn2.id = `sidecar_auth_${i + 1}`;
                btn2.className = 'sidecar-btn';
                btn2.textContent = authErrorTests[i + 1].text;
                btn2.title = authErrorTests[i + 1].text; // Full text for hover
                btn2.setAttribute('data-message', authErrorTests[i + 1].message);
                btn2.setAttribute('data-message-type', authErrorTests[i + 1].type);
                btn2.style.overflow = 'hidden';
                btn2.style.textOverflow = 'ellipsis';
                btn2.style.whiteSpace = 'nowrap';
                btn2.addEventListener('click', () => {
                    this.overlay_manager?.fsm?.set_sidecar_notification_preview?.(
                        authErrorTests[i + 1].message,
                        authErrorTests[i + 1].type
                    );
                });
                row.appendChild(btn2);
            }
            
            sc.appendChild(row);
        }

        // --- Custom Message Row ---
        const customRow = document.createElement('div');
        customRow.className = 'sidecar-row';
        sc.appendChild(customRow);

        const customInput = document.createElement('input');
        customInput.type = 'text';
        customInput.id = 'sidecar_custom_message_input';
        customInput.className = 'sidecar-input';
        customInput.placeholder = 'Notification bubble message';
        customRow.appendChild(customInput);

        const customBtn = document.createElement('button');
        customBtn.id = 'sidecar_custom_message_btn';
        customBtn.className = 'sidecar-btn';
        customBtn.textContent = 'Set Custom';
        customRow.appendChild(customBtn);

        const applyCustomMessage = () => {
            const text = (customInput.value || '').trim();
            this.overlay_manager?.fsm?.set_sidecar_notification_preview?.(text, 'auth_error');
        };

        customBtn.addEventListener('click', applyCustomMessage);
        customInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') applyCustomMessage();
        });

        // --- Rankings Loading Checkbox Row ---
        const loadingCheckboxRow = document.createElement('div');
        loadingCheckboxRow.className = 'sidecar-row';
        sc.appendChild(loadingCheckboxRow);

        const loadingCheckbox = document.createElement('input');
        loadingCheckbox.type = 'checkbox';
        loadingCheckbox.id = 'sidecar_rankings_loading_checkbox';
        // Get state from model if available, otherwise from FSM
        const loadingState = this.overlay_manager?.model?.get('rankings_loading') ?? this.overlay_manager.fsm.state_data.rankings_loading;
        loadingCheckbox.checked = loadingState;
        loadingCheckbox.addEventListener('change', () => {
            const newValue = loadingCheckbox.checked;
            const checkboxChangedLogData = {
                newValue: newValue,
                old_fsm_value: this.overlay_manager.fsm.state_data.rankings_loading,
                old_model_value: this.overlay_manager?.model?.get('rankings_loading'),
                stack: new Error().stack.split('\n').slice(1, 4).join('\n')
            };
            this.overlay_manager.fsm.state_data.rankings_loading = newValue;
            // Update model
            if (this.overlay_manager?.model) {
                this.overlay_manager.model.set('rankings_loading', newValue);
            }
            this.overlay_manager.refresh_loading_animation();
        });
        loadingCheckboxRow.appendChild(loadingCheckbox);

        const loadingLabel = document.createElement('label');
        loadingLabel.setAttribute('for', 'sidecar_rankings_loading_checkbox');
        loadingLabel.textContent = 'Rankings Loading';
        loadingLabel.style.cssText = 'cursor: pointer; margin-left: 8px; color: white;';
        loadingCheckboxRow.appendChild(loadingLabel);

        // Store reference for updates
        this._rankingsLoadingCheckbox = loadingCheckbox;

        // --- Cached Rankings Toggle Row ---
        const cached_rankings_row = document.createElement('div');
        cached_rankings_row.className = 'sidecar-row';
        sc.appendChild(cached_rankings_row);

        const cached_rankings_checkbox = document.createElement('input');
        cached_rankings_checkbox.type = 'checkbox';
        cached_rankings_checkbox.id = 'sidecar_use_cached_rankings_checkbox';
        // use_cached_rankings is stored in user_settings
        const cached_state = this.overlay_manager?.fsm?.user_settings?.use_cached_rankings;
        cached_rankings_checkbox.checked = Boolean(cached_state);
        cached_rankings_checkbox.addEventListener('change', () => {
            const new_value = cached_rankings_checkbox.checked;
            // Update user_settings (source of truth)
            if (this.overlay_manager?.fsm?.user_settings) {
                this.overlay_manager.fsm.user_settings.use_cached_rankings = new_value;
            }
            // Save to background
            const fsm = this.overlay_manager?.fsm;
            if (fsm && fsm.bg_port && fsm.bg_connected) {
                fsm.send_port_request('SET_SETTINGS', {
                    settings: { use_cached_rankings: new_value }
                }).catch((err) => {
                    console.error('[overlay_sidecar] set_settings failed', err);
                });
            }
            this.overlay_manager?.trigger_rankings_refresh?.();
        });
        cached_rankings_row.appendChild(cached_rankings_checkbox);

        const cached_rankings_label = document.createElement('label');
        cached_rankings_label.setAttribute('for', 'sidecar_use_cached_rankings_checkbox');
        cached_rankings_label.textContent = 'Use Cached Rankings';
        cached_rankings_label.style.cssText = 'cursor: pointer; margin-left: 8px; color: white;';
        cached_rankings_row.appendChild(cached_rankings_label);

        // --- Force Lite Mode Toggle Row ---
        const force_lite_mode_row = document.createElement('div');
        force_lite_mode_row.className = 'sidecar-row';
        sc.appendChild(force_lite_mode_row);

        const force_lite_mode_checkbox = document.createElement('input');
        force_lite_mode_checkbox.type = 'checkbox';
        force_lite_mode_checkbox.id = 'sidecar_force_lite_mode_checkbox';
        const signed_in = Boolean(this.overlay_manager?.fsm?.session_data?.user_uuid);
        force_lite_mode_checkbox.disabled = !signed_in;
        force_lite_mode_checkbox.checked = signed_in
            && Boolean(this.overlay_manager?.fsm?.user_settings?.force_lite_mode);
        force_lite_mode_checkbox.title = signed_in
            ? 'Treat session as LegUp lite (no Sidekick rankings)'
            : 'Sign in to Legendary Upside to enable';
        force_lite_mode_checkbox.addEventListener('change', () => {
            Sidecar._on_force_lite_mode_changed(this.overlay_manager, force_lite_mode_checkbox.checked);
        });
        force_lite_mode_row.appendChild(force_lite_mode_checkbox);

        const force_lite_mode_label = document.createElement('label');
        force_lite_mode_label.setAttribute('for', 'sidecar_force_lite_mode_checkbox');
        force_lite_mode_label.textContent = 'Force Lite Mode';
        force_lite_mode_label.style.cssText = signed_in
            ? 'cursor: pointer; margin-left: 8px; color: white;'
            : 'cursor: default; margin-left: 8px; color: white; opacity: 0.7;';
        force_lite_mode_row.appendChild(force_lite_mode_label);

        // --- User OTC Status Row (read-only, shows current on-the-clock status) ---
        const user_otc_row = document.createElement('div');
        user_otc_row.className = 'sidecar-row';
        sc.appendChild(user_otc_row);

        const user_otc_checkbox = document.createElement('input');
        user_otc_checkbox.type = 'checkbox';
        user_otc_checkbox.id = 'sidecar_user_otc_checkbox';
        user_otc_checkbox.disabled = true; // Read-only, set automatically by polling
        const user_otc_state = this.overlay_manager?.model?.get('user_otc');
        user_otc_checkbox.checked = user_otc_state !== undefined ? user_otc_state : false;
        // Subscribe to model changes to keep checkbox in sync
        if (this.overlay_manager?.model) {
            this.overlay_manager.model.subscribe('user_otcChanged', () => {
                const current_state = this.overlay_manager.model.get('user_otc');
                user_otc_checkbox.checked = current_state || false;
            });
        }
        user_otc_row.appendChild(user_otc_checkbox);

        const user_otc_label = document.createElement('label');
        user_otc_label.setAttribute('for', 'sidecar_user_otc_checkbox');
        user_otc_label.textContent = 'On The Clock (auto)';
        user_otc_label.style.cssText = 'cursor: default; margin-left: 8px; color: white; opacity: 0.7;';
        user_otc_row.appendChild(user_otc_label);

        // --- Show Notch Hover Area Toggle Row ---
        const hover_area_row = document.createElement('div');
        hover_area_row.className = 'sidecar-row';
        sc.appendChild(hover_area_row);

        const hover_area_checkbox = document.createElement('input');
        hover_area_checkbox.type = 'checkbox';
        hover_area_checkbox.id = 'sidecar_show_notch_hover_area_checkbox';
        const hover_area_state = this.overlay_manager?.model?.get('show_notch_hover_area');
        hover_area_checkbox.checked = hover_area_state !== undefined ? hover_area_state : false;
        hover_area_checkbox.addEventListener('change', () => {
            const new_value = hover_area_checkbox.checked;
            if (this.overlay_manager?.model) {
                this.overlay_manager.model.set('show_notch_hover_area', new_value);
            }
        });
        hover_area_row.appendChild(hover_area_checkbox);

        const hover_area_label = document.createElement('label');
        hover_area_label.setAttribute('for', 'sidecar_show_notch_hover_area_checkbox');
        hover_area_label.textContent = 'Show Notch Hover Area';
        hover_area_label.style.cssText = 'cursor: pointer; margin-left: 8px; color: white;';
        hover_area_row.appendChild(hover_area_label);

        // --- Show Notch Refresh Toggle Row ---
        const notch_refresh_row = document.createElement('div');
        notch_refresh_row.className = 'sidecar-row';
        sc.appendChild(notch_refresh_row);

        const notch_refresh_checkbox = document.createElement('input');
        notch_refresh_checkbox.type = 'checkbox';
        notch_refresh_checkbox.id = 'sidecar_show_notch_refresh_checkbox';
        const notch_refresh_state = this.overlay_manager?.model?.get('show_notch_refresh');
        notch_refresh_checkbox.checked = notch_refresh_state !== undefined ? notch_refresh_state : false;
        notch_refresh_checkbox.addEventListener('change', () => {
            const new_value = notch_refresh_checkbox.checked;
            if (this.overlay_manager?.model) {
                this.overlay_manager.model.set('show_notch_refresh', new_value);
            }
        });
        notch_refresh_row.appendChild(notch_refresh_checkbox);

        const notch_refresh_label = document.createElement('label');
        notch_refresh_label.setAttribute('for', 'sidecar_show_notch_refresh_checkbox');
        notch_refresh_label.textContent = 'Show Notch Refresh';
        notch_refresh_label.style.cssText = 'cursor: pointer; margin-left: 8px; color: white;';
        notch_refresh_row.appendChild(notch_refresh_label);

        this._use_cached_rankings_checkbox = cached_rankings_checkbox;
        this._force_lite_mode_checkbox = force_lite_mode_checkbox;

        // --- Test pick row with position input, add button, and clear button ---
        const testPickRow = document.createElement('div');
        testPickRow.className = 'sidecar-row';
        sc.appendChild(testPickRow);
        
        const positionInput = document.createElement('input');
        positionInput.type = 'text';
        positionInput.id = 'sidecar_position_input';
        positionInput.className = 'sidecar-input';
        positionInput.placeholder = 'Position (QB, RB, WR, TE)';
        positionInput.value = 'QB';
        testPickRow.appendChild(positionInput);
        
        const testPicksBtn = document.createElement('button');
        testPicksBtn.id = 'sidecar_add_pick_btn';
        testPicksBtn.className = 'sidecar-btn';
        testPicksBtn.textContent = 'Add Pick';
        testPicksBtn.addEventListener('click', () => {
            if (this.overlay_manager.picks_container) {
                const position = (positionInput.value || 'QB').trim().toUpperCase();
                const test_pick = {
                    name: 'Test Player',
                    full_name: 'Test Player',
                    adp: 5.5,
                    team: 'KC',
                    position: position,
                    pos: position
                };
                this.overlay_manager.picks_container.add_pick(test_pick);
            }
        });
        testPickRow.appendChild(testPicksBtn);
        
        const clearPicksBtn = document.createElement('button');
        clearPicksBtn.id = 'sidecar_clear_picks_btn';
        clearPicksBtn.className = 'sidecar-btn';
        clearPicksBtn.textContent = 'Clear Picks';
        clearPicksBtn.addEventListener('click', () => {
            if (this.overlay_manager.picks_container) {
                this.overlay_manager.picks_container.clear();
            }
        });
        testPickRow.appendChild(clearPicksBtn);

        // --- Model State Display (replaces dummy buttons 7-10) ---
        const modelStateRow = document.createElement('div');
        modelStateRow.className = 'sidecar-row';
        modelStateRow.style.cssText = 'flex-direction: column; align-items: stretch; padding: 8px;';
        
        // Create toggle button
        const modelStateToggle = document.createElement('button');
        modelStateToggle.textContent = '▶ Model State (JSON)';
        modelStateToggle.className = 'sidecar-btn';
        modelStateToggle.style.cssText = 'text-align: left; margin-bottom: 8px; cursor: pointer;';
        modelStateRow.appendChild(modelStateToggle);
        
        const modelStatePre = document.createElement('pre');
        modelStatePre.id = 'sidecar_model_state_display';
        modelStatePre.style.cssText = `
            background: #1a1a1a;
            color: #0f0;
            padding: 8px;
            margin: 0;
            border-radius: 4px;
            font-size: 10px;
            overflow-x: auto;
            max-height: 300px;
            overflow-y: auto;
            white-space: pre-wrap;
            word-wrap: break-word;
            font-family: 'Courier New', monospace;
            display: none;
        `;
        modelStateRow.appendChild(modelStatePre);
        
        // Track collapsed state
        let isCollapsed = true;
        
        // Toggle function
        const toggleModelState = () => {
            isCollapsed = !isCollapsed;
            if (isCollapsed) {
                modelStatePre.style.display = 'none';
                modelStateToggle.textContent = '▶ Model State (JSON)';
            } else {
                modelStatePre.style.display = 'block';
                modelStateToggle.textContent = '▼ Model State (JSON)';
                // Update content when expanding
                updateModelStateDisplay();
            }
        };
        
        modelStateToggle.addEventListener('click', toggleModelState);
        
        // Update function to refresh model state display
        const updateModelStateDisplay = () => {
            // Only update if expanded
            if (!isCollapsed && this.overlay_manager?.model) {
                try {
                    const json = JSON.stringify(this.overlay_manager.model.toJSON(), null, 2);
                    modelStatePre.textContent = json;
                } catch (error) {
                    modelStatePre.textContent = `Error: ${error.message}`;
                }
            } else if (!isCollapsed) {
                modelStatePre.textContent = 'Model not available';
            }
        };
        
        // Subscribe to model changes for real-time updates (only updates if expanded)
        if (this.overlay_manager?.model) {
            this.overlay_manager.model.subscribe('change', updateModelStateDisplay);
        }
        
        sc.appendChild(modelStateRow);
        
        // Store reference for cleanup
        this._modelStateDisplay = modelStatePre;
        this._updateModelStateDisplay = updateModelStateDisplay;
        this._user_otc_checkbox = user_otc_checkbox;
        
        // --- Dev/Debug Control Buttons ---
        
        // Row 1: Reload Rankings & Reset Overlay
        const devRow1 = document.createElement('div');
        devRow1.className = 'sidecar-row';
        sc.appendChild(devRow1);
        
        const reloadRankingsBtn = document.createElement('button');
        reloadRankingsBtn.id = 'sidecar_reload_rankings_btn';
        reloadRankingsBtn.className = 'sidecar-btn';
        reloadRankingsBtn.textContent = 'Reload Rankings';
        reloadRankingsBtn.addEventListener('click', async () => {
            // Reset draft state to clear cache, then trigger rankings refresh
            // This matches the behavior of the bottom bar reload button
            if (this.overlay_manager?.fsm?.reset_draft_state) {
                await this.overlay_manager.fsm.reset_draft_state();
            }
        });
        devRow1.appendChild(reloadRankingsBtn);
        
        const resetOverlayBtn = document.createElement('button');
        resetOverlayBtn.id = 'sidecar_reset_overlay_btn';
        resetOverlayBtn.className = 'sidecar-btn';
        resetOverlayBtn.textContent = 'Reset Overlay';
        resetOverlayBtn.addEventListener('click', async () => {
            if (this.overlay_manager) {
                this.overlay_manager.destroy();
                await this.overlay_manager.initialize();
            }
        });
        devRow1.appendChild(resetOverlayBtn);
        
        // Row 2: Restart Extension & Toggle Mini
        const devRow2 = document.createElement('div');
        devRow2.className = 'sidecar-row';
        sc.appendChild(devRow2);
        
        const restartExtensionBtn = document.createElement('button');
        restartExtensionBtn.id = 'sidecar_restart_extension_btn';
        restartExtensionBtn.className = 'sidecar-btn';
        restartExtensionBtn.textContent = 'Restart Extension';
        restartExtensionBtn.addEventListener('click', () => {
            chrome.runtime.reload();
        });
        devRow2.appendChild(restartExtensionBtn);
        
        const toggleMiniBtn = document.createElement('button');
        toggleMiniBtn.id = 'sidecar_toggle_mini_btn';
        toggleMiniBtn.className = 'sidecar-btn';
        toggleMiniBtn.textContent = 'Toggle Mini';
        toggleMiniBtn.addEventListener('click', () => {
            if (this.overlay_manager?.toggle_mini_mode) {
                this.overlay_manager.toggle_mini_mode();
            }
        });
        devRow2.appendChild(toggleMiniBtn);

        // Row 2.5: Ghost overlay test (pass-through)
        const ghostRow = document.createElement('div');
        ghostRow.className = 'sidecar-row';
        sc.appendChild(ghostRow);

        const ghostOverlayBtn = document.createElement('button');
        ghostOverlayBtn.id = 'sidecar_ghost_overlay_btn';
        ghostOverlayBtn.className = 'sidecar-btn';
        ghostOverlayBtn.textContent = 'Ghost Overlay (8s)';
        ghostOverlayBtn.title = 'Make overlay translucent and click-through (Esc to exit early)';
        ghostOverlayBtn.addEventListener('click', () => {
            if (this.overlay_manager?.enter_ghost_mode) {
                this.overlay_manager.enter_ghost_mode(8000);
            }
        });
        ghostRow.appendChild(ghostOverlayBtn);
        
        // Row 3: Logout & Reinstall & Play Sound
        const devRow3 = document.createElement('div');
        devRow3.className = 'sidecar-row';
        sc.appendChild(devRow3);
        
        const logoutReinstallBtn = document.createElement('button');
        logoutReinstallBtn.id = 'sidecar_logout_reinstall_btn';
        logoutReinstallBtn.className = 'sidecar-btn';
        logoutReinstallBtn.textContent = 'Logout & Reinstall';
        logoutReinstallBtn.addEventListener('click', () => {
            chrome.storage.local.clear(() => {
                chrome.runtime.reload();
            });
        });
        devRow3.appendChild(logoutReinstallBtn);
        
        const playSoundBtn = document.createElement('button');
        playSoundBtn.id = 'sidecar_play_sound_btn';
        playSoundBtn.className = 'sidecar-btn';
        playSoundBtn.textContent = 'Play On-The-Clock';
        playSoundBtn.addEventListener('click', () => {
            const audio = new Audio(chrome.runtime.getURL('assets/warning.wav'));
            audio.play().catch(err => {
                console.error('[Sidecar] Failed to play sound:', err);
            });
        });
        devRow3.appendChild(playSoundBtn);
        
        // Row 4: Force Config Refresh (single button row)
        const devRow4 = document.createElement('div');
        devRow4.className = 'sidecar-row';
        sc.appendChild(devRow4);
        
        const forceConfigBtn = document.createElement('button');
        forceConfigBtn.id = 'sidecar_force_config_btn';
        forceConfigBtn.className = 'sidecar-btn';
        forceConfigBtn.textContent = 'Force Config Refresh';
        forceConfigBtn.addEventListener('click', () => {
            const fsm = this.overlay_manager?.fsm;
            if (fsm && fsm.bg_port && fsm.bg_connected) {
                fsm.send_port_request('FORCE_CONFIG_REFRESH')
                    .then((response) => {
                        if (response?.status === 'ok') {
                        } else {
                            console.error('[Sidecar] Config refresh failed:', response);
                        }
                    })
                    .catch((err) => {
                        console.error('[Sidecar] Config refresh failed:', err);
                    });
            }
        });
        devRow4.appendChild(forceConfigBtn);

        // Row 4b: Force DK Slate Update (only does anything on DraftKings; respects allowed UUIDs)
        const dkSlateRow = document.createElement('div');
        dkSlateRow.className = 'sidecar-row';
        sc.appendChild(dkSlateRow);

        const forceDkSlateBtn = document.createElement('button');
        forceDkSlateBtn.id = 'sidecar_force_dk_slate_btn';
        forceDkSlateBtn.className = 'sidecar-btn';
        forceDkSlateBtn.textContent = 'Force DK Slate Update';
        forceDkSlateBtn.title = 'Fetch DK slates and send to backend (DraftKings only; allowed users only)';
        forceDkSlateBtn.addEventListener('click', () => {
            if (!window.location.href.includes('draftkings.com')) {
                return;
            }
            const fsm = this.overlay_manager?.fsm;
            if (fsm && typeof fsm.trigger_dk_slate_update === 'function') {
                fsm.trigger_dk_slate_update()
                    .then(() => {
                    })
                    .catch((err) => {
                        console.error('[Sidecar] DK slate update failed', err);
                    });
            }
        });
        dkSlateRow.appendChild(forceDkSlateBtn);

        // Row 5: Toggle Stars (test button for star functionality)
        const devRow5 = document.createElement('div');
        devRow5.className = 'sidecar-row';
        sc.appendChild(devRow5);
        
        const toggleStarsBtn = document.createElement('button');
        toggleStarsBtn.id = 'sidecar_toggle_stars_btn';
        toggleStarsBtn.className = 'sidecar-btn';
        toggleStarsBtn.textContent = 'Toggle Stars';
        toggleStarsBtn.addEventListener('click', () => {
            if (this.overlay_manager?.picks_container) {
                const picks = this.overlay_manager.picks_container.picks || [];
                if (picks.length === 0) {
                    return;
                }
                
                // Check if any pick has a star to determine toggle direction
                const hasAnyStar = picks.some(pick => {
                    return pick._star_element && pick._star_element.parentElement === pick.element;
                });
                
                // Toggle all picks
                picks.forEach(pick => {
                    if (hasAnyStar) {
                        pick.hide_star();
                    } else {
                        pick.show_star();
                    }
                });
                
            } else {
            }
        });
        devRow5.appendChild(toggleStarsBtn);

        // Row 6: Skip Lobby Check Debug Toggle
        const devRow6 = document.createElement('div');
        devRow6.className = 'sidecar-row';
        sc.appendChild(devRow6);
        
        const skipLobbyCheckCheckbox = document.createElement('input');
        skipLobbyCheckCheckbox.type = 'checkbox';
        skipLobbyCheckCheckbox.id = 'sidecar_skip_lobby_check_checkbox';
        const skipLobbyCheckState = this.overlay_manager?.fsm?.state_data?.skip_lobby_check_debug;
        skipLobbyCheckCheckbox.checked = Boolean(skipLobbyCheckState);
        skipLobbyCheckCheckbox.addEventListener('change', () => {
            const new_value = skipLobbyCheckCheckbox.checked;
            if (this.overlay_manager?.fsm?.state_data) {
                this.overlay_manager.fsm.state_data.skip_lobby_check_debug = new_value;
            }
        });
        devRow6.appendChild(skipLobbyCheckCheckbox);
        
        const skipLobbyCheckLabel = document.createElement('label');
        skipLobbyCheckLabel.setAttribute('for', 'sidecar_skip_lobby_check_checkbox');
        skipLobbyCheckLabel.textContent = 'Skip Lobby Check (Debug)';
        skipLobbyCheckLabel.style.cssText = 'cursor: pointer; margin-left: 8px; color: white;';
        devRow6.appendChild(skipLobbyCheckLabel);

        const devRow6b = document.createElement('div');
        devRow6b.className = 'sidecar-row';
        sc.appendChild(devRow6b);

        const udInterceptCheckbox = document.createElement('input');
        udInterceptCheckbox.type = 'checkbox';
        udInterceptCheckbox.id = 'sidecar_ud_intercept_extraction_checkbox';
        const udInterceptState = this.overlay_manager?.fsm?.state_data?.static_settings?.ud_intercept_extraction_enabled;
        udInterceptCheckbox.checked = udInterceptState === true;
        udInterceptCheckbox.addEventListener('change', () => {
            const new_value = udInterceptCheckbox.checked;
            const fsm = this.overlay_manager?.fsm;
            if (fsm?.state_data) {
                fsm.state_data.last_extraction_result = null;
                if (!fsm.state_data.static_settings) fsm.state_data.static_settings = {};
                fsm.state_data.static_settings.ud_intercept_extraction_enabled = new_value;
            }
            if (!new_value && fsm?.clear_warning_notification) {
                fsm.clear_warning_notification('ud_legacy_fallback');
            }
            // Remote config owns static_settings.ud_intercept_extraction_enabled; this toggle is session-local only.
        });
        devRow6b.appendChild(udInterceptCheckbox);

        const udInterceptLabel = document.createElement('label');
        udInterceptLabel.setAttribute('for', 'sidecar_ud_intercept_extraction_checkbox');
        udInterceptLabel.textContent = 'Intercept draft picks (XHR / Pusher)';
        udInterceptLabel.style.cssText = 'cursor: pointer; margin-left: 8px; color: white;';
        devRow6b.appendChild(udInterceptLabel);

        const devRow6b2 = document.createElement('div');
        devRow6b2.className = 'sidecar-row';
        sc.appendChild(devRow6b2);

        const udNonopTickCheckbox = document.createElement('input');
        udNonopTickCheckbox.type = 'checkbox';
        udNonopTickCheckbox.id = 'sidecar_ud_nonop_tick_after_nav_checkbox';
        const udNonopTickState =
            this.overlay_manager?.fsm?.state_data?.static_settings?.ud_enable_nonop_tick_after_nav;
        udNonopTickCheckbox.checked = udNonopTickState === true;
        udNonopTickCheckbox.addEventListener('change', () => {
            const new_value = udNonopTickCheckbox.checked;
            const fsm = this.overlay_manager?.fsm;
            if (fsm?.state_data) {
                if (!fsm.state_data.static_settings) fsm.state_data.static_settings = {};
                fsm.state_data.static_settings.ud_enable_nonop_tick_after_nav = new_value;
            }
            if (fsm && fsm.bg_port && fsm.bg_connected) {
                fsm.send_port_request('SET_SETTINGS', {
                    settings: { static_settings: { ud_enable_nonop_tick_after_nav: new_value } }
                }).catch((err) => {
                    console.error('[Sidecar] SET_SETTINGS ud_enable_nonop_tick_after_nav failed', err);
                });
            }
        });
        devRow6b2.appendChild(udNonopTickCheckbox);

        const udNonopTickLabel = document.createElement('label');
        udNonopTickLabel.setAttribute('for', 'sidecar_ud_nonop_tick_after_nav_checkbox');
        udNonopTickLabel.textContent =
            'Underdog /active/: non-op tick after draft id change (flag ignored elsewhere)';
        udNonopTickLabel.style.cssText = 'cursor: pointer; margin-left: 8px; color: white;';
        devRow6b2.appendChild(udNonopTickLabel);

        const replayUdXhrBtn = document.createElement('button');
        replayUdXhrBtn.id = 'sidecar_replay_ud_draft_xhr_btn';
        replayUdXhrBtn.className = 'sidecar-btn';
        replayUdXhrBtn.textContent = 'Replay draft XHR';
        replayUdXhrBtn.title =
            'Re-issue the last captured GET /v2/drafts/... for the current draft (Underdog only; console logs XHR-replay)';
        const disableUdXhrReplayState = this.overlay_manager?.fsm?.user_settings?.ud_xhr_replay_disabled;
        replayUdXhrBtn.disabled = Boolean(disableUdXhrReplayState);
        replayUdXhrBtn.addEventListener('click', () => {
            Sidecar.replayUdDraftXhrFromBackground(this.overlay_manager);
        });

        const devRow6c = document.createElement('div');
        devRow6c.className = 'sidecar-row';
        sc.appendChild(devRow6c);

        const disableUdXhrReplayCheckbox = document.createElement('input');
        disableUdXhrReplayCheckbox.type = 'checkbox';
        disableUdXhrReplayCheckbox.id = 'sidecar_disable_ud_xhr_replay_checkbox';
        disableUdXhrReplayCheckbox.checked = Boolean(disableUdXhrReplayState);
        disableUdXhrReplayCheckbox.addEventListener('change', () => {
            const new_value = disableUdXhrReplayCheckbox.checked;
            const fsm = this.overlay_manager?.fsm;
            if (fsm?.user_settings) {
                fsm.user_settings.ud_xhr_replay_disabled = new_value;
            }
            replayUdXhrBtn.disabled = new_value;
            if (fsm?.bg_port && fsm.bg_connected) {
                fsm.send_port_request('SET_SETTINGS', {
                    settings: { ud_xhr_replay_disabled: new_value }
                }).catch((err) => {
                    console.error('[Sidecar] SET_SETTINGS ud_xhr_replay_disabled failed', err);
                });
            }
        });
        devRow6c.appendChild(disableUdXhrReplayCheckbox);

        const disableUdXhrReplayLabel = document.createElement('label');
        disableUdXhrReplayLabel.setAttribute('for', 'sidecar_disable_ud_xhr_replay_checkbox');
        disableUdXhrReplayLabel.textContent = 'Disable Underdog XHR replay';
        disableUdXhrReplayLabel.style.cssText = 'cursor: pointer; margin-left: 8px; color: white;';
        devRow6c.appendChild(disableUdXhrReplayLabel);

        const devRow6d = document.createElement('div');
        devRow6d.className = 'sidecar-row';
        sc.appendChild(devRow6d);

        const udLegacyCollisionDebugCheckbox = document.createElement('input');
        udLegacyCollisionDebugCheckbox.type = 'checkbox';
        udLegacyCollisionDebugCheckbox.id = 'sidecar_ud_debug_ignore_legacy_collision_checkbox';
        const udLegacyCollisionDebugState = this.overlay_manager?.fsm?.user_settings?.ud_debug_ignore_legacy_collision_rules;
        udLegacyCollisionDebugCheckbox.checked = Boolean(udLegacyCollisionDebugState);
        udLegacyCollisionDebugCheckbox.addEventListener('change', () => {
            const new_value = udLegacyCollisionDebugCheckbox.checked;
            const fsm = this.overlay_manager?.fsm;
            if (fsm?.user_settings) {
                fsm.user_settings.ud_debug_ignore_legacy_collision_rules = new_value;
            }
            if (fsm?.bg_port && fsm.bg_connected) {
                fsm.send_port_request('SET_SETTINGS', {
                    settings: { ud_debug_ignore_legacy_collision_rules: new_value }
                }).catch((err) => {
                    console.error('[Sidecar] SET_SETTINGS ud_debug_ignore_legacy_collision_rules failed', err);
                });
            }
        });
        devRow6d.appendChild(udLegacyCollisionDebugCheckbox);

        const udLegacyCollisionDebugLabel = document.createElement('label');
        udLegacyCollisionDebugLabel.setAttribute('for', 'sidecar_ud_debug_ignore_legacy_collision_checkbox');
        udLegacyCollisionDebugLabel.textContent = 'Debug: ignore legacy collision rules (test urgent warning)';
        udLegacyCollisionDebugLabel.style.cssText = 'cursor: pointer; margin-left: 8px; color: white;';
        devRow6d.appendChild(udLegacyCollisionDebugLabel);

        const devRow6cBtn = document.createElement('div');
        devRow6cBtn.className = 'sidecar-row';
        sc.appendChild(devRow6cBtn);
        devRow6cBtn.appendChild(replayUdXhrBtn);
        
        // Row 7: Toggle Star by Player Name
        const devRow7 = document.createElement('div');
        devRow7.className = 'sidecar-row';
        sc.appendChild(devRow7);
        
        const playerNameInput = document.createElement('input');
        playerNameInput.type = 'text';
        playerNameInput.id = 'sidecar_player_name_input';
        playerNameInput.className = 'sidecar-input';
        playerNameInput.placeholder = 'Player name';
        devRow7.appendChild(playerNameInput);
        
        const togglePlayerStarBtn = document.createElement('button');
        togglePlayerStarBtn.id = 'sidecar_toggle_player_star_btn';
        togglePlayerStarBtn.className = 'sidecar-btn';
        togglePlayerStarBtn.textContent = 'Toggle Player Star';
        togglePlayerStarBtn.addEventListener('click', () => {
            if (this.overlay_manager?.picks_container) {
                const picks = this.overlay_manager.picks_container.picks || [];
                const searchName = (playerNameInput.value || '').trim();
                
                if (!searchName) {
                    return;
                }
                
                if (picks.length === 0) {
                    return;
                }
                
                // Find matching picks (case insensitive)
                const matchingPicks = picks.filter(pick => {
                    const fullName = pick.pick_data?.full_name || pick.pick_data?.name || '';
                    return fullName.toLowerCase() === searchName.toLowerCase();
                });
                
                if (matchingPicks.length === 0) {
                    return;
                }
                
                // Check if any matching pick has a star to determine toggle direction
                const hasAnyStar = matchingPicks.some(pick => {
                    return pick._star_element && pick._star_element.parentElement === pick.element;
                });
                
                // Toggle stars on matching picks
                matchingPicks.forEach(pick => {
                    if (hasAnyStar) {
                        pick.hide_star();
                    } else {
                        pick.show_star();
                    }
                });
                
            } else {
            }
        });
        devRow7.appendChild(togglePlayerStarBtn);
        
        // Allow Enter key to trigger the button
        playerNameInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                togglePlayerStarBtn.click();
            }
        });

        this.element = sc;
        this._msgInput = msgInput;
        this._setBtn = setBtn;
        this._rankingsLoadingCheckbox = loadingCheckbox;
        this._use_cached_rankings_checkbox = cached_rankings_checkbox;
        this._force_lite_mode_checkbox = force_lite_mode_checkbox;
        return sc;
    }

    mount(parentEl) {
        const el = this._createElement();
        if (!el.isConnected) parentEl.appendChild(el);
        return this;
    }

    detach() {
        if (this.element?.parentElement) {
            this.element.parentElement.removeChild(this.element);
        }
    }

    destroy() {
        // Unsubscribe from model changes
        if (this._updateModelStateDisplay && this.overlay_manager?.model) {
            this.overlay_manager.model.unsubscribe('change', this._updateModelStateDisplay);
        }
        
        this.detach();
        this.element = null;
        this._msgInput = null;
        this._setBtn = null;
        this._rankingsLoadingCheckbox = null;
        this._use_cached_rankings_checkbox = null;
        this._force_lite_mode_checkbox = null;
        this._user_otc_checkbox = null;
        this._modelStateDisplay = null;
        this._updateModelStateDisplay = null;
    }

    getWidth() {
        // Prefer explicit width style, fallback to offset
        if (this.element) {
            const w = parseInt(this.element.style.width, 10);
            return Number.isFinite(w) ? w : (this.element.offsetWidth || this.width);
        }
        return this.width;
    }

    setMessageInput(value) {
        if (this._msgInput) this._msgInput.value = value;
    }

    updateRankingsLoadingCheckbox() {
        if (this._rankingsLoadingCheckbox && this.overlay_manager?.model) {
            const currentState = this.overlay_manager.model.get('rankings_loading');
            this._rankingsLoadingCheckbox.checked = currentState;
        } else if (this._rankingsLoadingCheckbox) {
            // Fallback to FSM if model not available
            const currentState = this.overlay_manager.fsm.state_data.rankings_loading;
            this._rankingsLoadingCheckbox.checked = currentState;
        }
    }

    update_rankings_cache_checkbox() {
        if (this._use_cached_rankings_checkbox) {
            // use_cached_rankings is stored in user_settings
            const cached_state = this.overlay_manager?.fsm?.user_settings?.use_cached_rankings;
            this._use_cached_rankings_checkbox.checked = Boolean(cached_state);
        }
    }

    sync_force_lite_mode_checkbox() {
        const cb = this._force_lite_mode_checkbox
            || this.element?.querySelector('#sidecar_force_lite_mode_checkbox');
        if (!cb) return;
        const signed_in = Boolean(this.overlay_manager?.fsm?.session_data?.user_uuid);
        cb.disabled = !signed_in;
        cb.title = signed_in
            ? 'Treat session as LegUp lite (no Sidekick rankings)'
            : 'Sign in to Legendary Upside to enable';
        const label = this.element?.querySelector('label[for="sidecar_force_lite_mode_checkbox"]');
        if (label) {
            label.style.cursor = signed_in ? 'pointer' : 'default';
            label.style.opacity = signed_in ? '1' : '0.7';
        }
        if (!signed_in) {
            cb.checked = false;
            return;
        }
        cb.checked = Boolean(this.overlay_manager?.fsm?.user_settings?.force_lite_mode);
    }

    sync_ud_xhr_replay_controls() {
        if (!this.element) return;
        const disabled = Boolean(this.overlay_manager?.fsm?.user_settings?.ud_xhr_replay_disabled);
        const cb = this.element.querySelector('#sidecar_disable_ud_xhr_replay_checkbox');
        const btn = this.element.querySelector('#sidecar_replay_ud_draft_xhr_btn');
        if (cb) cb.checked = disabled;
        if (btn) btn.disabled = disabled;
    }

    sync_ud_debug_ignore_legacy_collision_checkbox() {
        if (!this.element) return;
        const on = Boolean(this.overlay_manager?.fsm?.user_settings?.ud_debug_ignore_legacy_collision_rules);
        const cb = this.element.querySelector('#sidecar_ud_debug_ignore_legacy_collision_checkbox');
        if (cb) cb.checked = on;
    }

    static fromExisting(existingEl, overlay_manager, opts = {}) {
        const sc = new Sidecar(overlay_manager, opts);
        sc.element = existingEl;
        const input = existingEl.querySelector('#sidecar_message_input');
        const btn = existingEl.querySelector('#sidecar_set_message_btn');
        const customInput = existingEl.querySelector('#sidecar_custom_message_input');
        const customBtn = existingEl.querySelector('#sidecar_custom_message_btn');
        const cached_checkbox = existingEl.querySelector('#sidecar_use_cached_rankings_checkbox');
        const closeBtn = existingEl.querySelector('#sidecar_close_btn');

        if (closeBtn) {
            closeBtn.onclick = null;
            closeBtn.addEventListener('click', () => {
                if (overlay_manager?.disable_sidecar_from_ui) {
                    overlay_manager.disable_sidecar_from_ui();
                } else if (overlay_manager?.close_sidecar) {
                    overlay_manager.close_sidecar();
                } else {
                    sc.destroy();
                    if (overlay_manager) {
                        overlay_manager.sidecar = null;
                    }
                }
            });
        }

        // (Re)bind events safely for main message input
        if (btn) {
            btn.onclick = null;
            btn.addEventListener('click', () => {
                const text = (input?.value || '').trim();
                // Update model (which will trigger top bar update via subscription)
                if (overlay_manager?.model) {
                    overlay_manager.model.set('top_bar_message', {
                        main_text: text,
                        hover_text: text
                    });
                } else {
                    // Fallback if model not available
                    overlay_manager.top_bar?.set_message?.({
                        main_text: text,
                        hover_text: text
                    });
                }
            });
        }
        if (input) {
            input.onkeydown = null;
            input.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    const text = (input.value || '').trim();
                    // Update model (which will trigger top bar update via subscription)
                    if (overlay_manager?.model) {
                        overlay_manager.model.set('top_bar_message', {
                            main_text: text,
                            hover_text: text
                        });
                    } else {
                        // Fallback if model not available
                        overlay_manager.top_bar?.set_message?.({
                            main_text: text,
                            hover_text: text
                        });
                    }
                }
            });
        }

        // (Re)bind events safely for custom notification input
        if (customBtn) {
            customBtn.onclick = null;
            customBtn.addEventListener('click', () => {
                const text = (customInput?.value || '').trim();
                overlay_manager?.fsm?.set_sidecar_notification_preview?.(text, 'auth_error');
            });
        }
        if (cached_checkbox) {
            cached_checkbox.onchange = null;
            // use_cached_rankings is stored in user_settings
            const cached_state = overlay_manager?.fsm?.user_settings?.use_cached_rankings;
            cached_checkbox.checked = Boolean(cached_state);
            cached_checkbox.addEventListener('change', () => {
                const new_value = cached_checkbox.checked;
                // Update user_settings (source of truth)
                if (overlay_manager?.fsm?.user_settings) {
                    overlay_manager.fsm.user_settings.use_cached_rankings = new_value;
                }
                // Save to background
                const fsm = overlay_manager?.fsm;
                if (fsm && fsm.bg_port && fsm.bg_connected) {
                    fsm.send_port_request('SET_SETTINGS', {
                        settings: { use_cached_rankings: new_value }
                    }).catch((err) => {
                        console.error('[overlay_sidecar] set_settings failed', err);
                    });
                }
                overlay_manager?.trigger_rankings_refresh?.();
            });
            sc._use_cached_rankings_checkbox = cached_checkbox;
        }

        const force_lite_checkbox = existingEl.querySelector('#sidecar_force_lite_mode_checkbox');
        if (force_lite_checkbox) {
            force_lite_checkbox.onchange = null;
            sc.sync_force_lite_mode_checkbox();
            force_lite_checkbox.addEventListener('change', () => {
                Sidecar._on_force_lite_mode_changed(overlay_manager, force_lite_checkbox.checked);
            });
            sc._force_lite_mode_checkbox = force_lite_checkbox;
        }

        // (Re)bind hover area checkbox
        const hover_area_checkbox = existingEl.querySelector('#sidecar_show_notch_hover_area_checkbox');
        if (hover_area_checkbox) {
            hover_area_checkbox.onchange = null;
            const hover_area_state = overlay_manager?.model?.get('show_notch_hover_area');
            hover_area_checkbox.checked = hover_area_state !== undefined ? hover_area_state : false;
            hover_area_checkbox.addEventListener('change', () => {
                const new_value = hover_area_checkbox.checked;
                if (overlay_manager?.model) {
                    overlay_manager.model.set('show_notch_hover_area', new_value);
                }
            });
        }
        
        // (Re)bind notch refresh checkbox
        const notch_refresh_checkbox = existingEl.querySelector('#sidecar_show_notch_refresh_checkbox');
        if (notch_refresh_checkbox) {
            notch_refresh_checkbox.onchange = null;
            const notch_refresh_state = overlay_manager?.model?.get('show_notch_refresh');
            notch_refresh_checkbox.checked = notch_refresh_state !== undefined ? notch_refresh_state : false;
            notch_refresh_checkbox.addEventListener('change', () => {
                const new_value = notch_refresh_checkbox.checked;
                if (overlay_manager?.model) {
                    overlay_manager.model.set('show_notch_refresh', new_value);
                }
            });
        }
        
        // (Re)bind skip lobby check debug checkbox
        const skipLobbyCheckCheckbox = existingEl.querySelector('#sidecar_skip_lobby_check_checkbox');
        if (skipLobbyCheckCheckbox) {
            skipLobbyCheckCheckbox.onchange = null;
            const skipLobbyCheckState = overlay_manager?.fsm?.state_data?.skip_lobby_check_debug;
            skipLobbyCheckCheckbox.checked = Boolean(skipLobbyCheckState);
            skipLobbyCheckCheckbox.addEventListener('change', () => {
                const new_value = skipLobbyCheckCheckbox.checked;
                if (overlay_manager?.fsm?.state_data) {
                    overlay_manager.fsm.state_data.skip_lobby_check_debug = new_value;
                }
            });
        }

        const udInterceptCheckbox = existingEl.querySelector('#sidecar_ud_intercept_extraction_checkbox');
        if (udInterceptCheckbox) {
            udInterceptCheckbox.onchange = null;
            const udInterceptState = overlay_manager?.fsm?.state_data?.static_settings?.ud_intercept_extraction_enabled;
            udInterceptCheckbox.checked = udInterceptState === true;
            udInterceptCheckbox.addEventListener('change', () => {
                const new_value = udInterceptCheckbox.checked;
                const fsm = overlay_manager?.fsm;
                if (fsm?.state_data) {
                    fsm.state_data.last_extraction_result = null;
                    if (!fsm.state_data.static_settings) fsm.state_data.static_settings = {};
                    fsm.state_data.static_settings.ud_intercept_extraction_enabled = new_value;
                }
                if (!new_value && fsm?.clear_warning_notification) {
                    fsm.clear_warning_notification('ud_legacy_fallback');
                }
                // Remote config owns static_settings.ud_intercept_extraction_enabled; this toggle is session-local only.
            });
        }

        const disableUdXhrReplayCheckbox = existingEl.querySelector('#sidecar_disable_ud_xhr_replay_checkbox');
        if (disableUdXhrReplayCheckbox) {
            disableUdXhrReplayCheckbox.onchange = null;
            const disableUdXhrReplayState = overlay_manager?.fsm?.user_settings?.ud_xhr_replay_disabled;
            disableUdXhrReplayCheckbox.checked = Boolean(disableUdXhrReplayState);
            disableUdXhrReplayCheckbox.addEventListener('change', () => {
                const new_value = disableUdXhrReplayCheckbox.checked;
                const fsm = overlay_manager?.fsm;
                if (fsm?.user_settings) {
                    fsm.user_settings.ud_xhr_replay_disabled = new_value;
                }
                const replayUdXhrBtn = existingEl.querySelector('#sidecar_replay_ud_draft_xhr_btn');
                if (replayUdXhrBtn) replayUdXhrBtn.disabled = new_value;
                if (fsm?.bg_port && fsm.bg_connected) {
                    fsm.send_port_request('SET_SETTINGS', {
                        settings: { ud_xhr_replay_disabled: new_value }
                    }).catch((err) => {
                        console.error('[Sidecar] SET_SETTINGS ud_xhr_replay_disabled failed', err);
                    });
                }
            });
        }

        const udLegacyCollisionDebugCheckbox = existingEl.querySelector('#sidecar_ud_debug_ignore_legacy_collision_checkbox');
        if (udLegacyCollisionDebugCheckbox) {
            udLegacyCollisionDebugCheckbox.onchange = null;
            const udLegacyCollisionDebugState = overlay_manager?.fsm?.user_settings?.ud_debug_ignore_legacy_collision_rules;
            udLegacyCollisionDebugCheckbox.checked = Boolean(udLegacyCollisionDebugState);
            udLegacyCollisionDebugCheckbox.addEventListener('change', () => {
                const new_value = udLegacyCollisionDebugCheckbox.checked;
                const fsm = overlay_manager?.fsm;
                if (fsm?.user_settings) {
                    fsm.user_settings.ud_debug_ignore_legacy_collision_rules = new_value;
                }
                if (fsm?.bg_port && fsm.bg_connected) {
                    fsm.send_port_request('SET_SETTINGS', {
                        settings: { ud_debug_ignore_legacy_collision_rules: new_value }
                    }).catch((err) => {
                        console.error('[Sidecar] SET_SETTINGS ud_debug_ignore_legacy_collision_rules failed', err);
                    });
                }
            });
        }

        const replayUdXhrBtn = existingEl.querySelector('#sidecar_replay_ud_draft_xhr_btn');
        if (replayUdXhrBtn) {
            replayUdXhrBtn.onclick = null;
            replayUdXhrBtn.disabled = Boolean(overlay_manager?.fsm?.user_settings?.ud_xhr_replay_disabled);
            replayUdXhrBtn.addEventListener('click', () => {
                Sidecar.replayUdDraftXhrFromBackground(overlay_manager);
            });
        }
        
        // (Re)bind user OTC checkbox (read-only, synced via model subscription)
        const user_otc_checkbox = existingEl.querySelector('#sidecar_user_otc_checkbox');
        if (user_otc_checkbox) {
            user_otc_checkbox.disabled = true; // Read-only
            user_otc_checkbox.onchange = null;
            const user_otc_state = overlay_manager?.model?.get('user_otc');
            user_otc_checkbox.checked = user_otc_state !== undefined ? user_otc_state : false;
            // Subscribe to model changes to keep checkbox in sync
            if (overlay_manager?.model) {
                const updateCheckbox = () => {
                    const current_state = overlay_manager.model.get('user_otc');
                    user_otc_checkbox.checked = current_state || false;
                };
                overlay_manager.model.subscribe('user_otcChanged', updateCheckbox);
            }
            sc._user_otc_checkbox = user_otc_checkbox;
        }
        
        if (customInput) {
            customInput.onkeydown = null;
            customInput.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    const text = (customInput.value || '').trim();
                    overlay_manager?.fsm?.set_sidecar_notification_preview?.(text, 'auth_error');
                }
            });
        }

        // (Re)bind rankings loading checkbox
        const rankingsLoadingCheckbox = existingEl.querySelector('#sidecar_rankings_loading_checkbox');
        if (rankingsLoadingCheckbox) {
            sc._rankingsLoadingCheckbox = rankingsLoadingCheckbox;
            rankingsLoadingCheckbox.onchange = null;
            // Get state from model if available, otherwise from FSM
            const loadingState = overlay_manager?.model?.get('rankings_loading') ?? overlay_manager.fsm.state_data.rankings_loading;
            rankingsLoadingCheckbox.checked = loadingState;
            rankingsLoadingCheckbox.addEventListener('change', () => {
                const newValue = rankingsLoadingCheckbox.checked;
                const checkboxChangedFromExistingLogData = {
                    newValue: newValue,
                    old_fsm_value: overlay_manager.fsm.state_data.rankings_loading,
                    old_model_value: overlay_manager?.model?.get('rankings_loading'),
                    stack: new Error().stack.split('\n').slice(1, 4).join('\n')
                };
                overlay_manager.fsm.state_data.rankings_loading = newValue;
                // Update model
                if (overlay_manager?.model) {
                    overlay_manager.model.set('rankings_loading', newValue);
                }
                overlay_manager.refresh_loading_animation();
            });
        }
        
        // Handle model state display if it exists
        const modelStatePre = existingEl.querySelector('#sidecar_model_state_display');
        const modelStateToggle = existingEl.querySelector('button');
        if (modelStatePre && overlay_manager?.model) {
            sc._modelStateDisplay = modelStatePre;
            
            // Check if there's a toggle button (find button with text containing "Model State")
            let toggleBtn = null;
            const buttons = existingEl.querySelectorAll('button');
            for (const btn of buttons) {
                if (btn.textContent.includes('Model State')) {
                    toggleBtn = btn;
                    break;
                }
            }
            
            let isCollapsed = modelStatePre.style.display === 'none' || !modelStatePre.style.display;
            
            const updateModelStateDisplay = () => {
                // Only update if expanded
                if (!isCollapsed) {
                    try {
                        const json = JSON.stringify(overlay_manager.model.toJSON(), null, 2);
                        modelStatePre.textContent = json;
                    } catch (error) {
                        modelStatePre.textContent = `Error: ${error.message}`;
                    }
                }
            };
            
            // Set up toggle if button exists
            if (toggleBtn) {
                const toggleModelState = () => {
                    isCollapsed = !isCollapsed;
                    if (isCollapsed) {
                        modelStatePre.style.display = 'none';
                        toggleBtn.textContent = '▶ Model State (JSON)';
                    } else {
                        modelStatePre.style.display = 'block';
                        toggleBtn.textContent = '▼ Model State (JSON)';
                        updateModelStateDisplay();
                    }
                };
                toggleBtn.onclick = null;
                toggleBtn.addEventListener('click', toggleModelState);
            }
            
            sc._updateModelStateDisplay = updateModelStateDisplay;
            // Initial update only if expanded
            if (!isCollapsed) {
                updateModelStateDisplay();
            }
            // Subscribe to model changes
            overlay_manager.model.subscribe('change', updateModelStateDisplay);
        }

        // (Re)bind test buttons using IDs
        const positionInput = existingEl.querySelector('#sidecar_position_input');
        
        // Handle add pick button
        const addPickBtn = existingEl.querySelector('#sidecar_add_pick_btn');
        if (addPickBtn) {
            addPickBtn.onclick = null;
            addPickBtn.addEventListener('click', () => {
                if (overlay_manager.picks_container) {
                    const position = (positionInput?.value || 'QB').trim().toUpperCase();
                    const test_pick = {
                        name: 'Test Player',
                        full_name: 'Test Player',
                        adp: 5.5,
                        team: 'KC',
                        position: position,
                        pos: position
                    };
                    overlay_manager.picks_container.add_pick(test_pick);
                }
            });
        }
        
        // Handle clear picks button
        const clearPicksBtn = existingEl.querySelector('#sidecar_clear_picks_btn');
        if (clearPicksBtn) {
            clearPicksBtn.onclick = null;
            clearPicksBtn.addEventListener('click', () => {
                if (overlay_manager.picks_container) {
                    overlay_manager.picks_container.clear();
                }
            });
        }
        
        // Handle auth error test buttons using data attributes
        for (let i = 0; i < 4; i++) {
            const authBtn = existingEl.querySelector(`#sidecar_auth_${i}`);
            if (authBtn) {
                authBtn.onclick = null;
                const message = authBtn.getAttribute('data-message');
                const messageType = authBtn.getAttribute('data-message-type') || 'auth_error';
                if (message) {
                    authBtn.addEventListener('click', () => {
                        overlay_manager?.fsm?.set_sidecar_notification_preview?.(message, messageType);
                    });
                }
            }
        }
        
        // (Re)bind dev/debug control buttons
        const reloadRankingsBtn = existingEl.querySelector('#sidecar_reload_rankings_btn');
        if (reloadRankingsBtn) {
            reloadRankingsBtn.onclick = null;
            reloadRankingsBtn.addEventListener('click', async () => {
                // Reset draft state to clear cache, then trigger rankings refresh
                // This matches the behavior of the bottom bar reload button
                if (overlay_manager?.fsm?.reset_draft_state) {
                    await overlay_manager.fsm.reset_draft_state();
                }
            });
        }
        
        const resetOverlayBtn = existingEl.querySelector('#sidecar_reset_overlay_btn');
        if (resetOverlayBtn) {
            resetOverlayBtn.onclick = null;
            resetOverlayBtn.addEventListener('click', async () => {
                if (overlay_manager) {
                    overlay_manager.destroy();
                    await overlay_manager.initialize();
                }
            });
        }
        
        const restartExtensionBtn = existingEl.querySelector('#sidecar_restart_extension_btn');
        if (restartExtensionBtn) {
            restartExtensionBtn.onclick = null;
            restartExtensionBtn.addEventListener('click', () => {
                chrome.runtime.reload();
            });
        }
        
        const toggleMiniBtn = existingEl.querySelector('#sidecar_toggle_mini_btn');
        if (toggleMiniBtn) {
            toggleMiniBtn.onclick = null;
            toggleMiniBtn.addEventListener('click', () => {
                if (overlay_manager?.toggle_mini_mode) {
                    overlay_manager.toggle_mini_mode();
                }
            });
        }

        const ghostOverlayBtn = existingEl.querySelector('#sidecar_ghost_overlay_btn');
        if (ghostOverlayBtn) {
            ghostOverlayBtn.onclick = null;
            ghostOverlayBtn.addEventListener('click', () => {
                if (overlay_manager?.enter_ghost_mode) {
                    overlay_manager.enter_ghost_mode(8000);
                }
            });
        }
        
        const logoutReinstallBtn = existingEl.querySelector('#sidecar_logout_reinstall_btn');
        if (logoutReinstallBtn) {
            logoutReinstallBtn.onclick = null;
            logoutReinstallBtn.addEventListener('click', () => {
                chrome.storage.local.clear(() => {
                    chrome.runtime.reload();
                });
            });
        }
        
        const playSoundBtn = existingEl.querySelector('#sidecar_play_sound_btn');
        if (playSoundBtn) {
            playSoundBtn.onclick = null;
            playSoundBtn.addEventListener('click', () => {
                const audio = new Audio(chrome.runtime.getURL('assets/warning.wav'));
                audio.play().catch(err => {
                    console.error('[Sidecar] Failed to play sound:', err);
                });
            });
        }
        
        const forceConfigBtn = existingEl.querySelector('#sidecar_force_config_btn');
        if (forceConfigBtn) {
            forceConfigBtn.onclick = null;
            forceConfigBtn.addEventListener('click', () => {
                chrome.runtime.sendMessage({ action: 'FORCE_CONFIG_REFRESH' }, (response) => {
                    if (response?.status === 'ok') {
                    } else {
                        console.error('[Sidecar] Config refresh failed:', response);
                    }
                });
            });
        }

        const forceDkSlateBtn = existingEl.querySelector('#sidecar_force_dk_slate_btn');
        if (forceDkSlateBtn) {
            forceDkSlateBtn.onclick = null;
            forceDkSlateBtn.addEventListener('click', () => {
                if (!window.location.href.includes('draftkings.com')) {
                    return;
                }
                const fsm = overlay_manager?.fsm;
                if (fsm && typeof fsm.trigger_dk_slate_update === 'function') {
                    fsm.trigger_dk_slate_update()
                        .then(() => {
                        })
                        .catch((err) => {
                            console.error('[Sidecar] DK slate update failed', err);
                        });
                }
            });
        }

        const toggleStarsBtn = existingEl.querySelector('#sidecar_toggle_stars_btn');
        if (toggleStarsBtn) {
            toggleStarsBtn.onclick = null;
            toggleStarsBtn.addEventListener('click', () => {
                if (overlay_manager?.picks_container) {
                    const picks = overlay_manager.picks_container.picks || [];
                    if (picks.length === 0) {
                        return;
                    }
                    
                    // Check if any pick has a star to determine toggle direction
                    const hasAnyStar = picks.some(pick => {
                        return pick._star_element && pick._star_element.parentElement === pick.element;
                    });
                    
                    // Toggle all picks
                    picks.forEach(pick => {
                        if (hasAnyStar) {
                            pick.hide_star();
                        } else {
                            pick.show_star();
                        }
                    });
                    
                } else {
                }
            });
        }

        const playerNameInput = existingEl.querySelector('#sidecar_player_name_input');
        const togglePlayerStarBtn = existingEl.querySelector('#sidecar_toggle_player_star_btn');
        if (playerNameInput && togglePlayerStarBtn) {
            togglePlayerStarBtn.onclick = null;
            togglePlayerStarBtn.addEventListener('click', () => {
                if (overlay_manager?.picks_container) {
                    const picks = overlay_manager.picks_container.picks || [];
                    const searchName = (playerNameInput.value || '').trim();
                    
                    if (!searchName) {
                        return;
                    }
                    
                    if (picks.length === 0) {
                        return;
                    }
                    
                    // Find matching picks (case insensitive)
                    const matchingPicks = picks.filter(pick => {
                        const fullName = pick.pick_data?.full_name || pick.pick_data?.name || '';
                        return fullName.toLowerCase() === searchName.toLowerCase();
                    });
                    
                    if (matchingPicks.length === 0) {
                        return;
                    }
                    
                    // Check if any matching pick has a star to determine toggle direction
                    const hasAnyStar = matchingPicks.some(pick => {
                        return pick._star_element && pick._star_element.parentElement === pick.element;
                    });
                    
                    // Toggle stars on matching picks
                    matchingPicks.forEach(pick => {
                        if (hasAnyStar) {
                            pick.hide_star();
                        } else {
                            pick.show_star();
                        }
                    });
                    
                } else {
                }
            });
            
            playerNameInput.onkeydown = null;
            playerNameInput.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    togglePlayerStarBtn.click();
                }
            });
        }

        return sc;
    }
}

/**
 * Dev/local-only: single top-bar strip with streamer text. Drag anywhere on the bar.
 * Position is persisted per site (underdog / draftkings) via overlay.<site>.streamerOverlayState.
 */
class Streamer_Overlay {
    constructor(overlay_manager) {
        this.overlay_manager = overlay_manager;
        this.root = null;
        this.content_el = null;
        this.winning_line_el = null;
        this.entry_fees_value_el = null;
        this._editing_entry_fees = false;
        this._onMove = null;
        this._onUp = null;
        this._onDragStart = (e) => this._handle_drag_start(e);
    }

    _build_dom() {
        this.root = document.createElement('div');
        this.root.id = 'streamerOverlayRoot';
        this.root.setAttribute('aria-label', 'Move streamer overlay');

        this.content_el = document.createElement('div');
        this.content_el.id = 'streamerOverlayContent';
        this.content_el.className = 'streamer_overlay_content';

        const winningLine = document.createElement('div');
        winningLine.className = 'streamer_overlay_line';
        this.winning_line_el = winningLine;

        const feesLine = document.createElement('div');
        feesLine.className = 'streamer_overlay_line';

        const feesLabel = document.createElement('span');
        feesLabel.className = 'streamer_overlay_label';
        feesLabel.textContent = 'Entry fees: ';

        const feesValue = document.createElement('span');
        feesValue.className = 'streamer_overlay_value streamer_overlay_value_clickable';
        feesValue.setAttribute('role', 'button');
        feesValue.setAttribute('tabindex', '0');
        feesValue.setAttribute('aria-label', 'Edit entry fees');
        feesValue.addEventListener('mousedown', (e) => e.stopPropagation());
        feesValue.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            this._enter_entry_fees_edit_mode();
        });
        feesValue.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                this._enter_entry_fees_edit_mode();
            }
        });
        this.entry_fees_value_el = feesValue;

        feesLine.appendChild(feesLabel);
        feesLine.appendChild(feesValue);

        this.content_el.appendChild(winningLine);
        this.content_el.appendChild(feesLine);
        this.root.appendChild(this.content_el);
    }

    _build_entry_fees_value_span() {
        const feesValue = document.createElement('span');
        feesValue.className = 'streamer_overlay_value streamer_overlay_value_clickable';
        feesValue.setAttribute('role', 'button');
        feesValue.setAttribute('tabindex', '0');
        feesValue.setAttribute('aria-label', 'Edit entry fees');
        feesValue.addEventListener('mousedown', (e) => e.stopPropagation());
        feesValue.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            this._enter_entry_fees_edit_mode();
        });
        feesValue.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                this._enter_entry_fees_edit_mode();
            }
        });
        return feesValue;
    }

    _ensure_entry_fees_value_span(existingOrInputEl = null) {
        if (!this.content_el) return null;
        const existing = this.content_el.querySelector('.streamer_overlay_value');
        if (existing) {
            this.entry_fees_value_el = existing;
            return existing;
        }
        const inputEl = existingOrInputEl && existingOrInputEl.tagName === 'INPUT' ? existingOrInputEl : null;
        if (inputEl) {
            const span = this._build_entry_fees_value_span();
            inputEl.replaceWith(span);
            this.entry_fees_value_el = span;
            return span;
        }
        return null;
    }

    _format_money_from_cents(cents) {
        const n = Number(cents);
        if (!Number.isFinite(n)) return null;
        const c = Math.max(0, Math.round(n));
        const dollars = Math.floor(c / 100);
        const rem = c % 100;
        const dollarsStr = dollars.toLocaleString('en-US');
        if (rem === 0) return `$${dollarsStr}`;
        return `$${dollarsStr}.${String(rem).padStart(2, '0')}`;
    }

    _parse_user_money_to_cents(raw) {
        const s = String(raw || '').trim();
        if (!s) return null;
        // Accept: "18", "$18", "18.5", "$1,234.56"
        const m = s.match(/\$?\s*([0-9][0-9,]*)(?:\.(\d{1,2}))?\s*$/);
        if (!m) return null;
        const dollars = parseInt(m[1].replace(/,/g, ''), 10);
        if (!Number.isFinite(dollars)) return null;
        const frac = m[2] ? m[2] : '0';
        const cents = parseInt(frac.padEnd(2, '0').slice(0, 2), 10);
        if (!Number.isFinite(cents)) return null;
        return (dollars * 100) + cents;
    }

    async _persist_entry_fees_cents(entry_fees_total_cents) {
        const fsm = this.overlay_manager?.fsm;
        if (!fsm?.bg_port || !fsm?.bg_connected) return;
        try {
            await fsm.send_port_request('SET_STREAMER_MODE_DATA', {
                data: { entry_fees_total_cents }
            });
        } catch (err) {
            console.error('[Streamer_Overlay] Failed to persist entry fees', err);
        }
    }

    _enter_entry_fees_edit_mode() {
        if (this._editing_entry_fees) return;
        if (!this.entry_fees_value_el) return;

        this._editing_entry_fees = true;

        const currentCents = this.overlay_manager?.fsm?.state_data?.streamer_mode_data?.entry_fees_total_cents ?? null;
        const currentDisplay = this._format_money_from_cents(currentCents) || '';
        const initialValue = currentDisplay.replace(/^\$/, '');

        const input = document.createElement('input');
        input.type = 'text';
        input.inputMode = 'decimal';
        input.autocomplete = 'off';
        input.spellcheck = false;
        input.className = 'streamer_overlay_entry_fees_input';
        input.value = initialValue;

        // Prevent drag while editing.
        input.addEventListener('mousedown', (e) => e.stopPropagation());

        const exit = async (commit) => {
            if (!this._editing_entry_fees) return;
            this._editing_entry_fees = false;

            const raw = input.value;
            const parsed = this._parse_user_money_to_cents(raw);

            // Always revert input -> span immediately.
            this._ensure_entry_fees_value_span(input);

            // If input isn't parseable, don't save; show previously stored value.
            const prevFees = this.overlay_manager?.fsm?.state_data?.streamer_mode_data?.entry_fees_total_cents ?? null;
            const nextFees = (commit && parsed != null) ? parsed : prevFees;
            const nextWinning = this.overlay_manager?.fsm?.state_data?.streamer_mode_data?.currently_winning || null;

            // Update UI right away (don't wait for BG roundtrip).
            this.set_streamer_data(nextWinning, nextFees);

            if (commit && parsed != null) {
                await this._persist_entry_fees_cents(parsed);
            }
        };

        input.addEventListener('blur', () => exit(true));
        input.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                input.blur();
            } else if (e.key === 'Escape') {
                e.preventDefault();
                exit(false);
            }
        });

        this.entry_fees_value_el.replaceWith(input);
        // Keep pointer for when we re-render.
        this.entry_fees_value_el = null;

        // Focus after insertion.
        requestAnimationFrame(() => {
            try {
                input.focus();
                input.select();
            } catch (e) {}
        });
    }

    set_streamer_data(currently_winning, entry_fees_total_cents) {
        if (!this.content_el) return;
        const win = typeof currently_winning === 'string' ? currently_winning.trim() : '';
        const winLine = win ? `Currently winning: ${win}` : 'Currently winning: --';
        const feesStr = this._format_money_from_cents(entry_fees_total_cents);
        const feesValue = feesStr || '--';

        // If we are mid-edit, don't stomp the input.
        if (this._editing_entry_fees) {
            if (this.winning_line_el) this.winning_line_el.textContent = winLine;
            return;
        }

        if (this.winning_line_el) this.winning_line_el.textContent = winLine;

        // Ensure the value span exists (edit mode may have replaced it).
        const feesValueEl = this.content_el.querySelector('.streamer_overlay_value');
        if (feesValueEl) {
            feesValueEl.textContent = feesValue;
            this.entry_fees_value_el = feesValueEl;
        }
    }

    set_currently_winning(value) {
        if (!this.content_el) return;
        const v = typeof value === 'string' ? value.trim() : '';
        this.set_streamer_data(v || null, this.overlay_manager?.fsm?.state_data?.streamer_mode_data?.entry_fees_total_cents ?? null);
    }

    _clamp_position(top, left, rootW, rootH) {
        const maxTop = Math.max(0, window.innerHeight - rootH);
        const maxLeft = Math.max(0, window.innerWidth - rootW);
        return {
            top: Math.min(Math.max(0, top), maxTop),
            left: Math.min(Math.max(0, left), maxLeft)
        };
    }

    _apply_position(top, left) {
        const w = this.root.offsetWidth;
        const h = this.root.offsetHeight;
        const { top: t, left: l } = this._clamp_position(top, left, w, h);
        this.root.style.top = `${t}px`;
        this.root.style.left = `${l}px`;
    }

    _default_position() {
        this._apply_position(96, 24);
    }

    async _apply_saved_or_default_position() {
        const site = detect_site_key();
        let siteOverlay = {};
        try {
            siteOverlay = await get_overlay_for_site(site);
        } catch (err) {
            console.error('[Streamer_Overlay] get_overlay_for_site failed', err);
        }
        const st = siteOverlay.streamerOverlayState || {};
        const hasTop = Object.prototype.hasOwnProperty.call(st, 'top');
        const hasLeft = Object.prototype.hasOwnProperty.call(st, 'left');
        const topOk = hasTop && Number.isFinite(+st.top);
        const leftOk = hasLeft && Number.isFinite(+st.left);

        requestAnimationFrame(() => {
            if (!this.root) return;
            if (topOk && leftOk) {
                this._apply_position(+st.top, +st.left);
            } else {
                this._default_position();
            }
        });
    }

    async _persist_position() {
        if (!this.root) return;
        const site = detect_site_key();
        const top = parseFloat(this.root.style.top) || 0;
        const left = parseFloat(this.root.style.left) || 0;
        try {
            await set_overlay_for_site(site, {
                streamerOverlayState: {
                    top: Math.round(top),
                    left: Math.round(left)
                }
            });
        } catch (err) {
            console.error('[Streamer_Overlay] persist position failed', err);
        }
    }

    _add_doc_listeners(onMove, onUp) {
        this._onMove = onMove;
        this._onUp = onUp;
        document.addEventListener('mousemove', this._onMove, true);
        document.addEventListener('mouseup', this._onUp, { once: true, capture: true });
    }

    _remove_doc_listeners() {
        if (this._onMove) document.removeEventListener('mousemove', this._onMove, true);
        this._onMove = null;
        this._onUp = null;
    }

    _handle_drag_start(e) {
        if (e.button !== 0) return;
        e.preventDefault();

        const startOffsetX = e.clientX - this.root.offsetLeft;
        const startOffsetY = e.clientY - this.root.offsetTop;
        let moved = false;

        const onMove = (evt) => {
            evt.preventDefault();
            moved = true;
            const newLeft = evt.clientX - startOffsetX;
            const newTop = evt.clientY - startOffsetY;
            this._apply_position(newTop, newLeft);
        };

        const onUp = () => {
            this._remove_doc_listeners();
            if (moved) {
                this._persist_position();
            }
        };

        this._add_doc_listeners(onMove, onUp);
    }

    mount() {
        if (this.root) return;
        this._build_dom();
        document.body.appendChild(this.root);
        this.root.addEventListener('mousedown', this._onDragStart);
        this.set_streamer_data(
            this.overlay_manager?.fsm?.state_data?.streamer_mode_data?.currently_winning || null,
            this.overlay_manager?.fsm?.state_data?.streamer_mode_data?.entry_fees_total_cents ?? null
        );
        this._apply_saved_or_default_position();
    }

    destroy() {
        this._remove_doc_listeners();
        if (this.root && this._onDragStart) {
            this.root.removeEventListener('mousedown', this._onDragStart);
        }
        this.content_el = null;
        this.winning_line_el = null;
        this.entry_fees_value_el = null;
        if (this.root?.parentNode) {
            this.root.remove();
        }
        this.root = null;
    }
}



// Diagnostic logging for exposure slate matching. Exposure lookup runs per pick per render, so
// logs are deduped by content key to avoid console spam while still re-logging when data changes.
const _LEGUP_EXPOSURE_LOG_SEEN = new Set();
function _legupExposureLogOnce(dedupeKey, message, logData) {
    if (_LEGUP_EXPOSURE_LOG_SEEN.has(dedupeKey)) return;
    _LEGUP_EXPOSURE_LOG_SEEN.add(dedupeKey);
}

class Pick_Element {
    constructor(pick_data, site_type = 'draftkings', render_context = {}, queue_click_handler = null, overlay_manager = null) {
        this.pick_data = pick_data;
        this.site_type = site_type;
        this.render_context = render_context || {};
        this.queue_click_handler = queue_click_handler;
        this.overlay_manager = overlay_manager;
        this.element = null;
        this._star_element = null;
        this._drafted_overlay = null;
        this._create_element();
    }

    _is_error_pick() {
        return this.pick_data?.full_name === 'error_pick';
    }

    /**
     * Dev/local-only extras on pick rows (S/C/B/W scores, dual ADP, payload tooltips).
     * With streamer overlay on, hide those like prod even when env is dev/local.
     */
    _show_dev_recommended_pick_extras() {
        const env = this.overlay_manager?.fsm?.state_data?.env_value;
        if (!['dev', 'local'].includes(env)) return false;
        if (this.overlay_manager?.fsm?.user_settings?.streamer_overlay_enabled) return false;
        return true;
    }

    _create_element() {
        const el = document.createElement('div');
        el.classList.add('pick-element');
        el.setAttribute('data-fullname', this.pick_data.full_name || this.pick_data.name || '');
        const classicScore = Number(this.pick_data?.classic_score);
        if (Number.isFinite(classicScore)) {
            el.dataset.classicScore = classicScore.toString();
        }
        
        const is_error_pick = this._is_error_pick();
        if (is_error_pick) {
            el.classList.add('pick-element-error');
        }
        
        const is_underdog = this.site_type === 'underdog';
        const text_color = is_underdog ? 'white' : 'black';
        const base_background = is_underdog ? '#555' : '#f0f0f0';
        
        el.style.cssText = `
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            padding: 3px;
            margin-bottom: 5px;
            border-radius: 3px;
            font-size: 16px;
            color: ${text_color};
            cursor: ${is_error_pick ? 'default' : 'pointer'};
            position: relative;
            background-color: ${base_background};
            user-select: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
        `;
        
        this._apply_position_color(el);
        this._apply_payload_tooltip(el);
        this._apply_picked_opacity(el);

        const text_container = this._create_text_container();
        el.appendChild(text_container);

        const tag_container = this._create_tag_icon_container();
        if (tag_container) {
            el.appendChild(tag_container);
        }

        const drafted_overlay = document.createElement('div');
        drafted_overlay.setAttribute('aria-hidden', 'true');
        drafted_overlay.textContent = 'DRAFTED';
        drafted_overlay.style.cssText = `
            position: absolute;
            left: 0;
            right: 0;
            top: 0;
            bottom: 0;
            width: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            font-weight: 700;
            letter-spacing: 0.05em;
            color: ${is_underdog ? 'rgba(255,255,255,0.9)' : 'rgba(0,0,0,0.85)'};
            pointer-events: none;
            border-radius: inherit;
        `;
        el.appendChild(drafted_overlay);
        this._drafted_overlay = drafted_overlay;
        const picked_ids = this.render_context?.picked_ids || [];
        drafted_overlay.style.visibility = this._is_picked(picked_ids) ? 'visible' : 'hidden';

        if (!is_error_pick) {
            el.addEventListener('click', (e) => this._handle_click(e));
        }

        this.element = el;
        return el;
    }

    _is_picked(picked_ids) {
        if (!Array.isArray(picked_ids) || picked_ids.length === 0) return false;
        const id = this.site_type === 'underdog' ? this.pick_data?.ud_id : this.pick_data?.dk_id;
        if (id == null || id === '') return false;
        const idStr = String(id);
        return picked_ids.some(pid => String(pid) === idStr);
    }

    _apply_picked_opacity(element) {
        const picked_ids = this.render_context?.picked_ids || [];
        const is_picked = this._is_picked(picked_ids);
        element.style.opacity = is_picked ? '0.5' : '1';
        if (this._drafted_overlay) {
            this._drafted_overlay.style.visibility = is_picked ? 'visible' : 'hidden';
        }
    }

    update_picked_opacity(picked_ids) {
        if (!this.element) return;
        const is_picked = this._is_picked(picked_ids || []);
        this.element.style.opacity = is_picked ? '0.5' : '1';
        if (this._drafted_overlay) {
            this._drafted_overlay.style.visibility = is_picked ? 'visible' : 'hidden';
        }
    }

    async _handle_click(event) {
        event.preventDefault();
        event.stopPropagation();

        if (window.getSelection && window.getSelection().toString()) {
            return;
        }

        const playerName = this.pick_data?.full_name || this.pick_data?.name || '';
        if (!playerName) {
            return;
        }


        const team = this.pick_data?.team || '';
        const position = this.pick_data?.position || this.pick_data?.pos || '';

        if (this.queue_click_handler && typeof this.queue_click_handler.handleClick === 'function') {
            await this.queue_click_handler.handleClick(playerName, team, position);
        } else {
        }
    }

    _apply_position_color(element) {
        // Explicit error pick format from backend (full_name === 'error_pick', error_text holds message)
        if (this._is_error_pick()) {
            element.style.backgroundColor = '#555';
            return;
        }
        // Legacy: spoofed error from backend (error message in full_name)
        const fullName = this.pick_data.full_name || this.pick_data.name || '';
        const is_legacy_error = fullName.startsWith('HTTP ') || fullName.includes('error') || fullName.includes('Error');
        if (is_legacy_error) {
            element.style.backgroundColor = '#555';
            return;
        }
        
        const position = this.pick_data.position || this.pick_data.pos || '';
        const color = this._get_color_for_position(position);
        element.style.backgroundColor = color;
    }

    _apply_payload_tooltip(element) {
        if (!element) return;

        // Only show payload tooltip in dev/local when streamer mode is not hiding dev-only UI
        if (!this._show_dev_recommended_pick_extras()) {
            element.removeAttribute('title');
            return;
        }

        const enableTooltips = this.overlay_manager?.fsm?.user_settings?.enable_mouse_over_text;
        if (enableTooltips === false) {
            element.removeAttribute('title');
            return;
        }

        const payloadEntries = this._collect_payload_fields(this.pick_data);
        if (!payloadEntries) {
            element.removeAttribute('title');
            return;
        }

        const tooltipText = this._safe_stringify({ payloads: payloadEntries });
        if (tooltipText) {
            element.setAttribute('title', tooltipText);
        } else {
            element.removeAttribute('title');
        }
    }

    _collect_payload_fields(source) {
        if (!source || typeof source !== 'object') return null;

        const seen = new WeakSet();
        const payloadEntries = {};

        const traverse = (value, path = []) => {
            if (!value || typeof value !== 'object') return;
            if (seen.has(value)) return;
            seen.add(value);

            Object.entries(value).forEach(([key, child]) => {
                const nextPath = [...path, key];
                if (key.includes('_payload')) {
                    const pathKey = nextPath.join('.');
                    payloadEntries[pathKey] = child;
                }
                if (child && typeof child === 'object') {
                    traverse(child, nextPath);
                }
            });
        };

        traverse(source);

        return Object.keys(payloadEntries).length ? payloadEntries : null;
    }

    _safe_stringify(value) {
        const visited = new WeakSet();
        try {
            return JSON.stringify(value, (key, val) => {
                if (typeof val === 'bigint') {
                    return val.toString();
                }
                if (typeof val === 'undefined') {
                    return null;
                }
                if (val && typeof val === 'object') {
                    if (visited.has(val)) {
                        return '[Circular]';
                    }
                    visited.add(val);
                }
                return val;
            }, 2);
        } catch (error) {
            return null;
        }
    }

    _is_lite_mode() {
        if (this.overlay_manager?._is_legup_lite_mode) {
            return this.overlay_manager._is_legup_lite_mode();
        }
        const fsm = this.overlay_manager?.fsm;
        if (fsm?.is_legup_lite_mode) {
            return fsm.is_legup_lite_mode();
        }
        return is_legup_lite_mode(fsm?.session_data, fsm?.user_settings);
    }

    _get_color_for_position(position) {
        return get_pick_position_color(this.site_type, position, this._is_lite_mode());
    }

    _get_sim_score_text() {
        const algo_type = this.overlay_manager?.model?.get?.('algo_type');

        if (!this._show_dev_recommended_pick_extras()) return null;
        const is_sim_like = algo_type && algo_type.toLowerCase().includes('sim');
        if (!is_sim_like) return null;

        const raw_score = this.pick_data?.normed_sim_algo_score;
        if (raw_score === undefined || raw_score === null) return null;

        const numeric_score = Number(raw_score);
        if (!Number.isFinite(numeric_score)) return null;

        return `S: ${numeric_score.toFixed(2)}`;
    }

    _get_classic_score_text() {
        const algo_type = this.overlay_manager?.model?.get?.('algo_type');

        if (!this._show_dev_recommended_pick_extras()) return null;
        
        // Show classic score for classic algo OR sim-like algos
        const is_sim_like = algo_type && algo_type.toLowerCase().includes('sim');
        if (algo_type !== 'classic' && !is_sim_like) return null;

        // Use classic_score for classic algo, normed_classic_score for sim algos
        const raw_score = algo_type === 'classic' 
            ? this.pick_data?.classic_score 
            : this.pick_data?.normed_classic_score;
        
        if (raw_score === undefined || raw_score === null) return null;

        const numeric_score = Number(raw_score);
        if (!Number.isFinite(numeric_score)) return null;

        return `C: ${numeric_score.toFixed(2)}`;
    }

    _get_blended_score_text() {
        const algo_type = this.overlay_manager?.model?.get?.('algo_type');

        if (!this._show_dev_recommended_pick_extras()) return null;
        
        // Only show blended score for sim-like algos
        const is_sim_like = algo_type && algo_type.toLowerCase().includes('sim');
        if (!is_sim_like) return null;

        const raw_score = this.pick_data?.normed_blended_score;
        if (raw_score === undefined || raw_score === null) return null;

        const numeric_score = Number(raw_score);
        if (!Number.isFinite(numeric_score)) return null;

        return `B: ${numeric_score.toFixed(2)}`;
    }

    _get_classic_weight_text() {
        const algo_type = this.overlay_manager?.model?.get?.('algo_type');

        if (!this._show_dev_recommended_pick_extras()) return null;
        
        // Only show classic weight for sim-like algos
        const is_sim_like = algo_type && algo_type.toLowerCase().includes('sim');
        if (!is_sim_like) return null;

        const raw_weight = this.pick_data?.classicWeight;
        if (raw_weight === undefined || raw_weight === null) return null;

        const numeric_weight = Number(raw_weight);
        if (!Number.isFinite(numeric_weight)) return null;

        return `W: ${numeric_weight.toFixed(3)}`;
    }

    _get_display_adp_text() {
        const adp_value = Number(this.pick_data?.adp);
        const real_adp_value = Number(this.pick_data?.real_adp);
        const has_adp = Number.isFinite(adp_value);
        const has_real_adp = Number.isFinite(real_adp_value);

        if (!has_adp && !has_real_adp) {
            return 'N/A';
        }

        const display_adp_value = has_real_adp ? real_adp_value : adp_value;
        const display_text = display_adp_value.toFixed(1);

        if (this._show_dev_recommended_pick_extras() && has_adp && has_real_adp && adp_value !== real_adp_value) {
            return `${real_adp_value.toFixed(1)} (${adp_value.toFixed(1)})`;
        }

        return display_text;
    }

    _get_display_team_text() {
        const team_value = this.pick_data?.team;
        const real_team_value = this.pick_data?.real_team;
        const has_team = team_value != null && String(team_value).trim() !== '';
        const has_real_team = real_team_value != null && String(real_team_value).trim() !== '';

        if (!has_team && !has_real_team) {
            return 'N/A';
        }

        const display_team_value = has_real_team ? real_team_value : team_value;
        const display_text = String(display_team_value).trim();

        // Always show both when they differ (prod feature; unlike ADP which stays dev-only for dual)
        if (has_team && has_real_team && String(team_value).trim() !== String(real_team_value).trim()) {
            return `${String(real_team_value).trim()} (${String(team_value).trim()})`;
        }

        return display_text;
    }

    _create_text_container() {
        const container = document.createElement('div');
        const name = this.pick_data.full_name || this.pick_data.name || 'Unknown Player';
        
        // Explicit error pick format: full_name === 'error_pick', display error_text with wrapping
        if (this._is_error_pick()) {
            container.style.cssText = `
                white-space: pre-wrap;
                overflow-wrap: break-word;
                word-wrap: break-word;
                overflow: visible;
                padding: 3px;
                margin-bottom: 3px;
                text-align: center;
            `;
            container.textContent = (this.pick_data.error_text || '').trim() || 'Error';
            return container;
        }
        
        container.style.cssText = `
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            padding: 3px;
            margin-bottom: 3px;
            text-align: center;
        `;
        
        // Legacy error pick (spoofed error message in full_name)
        const is_legacy_error = name.startsWith('HTTP ') || name.includes('error') || name.includes('Error');
        if (is_legacy_error) {
            container.textContent = name.trim();
        } else {
            const adp = this._get_display_adp_text();
            const team = this._get_display_team_text();
            const position = this.pick_data.position || this.pick_data.pos || 'N/A';
            const sim_score_text = this._get_sim_score_text();
            const classic_score_text = this._get_classic_score_text();
            const blended_score_text = this._get_blended_score_text();
            const classic_weight_text = this._get_classic_weight_text();

            const details = [`ADP: ${adp}`];
            if (classic_score_text) {
                details.push(classic_score_text);
            }
            if (blended_score_text) {
                details.push(blended_score_text);
            }
            if (sim_score_text) {
                details.push(sim_score_text);
            }
            if (classic_weight_text) {
                details.push(classic_weight_text);
            }
            details.push(team);
            details.push(position);
            
            container.textContent = `${name} • ${details.join(' • ')}`;
        }
        
        return container;
    }

    get_element() {
        return this.element;
    }

    show_star() {
        if (!this.element) return;
        
        if (this._star_element && this._star_element.parentElement === this.element) {
            this._star_element.style.display = '';
            return;
        }

        if (this._star_element && this._star_element.parentElement !== this.element) {
            this._star_element = null;
        }

        if (!this._star_element) {
            this._star_element = this._create_star_element();
        }

        if (this._star_element.parentElement !== this.element) {
            this.element.appendChild(this._star_element);
        }
    }

    hide_star() {
        if (this._star_element && this._star_element.parentElement) {
            this._star_element.parentElement.removeChild(this._star_element);
        }
    }

    _create_star_element() {
        const starContainer = document.createElement('div');
        starContainer.className = 'star-icon-container';
        starContainer.style.cssText = `
            position: absolute;
            top: -14px;
            left: -14px;
            width: 40px;
            height: 40px;
            background-color: #1b1b1b;
            clip-path: polygon(50% 0%, 61% 35%, 98% 35%, 68% 57%, 79% 91%, 50% 70%, 21% 91%, 32% 57%, 2% 35%, 39% 35%);
            z-index: 1;
        `;

        const starIcon = document.createElement('div');
        starIcon.className = 'star-icon';
        starIcon.style.cssText = `
            position: absolute;
            top: 2px;
            left: 2px;
            width: 36px;
            height: 36px;
            background-color: #e0b400;
            clip-path: polygon(50% 0%, 61% 35%, 98% 35%, 68% 57%, 79% 91%, 50% 70%, 21% 91%, 32% 57%, 2% 35%, 39% 35%);
        `;

        starContainer.appendChild(starIcon);
        return starContainer;
    }

    _create_tag_icon_container() {
        if (this._is_error_pick()) {
            return null;
        }
        const tags = this.pick_data?.tags || [];
        // Always create container even if tags array is empty - we want to show inactive tag icons
        if (!Array.isArray(tags)) {
            return null;
        }

        const format_type = this._determine_format_type();
        
        const icon_container = document.createElement('div');
        icon_container.style.cssText = `
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            align-items: center;
            width: 100%;
        `;

        this._create_tag_icons(icon_container, tags, format_type);

        return icon_container.children.length > 0 ? icon_container : null;
    }

    _determine_format_type() {
        const season_stage = this.render_context?.season_stage ?? this.overlay_manager?.fsm?.state_data?.season_stage;
        return season_stage === 'playoffs' ? 'playoffs' : 'regular_season';
    }

    _create_tag_icons(container, tags, season_stage) {
        const enable_mouse_over_text = this.overlay_manager?.fsm?.user_settings?.enable_mouse_over_text !== false;
        const tag_icon_settings = this.overlay_manager?.fsm?.tag_icon_settings || {};
        const hide_inactive = tag_icon_settings.tag_icon_hide_inactive === true;
        const is_enabled = (key) => {
            const value = tag_icon_settings?.[key];
            if (value !== undefined) return !!value;
            return TAG_ICON_DEFAULTS[key] !== undefined ? !!TAG_ICON_DEFAULTS[key] : true;
        };
        const should_show = (setting_key, is_active) => {
            if (setting_key && !is_enabled(setting_key)) {
                return false;
            }
            return is_active || !hide_inactive;
        };

        if (season_stage === 'playoffs') {
            const r1ActiveData = is_enabled('tag_icon_r1_active') ? this._get_r1_active_data() : null;
            if (r1ActiveData) {
                this._create_tag_icon(
                    r1ActiveData.text,
                    r1ActiveData.hover_text,
                    container,
                    r1ActiveData.is_active,
                    r1ActiveData.background_color,
                    '#111',
                    null,
                    r1ActiveData.opacity,
                    enable_mouse_over_text
                );
            }

            const hasConfChampOpp = tags.includes('conf_champ_opp');
            const hasQuarterback = tags.includes('have_qb');
            const hasTeammate = tags.some(tag => {
                if (tag.startsWith('teammate_')) {
                    const value = parseInt(tag.replace('teammate_', ''), 10);
                    return !isNaN(value) && value > 0;
                }
                return false;
            });

            if (should_show('tag_icon_conf_champ_opp', hasConfChampOpp)) {
                this._create_tag_icon('C. Champ Opp', 'Conference Championship Opponent', container, hasConfChampOpp, '#444', 'black', null, 1, enable_mouse_over_text);
            }
            if (should_show('tag_icon_quarterback', hasQuarterback)) {
                this._create_tag_icon('Quarterback', 'Quarterback Boost', container, hasQuarterback, '#444', 'black', null, 1, enable_mouse_over_text);
            }
            if (should_show('tag_icon_teammate', hasTeammate)) {
                this._create_tag_icon('Teammate', 'Teammate Boost', container, hasTeammate, '#444', 'black', null, 1, enable_mouse_over_text);
            }
            this._maybe_add_exposure_tag(container, enable_mouse_over_text, tag_icon_settings);
            return;
        }

        // Regular season tags matching legacy format:
        // QB (boolean), TM (multiplier), W17 (Week 17), Bye (Bye Overlap)
        const hasW17 = tags.some(tag => tag.startsWith('W17'));
        const hasTM = tags.some(tag => tag.startsWith('TM'));
        const hasQB = tags.includes('QB');
        const hasBye = tags.some(tag => tag.startsWith('Bye'));

        if (should_show('tag_icon_quarterback', hasQB)) {
            this._create_tag_icon(
                'Quarterback',
                hasQB ? 'Quarterback in Roster' : 'No Quarterback in Roster',
                container,
                hasQB,
                '#444',
                'black',
                null,
                1,
                enable_mouse_over_text
            );
        }

        if (should_show('tag_icon_teammate', hasTM)) {
            this._create_tag_icon_with_value(
                'Teammate',
                'Teammate in Roster',
                'No Teammate in Roster',
                container,
                tags,
                'TM',
                hasTM,
                enable_mouse_over_text
            );
        }

        if (should_show('tag_icon_week_17', hasW17)) {
            this._create_tag_icon_with_value(
                'Week 17',
                'Week 17 Bring Backs',
                'No Week 17 Bring Backs',
                container,
                tags,
                'W17',
                hasW17,
                enable_mouse_over_text
            );
        }

        if (should_show('tag_icon_bye_overlap', hasBye)) {
            this._create_tag_icon_with_value(
                'Bye Overlap',
                'Bye Overlap',
                'No Bye Overlap',
                container,
                tags,
                'Bye',
                hasBye,
                enable_mouse_over_text
            );
        }

        this._maybe_add_exposure_tag(container, enable_mouse_over_text, tag_icon_settings);
    }

    _get_current_ud_slate_id() {
        if (this.site_type !== 'underdog') return null;
        const fsm = this.overlay_manager?.fsm;
        if (!fsm) return null;
        const draftId = typeof get_underdog_draft_id_from_url === 'function'
            ? get_underdog_draft_id_from_url(window.location.href)
            : null;
        if (!draftId) return null;
        const draft = fsm.state_data?.ud_intercepted_drafts?.[String(draftId)]?.draft;
        const rawSlateId = draft?.slate_id;
        const slateId = rawSlateId != null && String(rawSlateId).trim() ? String(rawSlateId).trim() : null;
        const formatType = this.overlay_manager?.model?.get?.('format_type') || null;
        const resolveLogData = { draft_id: String(draftId), resolved_slate_id: slateId, has_intercepted_draft: !!draft, format_type: formatType };
        _legupExposureLogOnce(`ud_slate_resolve|${draftId}|${slateId || ''}|${draft ? 1 : 0}|${formatType || ''}`, '[LegUp exposure][UD] current draft slate id resolution', resolveLogData);
        return slateId;
    }

    _get_current_dk_slate_id() {
        if (this.site_type !== 'draftkings') return null;
        const fsm = this.overlay_manager?.fsm;
        if (!fsm) return null;
        const href = window.location && typeof window.location.href === 'string' ? window.location.href : '';
        const draftId =
            typeof get_draftkings_draft_id_from_url === 'function' ? get_draftkings_draft_id_from_url(href) : null;
        if (!draftId) return null;
        const map = fsm.state_data?.draft_kings_exposure_slate_by_draft_id;
        const raw = map && typeof map === 'object' ? map[String(draftId)] : null;
        return raw != null && String(raw).trim() ? String(raw).trim() : null;
    }

    _get_exposure_row_for_pick() {
        // Exposure rows are keyed by canonical Underdog player id: ud_*_appearance_id_map.map[appearance_id] or legacy player_map_ud.players.
        const raw = this.pick_data?.id;
        if (raw == null || raw === '') {
            return null;
        }
        const key = String(raw).trim();
        if (!key) {
            return null;
        }
        const exp = this.overlay_manager?.fsm?.datasets?.player_exposure;
        if (!exp) return null;

        // Per-slate mode (default): only show exposure matching the current contest's slate.
        // Aggregate mode: use the combined by_id across all included slates.
        const aggregateUdSlates = this.overlay_manager?.fsm?.user_settings?.ud_exposure_aggregate_slates === true;
        if (!aggregateUdSlates && this.site_type === 'underdog') {
            const slateId = this._get_current_ud_slate_id();
            const availableSlateIds = exp.ud_by_slate && typeof exp.ud_by_slate === 'object' ? Object.keys(exp.ud_by_slate) : [];
            const slateEntry = slateId ? exp.ud_by_slate?.[slateId] : null;
            const slateMatched = !!(slateEntry && slateEntry.by_id);
            const matchLogData = { current_slate_id: slateId, slate_matched: slateMatched, available_ud_slate_ids: availableSlateIds };
            _legupExposureLogOnce(`ud_slate_match|${slateId || ''}|${slateMatched ? 1 : 0}|${availableSlateIds.slice().sort().join(',')}`, '[LegUp exposure][UD] slate match check before display', matchLogData);
            if (!slateId || !exp.ud_by_slate?.[slateId]?.by_id) return null;
            const slateRow = exp.ud_by_slate[slateId].by_id[key];
            if (!slateRow) return null;
            // Carry DK fields from aggregated row when cross-site aggregation is on
            const aggRow = exp.by_id?.[key];
            if (aggRow && typeof aggRow === 'object') {
                return { ...slateRow, dk_entry_fees: aggRow.dk_entry_fees, dk_pick_count: aggRow.dk_pick_count };
            }
            return slateRow;
        }

        const aggregateDkSlates = this.overlay_manager?.fsm?.user_settings?.dk_exposure_aggregate_slates === true;
        if (!aggregateDkSlates && this.site_type === 'draftkings') {
            const dgId = this._get_current_dk_slate_id();
            if (!dgId || !exp.dk_by_slate?.[dgId]?.by_id) return null;
            const slateRow = exp.dk_by_slate[dgId].by_id[key];
            if (!slateRow) return null;
            const aggRow = exp.by_id?.[key];
            if (aggRow && typeof aggRow === 'object') {
                return { ...slateRow, ud_entry_fees: aggRow.ud_entry_fees, ud_pick_count: aggRow.ud_pick_count };
            }
            return slateRow;
        }

        const byId = exp?.by_id;
        if (!byId || typeof byId !== 'object') {
            return null;
        }
        return byId[key];
    }

    _has_exposure_data_for_site(row, displayMode) {
        if (!row || typeof row !== 'object') return false;
        const ud = this.site_type === 'underdog';
        const agg = this.overlay_manager?.fsm?.user_settings?.exposure_aggregate_across_sites === true;
        const fees = agg ? this._compute_cross_site_entry_fees(row) : ud ? row.ud_entry_fees : row.dk_entry_fees;
        const pct = agg ? this._compute_cross_site_drafted_percent(row) : ud ? this._compute_ud_drafted_percent(row) : this._compute_dk_drafted_percent(row);
        const nf = Number(fees);
        const np = Number(pct);
        const mode = displayMode === 'fees_only' || displayMode === 'percent_only' ? displayMode : 'default';
        if (mode === 'fees_only') {
            return Number.isFinite(nf);
        }
        if (mode === 'percent_only') {
            return Number.isFinite(np);
        }
        if (!agg && this.site_type === 'draftkings') {
            return Number.isFinite(np);
        }
        return Number.isFinite(nf) && Number.isFinite(np);
    }

    _compute_cross_site_entry_fees(row) {
        if (!row || typeof row !== 'object') return null;
        const uf = Number(row.ud_entry_fees);
        const df = Number(row.dk_entry_fees);
        const hasU = Number.isFinite(uf);
        const hasD = Number.isFinite(df);
        if (!hasU && !hasD) return null;
        return (hasU ? uf : 0) + (hasD ? df : 0);
    }

    _compute_cross_site_drafted_percent(row) {
        if (!row || typeof row !== 'object') return null;
        const up = Number(row.ud_pick_count);
        const dp = Number(row.dk_pick_count);
        const hasU = Number.isFinite(up);
        const hasD = Number.isFinite(dp);
        const exp = this.overlay_manager?.fsm?.datasets?.player_exposure;
        let udDen = NaN;
        const aggregateSlates = this.overlay_manager?.fsm?.user_settings?.ud_exposure_aggregate_slates === true;
        if (!aggregateSlates) {
            const slateId = this._get_current_ud_slate_id();
            if (slateId && exp?.ud_by_slate?.[slateId]) {
                udDen = Number(exp.ud_by_slate[slateId].draft_count);
            }
        }
        if (!Number.isFinite(udDen) || udDen <= 0) {
            udDen = Number(exp?.ud_draft_count);
        }
        let dkDen = Number(exp?.dk_total_entries);
        const aggregateDkSlates = this.overlay_manager?.fsm?.user_settings?.dk_exposure_aggregate_slates === true;
        if (!aggregateDkSlates && this.site_type === 'draftkings') {
            const dgId = this._get_current_dk_slate_id();
            if (dgId && exp?.dk_by_slate?.[dgId] && exp.dk_by_slate[dgId].total_entries != null) {
                dkDen = Number(exp.dk_by_slate[dgId].total_entries);
            }
        }
        const denU = Number.isFinite(udDen) && udDen > 0 ? udDen : 0;
        const denD = Number.isFinite(dkDen) && dkDen > 0 ? dkDen : 0;
        const denom = denU + denD;
        if (denom <= 0) return null;
        const num = (hasU ? up : 0) + (hasD ? dp : 0);
        return (num / denom) * 100;
    }

    _compute_ud_drafted_percent(row) {
        if (!row || typeof row !== 'object') return null;
        const pickCount = Number(row.ud_pick_count);
        const exp = this.overlay_manager?.fsm?.datasets?.player_exposure;
        let denom = NaN;
        const aggregateSlates = this.overlay_manager?.fsm?.user_settings?.ud_exposure_aggregate_slates === true;
        if (!aggregateSlates) {
            const slateId = this._get_current_ud_slate_id();
            if (slateId && exp?.ud_by_slate?.[slateId]) {
                denom = Number(exp.ud_by_slate[slateId].draft_count);
            }
        }
        if (!Number.isFinite(denom) || denom <= 0) {
            denom = Number(exp?.ud_draft_count);
        }
        if (Number.isFinite(pickCount) && Number.isFinite(denom) && denom > 0) {
            return (pickCount / denom) * 100;
        }
        return null;
    }

    _compute_dk_drafted_percent(row) {
        if (!row || typeof row !== 'object') return null;
        const pickCount = Number(row.dk_pick_count);
        const exp = this.overlay_manager?.fsm?.datasets?.player_exposure;
        const aggregateDkSlates = this.overlay_manager?.fsm?.user_settings?.dk_exposure_aggregate_slates === true;
        let denom = Number(exp?.dk_total_entries);
        if (!aggregateDkSlates) {
            const dgId = this._get_current_dk_slate_id();
            if (dgId && exp?.dk_by_slate?.[dgId] && exp.dk_by_slate[dgId].total_entries != null) {
                denom = Number(exp.dk_by_slate[dgId].total_entries);
            }
        }
        if (Number.isFinite(pickCount) && Number.isFinite(denom) && denom > 0) {
            return (pickCount / denom) * 100;
        }
        return null;
    }

    _get_exposure_source_label() {
        const fsm = this.overlay_manager?.fsm;
        const us = fsm?.user_settings;
        if (this.site_type !== 'underdog') {
            if (us?.exposure_aggregate_across_sites === true) {
                return 'Aggregated UD + DK';
            }
            if (us?.dk_exposure_aggregate_slates === true) {
                return 'Aggregated DK';
            }
            const dgId = this._get_current_dk_slate_id();
            const staticSettings = fsm?.state_data?.static_settings;
            if (dgId && typeof formatDraftKingsSlateLabelForExposureToast === 'function') {
                const exp = fsm?.datasets?.player_exposure;
                const slateEnt = exp?.dk_by_slate?.[String(dgId)] || null;
                const fallback =
                    slateEnt && slateEnt.label != null && String(slateEnt.label).trim()
                        ? String(slateEnt.label).trim()
                        : '';
                return formatDraftKingsSlateLabelForExposureToast(dgId, staticSettings, fallback);
            }
            if (dgId) return 'DK Draft Group ' + dgId;
            return 'DK Regular Bestball';
        }
        const aggregateSlates = us?.ud_exposure_aggregate_slates === true;
        const aggregateAcrossSites = us?.exposure_aggregate_across_sites === true;
        if (aggregateSlates && aggregateAcrossSites) return 'Aggregated UD + DK';
        if (aggregateSlates) return 'Aggregated UD';
        const slateId = this._get_current_ud_slate_id();
        if (!slateId) return null;
        const staticSettings = fsm?.state_data?.static_settings;
        if (typeof formatUnderdogSlateLabelForExposureToast === 'function') {
            return formatUnderdogSlateLabelForExposureToast(slateId, staticSettings);
        }
        return `${slateId.slice(0, 8)}…`;
    }

    _format_exposure_entry_fee(fees) {
        const n = Number(fees);
        if (!Number.isFinite(n)) return '$0';
        return `$${Math.round(n)}`;
    }

    _maybe_add_exposure_tag(container, enable_mouseOverText, tag_icon_settings) {
        const hide_inactive = tag_icon_settings.tag_icon_hide_inactive === true;
        const is_enabled = (key) => {
            const value = tag_icon_settings?.[key];
            if (value !== undefined) return !!value;
            return TAG_ICON_DEFAULTS[key] !== undefined ? !!TAG_ICON_DEFAULTS[key] : true;
        };
        const should_show = (setting_key, is_active) => {
            if (setting_key && !is_enabled(setting_key)) {
                return false;
            }
            return is_active || !hide_inactive;
        };
        const rawMode = this.overlay_manager?.fsm?.user_settings?.tag_icon_exposure_display;
        const displayMode =
            rawMode === 'fees_only' || rawMode === 'percent_only' ? rawMode : 'default';
        const row = this._get_exposure_row_for_pick();
        const hasData = this._has_exposure_data_for_site(row, displayMode);
        if (!should_show('tag_icon_exposure', hasData)) {
            return;
        }
        if (!hasData) {
            const inactiveSource = this._get_exposure_source_label();
            const inactiveHover = inactiveSource
                ? `No exposure data for this player in slate: ${inactiveSource}`
                : 'No exposure data for this player';
            this._create_tag_icon(
                'Exposure',
                inactiveHover,
                container,
                false,
                '#444',
                'black',
                null,
                1,
                enable_mouseOverText,
                { exposureWidth: displayMode === 'default' ? 'default' : 'narrow' }
            );
            return;
        }
        const ud = this.site_type === 'underdog';
        const agg = this.overlay_manager?.fsm?.user_settings?.exposure_aggregate_across_sites === true;
        const fees = agg ? this._compute_cross_site_entry_fees(row) : ud ? row.ud_entry_fees : row.dk_entry_fees;
        const pct = agg ? this._compute_cross_site_drafted_percent(row) : ud ? this._compute_ud_drafted_percent(row) : this._compute_dk_drafted_percent(row);
        const feeStr = this._format_exposure_entry_fee(fees);
        const pctRounded = Math.round(Number(pct));
        const nf = Number(fees);
        const np = Number(pct);
        const feeOk = Number.isFinite(nf);
        const pctOk = Number.isFinite(np);
        let displayText;
        let hoverText;
        if (displayMode === 'fees_only') {
            displayText = feeStr;
            hoverText = pctOk
                ? `Entry Fees: ${feeStr}, Drafted %: ${pctRounded}%`
                : `Entry Fees: ${feeStr}`;
        } else if (displayMode === 'percent_only') {
            displayText = `${pctRounded}%`;
            hoverText = feeOk
                ? `Entry Fees: ${feeStr}, Drafted %: ${pctRounded}%`
                : `Drafted %: ${pctRounded}%`;
        } else {
            displayText = feeOk ? `${feeStr} / ${pctRounded}%` : `${pctRounded}%`;
            hoverText = feeOk
                ? `Entry Fees: ${feeStr}, Drafted %: ${pctRounded}%`
                : `Drafted %: ${pctRounded}%`;
        }
        const sourceLabel = this._get_exposure_source_label();
        if (sourceLabel) hoverText += ` · ${sourceLabel}`;
        this._create_tag_icon(
            displayText,
            hoverText,
            container,
            true,
            '#444',
            '#111',
            null,
            1,
            enable_mouseOverText,
            { exposureWidth: displayMode === 'default' ? 'default' : 'narrow' }
        );
    }

    _get_r1_active_data() {
        const fsm = this.overlay_manager?.fsm;

        // R1 Active calculation from playoff_probabilities dataset
        // Calculate: pRound1Active = p_playoff - p_bye
        const playoff_probabilities = fsm?.datasets?.playoff_probabilities;
        let pRound1Active = 0;
        let r1ActiveBackgroundColor = '#444';
        let opacity = 1;
        let hasTeamData = false;

        if (!playoff_probabilities) {
        } else if (!this.pick_data?.team) {
        } else {
            const team = this.pick_data.team;
            let team_data = null;
            
            // Handle flattenedData array structure
            if (playoff_probabilities.flattenedData && Array.isArray(playoff_probabilities.flattenedData)) {
                // Find the team entry in the flattenedData array
                team_data = playoff_probabilities.flattenedData.find(entry => entry.team === team);
                
                if (!team_data) {
                }
            } else {
                // Fallback: try direct object access (legacy structure)
                team_data = playoff_probabilities[team];
                
                if (!team_data) {
                }
            }
            
            if (team_data) {
                hasTeamData = true;
                const p_playoff = team_data.p_playoff ?? 0;
                const p_bye = team_data.p_bye ?? 0;
                
                // Calculate pRound1Active = p_playoff - p_bye (as decimal 0-1)
                const pRound1ActiveDecimal = p_playoff - p_bye;
                pRound1Active = pRound1ActiveDecimal * 100;
                
                if (Number.isFinite(pRound1Active) && pRound1Active >= 0) {
                    if (pRound1Active < 40) {
                        r1ActiveBackgroundColor = '#CC3333'; // red
                    } else if (pRound1Active < 55) {
                        r1ActiveBackgroundColor = '#CCAA33'; // yellow
                    } else if (pRound1Active < 70) {
                        r1ActiveBackgroundColor = '#557733'; // dark green
                    } else if (pRound1Active >= 70) {
                        r1ActiveBackgroundColor = '#339933'; // bright green
                    }
                } else {
                    pRound1Active = 0;
                }
            }
        }

        if (playoff_probabilities && this.pick_data?.team && hasTeamData && Number.isFinite(pRound1Active) && pRound1Active >= 0) {
            return {
                text: `R1 Active: ${pRound1Active.toFixed(0)}%`,
                hover_text: 'Probability that the player will be active in Round 1',
                is_active: true,
                background_color: r1ActiveBackgroundColor,
                opacity: opacity
            };
        }

        return null;
    }

    _is_tag_icon_compact() {
        return this.overlay_manager?.fsm?.user_settings?.tag_icon_compact === true;
    }

    _tag_icon_compact_label(text) {
        const labels = {
            'Quarterback': 'QB',
            'Teammate': 'TM',
            'Week 17': 'W17',
            'Bye Overlap': 'Bye'
        };
        return labels[text] || text;
    }

    _format_tag_icon_multiplier_label(abbrev, mult) {
        return `${abbrev}×${mult}`;
    }

    _create_tag_icon(text, hoverText, container, isActive, backgroundColor = '#444', outline = 'black', textValue = null, opacity = 1, enableMouseOverText = true, options = {}) {
        const icon = document.createElement('div');
        icon.classList.add('legup-tag-icon');
        if (this._is_tag_icon_compact()) {
            icon.classList.add('legup-tag-icon--compact');
            const exposureWidth = options.exposureWidth;
            if (exposureWidth === 'default') {
                icon.classList.add('legup-tag-icon--exposure-default');
            } else if (exposureWidth === 'narrow') {
                icon.classList.add('legup-tag-icon--exposure-narrow');
            }
        }

        const backgroundRGBA = isActive
            ? this._convert_to_rgba(backgroundColor, opacity)
            : 'transparent';

        const displayText = textValue !== null
            ? textValue
            : (this._is_tag_icon_compact() ? this._tag_icon_compact_label(text) : text);
        icon.innerText = displayText;
        
        // Only set dynamic properties as inline styles
        icon.style.backgroundColor = backgroundRGBA;
        icon.style.color = isActive ? 'white' : '#555';
        icon.style.border = `2px solid ${isActive ? outline : '#555'}`;
        
        if (enableMouseOverText) {
            icon.title = hoverText;
        }
        
        container.appendChild(icon);
    }

    _create_tag_icon_with_value(baseText, activeHoverText, inactiveHoverText, container, tags, prefix, isActive, enableMouseOverText = true) {
        const compact = this._is_tag_icon_compact();
        const abbrev = compact ? this._tag_icon_compact_label(baseText) : baseText;
        let text = abbrev;
        let hoverText = isActive ? activeHoverText : inactiveHoverText;
        let backgroundColor = '#444';
        let outline = '#111';

        if (isActive) {
            const tag = tags.find(t => t.startsWith(prefix));
            if (tag) {
                // MULTIPLIER TAGS (ByeX2, TMx1 …)
                if (/x\d+/i.test(tag)) {
                    const [, mult] = tag.match(/x(\d+)/i) || [];
                    if (mult) {
                        text = compact
                            ? this._format_tag_icon_multiplier_label(abbrev, mult)
                            : `${baseText} ×${mult}`;
                        hoverText = `${baseText} ×${mult}`;

                        if (prefix === 'Bye') {
                            const m = +mult;
                            backgroundColor = m === 1 ? '#9c3d10'
                                            : m === 2 ? '#a53307'
                                                       : '#ad2600';
                        }
                    }
                }
                // NUMERIC-VALUE TAGS (CU55, NPA85)
                else {
                    const [, valueStr] = tag.match(new RegExp(`^${prefix}(\\d+)`, 'i')) || [];
                    if (valueStr) {
                        const value = +valueStr;

                        // Special handling for NPA (+ optional NPT)
                        if (prefix === 'NPA') {
                            // Pull companion NPT tag if present (e.g. NPT86)
                            const nptTag = tags.find(t => t.startsWith('NPT'));
                            const [, pickStr] = nptTag?.match(/^NPT(\d+)/i) || [];

                            const availability =
                                  value > 90 ? '>90%' :
                                  value < 10 ? '<10%' : `${value}%`;

                            const pickPart = pickStr ? `(${pickStr})` : '';
                            text = `PA${pickPart}${pickPart ? ': ' : ''}${availability}`;

                            // Build the hover text: "Probability player will be available at Pick N"
                            if (pickStr) {
                                hoverText = `${activeHoverText} at Pick ${pickStr}`;
                            }
                        }
                        // Generic numeric-percentage handling
                        else {
                            text = `${baseText} ${value}%`;
                        }
                    }
                }
            }
        }

        this._create_tag_icon(text, hoverText, container, isActive, backgroundColor, outline, null, 1, enableMouseOverText);
    }

    _convert_to_rgba(hex, opacity) {
        let c;
        if (/^#([A-Fa-f0-9]{3}){1,2}$/.test(hex)) {
            c = hex.substring(1).split('');
            if (c.length === 3) {
                c = [c[0], c[0], c[1], c[1], c[2], c[2]];
            }
            c = '0x' + c.join('');
            return `rgba(${[(c >> 16) & 255, (c >> 8) & 255, c & 255].join(',')}, ${opacity})`;
        }
        console.error('Invalid HEX color:', hex);
        return hex; // Return original if invalid
    }
}

class Picks_Notch {
    constructor(container_element, overlay_manager, trigger_refresh_callback) {
        this.container_element = container_element;
        this.overlay_manager = overlay_manager;
        this.trigger_refresh_callback = trigger_refresh_callback;
        this.anchor_element = null;
        this.notch_element = null;
        this.hover_area_element = null;
        this._refresh_hover = null;
        this._notch_click_handler = null;
        this._render_context = null;
        this._ensure_structure();
        this._setup_model_subscription();
    }
    
    _setup_model_subscription() {
        if (this.overlay_manager?.model) {
            this.overlay_manager.model.subscribe('show_notch_hover_areaChanged', () => {
                this._update_hover_area_visibility();
            });
            this._update_hover_area_visibility();
            
            this.overlay_manager.model.subscribe('show_notch_refreshChanged', () => {
                // If refresh is disabled and we're not loading, hide the notch
                const loading = this.overlay_manager?.fsm?.state_data?.rankings_loading;
                if (!loading && !this.overlay_manager.model.get('show_notch_refresh')) {
                    this.hide_loading();
                } else if (!loading && this.overlay_manager.model.get('show_notch_refresh')) {
                    // If refresh is enabled and not loading, show refresh icon
                    this.show_refresh_icon();
                }
            });
        }
    }
    
    _update_hover_area_visibility() {
        if (!this.hover_area_element || !this.overlay_manager?.model) return;
        const should_show = this.overlay_manager.model.get('show_notch_hover_area');
        if (should_show) {
            this.hover_area_element.classList.add('is-visible');
        } else {
            this.hover_area_element.classList.remove('is-visible');
        }
    }

    _ensure_structure() {
        if (!this.container_element) return;

        const existing_anchor = this.container_element.querySelector('.picks-notch-anchor');
        if (existing_anchor) {
            this.anchor_element = existing_anchor;
            this.notch_element = existing_anchor.querySelector('.picks-notch');
            if (this.notch_element) {
                this.hover_area_element = existing_anchor.querySelector('.notch-hover-area');
                if (!this.hover_area_element) {
                    this.hover_area_element = this._create_hover_area_element();
                }
                return;
            }
            existing_anchor.remove();
        }

        // Clean up any legacy notch or hover area nodes
        const legacy_notch = this.container_element.querySelector('.picks-notch');
        if (legacy_notch) {
            legacy_notch.remove();
        }
        const legacy_hover_area = this.container_element.querySelectorAll('.notch-hover-area');
        legacy_hover_area.forEach(node => node.remove());

        const anchor = document.createElement('div');
        anchor.className = 'picks-notch-anchor';
        const notch = document.createElement('div');
        notch.className = 'picks-notch';
        anchor.appendChild(notch);

        this.anchor_element = anchor;
        this.notch_element = notch;
        
        this.hover_area_element = this._create_hover_area_element();
        
        this.attach();
    }

    attach() {
        if (!this.container_element || !this.anchor_element) return;
        if (this.anchor_element.parentElement === this.container_element) return;
        this.container_element.insertBefore(this.anchor_element, this.container_element.firstChild);
    }

    detach() {
        if (!this.anchor_element || !this.container_element) return;
        if (this.anchor_element.parentElement === this.container_element) {
            this.container_element.removeChild(this.anchor_element);
        }
    }

    update_render_context(render_context) {
        this._render_context = render_context;
    }

    show_loading() {
        if (!this.notch_element) return;
        
        // Check if already showing loading to avoid restarting animation
        const has_loading_dots = this.notch_element.querySelectorAll('.loading-dot').length > 0;
        const is_hidden = this.notch_element.classList.contains('is-hidden');
        
        // Only update if not already showing loading dots or if hidden
        if (!has_loading_dots || is_hidden) {
            // const showLoadingLogData = {
            //     had_dots: has_loading_dots,
            //     was_hidden: is_hidden,
            //     stack: new Error().stack.split('\n').slice(1, 4).join('\n')
            // };
            // console.log('[PicksContainer] show_loading() - creating loading dots', showLoadingLogData);
            this._teardown_refresh_hover();
            this._clear_notch_content();
            this.notch_element.innerHTML = `
                <span class="loading-dot"></span>
                <span class="loading-dot"></span>
                <span class="loading-dot"></span>
            `;
            this.notch_element.classList.remove('is-clickable', 'is-hidden');
        } else {
            const alreadyShowingLogData = {
                has_loading_dots: has_loading_dots,
                is_hidden: is_hidden
            };
        }
    }

    hide_loading() {
        this._teardown_refresh_hover();
        this._clear_notch_content();
        if (this.notch_element) {
            this.notch_element.classList.add('is-hidden');
        }
    }

    show_refresh_icon() {
        if (!this.notch_element) return;
        
        const show_refresh = this.overlay_manager?.model?.get('show_notch_refresh') !== false;
        if (!show_refresh) {
            this.hide_loading();
            return;
        }

        this._clear_notch_content();
        const refresh_icon = document.createElement('div');
        refresh_icon.className = 'refresh-icon';
        this.notch_element.appendChild(refresh_icon);
        this.notch_element.classList.add('is-clickable', 'is-hidden');

        const handle_click = () => {
            const current_icon = this.notch_element.querySelector('.refresh-icon');
            if (current_icon) {
                current_icon.classList.add('is-rotating');
                setTimeout(() => {
                    current_icon.classList.remove('is-rotating');
                }, 600);
            }
            if (typeof this.trigger_refresh_callback === 'function') {
                this.trigger_refresh_callback();
            }
        };

        this.notch_element.removeEventListener('click', this._notch_click_handler);
        this._notch_click_handler = handle_click;
        this.notch_element.addEventListener('click', handle_click);

        this._setup_refresh_hover();
    }

    _clear_notch_content() {
        if (!this.notch_element) return;
        this.notch_element.innerHTML = '';
        this.notch_element.classList.remove('is-clickable');
    }

    _resolve_env_value() {
        return this.overlay_manager?.fsm?.state_data?.env_value;
    }

    _setup_refresh_hover() {
        if (!this.container_element || !this.notch_element) return;
        this._teardown_refresh_hover();

        const state = { visible: true };
        const set_visible = (visible) => {
            state.visible = visible;
            if (visible) {
                this.notch_element.classList.remove('is-hidden');
            } else {
                this.notch_element.classList.add('is-hidden');
            }
        };

        set_visible(false);

        // Hover area element should already exist (created in _ensure_structure)
        // If it doesn't exist for some reason, create it now
        if (!this.hover_area_element) {
            this.hover_area_element = this._create_hover_area_element();
        }

        const calculate_hover_area = () => {
            const container_rect = this.container_element.getBoundingClientRect();
            const notch_rect = this.notch_element.getBoundingClientRect();
            const hover_width = Math.min(
                notch_rect.width + 80,
                Math.max(100, container_rect.width * 0.7)
            );
            const radius = hover_width / 2;
            const center_x = notch_rect.left + (notch_rect.width / 2);
            const center_y = container_rect.top;
            return { container_rect, notch_rect, hover_width, radius, center_x, center_y };
        };

        const update_hover_area_element = () => {
            if (!this.hover_area_element || !this.anchor_element || !this.notch_element?.isConnected) return;
            const { hover_width, radius, center_x, center_y } = calculate_hover_area();
            const anchor_rect = this.anchor_element.getBoundingClientRect();
            const relative_x = center_x - anchor_rect.left;
            const relative_y = center_y - anchor_rect.top;
            this.hover_area_element.style.left = `${relative_x}px`;
            this.hover_area_element.style.top = `${relative_y}px`;
            this.hover_area_element.style.width = `${hover_width}px`;
            this.hover_area_element.style.height = `${radius}px`;
        };

        const on_move = (event) => {
            if (!this.notch_element?.isConnected) return;
            const { radius, center_x, center_y } = calculate_hover_area();
            const delta_x = event.clientX - center_x;
            const delta_y = event.clientY - center_y;
            const distance = Math.sqrt((delta_x * delta_x) + (delta_y * delta_y));
            const within_circle = distance <= radius;
            const below_center = event.clientY >= center_y;
            const within_area = within_circle && below_center;

            set_visible(within_area);
            update_hover_area_element();
        };

        const always_visible = () => set_visible(true);
        const on_leave = () => set_visible(false);

        this.container_element.addEventListener('mousemove', on_move);
        this.container_element.addEventListener('mouseleave', on_leave);
        this.notch_element.addEventListener('mouseenter', always_visible);
        this.notch_element.addEventListener('mousemove', always_visible);

        const update_on_change = () => {
            if (this.hover_area_element && this.notch_element?.isConnected) {
                update_hover_area_element();
            }
        };
        update_hover_area_element();
        window.addEventListener('resize', update_on_change);
        this.container_element.addEventListener('scroll', update_on_change);

        this._refresh_hover = {
            on_move,
            on_leave,
            always_visible,
            set_visible,
            state,
            update_on_change
        };
    }

    _teardown_refresh_hover() {
        if (!this._refresh_hover) return;
        const {
            on_move,
            on_leave,
            always_visible,
            update_on_change
        } = this._refresh_hover;

        this.container_element?.removeEventListener('mousemove', on_move);
        this.container_element?.removeEventListener('mouseleave', on_leave);
        this.notch_element?.removeEventListener('mouseenter', always_visible);
        this.notch_element?.removeEventListener('mousemove', always_visible);

        if (update_on_change) {
            window.removeEventListener('resize', update_on_change);
            this.container_element?.removeEventListener('scroll', update_on_change);
        }

        this._refresh_hover = null;
    }

    _create_hover_area_element() {
        if (!this.anchor_element) return null;
        const existing = this.anchor_element.querySelector('.notch-hover-area');
        if (existing) {
            return existing;
        }
        const hover_area = document.createElement('div');
        hover_area.className = 'notch-hover-area';
        hover_area.style.zIndex = '1';
        this.anchor_element.appendChild(hover_area);
        return hover_area;
    }
}

class Picks_Container {
    constructor(container_element, site_type = 'draftkings', model = null, overlay_manager = null, queue_click_handler = null) {
        this.container_element = container_element;
        this.site_type = site_type;
        this.model = model;
        this.overlay_manager = overlay_manager;
        this.queue_click_handler = queue_click_handler;
        this.season_stage_override = null;
        this.picks = [];
        this.notch_controller = null;
        this._empty_placeholder_element = null;
        this._render_context = this._build_render_context();
        this._setup_container_style();
        this._create_notch_controller();
        
        if (this.model) {
            this._setup_model_subscriptions();
            this._update_render_context(true);
            this._update_from_model();
            // Initialize loading state from model (only once during setup)
            this._update_loading_from_model();
        }
    }

    _ensure_empty_placeholder_element() {
        if (this._empty_placeholder_element && this._empty_placeholder_element.parentNode) {
            this._remove_duplicate_empty_placeholders();
            return this._empty_placeholder_element;
        }
        // Rehydrate: reuse existing placeholder in DOM (e.g. after extension reload) so we never duplicate
        if (this.container_element) {
            const existing = this.container_element.querySelector('.picks-container-empty-message');
            if (existing) {
                this._empty_placeholder_element = existing;
                this._remove_duplicate_empty_placeholders();
                return existing;
            }
        }
        const el = document.createElement('div');
        el.className = 'picks-container-empty-message';
        el.setAttribute('aria-hidden', 'true');
        el.textContent = 'Player list will load once you start a bestball draft on Underdog or Draftkings.';
        el.style.cssText = `
            color: #9e9e9e;
            font-size: 13px;
            line-height: 1.4;
            padding: 12px 8px;
            text-align: center;
            user-select: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            pointer-events: none;
        `;
        this._empty_placeholder_element = el;
        if (this.container_element) {
            this.container_element.appendChild(el);
        }
        return el;
    }

    _remove_duplicate_empty_placeholders() {
        if (!this.container_element || !this._empty_placeholder_element) return;
        const all = this.container_element.querySelectorAll('.picks-container-empty-message');
        all.forEach(node => {
            if (node !== this._empty_placeholder_element) {
                node.remove();
            }
        });
    }

    _show_empty_placeholder() {
        const el = this._ensure_empty_placeholder_element();
        el.style.display = '';
    }

    _hide_empty_placeholder() {
        if (this._empty_placeholder_element) {
            this._empty_placeholder_element.style.display = 'none';
        }
    }
    
    _setup_model_subscriptions() {
        this.model.subscribe('picksChanged', () => {
            this._update_picks_from_model();
        });
        
        this.model.subscribe('rankings_loadingChanged', (data) => {
            // const rankingsLoadingChangedLogData = {
            //     oldValue: data?.oldValue,
            //     newValue: data?.newValue,
            //     current_model_value: this.model.get('rankings_loading'),
            //     current_fsm_value: this.overlay_manager?.fsm?.state_data?.rankings_loading
            // };
            // console.log('[PicksContainer] rankings_loadingChanged event received', rankingsLoadingChangedLogData);
            this._update_loading_from_model();
        });

        // env_value is stored in state_data only (not in model), so no subscription needed
        // If env_value changes, we'd need to watch FSM state_data directly or re-render on other triggers
        
        this.model.subscribe('algo_typeChanged', () => {
            this._handle_render_context_change();
        });

        this.model.subscribe('picked_idsChanged', () => {
            this._update_picked_opacities();
        });
    }

    _update_picked_opacities() {
        const picked_ids = this.model.get('picked_ids') || [];
        this.picks.forEach(pick_el => pick_el.update_picked_opacity(picked_ids));
    }
    
    _update_from_model() {
        this._update_render_context();
        this._update_picks_from_model();
        // Don't call _update_loading_from_model() here - it should only be called
        // when rankings_loadingChanged event fires, not when picks change
        // this._update_loading_from_model();
    }
    
    _update_picks_from_model() {
        this._update_render_context();
        const picks = this.model.get('picks') || [];
        this.set_picks(picks);
    }
    
    _update_loading_from_model() {
        // Read from model, not FSM state_data - model is the source of truth for UI
        const loading = this.model.get('rankings_loading');
        const show_refresh = this.model.get('show_notch_refresh') !== false;
        
        // const updateLoadingFromModelLogData = {
        //     loading: loading,
        //     show_refresh: show_refresh,
        //     notch_exists: !!this.notch_controller?.notch_element,
        //     has_dots: this.notch_controller?.notch_element ? this.notch_controller.notch_element.querySelectorAll('.loading-dot').length : 0,
        //     is_hidden: this.notch_controller?.notch_element?.classList.contains('is-hidden'),
        //     stack: new Error().stack.split('\n').slice(1, 5).join('\n')
        // };
        // console.log('[PicksContainer] _update_loading_from_model() called', updateLoadingFromModelLogData);
        
        if (loading) {
            this.show_loading();
        } else if (show_refresh) {
            this.show_refresh_icon();
        } else {
            // If refresh is disabled and not loading, hide the notch
            this.hide_loading();
        }
    }

    _setup_container_style() {
        if (this.container_element) {
            const currentPosition = window.getComputedStyle(this.container_element).position;
            if (currentPosition === 'static' || !currentPosition) {
                this.container_element.style.position = 'relative';
            }
        }
    }

    _create_notch_controller() {
        if (!this.container_element) return;
        this.notch_controller = new Picks_Notch(
            this.container_element,
            this.overlay_manager,
            () => this._trigger_rankings_refresh()
        );
        this.notch_controller.update_render_context(this._render_context);
    }

    _build_render_context() {
        // env_value is stored in state_data only (not in model)
        // algo_type is in model (UI state that needs subscriptions)
        // enable_mouse_over_text is in user_settings (not in model)
        // Note: render_context is mostly unused now since Pick_Element queries FSM/model directly
        const algo_type = this.model?.get?.('algo_type');
        const enable_mouse_over_text = this.overlay_manager?.fsm?.user_settings?.enable_mouse_over_text;
        const season_stage = this.season_stage_override ?? this.overlay_manager?.fsm?.state_data?.season_stage ?? 'regular_season';

        const picked_ids = this.model?.get?.('picked_ids') || [];
        return {
            env_value: this.overlay_manager?.fsm?.state_data?.env_value ?? null,
            algo_type: algo_type ?? null,
            enable_mouse_over_text: enable_mouse_over_text !== undefined ? !!enable_mouse_over_text : true,
            season_stage: season_stage,
            picked_ids: picked_ids
        };
    }

    _update_render_context(force = false) {
        const next_context = this._build_render_context();
        const previous_context = this._render_context || {};
        const prev_ids = previous_context.picked_ids || [];
        const next_ids = next_context.picked_ids || [];
        const picked_ids_changed = prev_ids.length !== next_ids.length || next_ids.some((id, i) => String(prev_ids[i]) !== String(id));
        const has_changed = force ||
            previous_context.env_value !== next_context.env_value ||
            previous_context.algo_type !== next_context.algo_type ||
            previous_context.enable_mouse_over_text !== next_context.enable_mouse_over_text ||
            previous_context.season_stage !== next_context.season_stage ||
            picked_ids_changed;

        if (has_changed || force) {
            this._render_context = next_context;
            if (this.notch_controller) {
                this.notch_controller.update_render_context(this._render_context);
            }
        }

        return has_changed;
    }

    _handle_render_context_change() {
        const changed = this._update_render_context();
        if (changed) {
            this._rerender_picks();
        }
    }

    set_season_stage(season_stage) {
        this.season_stage_override = season_stage || null;
        const changed = this._update_render_context();
        if (changed) {
            this._rerender_picks();
        }
    }

    _rerender_picks() {
        if (!this.picks.length) return;
        const current_pick_data = this.picks.map(pick_element => pick_element.pick_data);
        this.set_picks(current_pick_data);
    }

    clear() {
        if (this.container_element) {
            // Clear only pick elements, not the entire container
            // This preserves the notch anchor element which is managed by notch_controller
            // The notch_controller maintains its own reference to anchor_element and notch_element
            // so we don't need to detach/re-attach - just remove pick elements
            const pick_elements = this.container_element.querySelectorAll('.pick-element');
            pick_elements.forEach(el => el.remove());
            
            // Clear picks array
            this.picks = [];
            
            // Show empty-state message when no picks are displayed (model cleared picks)
            this._show_empty_placeholder();

            // No need to detach/re-attach notch - it stays in place since we only removed pick elements
        } else {
            this.picks = [];
        }
    }

    add_pick(pick_data) {
        const pick_element = new Pick_Element(pick_data, this.site_type, this._render_context, this.queue_click_handler, this.overlay_manager);
        const element = pick_element.get_element();
        
        if (this.container_element && element) {
            this.container_element.appendChild(element);
            this.picks.push(pick_element);
            return pick_element;
        }
        return null;
    }

    set_picks(picks_array) {
        this._update_render_context();
        this.clear();
        if (Array.isArray(picks_array)) {
            picks_array.forEach(pick => this.add_pick(pick));
        }
        this.update_stars_from_queue();
        if (this.picks.length === 0) {
            this._show_empty_placeholder();
        } else {
            this._hide_empty_placeholder();
        }
    }

    set_site_type(site_type) {
        this.site_type = site_type;
        if (this.queue_click_handler) {
            this.queue_click_handler.site_type = site_type;
        }
        const current_pick_data = this.picks.map(p => p.pick_data);
        this.set_picks(current_pick_data);
    }

    refresh_position_colors() {
        for (const pick of this.picks) {
            if (pick?.element) {
                pick._apply_position_color(pick.element);
            }
        }
    }

    show_loading() {
        this.notch_controller?.show_loading();
    }

    hide_loading() {
        this.notch_controller?.hide_loading();
    }

    show_refresh_icon() {
        this.notch_controller?.show_refresh_icon();
    }

    _trigger_rankings_refresh() {
        if (this.overlay_manager && this.overlay_manager.trigger_rankings_refresh) {
            this.overlay_manager.trigger_rankings_refresh();
        }
    }

    update_stars_from_queue(queue_players = null) {
        if (queue_players === null) {
            queue_players = this.overlay_manager?.fsm?.state_data?.queue?.players || [];
        }

        if (!Array.isArray(queue_players) || queue_players.length === 0) {
            this.picks.forEach(pick => pick.hide_star());
            return;
        }

        // Normalize: Underdog stores plain names (string[]), DraftKings stores { name, position }[]
        const queueEntries = queue_players.map(entry => {
            if (typeof entry === 'string') {
                return { name: entry, position: undefined };
            }
            return {
                name: entry && entry.name != null ? String(entry.name) : '',
                position: entry && entry.position != null ? String(entry.position).trim() : undefined
            };
        }).filter(entry => entry.name !== '');

        // Underdog should not need fuzzy matching: star visibility should be based on exact full name.
        // This prevents "Javonte Williams" incorrectly matching "Jameson Williams".
        if (this.site_type === 'underdog') {
            const normalizeUdExactName = (name) => {
                return String(name)
                    .replace(/[\u2019’]/g, "'")
                    .replace(/\s+/g, ' ')
                    .trim()
                    .toLowerCase();
            };

            const queueNameSet = new Set(
                queueEntries.map(e => normalizeUdExactName(e.name)).filter(Boolean)
            );

            this.picks.forEach(pick => {
                const pickName = (pick.pick_data?.full_name || pick.pick_data?.name || '').trim();
                if (!pickName) {
                    pick.hide_star();
                    return;
                }

                const pickNameNorm = normalizeUdExactName(pickName);
                if (queueNameSet.has(pickNameNorm)) {
                    pick.show_star();
                } else {
                    pick.hide_star();
                }
            });

            return;
        }

        const queueMatchData = queueEntries.map(entry => {
            const matchData = getFuzzyNameMatchData(entry.name);
            return matchData ? { matchData, position: entry.position } : null;
        }).filter(Boolean);

        const usePositionMatch = this.site_type === 'draftkings';

        this.picks.forEach(pick => {
            const pick_name = pick.pick_data?.full_name || pick.pick_data?.name || '';
            const trimmed_pick_name = pick_name.trim();
            if (!trimmed_pick_name) {
                pick.hide_star();
                return;
            }

            const pickMatchData = getFuzzyNameMatchData(trimmed_pick_name);
            const pickPosition = (pick.pick_data?.position || pick.pick_data?.pos || '').trim();

            let isQueued = false;
            if (pickMatchData) {
                const nameMatches = (allowFuzzy) => queueMatchData.some(
                    ({ matchData }) => isPlayerNameMatchData(matchData, pickMatchData, { allowFuzzy })
                );
                isQueued = nameMatches(false) || nameMatches(true);
                if (isQueued && usePositionMatch) {
                    // DraftKings: require at least one queue entry to match name and, when both have position, position
                    isQueued = queueMatchData.some(({ matchData, position: queuePosition }) => {
                        const nameMatch = isPlayerNameMatchData(matchData, pickMatchData, { allowFuzzy: false }) ||
                            isPlayerNameMatchData(matchData, pickMatchData, { allowFuzzy: true });
                        if (!nameMatch) return false;
                        const qPos = queuePosition != null && queuePosition !== '' ? queuePosition.trim() : '';
                        if (!qPos || !pickPosition) return true; // one side missing position -> name match enough
                        return qPos.toUpperCase() === pickPosition.toUpperCase();
                    });
                }
            }

            if (isQueued) {
                pick.show_star();
            } else {
                pick.hide_star();
            }
        });
    }
}

class Overlay_Manager {
    constructor(fsm) {
        this.fsm = fsm;
        this.overlay = null;
        this.is_initialized = false;
        this.min_width = 220;
        this.middle_width = 290;
        this.max_width = 400;
        this.handles = {};
        this.drag_occurred = false;
        this.is_mini = false;
        this._preMini = null;
        this.notification_bubble = null;
        this.exposure_saved_toast = null;
        this._pending_exposure_toast = null;
        this.last_restored_draft_id = null;
        this.wrapper = null;
        this._onMove = null;
        this._onUp = null;
        this.sidecar = null;
        this.sidecar_width = 360;
        this.streamer_overlay = null;
        this.picks_container = null;
        this.model = new Overlay_Model();
        this.model._fsm = this.fsm; // Set FSM reference for validation
        this._ghostModeTimeout = null;
        this._ghostKeyHandler = null;
        this._onWindowResize = null;
        this._onTopBarMouseDown = null;
        // Cache while chrome.runtime is alive — getURL throws after extension context invalidation.
        try {
            this._refresh_icon_url = chrome.runtime.getURL('assets/refresh.png');
        } catch {
            this._refresh_icon_url = null;
        }
        this._initialize_model();
    }
    
    async _initialize_model() {
        this.model.set('sound_enabled', this.fsm.user_settings.user_sound_enabled);
        // Sync rankings_loading from state_data (FSM is source of truth)
        this.model.set('rankings_loading', this.fsm.state_data.rankings_loading);
        
        const site = detect_site_key();
        const siteOverlay = await get_overlay_for_site(site);
        const ui = siteOverlay?.ui || {};
        
        this.model.set('ranking_set', ui.selected_ranking_set || 'legup');
        this.model.set('algo_type', ui.selected_algo_type || 'sim');
        this._persist_normalized_algo_type(site, ui.selected_algo_type);
        
        // Initialize format_type based on season_stage (auto-updated per draft later)
        const defaultFormat = this.fsm.state_data.season_stage === 'playoffs' ? 'playoff' : 'standard';
        this.model.set('format_type', defaultFormat);

        // Subscribe to user_otc flag changes to show/hide green border
        this.model.subscribe('user_otcChanged', () => {
            this._update_otc_border();
        });

        this._setup_fsm_sync();
        this.model.subscribe('format_typeChanged', () => {
            if (this.update_top_bar_from_state) {
                this.update_top_bar_from_state({});
            }
        });
        this.model.subscribe('ranking_setChanged', () => {
            if (this.update_top_bar_from_state) {
                this.update_top_bar_from_state({});
            }
        });
    }

    static WEEKLY_WINNERS_ADVANCEMENT_LABEL = 'Weekly Winners';

    _persist_normalized_algo_type(site, stored_algo_type) {
        // Retired algo types (e.g. 'classic') get coerced to 'sim' by the
        // model's validation; rewrite storage so the stale value doesn't linger.
        if (stored_algo_type === undefined) return;
        const normalized = this.model.get('algo_type');
        if (stored_algo_type !== normalized) {
            set_overlay_for_site(site, { ui: { selected_algo_type: normalized } });
        }
    }

    _get_lite_mode_ranking_set_label() {
        const ranking_set = this.model?.get('ranking_set') || 'legup';
        const format_type = this.model?.get('format_type') || 'standard';
        const scoring = this.model?.get('scoring') || null;
        const effective_ranking_set = resolveLegUpRankingSet(ranking_set, format_type, scoring);
        if (effective_ranking_set === 'adp') return 'ADP';
        if (effective_ranking_set === 'custom') return 'Custom Rank';
        return 'LegUp Rank';
    }

    _get_lite_mode_upgrade_segments() {
        return [
            { type: 'linebreak' },
            { type: 'text', text: 'For dynamic rankings, upgrade to the ', muted: true },
            {
                type: 'link',
                text: 'Sidekick',
                href: 'https://www.legendaryupside.com/sidekick/#/portal/account'
            },
            { type: 'text', text: '.', muted: true }
        ];
    }

    _compose_legup_lite_mode_top_bar_message(overlay_width = null) {
        const ranking_set_label = this._get_lite_mode_ranking_set_label();
        const show_full_message = overlay_width === null || overlay_width >= this.max_width;
        const primary_text = show_full_message
            ? `Kickstand player rankings sorted by ${ranking_set_label}.`
            : `Sorted by ${ranking_set_label}.`;

        return {
            segments: [
                {
                    type: 'text',
                    text: primary_text,
                    emphasis: true
                },
                ...this._get_lite_mode_upgrade_segments()
            ],
            hover_text: ''
        };
    }

    _normalize_advancement_structure(advancement_structure) {
        if (!advancement_structure || typeof advancement_structure !== 'object') {
            return null;
        }
        const has_raw =
            typeof advancement_structure.raw_string === 'string' &&
            advancement_structure.raw_string.trim() !== '';
        const has_round_fields =
            advancement_structure.regular_season_num != null ||
            advancement_structure.regular_season_denom != null ||
            advancement_structure.w15_num != null ||
            advancement_structure.w16_num != null ||
            advancement_structure.finals_size != null;
        if (!has_raw && !has_round_fields) {
            return null;
        }
        return advancement_structure;
    }

    set_advancement_structure_on_model(advancement_structure) {
        if (this._is_legup_lite_mode?.()) {
            this.model.set('advancement_structure', null);
            return;
        }
        if (this.model?.get('format_type') === 'weekly_winners') {
            this.model.set('advancement_structure', null);
            return;
        }
        this.model.set(
            'advancement_structure',
            this._normalize_advancement_structure(advancement_structure)
        );
    }

    clear_advancement_structure() {
        this.set_advancement_structure_on_model(null);
    }

    _resolve_advancement_display_text(advancement_structure = null) {
        const format_type = this.model?.get('format_type');
        if (format_type === 'weekly_winners') {
            return Overlay_Manager.WEEKLY_WINNERS_ADVANCEMENT_LABEL;
        }
        const adv =
            advancement_structure != null
                ? this._normalize_advancement_structure(advancement_structure)
                : this.model?.get('advancement_structure');
        return adv?.raw_string || null;
    }
    
    _setup_fsm_sync() {
        // Watch for FSM state changes that affect the model
        // Note: We'll update this when FSM changes occur via content_script_fsm.js
    }
    
    async sync_overlay_settings_from_background() {
        // Sync overlay dropdown values from background settings
        // This is called when settings are received via BG_HELLO or UPDATE_SETTINGS
        const site = detect_site_key();
        const siteOverlay = await get_overlay_for_site(site);
        const ui = siteOverlay?.ui || {};
        
        if (ui.selected_ranking_set !== undefined) {
            this.model.set('ranking_set', ui.selected_ranking_set);
        }
        if (ui.selected_algo_type !== undefined) {
            // Model.set() will validate the algo_type value
            this.model.set('algo_type', ui.selected_algo_type);
            this._persist_normalized_algo_type(site, ui.selected_algo_type);
        }
        // Note: format_type is draft-specific and loaded separately via load_format_selection()
    }

    _nextFrame() {
        return new Promise(r => requestAnimationFrame(() => r()));
    }
    
    _detect_site_type() {
        const url = window.location.href;
        if (is_underdog_draft_url(url) || is_active_url(url)) {
            return 'underdog';
        } else if (is_draft_kings_draft_url(url)) {
            return 'draftkings';
        }
        return 'draftkings';
    }
    _effective_wrapper_width(overlayWidth) {
        return overlayWidth + (this.sidecar ? this.sidecar.getWidth() : 0);
    }
    _should_show_sidecar() {
        const env = this.fsm?.state_data?.env_value;
        const envAllowsSidecar = ['dev', 'local'].includes(env);
        const userEnabled = !!this.fsm?.user_settings?.sidecar_enabled;
        return envAllowsSidecar && userEnabled && this._is_on_draft_page();
    }
    _should_show_streamer_overlay() {
        const env = this.fsm?.state_data?.env_value;
        const envOk = ['dev', 'local'].includes(env);
        const userEnabled = !!this.fsm?.user_settings?.streamer_overlay_enabled;
        return envOk && userEnabled;
    }
    /**
     * Drop stale Streamer_Overlay refs (e.g. DOM removed without destroy) and remove orphan
     * #streamerOverlayRoot nodes so reconnect / BG restart cannot leave a dead duplicate panel.
     */
    _rehydrate_streamer_overlay_dom() {
        if (this.streamer_overlay) {
            const r = this.streamer_overlay.root;
            if (!r || !r.isConnected) {
                this.streamer_overlay.destroy();
                this.streamer_overlay = null;
            }
        }
        const keep = this.streamer_overlay?.root ?? null;
        document.querySelectorAll('#streamerOverlayRoot').forEach((el) => {
            if (keep && el === keep) return;
            el.remove();
        });
    }
    sync_streamer_overlay_visibility() {
        if (!this.is_initialized) return;
        this._rehydrate_streamer_overlay_dom();
        const want = this._should_show_streamer_overlay();
        const has = !!this.streamer_overlay;
        if (want && !has) {
            this.streamer_overlay = new Streamer_Overlay(this);
            this.streamer_overlay.mount();
            this.update_streamer_overlay_content();
            return;
        }
        if (want && has) {
            this.update_streamer_overlay_content();
            return;
        }
        if (!want && has) {
            this.streamer_overlay.destroy();
            this.streamer_overlay = null;
        }
    }
    update_streamer_overlay_content() {
        if (!this.streamer_overlay) return;
        const currentlyWinning = this.fsm?.state_data?.streamer_mode_data?.currently_winning || null;
        const entryFeesCents = this.fsm?.state_data?.streamer_mode_data?.entry_fees_total_cents ?? null;
        if (typeof this.streamer_overlay.set_streamer_data === 'function') {
            this.streamer_overlay.set_streamer_data(currentlyWinning, entryFeesCents);
            return;
        }
        this.streamer_overlay.set_currently_winning?.(currentlyWinning);
    }
    disable_sidecar_from_ui() {
        if (this.fsm && this.fsm.user_settings) {
            this.fsm.user_settings.sidecar_enabled = false;
        }
        this.sync_sidecar_visibility();
        if (this.fsm?.bg_port && this.fsm.bg_connected) {
            this.fsm.send_port_request('SET_SETTINGS', {
                scope: 'content_script',
                settings: { sidecar_enabled: false }
            }).catch((err) => {
                console.error('[overlay_manager] set_settings sidecar_enabled=false failed', err);
            });
        }
    }
    sync_sidecar_visibility() {
        if (!this.wrapper) return;
        const wantSidecar = this._should_show_sidecar();
        const hasSidecar = !!this.sidecar;
        const overlayWidth = this.overlay?.offsetWidth || this.middle_width;

        if (wantSidecar && !hasSidecar) {
            this.sidecar = new Sidecar(this, { width: this.sidecar_width });
            this.sidecar.mount(this.wrapper);
            this.refresh_cached_rankings_checkbox();
            this.refresh_ud_xhr_replay_controls();
            this.wrapper.style.width = `${this._effective_wrapper_width(overlayWidth)}px`;
            return;
        }

        if (!wantSidecar && hasSidecar) {
            this.close_sidecar();
            this.wrapper.style.width = `${overlayWidth}px`;
        }
    }
    _waitEnvReady(timeoutMs = 5000) {
        const start = Date.now();
        return new Promise(resolve => {
            const tick = () => {
                if (['dev', 'local', 'prod'].includes(this.fsm.state_data.env_value || '')) return resolve();
                if (Date.now() - start > timeoutMs) return resolve(); // don’t hang forever; best-effort
                setTimeout(tick, 50);
            };
            tick();
        });
    }
    async _initial_toggle_after_mount() {
        if (this.bottom_bar?.ready) await this.bottom_bar.ready;
        await this._waitEnvReady();
        // two RAFs is a common trick to ensure style & layout are committed
        await this._nextFrame();
        await this._nextFrame();
        this.toggle_bar_elements(this._get_layout_width());
        this.refresh_legup_button_icon();
        // Always sync notification bubble state after mount, even when message is ''.
        // This prevents a timing race where the bubble becomes visible during overlay init,
        // but the auth handshake later clears it before overlay is fully initialized.
        const eff = this.fsm?.get_effective_notification?.();
        if (eff) {
            this.display_notification(eff.message ?? '', eff.type ?? 'auth_error', { closable: eff.closable, layer: eff.layer });
        } else {
            this.display_notification('', 'auth_error', { closable: false, layer: 'none' });
        }
    }

    _get_topbar_height() {
        return this.top_bar?.element?.offsetHeight || 60; // fallback to 60
    }

    // Prefer authored width — offsetWidth is often 0 before first layout commit.
    _get_layout_width() {
        if (!this.overlay) return this.middle_width;
        const styled = parseInt(this.overlay.style.width, 10);
        if (Number.isFinite(styled) && styled > 0) return styled;
        const measured = this.overlay.offsetWidth;
        if (measured > 0) return measured;
        return this.middle_width;
    }

    _sync_top_bar_message_box_visibility(width) {
        const top_bar_message_box = this.top_bar?.element?.querySelector?.('#top_bar_message_box');
        if (!top_bar_message_box) return;

        const set_visible = (on) => {
            top_bar_message_box.style.display = on ? '' : 'none';
        };

        if (this.is_mini) {
            set_visible(false);
            return;
        }

        const w = Number.isFinite(width) && width > 0 ? width : this._get_layout_width();
        if (this._is_legup_lite_mode() || w >= this.middle_width - 2) {
            set_visible(true);
        } else {
            set_visible(false);
        }
    }
    _enable_resize_handles() {
        if (this.is_mini) return;
        if (Object.keys(this.handles || {}).length) return;

        this.handles = {};
        this.create_resize_handles(); // creates DOM nodes + populates this.handles

        // bind listeners for the newly created handles (same logic as setup_event_listeners)
        for (const [key, handle] of Object.entries(this.handles)) {
            handle.addEventListener('mousedown', (e) => this.handle_resize_start(e, key));
        }
    }

    _disable_resize_handles() {
        this._remove_doc_listeners();

        if (!this.handles) this.handles = {};
        Object.values(this.handles).forEach(el => el?.remove());
        this.handles = {};
    }
    _apply_mini_size() {
        const h = this._get_topbar_height();
        const top = parseInt(this.wrapper?.style?.top || 0, 10);
        const left = parseInt(this.wrapper?.style?.left || 0, 10);

        this._apply_geometry(
            { width: h, height: h, top, left },
            { allowMini: true, persist: false }
        ).catch(err => console.error('[Overlay] Failed to apply mini geometry', err));
    }


    _enter_mini_mode() {
        if (this.is_mini) return;

        const rawWidth = parseInt(this.overlay.style.width, 10) || this.overlay.offsetWidth || this.middle_width;
        const rawHeight = parseInt(this.overlay.style.height, 10) || this.overlay.offsetHeight || 500;
        this._preMini = this._clamp_stored_dimensions(rawWidth, rawHeight);

        // kill resizers so the top-bar drag gets maximum real estate
        this._disable_resize_handles();

        this.overlay.classList.add('mini');
        this.is_mini = true;
        this._apply_mini_size();
        this._persist_ui_state();
    }

    _exit_mini_mode() {
        if (!this.is_mini) return;

        this.overlay.classList.remove('mini');
        this.is_mini = false;

        const prev = this._preMini || {};
        const { width, height } = this._clamp_stored_dimensions(
            prev.width || this.middle_width,
            prev.height || 500
        );

        this.overlay.style.width = `${width}px`;
        this.overlay.style.height = `${height}px`;
        const effW = this._effective_wrapper_width(width);
        this.wrapper.style.width = `${effW}px`;
        this.wrapper.style.height = `${height}px`;

        this.ensure_overlay_in_viewport();
        this._enable_resize_handles();
        this._persist_ui_state();
    }

    toggle_mini_mode() {
        this.set_mini_mode(!this.is_mini);
    }

    set_mini_mode(on) {
        if (on) this._enter_mini_mode();
        else this._exit_mini_mode();
    }

    enter_ghost_mode(durationMs = 8000) {
        if (!this.wrapper) return;
        const timeoutMs = Number.isFinite(durationMs) ? durationMs : 8000;
        this.wrapper.classList.add('overlay-ghost');
        this._bind_ghost_escape();
        if (this._ghostModeTimeout) {
            clearTimeout(this._ghostModeTimeout);
        }
        this._ghostModeTimeout = setTimeout(() => this.exit_ghost_mode(), timeoutMs);
    }

    exit_ghost_mode() {
        if (this._ghostModeTimeout) {
            clearTimeout(this._ghostModeTimeout);
            this._ghostModeTimeout = null;
        }
        if (this.wrapper) {
            this.wrapper.classList.remove('overlay-ghost');
        }
        this._unbind_ghost_escape();
    }

    _bind_ghost_escape() {
        if (this._ghostKeyHandler) return;
        this._ghostKeyHandler = (event) => {
            if (event.key === 'Escape') {
                this.exit_ghost_mode();
            }
        };
        document.addEventListener('keydown', this._ghostKeyHandler);
    }

    _unbind_ghost_escape() {
        if (!this._ghostKeyHandler) return;
        document.removeEventListener('keydown', this._ghostKeyHandler);
        this._ghostKeyHandler = null;
    }
    refresh_sound_button_visual() {
        const btnEl = this.top_bar?.element?.querySelector?.('#sound_icon_button');
        if (btnEl) this._update_sound_button_visual(btnEl);
    }

    /** Re-render visible pick rows when tag icon / hide-inactive user_settings change (FSM calls this). */
    refresh_displayed_picks_for_settings() {
        if (this.picks_container && typeof this.picks_container._rerender_picks === 'function') {
            this.picks_container._rerender_picks();
        }
    }

    refresh_loading_animation() {
        // Loading state is now managed by model subscriptions
        // This method is kept for backward compatibility but the model handles updates
        
        if (this.sidecar) {
            this.sidecar.updateRankingsLoadingCheckbox();
        }
    }

    refresh_cached_rankings_checkbox() {
        if (this.sidecar) {
            this.sidecar.update_rankings_cache_checkbox();
        }
    }

    refresh_ud_xhr_replay_controls() {
        if (this.sidecar) {
            this.sidecar.sync_ud_xhr_replay_controls();
            this.sidecar.sync_ud_debug_ignore_legacy_collision_checkbox?.();
        }
    }

    async trigger_rankings_refresh() {
        // Clear picks and draft metadata
        if (this.fsm && this.fsm._clear_displayed_picks) {
            this.fsm._clear_displayed_picks();
        } else {
            // Fallback if FSM method not available
            if (this.picks_container) {
                this.picks_container.clear();
            }
            if (this.model) {
                this.model.set('picks', []);
            }
        }
        
        if (this.fsm && this.fsm.state_data) {
            // Set force_poll flag to bypass debouncing and trigger immediate rankings request
            this.fsm.state_data.force_poll = true;
            if (this.fsm.handle_extraction) {
                this.fsm.handle_extraction();
            }
        }
    }

    
    trigger_otc_notification(draftId, pickNumber) {
        if (!this.overlay) {
            return;
        }

        const userOtcEnabled = this.model.get('user_otc');
        if (!userOtcEnabled) {
            return;
        }

        const stateData = this.fsm?.state_data;
        if (!stateData) {
            return;
        }

        // Check if we're on Underdog active drafts page - sound is disabled on active page
        const url = window.location.href;
        const isActivePage = is_active_url(url);

        // Play sound (FSM has already verified this is a new draft/pick combo and updated last_otc_sound)
        // Skip sound on active drafts page even if user_sound_enabled is set
        const soundEnabled = this.model.get('sound_enabled');
        if (soundEnabled && !isActivePage) {
            const audio = new Audio(chrome.runtime.getURL('assets/warning.wav'));
            audio.play().catch(error => {
                console.error('[Overlay] Error playing OTC sound:', error);
            });
        } else {
            if (isActivePage) {
            } else {
            }
        }

        // Show green border (always when flag is enabled, even on active page)
        this._update_otc_border();
    }

    _update_otc_border() {
        if (!this.overlay) return;
        
        const userOtcEnabled = this.model.get('user_otc');
        if (userOtcEnabled) {
            this.overlay.classList.add('otc-active');
        } else {
            this.overlay.classList.remove('otc-active');
        }
    }
    async _persist_ui_state() {
        const site = detect_site_key();
        const st = {
            mini: !!this.is_mini,
            top: parseInt(this.wrapper?.style.top) || 0,
            left: parseInt(this.wrapper?.style.left) || 0
        };
        if (this._preMini && this.is_mini) {
            st.width = this._preMini.width;
            st.height = this._preMini.height;
        } else if (!this.is_mini) {
            const { width, height } = this._clamp_stored_dimensions(
                parseInt(this.overlay.style.width, 10) || this.middle_width,
                parseInt(this.overlay.style.height, 10) || 500
            );
            st.width = width;
            st.height = height;
        }
        await set_overlay_for_site(site, { overlayState: st });
    }

    _add_doc_listeners(moveFn, upFn) {
        this._onMove = moveFn;
        this._onUp = upFn;
        document.addEventListener('mousemove', this._onMove, true);
        document.addEventListener('mouseup', this._onUp, { once: true, capture: true });
    }

    _remove_doc_listeners() {
        if (this._onMove) document.removeEventListener('mousemove', this._onMove, true);
        this._onMove = null;
        this._onUp = null;
    }

    _schedule_geometry_apply(pending) {
        this._dragResizePending = pending;
        if (this._dragResizeRafId != null) return;
        this._dragResizeRafId = requestAnimationFrame(() => {
            this._dragResizeRafId = null;
            const p = this._dragResizePending;
            if (p) {
                this._apply_geometry(p, { persist: false, allowMini: this.is_mini });
                this.toggle_bar_elements(this.overlay.offsetWidth);
            }
        });
    }

    _cancel_pending_geometry_apply() {
        if (this._dragResizeRafId != null) {
            cancelAnimationFrame(this._dragResizeRafId);
            this._dragResizeRafId = null;
        }
        this._dragResizePending = null;
    }

    _clamp_to_view(top, left, width, height) {
        const maxTop = Math.max(0, window.innerHeight - (this.top_bar?.element?.offsetHeight || 60));
        const maxLeft = Math.max(0, window.innerWidth - width);
        return {
            top: Math.min(Math.max(0, top), maxTop),
            left: Math.min(Math.max(0, left), maxLeft)
        };
    }

    async _apply_geometry(next = {}, opts = {}) {
        const { persist = true, clamp = true, allowMini = false } = opts;
        if (!this.wrapper || !this.overlay) return;

        const minWidth = this._get_effective_min_width(allowMini);
        const minHeight = this._get_effective_min_height(allowMini);

        const curWidth = parseInt(this.overlay.style.width, 10);
        const curHeight = parseInt(this.overlay.style.height, 10);
        const curTop = parseInt(this.wrapper.style.top, 10);
        const curLeft = parseInt(this.wrapper.style.left, 10);

        const width = Math.max(
            minWidth,
            Number.isFinite(next.width) ? next.width : (Number.isFinite(curWidth) ? curWidth : (this.overlay.offsetWidth || this.middle_width))
        );
        const height = Math.max(
            minHeight,
            Number.isFinite(next.height) ? next.height : (Number.isFinite(curHeight) ? curHeight : (this.overlay.offsetHeight || 500))
        );

        const effW = this._effective_wrapper_width(width);
        const unclampedTop = Number.isFinite(next.top) ? next.top : (Number.isFinite(curTop) ? curTop : 0);
        const unclampedLeft = Number.isFinite(next.left) ? next.left : (Number.isFinite(curLeft) ? curLeft : 0);
        const { top, left } = clamp ? this._clamp_to_view(unclampedTop, unclampedLeft, effW, height) : { top: unclampedTop, left: unclampedLeft };

        this.overlay.style.width = `${width}px`;
        this.overlay.style.height = `${height}px`;
        this.wrapper.style.width = `${effW}px`;
        this.wrapper.style.height = `${height}px`;
        this.wrapper.style.top = `${top}px`;
        this.wrapper.style.left = `${left}px`;

        if (persist) {
            if (this.fsm?.background_communication_broken) {
                console.error('[Overlay] Failed to persist overlay geometry: background communication broken');
                return { width, height, top, left };
            }
            try {
                await this.save_state();
            } catch (err) {
                console.error('[Overlay] Failed to persist overlay geometry', err);
                if (this.fsm?.is_background_communication_broken_error?.(err)) {
                    this.fsm.handle_background_communication_broken?.('overlay:persist-geometry', err);
                }
            }
        }

        return { width, height, top, left };
    }

    async initialize() {
        if (this.is_initialized) return;
        const existingWrapper = document.getElementById('overlayWrapper');

        if (existingWrapper) {
            this.wrapper = existingWrapper;
            this.overlay = existingWrapper.querySelector('#resizableContainer');
            this.is_initialized = true;
            this.rehydrate_existing_overlay();
            // Ensure bubble state matches effective notification (auth > warning).
            const eff = this.fsm?.get_effective_notification?.();
            if (eff) {
                this.display_notification(eff.message ?? '', eff.type ?? 'auth_error', { closable: eff.closable, layer: eff.layer });
            } else {
                this.display_notification('', 'auth_error', { closable: false, layer: 'none' });
            }
            this._sync_legup_lite_mode_chrome();
            this._flush_pending_exposure_toast();
            return;
        }

        this.create_overlay_structure();
        this.setup_event_listeners();
        await this.apply_initial_position();
        document.body.appendChild(this.wrapper);
        const ghost = document.getElementById('notificationBubble');
        if (ghost && !ghost.closest('#overlayWrapper')) ghost.remove();
        const ghostExposureToast = document.getElementById('exposureSavedToast');
        if (ghostExposureToast && !ghostExposureToast.closest('#overlayWrapper')) ghostExposureToast.remove();
        this.is_initialized = true;
        this.sync_streamer_overlay_visibility();
        this._initial_toggle_after_mount();
        this._update_otc_border();
        this.sync_mini_mode_for_page();
        this._flush_pending_exposure_toast();
    }

    rehydrate_existing_overlay() {
        if (!this.top_bar || !this.top_bar.element) {
            this.top_bar = new Top_Bar(this.fsm, this, this.model);
            const existingTopBar = this.overlay.querySelector('#resizeTopBar');
            if (existingTopBar) {
                existingTopBar.replaceWith(this.top_bar.element);
            } else {
                this.overlay.insertBefore(this.top_bar.element, this.overlay.firstChild);
            }
        } else {
            this.top_bar.element = this.overlay.querySelector('#resizeTopBar') || null;
        }

        // Set recommended_picks_container reference
        this.recommended_picks_container = this.overlay.querySelector('#recommendedPicksContainer') || null;

        // Reinitialize picks container if needed
        if (!this.picks_container && this.recommended_picks_container) {
            const site_type = this._detect_site_type();
            this.queue_click_handler = new QueueClickHandler(site_type);
            this.picks_container = new Picks_Container(this.recommended_picks_container, site_type, this.model, this, this.queue_click_handler);
        }

        const need_sidecar = this._should_show_sidecar();
        const existingSidecarEl = this.wrapper.querySelector('#sidecar');

        this.wrapper.classList.remove('overlay-ghost');

        if (need_sidecar) {
            if (existingSidecarEl) {
                this.sidecar = Sidecar.fromExisting(existingSidecarEl, this, { width: this.sidecar_width });
            } else {
                this.sidecar = new Sidecar(this, { width: this.sidecar_width });
                this.sidecar.mount(this.wrapper);
            }
        } else {
            if (this.sidecar) {
                this.sidecar.destroy();
            }
            if (existingSidecarEl) {
                existingSidecarEl.remove();
            }
            this.sidecar = null;
            if (this.overlay && this.wrapper) {
                const width = this.overlay.offsetWidth || this.middle_width;
                this.wrapper.style.width = `${width}px`;
            }
        }

        this.refresh_cached_rankings_checkbox();
        this.refresh_ud_xhr_replay_controls();
        this.sync_streamer_overlay_visibility();

        this.is_mini = this.overlay.classList.contains('mini');

        this.handles = {};
        if (!this.is_mini) {
            this.overlay.querySelectorAll('.resize_handle').forEach(h => {
                const m = h.className.match(/resize_handle_([A-Z]+)/);
                const key = m && m[1];
                if (key) this.handles[key] = h;
            });
            if (!Object.keys(this.handles).length) {
                this._enable_resize_handles();
            }
        } else {
            this._disable_resize_handles();
        }

        this.notification_bubble = this.wrapper.querySelector('#notificationBubble') || this.create_notification_bubble();
        this.exposure_saved_toast = this.wrapper.querySelector('#exposureSavedToast') || this.create_exposure_saved_toast();
        if (this.exposure_saved_toast && this.exposure_saved_toast.parentElement !== this.wrapper) {
            this.wrapper.appendChild(this.exposure_saved_toast);
        }

        if (!this.bottom_bar || !this.bottom_bar.element) {
            this.create_bottom_bar();
        } else {
            this.bottom_bar.element = this.overlay.querySelector('#bottomBar') || null;
            const bars = this.overlay.querySelectorAll('#bottomBar');
            if (bars.length > 1) {
                bars.forEach((el, i) => { if (i > 0) el.remove(); });
                this.bottom_bar.element = this.overlay.querySelector('#bottomBar');
            }
        }

        this.rebind_event_listeners();
        this.ensure_overlay_in_viewport();
        this._initial_toggle_after_mount();
        this._update_otc_border();
        this.sync_mini_mode_for_page();
    }

    rebind_event_listeners() {
        this._unbind_global_listeners();
        this._bind_global_listeners();

        const legup_button = this.top_bar?.element?.querySelector?.('#legup_icon_button');
        const sound_button = this.top_bar?.element?.querySelector?.('#sound_icon_button');

        if (legup_button) this._bind_legup_button(legup_button);
        // Sound clicks are handled only by Sound_Button (overlay_top_bar.js). Rebind must not add a second mouseup.
        if (sound_button) {
            this._update_sound_button_visual(sound_button);
            this.refresh_loading_animation();
        }

        if (this.notification_bubble) {
            this.notification_bubble.style.pointerEvents = 'none';
            // Bubble container is intentionally click-through; keep the close button interactive.
            const closeBtn = this.notification_bubble.querySelector('#notificationCloseButton');
            if (closeBtn) closeBtn.style.pointerEvents = 'auto';
            // Rehydrated DOM may already have a close button with no/stale listeners — (re)bind every time.
            this._ensure_notification_close_button(this.notification_bubble);
        }
    }

    _get_legup_anchor_rect() {
        const btn = this.top_bar?.element?.querySelector?.('#legup_icon_button');
        if (!btn) return null;
        return btn.getBoundingClientRect();
    }

    _get_legup_button_icon_url() {
        try {
            if (this._is_legup_lite_mode()) {
                return chrome.runtime.getURL('assets/kickstand_favicon_145x150.png');
            }

            const url = window.location.href;
            let iconUrl;

            const draft_test_page = document.getElementById('draftTestPage');
            if (draft_test_page) {
                const draft_state_element = document.getElementById('draftStateJsonMirror');
                if (draft_state_element && draft_state_element.textContent) {
                    try {
                        const draft_state = JSON.parse(draft_state_element.textContent);
                        const site_name = draft_state.draft?.site_name;
                        if (site_name) {
                            const site_name_lower = String(site_name).toLowerCase();
                            if (site_name_lower.includes('underdog')) {
                                iconUrl = chrome.runtime.getURL('assets/Sidekick_Favicon-Transparent.png');
                            } else if (site_name_lower.includes('draftkings') || site_name_lower.includes('draft_kings')) {
                                iconUrl = chrome.runtime.getURL('assets/Sidekick_Favicon-DK.png');
                            }
                        }
                    } catch (error) {
                    }
                }
            }

            if (!iconUrl) {
                if (is_underdog_url(url)) {
                    iconUrl = chrome.runtime.getURL('assets/Sidekick_Favicon-Transparent.png');
                } else if (is_draft_kings_url(url)) {
                    iconUrl = chrome.runtime.getURL('assets/Sidekick_Favicon-DK.png');
                }
            }

            return iconUrl || chrome.runtime.getURL('assets/Sidekick_Favicon-Black2x-100.png');
        } catch {
            // chrome.runtime.getURL throws after extension context invalidation
            return null;
        }
    }

    _is_legup_lite_mode() {
        if (this.fsm?.is_legup_lite_mode) {
            return this.fsm.is_legup_lite_mode();
        }
        return is_legup_lite_mode(this.fsm?.session_data, this.fsm?.user_settings);
    }

    _get_effective_min_width(allowMini = false) {
        if (allowMini) {
            return this._get_topbar_height();
        }
        if (this._is_legup_lite_mode()) {
            return this.middle_width;
        }
        return this.min_width;
    }

    _get_effective_min_height(allowMini = false) {
        if (allowMini) {
            return this._get_topbar_height();
        }
        return 200;
    }

    _clamp_stored_dimensions(width, height) {
        const minW = this._get_effective_min_width();
        const minH = this._get_effective_min_height();
        return {
            width: Math.max(minW, Number.isFinite(width) ? width : minW),
            height: Math.max(minH, Number.isFinite(height) ? height : minH),
        };
    }

    _is_on_draft_page() {
        const url = window.location.href;
        if (is_completed_url(url)) return false;
        return is_draft_url(url) || is_test_draft_url(url);
    }

    _ensure_legal_dimensions() {
        if (!this.overlay || this.is_mini) return;
        const minW = this._get_effective_min_width();
        const minH = this._get_effective_min_height();
        const curW = parseInt(this.overlay.style.width, 10) || this.overlay.offsetWidth || 0;
        const curH = parseInt(this.overlay.style.height, 10) || this.overlay.offsetHeight || 0;
        if (curW < minW || curH < minH) {
            this._apply_geometry({
                width: Math.max(minW, curW),
                height: Math.max(minH, curH),
            }, { persist: true }).catch((err) => {
                console.error('[Overlay] Failed to enforce legal dimensions', err);
            });
        }
    }

    sync_mini_mode_for_page() {
        if (!this.overlay || !this.is_initialized) return;
        const wantMini = !this._is_on_draft_page();
        if (wantMini !== this.is_mini) {
            this.set_mini_mode(wantMini);
        } else if (!wantMini) {
            this._ensure_legal_dimensions();
        }
        this.sync_sidecar_visibility();
    }

    async _enforce_lite_mode_min_width() {
        if (!this._is_legup_lite_mode() || !this.overlay || this.is_mini) {
            return;
        }
        const effectiveMin = this._get_effective_min_width();
        const curWidth = parseInt(this.overlay.style.width, 10) || this.overlay.offsetWidth || 0;
        if (curWidth < effectiveMin) {
            await this._apply_geometry({ width: effectiveMin }, { persist: true });
            this.toggle_bar_elements(this.overlay.offsetWidth);
        }
    }

    _sync_legup_lite_mode_chrome() {
        if (!this.overlay) return;
        this.overlay.classList.toggle('legup-lite-mode', this._is_legup_lite_mode());
    }

    refresh_legup_button_icon() {
        this._sync_legup_lite_mode_chrome();
        this._sync_legup_button_icon();
        this.bottom_bar?._update_sidekick_controls_visibility?.();
        if (this._is_legup_lite_mode()) {
            this.clear_advancement_structure();
        }
        this.update_top_bar_from_state({});
        this.picks_container?.refresh_position_colors?.();
        this._enforce_lite_mode_min_width().catch((err) => {
            console.error('[Overlay] Failed to enforce lite mode min width', err);
        });
        this.sidecar?.sync_force_lite_mode_checkbox?.();
    }

    _bind_legup_button(btnEl) {
        btnEl.onmouseup = null;
        btnEl.oncontextmenu = null;

        btnEl.addEventListener('mouseup', (e) => {
            if (!this.drag_occurred) {
                // no-op click behavior by default; login handling happens in display_notification()
            }
        });
        btnEl.addEventListener('contextmenu', (e) => e.preventDefault());

        // Ensure correct icon for current site
        const img = btnEl.querySelector('img') || document.createElement('img');
        if (!btnEl.contains(img)) btnEl.appendChild(img);

        const updateIcon = () => {
            this._sync_legup_button_icon();
        };

        updateIcon();

        const draft_test_page = document.getElementById('draftTestPage');
        if (draft_test_page) {
            const getDraftStateElement = () => {
                return document.getElementById('draftStateJsonMirror');
            };

            const setupEventListener = () => {
                const draft_state_element = getDraftStateElement();
                if (draft_state_element) {
                    draft_state_element.addEventListener('draft:minimalStateChanged', updateIcon);
                    return true;
                }
                return false;
            };

            if (!setupEventListener()) {
                let retryCount = 0;
                const maxRetries = 10;
                const retryInterval = 100; // 100ms

                const retryTimer = setInterval(() => {
                    if (setupEventListener() || retryCount >= maxRetries) {
                        clearInterval(retryTimer);
                    }
                    retryCount++;
                }, retryInterval);
            }
        }
    }

    _update_sound_button_visual(btnEl) {
        const img = btnEl.querySelector('img') || document.createElement('img');
        if (!btnEl.contains(img)) btnEl.appendChild(img);
        const on = this.model?.get('sound_enabled') ?? !!this.fsm.user_settings.user_sound_enabled;
        const icon_name = on ? 'sound_loud' : 'sound_mute';
        img.src = chrome.runtime.getURL(`assets/${icon_name}.png`);
        btnEl.style.backgroundColor = on ? '#53d337' : '';
    }

    create_overlay_structure() {
        this.wrapper = document.createElement('div');
        this.wrapper.id = 'overlayWrapper';

        this.overlay = document.createElement('div');
        this.overlay.id = 'resizableContainer';

        this.top_bar = new Top_Bar(this.fsm, this, this.model);
        this.overlay.appendChild(this.top_bar.element);

        this.recommended_picks_container = document.createElement('div');
        this.recommended_picks_container.id = 'recommendedPicksContainer';
        this.overlay.appendChild(this.recommended_picks_container);
        
        // Initialize picks container
        const site_type = this._detect_site_type();
        this.queue_click_handler = new QueueClickHandler(site_type);
        this.picks_container = new Picks_Container(this.recommended_picks_container, site_type, this.model, this, this.queue_click_handler);
        this.refresh_loading_animation();

        this.create_bottom_bar();
        this.create_resize_handles();

        this.wrapper.appendChild(this.overlay);

        const need_sidecar = this._should_show_sidecar();
        if (need_sidecar) {
            this.sidecar = new Sidecar(this, { width: this.sidecar_width });
            this.sidecar.mount(this.wrapper);
            this.refresh_cached_rankings_checkbox();
            this.refresh_ud_xhr_replay_controls();
        }

        this.notification_bubble = this.create_notification_bubble();
        this.wrapper.appendChild(this.notification_bubble);
        this.exposure_saved_toast = this.create_exposure_saved_toast();
        this.wrapper.appendChild(this.exposure_saved_toast);
    }

    close_sidecar() {
        if (!this.sidecar) return;
        this.sidecar.destroy();
        this.sidecar = null;
        if (this.overlay && this.wrapper) {
            const width = this.overlay.offsetWidth || this.middle_width;
            this.wrapper.style.width = `${this._effective_wrapper_width(width)}px`;
        }
        this.ensure_overlay_in_viewport();
    }

    create_resize_handles() {
        const handles = {
            'SE': 'se-resize',
            'SW': 'sw-resize',
            'NE': 'ne-resize',
            'NW': 'nw-resize',
            'N': 'n-resize',
            'S': 's-resize',
            'E': 'e-resize',
            'W': 'w-resize'
        };

        for (const [key, cursor] of Object.entries(handles)) {
            const handle = document.createElement('div');
            handle.className = `resize_handle resize_handle_${key}`;
            handle.dataset.handle = key;
            this.overlay.appendChild(handle);
            this.handles[key] = handle;
        }
    }

    create_notification_bubble() {
        const existingInWrapper = this.wrapper?.querySelector?.('#notificationBubble');
        if (existingInWrapper) {
            this._ensure_notification_close_button(existingInWrapper);
            return existingInWrapper;
        }

        // if there’s a orphan bubble in the document (from older builds),
        // adopt it into the wrapper so it is torn down with the overlay
        const orphan = document.getElementById('notificationBubble');
        if (orphan && orphan.parentElement !== this.wrapper) {
            this.wrapper.appendChild(orphan);
            this._ensure_notification_close_button(orphan);
            return orphan;
        }

        const bubble = document.createElement('div');
        bubble.id = 'notificationBubble';
        bubble.className = 'notification_bubble';

        this._ensure_notification_close_button(bubble);

        const text = document.createElement('span');
        text.id = 'notificationText';
        text.className = 'notification_text';
        bubble.appendChild(text);

        const tail = document.createElement('div');
        tail.className = 'notification_bubble_tail';
        bubble.appendChild(tail);

        this.wrapper.appendChild(bubble);
        return bubble;
    }

    create_exposure_saved_toast() {
        const existing = this.wrapper?.querySelector?.('#exposureSavedToast');
        if (existing) {
            return existing;
        }
        const orphan = document.getElementById('exposureSavedToast');
        if (orphan && orphan.parentElement !== this.wrapper) {
            return orphan;
        }
        const el = document.createElement('div');
        el.id = 'exposureSavedToast';
        el.className = 'exposure_saved_toast';
        el.setAttribute('role', 'status');
        el.setAttribute('aria-live', 'polite');
        return el;
    }

    // Short-lived toast near the top bar; does not change the LegUp button or auth notification bubble.
    // If the overlay wrapper is not mounted yet, the message is saved and shown from initialize().
    show_exposure_saved_toast(message, durationMs = 5000) {
        if (!message || typeof message !== 'string') {
            return;
        }
        const duration = Number.isFinite(durationMs) && durationMs >= 0 ? durationMs : 5000;
        const pending = { message, durationMs: duration };
        this._pending_exposure_toast = pending;
        if (this.fsm && this.fsm.state_data) {
            this.fsm.state_data.pending_exposure_toast = pending;
        }
        if (!this.wrapper) {
            return;
        }
        this._present_exposure_saved_toast(message, duration);
    }

    _clear_pending_exposure_toast() {
        this._pending_exposure_toast = null;
        if (this.fsm && this.fsm.state_data) {
            delete this.fsm.state_data.pending_exposure_toast;
        }
    }

    _flush_pending_exposure_toast() {
        const pending = this._pending_exposure_toast
            || (this.fsm && this.fsm.state_data && this.fsm.state_data.pending_exposure_toast)
            || null;
        if (!pending || !pending.message || !this.wrapper) {
            return;
        }
        this._pending_exposure_toast = pending;
        this._present_exposure_saved_toast(pending.message, pending.durationMs);
    }

    _present_exposure_saved_toast(message, durationMs) {
        if (!this.exposure_saved_toast || !this.exposure_saved_toast.isConnected) {
            this.exposure_saved_toast = this.wrapper.querySelector('#exposureSavedToast') || this.create_exposure_saved_toast();
            if (this.exposure_saved_toast.parentElement !== this.wrapper) {
                this.wrapper.appendChild(this.exposure_saved_toast);
            }
        }
        const el = this.exposure_saved_toast;
        if (this._exposure_toast_fade_timer) {
            clearTimeout(this._exposure_toast_fade_timer);
            this._exposure_toast_fade_timer = null;
        }
        if (this._exposure_toast_remove_timer) {
            clearTimeout(this._exposure_toast_remove_timer);
            this._exposure_toast_remove_timer = null;
        }

        const duration = Number.isFinite(durationMs) && durationMs >= 0 ? durationMs : 5000;
        el.classList.remove('is-hiding');
        el.textContent = message;
        el.classList.add('is-visible');
        this._clear_pending_exposure_toast();

        const fadeLeadMs = Math.max(0, duration - 500);
        this._exposure_toast_fade_timer = setTimeout(() => {
            el.classList.add('is-hiding');
            this._exposure_toast_remove_timer = setTimeout(() => {
                el.classList.remove('is-visible', 'is-hiding');
                el.textContent = '';
                this._exposure_toast_remove_timer = null;
            }, 500);
            this._exposure_toast_fade_timer = null;
        }, fadeLeadMs);
    }

    // Clears pending toast intent and hides the element (e.g. cancelled / failed merge).
    dismiss_exposure_saved_toast() {
        this._clear_pending_exposure_toast();
        if (this._exposure_toast_fade_timer) {
            clearTimeout(this._exposure_toast_fade_timer);
            this._exposure_toast_fade_timer = null;
        }
        if (this._exposure_toast_remove_timer) {
            clearTimeout(this._exposure_toast_remove_timer);
            this._exposure_toast_remove_timer = null;
        }
        const el = this.exposure_saved_toast;
        if (!el || !el.isConnected) {
            return;
        }
        el.classList.remove('is-visible', 'is-hiding');
        el.textContent = '';
    }

    _ensure_notification_close_button(bubble) {
        if (!bubble || !(bubble instanceof HTMLElement)) return;

        let close = bubble.querySelector('#notificationCloseButton');
        if (!close) {
            close = document.createElement('button');
            close.type = 'button';
            close.id = 'notificationCloseButton';
            close.className = 'notification_close_button';
            close.textContent = 'x';
            close.setAttribute('aria-label', 'Clear notification');
            bubble.appendChild(close);
        }

        // Use onclick so rehydrate / rebind never leaves a stale handler on a reused DOM node.
        close.onclick = (e) => {
            e.preventDefault();
            e.stopPropagation();

            const eff = typeof this.fsm?.get_effective_notification === 'function'
                ? this.fsm.get_effective_notification()
                : null;

            // For non-fatal warnings, closing should suppress this kind of warning going forward.
            if (eff?.layer === 'warning') {
                this.suppress_nonfatal_warning_notifications_from_ui();
                return;
            }

            if (typeof this.fsm?.dismiss_notification_bubble === 'function') {
                this.fsm.dismiss_notification_bubble();
            } else {
                this.display_notification('', 'auth_error', { closable: false, layer: 'none' });
            }
        };
    }

    suppress_nonfatal_warning_notifications_from_ui() {
        if (!this.fsm) return;
        if (!this.fsm.user_settings) this.fsm.user_settings = {};
        this.fsm.user_settings.suppress_nonfatal_warning_notifications = true;

        // Clear current non-urgent warning immediately.
        if (typeof this.fsm.clear_warning_notification === 'function') {
            this.fsm.clear_warning_notification(null);
        } else if (typeof this.fsm.dismiss_notification_bubble === 'function') {
            this.fsm.dismiss_notification_bubble();
        } else {
            this.display_notification('', 'auth_error', { closable: false, layer: 'none' });
        }

        // Persist user setting in background local storage (user override > remote defaults > code defaults).
        if (this.fsm?.bg_port && this.fsm.bg_connected) {
            this.fsm.send_port_request('SET_SETTINGS', {
                scope: 'content_script',
                settings: { suppress_nonfatal_warning_notifications: true }
            }).catch((err) => {
                console.error('[overlay_manager] set_settings suppress_nonfatal_warning_notifications=true failed', err);
            });
        }
    }

    async apply_initial_position() {
        const site = detect_site_key();
        const siteOverlay = await get_overlay_for_site(site);
        const st = siteOverlay.overlayState || {};


        const stored = this._clamp_stored_dimensions(
            Number.isFinite(+st.width) ? +st.width : this.middle_width,
            Number.isFinite(+st.height) ? +st.height : 500
        );
        const width = stored.width;
        const height = stored.height;

        const hasTop = Object.prototype.hasOwnProperty.call(st, 'top');
        const hasLeft = Object.prototype.hasOwnProperty.call(st, 'left');

        const top = (hasTop && Number.isFinite(+st.top))
            ? +st.top
            : (window.innerHeight - height); // default bottom
        const left = (hasLeft && Number.isFinite(+st.left))
            ? +st.left
            : 0;                             // default left

        const mini = !!st.mini;

        await this._apply_geometry({ width, height, top, left }, { persist: false });

        if (mini) this.set_mini_mode(true);
    }

    setup_event_listeners() {
        this._unbind_global_listeners();
        this._bind_global_listeners();
    }

    _bind_global_listeners() {
        if (this.top_bar?.element) {
            if (!this._onTopBarMouseDown) {
                this._onTopBarMouseDown = (e) => this.handle_drag_start(e);
            }
            // Use property assignment to avoid accumulating addEventListener handlers on rehydrate.
            this.top_bar.element.onmousedown = this._onTopBarMouseDown;
        }

        if (!this.is_mini) {
            for (const [key, handle] of Object.entries(this.handles || {})) {
                if (!handle) continue;
                // Assign per-handle property so repeated binds don't accumulate.
                handle.onmousedown = (e) => this.handle_resize_start(e, key);
            }
        }

        if (!this._onWindowResize) {
            this._onWindowResize = () => this.handle_window_resize();
        }
        window.addEventListener('resize', this._onWindowResize);
    }

    _unbind_global_listeners() {
        if (this._onWindowResize) {
            try { window.removeEventListener('resize', this._onWindowResize); } catch {}
        }
        if (this.top_bar?.element && this._onTopBarMouseDown) {
            this.top_bar.element.onmousedown = null;
        }
        if (this.handles) {
            for (const handle of Object.values(this.handles)) {
                if (!handle) continue;
                handle.onmousedown = null;
            }
        }
    }

    handle_drag_start(e) {
        this.drag_occurred = false;
        if (e.button !== 0) return;
        e.preventDefault();

        const startOffsetX = e.clientX - this.wrapper.offsetLeft;
        const startOffsetY = e.clientY - this.wrapper.offsetTop;
        const wrapperW = this.wrapper.offsetWidth;
        const wrapperH = this.wrapper.offsetHeight;

        const onMove = (evt) => {
            evt.preventDefault();
            const newLeft = evt.clientX - startOffsetX;
            const newTop = evt.clientY - startOffsetY;
            const { top, left } = this._clamp_to_view(newTop, newLeft, wrapperW, wrapperH);
            this.drag_occurred = true;
            this._schedule_geometry_apply({ top, left });
        };

        const onUp = () => {
            this._remove_doc_listeners();
            this._cancel_pending_geometry_apply();
            this._apply_geometry({}, { persist: true, allowMini: this.is_mini }).catch(err => console.error('[Overlay] Failed to persist drag position', err));
        };

        this._add_doc_listeners(onMove, onUp);
    }

    handle_resize_start(e, handle) {
        if (this.is_mini) return;
        if (e.button !== 0) return;
        e.preventDefault();
        e.stopPropagation();

        const startX = e.clientX;
        const startY = e.clientY;
        const startWidth = this.overlay.offsetWidth;
        const startHeight = this.overlay.offsetHeight;
        const startLeft = this.wrapper.offsetLeft;
        const startTop = this.wrapper.offsetTop;

        const computeResize = (evt) => {
            const dx = evt.clientX - startX;
            const dy = evt.clientY - startY;
            let w = startWidth, h = startHeight, L = startLeft, T = startTop;
            switch (handle) {
                case 'SE': w = startWidth + dx; h = startHeight + dy; break;
                case 'SW': w = startWidth - dx; L = startLeft + dx; h = startHeight + dy; break;
                case 'NE': w = startWidth + dx; h = startHeight - dy; T = startTop + dy; break;
                case 'NW': w = startWidth - dx; L = startLeft + dx; h = startHeight - dy; T = startTop + dy; break;
                case 'N': h = startHeight - dy; T = startTop + dy; break;
                case 'S': h = startHeight + dy; break;
                case 'E': w = startWidth + dx; break;
                case 'W': w = startWidth - dx; L = startLeft + dx; break;
            }
            w = Math.max(this._get_effective_min_width(), w);
            h = Math.max(this._get_effective_min_height(), h);
            const effW = this._effective_wrapper_width(w);
            const { top, left } = this._clamp_to_view(T, L, effW, h);
            return { width: w, height: h, top, left };
        };

        const onMove = (evt) => {
            evt.preventDefault();
            this._schedule_geometry_apply(computeResize(evt));
        };

        const onUp = () => {
            this._remove_doc_listeners();
            this._cancel_pending_geometry_apply();
            this._apply_geometry({}, { persist: true }).catch(err => console.error('[Overlay] Failed to persist resize', err));
            this.toggle_bar_elements(this.overlay.offsetWidth);
        };

        this._add_doc_listeners(onMove, onUp);
    }

    handle_window_resize() {
        this.ensure_overlay_in_viewport();
        this.toggle_bar_elements(this.overlay.offsetWidth);
    }

    ensure_overlay_in_viewport() {
        const width = this.overlay.offsetWidth;
        const height = this.overlay.offsetHeight;
        const effW = this._effective_wrapper_width(width);

        const currentTop = parseInt(this.wrapper.style.top || 0, 10);
        const currentLeft = parseInt(this.wrapper.style.left || 0, 10);

        this._apply_geometry({
            width,
            height,
            top: currentTop,
            left: currentLeft
        }, { allowMini: this.is_mini }).catch(err => console.error('[Overlay] Failed to clamp overlay into view', err));
    }

    // Width-based responsive UI toggles (safe if some elements are absent)
    async toggle_bar_elements(width) {
        const resolvedWidth = Number.isFinite(width) && width > 0 ? width : this._get_layout_width();
        let env_tag_container = document.getElementById('env_tag_container');

        // If env is one we show and the tag hasn't been created yet, create it now.
        const needEnvTag = ['dev', 'local'].includes(this.fsm.state_data.env_value);
        if (needEnvTag && !env_tag_container) {
            await this.bottom_bar.create_environment_tag();
            env_tag_container = document.getElementById('env_tag_container');
        }

        this._sync_top_bar_message_box_visibility(resolvedWidth);

        if (env_tag_container) {
            env_tag_container.style.display = resolvedWidth >= this.middle_width - 2 ? 'inline-block' : 'none';
        }

        // Refresh top bar message to show/hide advancement text based on width
        // This ensures advancement text appears/disappears when resizing
        if (this.update_top_bar_from_state) {
            this.update_top_bar_from_state({});
        }
    }

    create_bottom_bar() {
        this.overlay.querySelectorAll('#bottomBar').forEach((el, i) => {
            el.remove();
        });
        this.bottom_bar = new Bottom_Bar(this.fsm, this.model);
        this.overlay.appendChild(this.bottom_bar.element);
    }

    _compose_top_bar_message({ advancement_text = null, request_identifier = null, overlay_width = null } = {}) {
        // Check if we're on a draft page - if no draft_id, return empty message
        const unsupported = this.fsm?.state_data?.unsupported_contest;
        const url_draft_id =
            typeof get_underdog_draft_id_from_url === 'function'
                ? get_underdog_draft_id_from_url(window.location.href)
                : null;
        const draft_id = this.fsm?.state_data?.rankings_needed?.draft_id ??
            this.fsm?.state_data?.current_draft_context?.draft_id ??
            this.fsm?.state_data?.currently_displayed?.draft_id ??
            unsupported?.draft_id ??
            url_draft_id ??
            null;
        
        if (!draft_id) {
            // Not on a draft page - return empty message
            return { main_text: '', hover_text: '' };
        }

        // Unsupported Underdog contests never get rankings; show a clear status instead of a blank bar
        if (
            unsupported?.draft_id != null &&
            String(unsupported.draft_id) === String(draft_id)
        ) {
            return {
                main_text: 'Contest not supported\nCheck the LegUp Discord for more info.',
                hover_text: ''
            };
        }

        if (this._is_legup_lite_mode()) {
            return this._compose_legup_lite_mode_top_bar_message(overlay_width);
        }

        // Last updated = pick count we have rankings for; current pick = draft's current state.
        const displayed_pick = this.fsm?.state_data?.currently_displayed?.num_picks ?? null;
        const current_pick = this.fsm?.state_data?.rankings_needed?.num_picks ??
            this.fsm?.state_data?.current_draft_context?.num_picks ?? null;

        let main_text = '';
        if (displayed_pick !== null && current_pick !== null) {
            if (displayed_pick !== current_pick) {
                const raw_delta = current_pick - displayed_pick;
                // Clamp: negative deltas happen when displayed metadata briefly lags live extraction
                // (e.g. stale cache row vs fresh draft state); treat as "behind" wording, not negative picks.
                const n = raw_delta > 0 ? raw_delta : 0;
                if (n > 0) {
                    main_text = `Rankings updated ${n} pick${n === 1 ? '' : 's'} ago`;
                } else {
                    main_text = 'Rankings are catching up to live draft';
                }
            } else {
                main_text = 'Rankings are up to date';
            }
        }

        const advText =
            advancement_text != null
                ? advancement_text
                : this._resolve_advancement_display_text();
        const show_advancement = advText && (overlay_width === null || overlay_width >= this.max_width);

        if (displayed_pick !== null && current_pick !== null && main_text) {
            const pick_suffix = `(Pick ${displayed_pick})`;
            main_text += show_advancement ? ` ${pick_suffix}` : `\n${pick_suffix}`;
        }

        // Add advancement text on a new line (only if width >= max_width)
        if (show_advancement) {
            main_text += main_text ? `\n${advText}` : advText;
        }

        // Hover text should be minimal now (no advancement text)
        const lines = [];
        if (request_identifier) lines.push(request_identifier);
        const hover_text = lines.join('\n');

        return { main_text, hover_text };
    }

    update_top_bar_from_state(opts = {}) {
        const overlay_width = this._get_layout_width();
        const message = this._compose_top_bar_message({
            ...opts,
            overlay_width: overlay_width
        });
        this.model.set('top_bar_message', message);
        this._sync_top_bar_message_box_visibility(overlay_width);
    }

    async update_recommended_picks(picks, request_identifier = null, advancement_structure = null) {
        const season_stage = this.fsm?.state_data?.season_stage || 'regular_season';
        if (!this.picks_container) {
            const site_type = this._detect_site_type();
            this.queue_click_handler = new QueueClickHandler(site_type);
            this.picks_container = new Picks_Container(this.recommended_picks_container, site_type, this.model, this, this.queue_click_handler);
            this.refresh_loading_animation();
        } else {
            const site_type = this._detect_site_type();
            if (this.picks_container.site_type !== site_type) {
                this.picks_container.set_site_type(site_type);
                if (this.queue_click_handler) {
                    this.queue_click_handler.site_type = site_type;
                }
            }
        }

        if (this.picks_container?.set_season_stage) {
            this.picks_container.set_season_stage(season_stage);
        }

        // Check queue size and auto-click queue button if needed (for Underdog active pages)
        try {
            const url = window.location.href;
            if (is_active_url(url)) {
                const queueButton =
                    typeof find_underdog_active_queue_toggle_button === 'function'
                        ? find_underdog_active_queue_toggle_button()
                        : null;

                if (!queueButton) {
                } else {
                    const queueSizeElement = queueButton.querySelector(
                        'div[class^="styles__counterBubble__"][class*="queueCounter"]'
                    );
                    const queueSize = queueSizeElement ? parseInt(queueSizeElement.textContent.trim(), 10) : 0;
                    const trackedLen = this.fsm.state_data.queue?.players?.length ?? 0;
                    const mismatch = queueSize !== trackedLen;
                    const flag = this.fsm.state_data.queue_size_changed;
                    const rosterShowing = !queueButton.classList.contains('styles__selected__');

                    if (rosterShowing && (flag || mismatch)) {
                        if (this.queue_click_handler) {
                            this.queue_click_handler.ensureUnderdogQueueVisible();
                            this.fsm.state_data.queue_size_changed = false;
                        }
                    }
                }
            }
        } catch (error) {
            console.error('[Overlay Manager] Error handling queue size:', error);
        }

        // Update model (views will react to model changes)
        if (Array.isArray(picks)) {
            this.model.set('picks', picks);
            // request_identifier is stored in fsm.state_data.currently_showing_request_identifier
            // Always update top bar message to match the picks being displayed
            // This ensures top bar text persists during loading and always matches displayed picks

            const request_id = this.fsm.state_data.currently_showing_request_identifier || request_identifier;
            if (this._is_legup_lite_mode()) {
                this.clear_advancement_structure();
                this.update_top_bar_from_state({
                    request_identifier: request_id
                });
            } else {
                this.set_advancement_structure_on_model(advancement_structure);
                const advancement_text = this._resolve_advancement_display_text(advancement_structure);
                this.update_top_bar_from_state({
                    advancement_text: advancement_text,
                    request_identifier: request_id
                });
            }
        } else {
            this.model.set('picks', []);
            this.model.set('top_bar_message', { main_text: '', hover_text: '' });
        }
    }

    update_stars_from_queue() {
        if (this.picks_container) {
            this.picks_container.update_stars_from_queue();
        }
    }

    toggle_visibility(show) {
        this.overlay.classList.toggle('hidden', !show);
    }

    _get_refresh_icon_url() {
        if (this._refresh_icon_url) {
            return this._refresh_icon_url;
        }
        try {
            this._refresh_icon_url = chrome.runtime.getURL('assets/refresh.png');
            return this._refresh_icon_url;
        } catch {
            return null;
        }
    }

    _sync_legup_button_icon() {
        const legup_button = this.top_bar?.element?.querySelector?.('#legup_icon_button');
        const button_icon = legup_button?.querySelector('img');
        if (!legup_button || !button_icon) {
            return;
        }

        const eff = typeof this.fsm?.get_effective_notification === 'function'
            ? this.fsm.get_effective_notification()
            : null;
        const refreshIconUrl = this._get_refresh_icon_url();

        if (eff?.message) {
            const notifType = eff.type || 'auth_error';
            if (notifType === 'auth_error' || notifType === 'auth_error_update') {
                legup_button.classList.remove('legup_button--page-refresh-hint');
                if (refreshIconUrl) {
                    button_icon.src = refreshIconUrl;
                }
                legup_button.onclick = () => {
                    const url = notifType === 'auth_error_update'
                        ? this.getExtensionDownloadUrl()
                        : 'https://www.legendaryupside.com';
                    // Focus + reload so an already-open LegUp tab is visible and Ghost can re-push.
                    // After sleep the content↔background port is often dead; wake/reconnect before open.
                    this._open_auth_recovery_tab(url);
                };
                if (refreshIconUrl) {
                    this.model?.set?.('icon_button_state', refreshIconUrl);
                }
                return;
            }
            if (notifType === 'page_refresh_hint') {
                if (refreshIconUrl) {
                    button_icon.src = refreshIconUrl;
                    this.model?.set?.('icon_button_state', refreshIconUrl);
                }
                legup_button.classList.add('legup_button--page-refresh-hint');
                legup_button.onclick = () => {
                    window.location.reload();
                };
                return;
            }
        }

        legup_button.classList.remove('legup_button--page-refresh-hint');
        const iconUrl = this._get_legup_button_icon_url();
        if (iconUrl) {
            button_icon.src = iconUrl;
            this.model?.set?.('icon_button_state', iconUrl);
        }
        legup_button.onclick = null;
        this.bind_legup_button_default_action();
    }

    display_notification(message, type, opts = {}) {
        this.notification_bubble = this.notification_bubble || this.create_notification_bubble();
        const bubble = this.notification_bubble;

        this.notification_text = this.notification_text || bubble.querySelector('#notificationText');
        if (this.notification_text) this.notification_text.innerHTML = message;

        const isAuthError = type === 'auth_error';
        const isUpdateError = type === 'auth_error_update';
        const isWarning = type === 'warning';
        const isPageRefreshHint = type === 'page_refresh_hint';

        if ((isWarning || isPageRefreshHint) && message !== '') {
            bubble.classList.add('notification-bubble--warning');
        } else {
            bubble.classList.remove('notification-bubble--warning');
        }

        const closable = opts?.closable !== false;
        if (!closable) {
            bubble.classList.add('notification-bubble--no-close');
        } else {
            bubble.classList.remove('notification-bubble--no-close');
        }

        if (
            ((isAuthError || isUpdateError) && message !== '') ||
            (isPageRefreshHint && message !== '') ||
            (isWarning && message !== '') ||
            (type === 'info' && message !== '')
        ) {
            bubble.classList.add('is-visible');
        } else {
            bubble.classList.remove('is-visible');
        }

        this._sync_legup_button_icon();
    }

    getExtensionDownloadUrl() {
        const manifest = chrome.runtime.getManifest();
        const isFirefox = Boolean(manifest?.browser_specific_settings);
        if (isFirefox) {
            return 'https://apps.legendaryupside.com/download-extension-landing';
        }
        return 'https://chromewebstore.google.com/detail/legendary-upside-sidekick/afmeoinleedkppffddmbefkjenaiefaa';
    }

    async _ensure_bg_port_for_user_action() {
        const fsm = this.fsm;
        if (!fsm) {
            throw new Error('FSM unavailable');
        }
        if (fsm.background_communication_broken || !fsm.is_background_runtime_alive?.()) {
            throw new Error('Background communication broken');
        }
        if (fsm.bg_port && fsm.bg_connected) {
            return;
        }
        try {
            fsm._wake_up_background_script?.();
        } catch (err) {
        }
        try {
            fsm.open_bg_port?.();
        } catch (err) {
        }
        for (let i = 0; i < 15; i++) {
            if (fsm.bg_port && fsm.bg_connected) {
                return;
            }
            await new Promise((resolve) => setTimeout(resolve, 100));
        }
        throw new Error('Port not connected');
    }

    _open_auth_recovery_tab(url) {
        this._ensure_bg_port_for_user_action()
            .then(() => this.fsm.send_port_request('OPEN_NEW_TAB', {
                url,
                active: true,
                reload: true
            }))
            .catch((err) => console.error('[overlay_manager] open_new_tab failed', err));
    }

    bind_legup_button_default_action() {
        const legup_button = this.top_bar?.element?.querySelector?.('#legup_icon_button');
        if (!legup_button) return;

        legup_button.onclick = () => {
            if (this.fsm && this.fsm.bg_port && this.fsm.bg_connected) {
                this.fsm.send_port_request('OPEN_EXTENSION_POPUP', {}, 8000).catch((err) => {
                });
            }
        };
    }

    destroy() {
        this.exit_ghost_mode();
        this._unbind_global_listeners();
        this._remove_doc_listeners();
        if (this.streamer_overlay) {
            this.streamer_overlay.destroy();
            this.streamer_overlay = null;
        }
        if (this.sidecar) {
            this.sidecar.destroy();
            this.sidecar = null;
        }
        if (this.wrapper) {
            this.wrapper.remove();
            this.wrapper = null;
        }
        this.overlay = null;
        this.notification_bubble = null;
        this.exposure_saved_toast = null;
        // Keep fsm.state_data.pending_exposure_toast so a rebuilt overlay can still flush it.
        this._pending_exposure_toast = null;
        if (this._exposure_toast_fade_timer) {
            clearTimeout(this._exposure_toast_fade_timer);
            this._exposure_toast_fade_timer = null;
        }
        if (this._exposure_toast_remove_timer) {
            clearTimeout(this._exposure_toast_remove_timer);
            this._exposure_toast_remove_timer = null;
        }
        this.is_initialized = false;
    }

    async save_state() {
        const site = detect_site_key();
        const top = parseFloat(this.wrapper.style.top) || 0;
        const left = parseFloat(this.wrapper.style.left) || 0;
        const st = {
            top: Math.round(top),
            left: Math.round(left),
            mini: !!this.is_mini
        };
        if (!this.is_mini) {
            const { width, height } = this._clamp_stored_dimensions(
                parseFloat(this.overlay.style.width) || this.middle_width,
                parseFloat(this.overlay.style.height) || 500
            );
            st.width = Math.round(width);
            st.height = Math.round(height);
        } else if (this._preMini) {
            st.width = this._preMini.width;
            st.height = this._preMini.height;
        }
        // console.log(`[Overlay] Saving state for site: ${site}`, st);
        await set_overlay_for_site(site, { overlayState: st });
    }
}

function maybe_tick_exposure_mode(fsm, url) {
    if (!fsm || !url) return;
    if (!fsm.state_data) fsm.state_data = {};
    const sd = fsm.state_data;
    if (sd.exposure_tick_url !== url) {
        sd.exposure_tick_url = url;
        sd.exposure_ud_logged = false;
        sd.exposure_dk_logged = false;
        sd.exposure_dk_force_sync_requested = false;
    }
    if (is_underdog_exposure_url(url) && !sd.exposure_ud_logged) {
        sd.exposure_ud_logged = true;
    }
    if (is_draft_kings_lineup_url(url)) {
        if (!sd.exposure_dk_logged) {
            sd.exposure_dk_logged = true;
        }
        // Re-submit stored DK lineups even when the page serves cached lineups and
        // no fresh intercept arrives (content-hash gate otherwise blocks upload).
        // Retry across ticks until the background port accepts the request.
        if (!sd.exposure_dk_force_sync_requested) {
            requestForceDkExposureSync(fsm);
        }
    }
}

function requestForceDkExposureSync(fsm) {
    if (!fsm || !fsm.state_data || !fsm.bg_port || !fsm.bg_connected || typeof fsm.send_port_request !== 'function') {
        return;
    }
    fsm.state_data.exposure_dk_force_sync_requested = true;
    fsm
        .send_port_request('FORCE_EXPOSURE_SYNC', { forceSites: ['draftkings'] })
        .then((res) => {
            if (!res || res.status !== 'ok') {
                if (fsm.state_data) fsm.state_data.exposure_dk_force_sync_requested = false;
                return;
            }
        })
        .catch((err) => {
            if (fsm.state_data) fsm.state_data.exposure_dk_force_sync_requested = false;
        });
}

class Content_Script_FSM {
    constructor() {
        this.current_state = STATE.INIT;
        this.AUTH_CHECK_INTERVAL = 1000; // used by both legup account sync and session check
        this.LONG_AUTH_CHECK_INTERVAL = 10 * 60 * 1000; 
        this.tick_timer = null;
        this.tick_interval = TICK_INTERVALS[this.current_state];
        this.system_sound_enabled = false;
        this.debug = {
            lastBootId: null,
            lastHelloAt: 0,
            lastPingAt: 0,
            lastKeepaliveAck: 0,
            rehydrateAttempts: 0
        };
        this.state_data = {
            dom_ready: false,
            environment_ready: false,
            session_ready: false,
            page_context: null,
            env_value: null,
            env_retries: 0,
            session_retries: 0,
            settings_ready: false,
            settings_requested: false,
            has_initialized_auth_loop: false,
            last_auth_check: 0,
            last_session_poll: 0,
            message_queue: [],
            streamer_mode_data: {
                currently_winning: null,
                updated_at_ms: null
            },
            notification_sidecar_preview: null,
            notification_background: null,
            session_auth_notification_dismissed_fingerprint: null,
            warning_notification: null,
            warning_notification_urgent: null,
            /** DraftKings lineup exposure merge in flight; plain `info` bubble (see set_dk_exposure_progress_notification). */
            dk_exposure_progress_message: null,
            queue_observer: null,
            last_sent: null,
            last_draft_send_time: 0,
            season_stage: 'regular', // fallback value
            force_poll: false, // User-initiated refresh, bypasses draft change check only
            rankings_loading: false, // Flag to control loading animation visibility
            currently_showing_request_identifier: null, // Request identifier for currently displayed picks
            last_request_sent_time: 0, // Timestamp of last request sent (for debugging/tracking)
            pending_request_timeout: null, // Timeout ID for pending request
            last_logged_state: null, // Track last logged state to avoid duplicate logs
            last_cached_rankings_request_time: 0,
            last_otc_sound: null, // Tracks last draft/pick combination that played OTC sound { draft_id, pick_number }
            current_draft_context: {
                draft_id: null,
                request_identifier: null,
                num_picks: 0,
                site_name: null,
                algo_type: null,
                ranking_set: null,
                format_type: null,
                last_updated: 0
            },
            cache_check_state: {
                last_requested_rankings_needed: null,
                last_cache_check_time: 0,
                skip_next_tick: false
            },
            tournament_summary_cache: {}, // draft_id -> small summary (supported flag, advancement raw string, payout/fee)
            unsupported_contest: null, // { draft_id, reason } when current Underdog draft is not supported
            last_seen_ud_tournament_marker_clear_gen: 0, // BG_HELLO ud_tournament_marker_clear_gen; stale summaries cleared when this bumps
            queue: {
                players: [], // Array of player names in queue
                last_logged_queue_state: null, // Track last logged queue state to avoid duplicate logs
                is_detected: false, // Whether queue elements are currently detected
            },
            queue_size_changed: false,
            queue_size_observer: null,
            last_queue_size: null,
            is_underdog_page: false,
            skip_lobby_check_debug: false,
            rankings_needed: null,
            currently_displayed: null,
            legup_player_lists: null,
            last_draft_status_span_text: null, // For lightweight extraction gate on Underdog
            last_extraction_result: null, // Cache last extraction result to prevent accidental clears
            // Underdog: full draft JSON from intercepted XHR + merged Pusher pick_made (not ribbon DOM)
            // Per Underdog draft id: { draft_id: { draft: {...} } } — XHR replaces; Pusher merges only into matching id
            ud_intercepted_drafts: {},
            ud_intercept_revision_by_draft: {},
            draft_kings_tournament_cache: {}, // Cache trimmed tournament summary (tournamentRounds, entryFee, draftRounds) to reduce background chatter
            // Low resources mode: suite of features to reduce load on low-end systems (not user-configurable)
            low_resources: {
                rankings_deferred: false // true when we skip rankings request because tab is hidden and user not on clock
            },
            // After navigation / draft switch: allow one stale CHECK_CACHED display, then force a real HTTP rankings fetch
            // (background may otherwise no-op RANKINGS_REQUEST when use_cached_rankings hits an exact cache key).
            post_cache_fresh_fetch_needed: false,
            bypass_rankings_cache_once: false,
            // Underdog /active/ SPA: navigation settle (see updateUdActiveNavigationSettle in content_script_underdog.js)
            ud_active_nav_track_id: null,
            ud_active_nav_changed_at: null,
            ud_active_nav_generation: 0,
            ud_active_nav_stable_ticks: 0,
            ud_active_nav_pending_log_complete: false,
            /** Last draft id we used for Underdog extraction/rankings (SPA navigation detection). */
            ud_fsm_extraction_draft_id: null,
            /** After draft id change or leaving draft: skip this many full extraction ticks (no extract, no CHECK_CACHED). */
            ud_underdog_extraction_skip_ticks_remaining: 0,
            /** Incremented on hard reset so stale extract_underdog_draft_data promises are ignored. */
            ud_extraction_dispatch_generation: 0
        };

        this.session_data = {
            user_uuid: null,
            allow_rankings: null,
            reason: null,
            tier: null
        };

        this.user_settings = {
            icon_size: '48',
            use_image_icons: false,
            enable_mouse_over_text: true,
            user_sound_enabled: false,
            use_cached_rankings: true,
            force_lite_mode: false,
            low_resources_mode: false,
            suppress_nonfatal_warning_notifications: false,
            sidecar_enabled: true,
            ghost_enable_button_container: true,
            ghost_enable_player_card: false,
            ghost_enable_draft_board: false,
            ud_intercept_extraction_enabled: true,
            ud_xhr_replay_disabled: false,
            ud_debug_ignore_legacy_collision_rules: false,
            streamer_overlay_enabled: false,
            tag_icon_exposure_display: 'default',
            exposure_aggregate_across_sites: false,
            ud_exposure_aggregate_slates: false,
            dk_exposure_aggregate_slates: false
        };
        this.tag_icon_settings = {};
        this.datasets = {
            player_map_ud: null,
            playoff_probabilities: null,
            id_map: null,
            exposure_id_map: null
        };
        this.message_queue = [];
        this.last_recommended = null;
        this.system_sound_enabled = true;
        this.overlay_manager = null; // Will be created after settings are loaded
        this.reset_seed_in_progress = false;
        this.reset_draft_state_in_progress = false;
        // Per-request_identifier count of automatic reloads triggered by "Insufficient samples"
        // error picks (sim endpoint warming up). Caps the auto-reload loop so a persistently
        // failing backend can't cause endless reload spam.
        this.error_pick_auto_reload_counts = {};
        this.MAX_ERROR_PICK_AUTO_RELOADS = 2;
        this.pending_port_requests = new Map(); // Key: request_id, Value: { resolve, reject, timeout }
        this.port_request_counter = 0; // For generating unique request IDs
        this._bootstrap_hello_done = false;
        this._bootstrap_hello_waiters = new Set();
        this._keepalive_timer = null; // Timer for periodic keepalive messages
        this.KEEPALIVE_INTERVAL_MS = 10000; // Send keepalive every 10 seconds
        this._keepalive_watchdog_timer = null; // Timer to detect if background script is dead
        this.KEEPALIVE_WATCHDOG_TIMEOUT_MS = 20000; // If no ack received within 20s, background may be dead
        this.PORT_STALE_THRESHOLD_MS = 90000; // Force reconnect if no health signal for 90s
        this._last_keepalive_sent = 0; // Timestamp of last keepalive sent
        this._port_health_listeners_bound = false;
        // True after chrome.runtime is dead for this content script until the page is refreshed.
        this.background_communication_broken = false;
        this.background_communication_broken_errors = [];
        this.extraction_error_details = [];

        // Port must exist before bootstrap_env_and_session / send_port_request (otherwise GET_ENVIRONMENT / GET_SESSION_DATA reject immediately).
        this.open_bg_port();
        this._bind_port_health_listeners();

        // Wait for BG_HELLO before creating overlay_manager. On cold install the background
        // may still be fetching remote config (ensure_config_ready); redundant GET_* here used
        // to time out at 5s while BG_HELLO carries the same env/session/settings snapshot.
        (async () => {
            try {
                await this._wait_for_bg_hello(30000);
            } catch (err) {
                if (this._bootstrap_hello_done || this.state_data.environment_ready) {
                } else {
                    await this.bootstrap_env_and_session_async(30000);
                    await this.load_settings_from_background(30000);
                }
            }
            this.state_data.settings_ready = true;

            if (!this.overlay_manager) {
                this.overlay_manager = new Overlay_Manager(this);
                if (this.overlay_manager.model && this.user_settings.user_sound_enabled !== undefined) {
                    this.overlay_manager.model.set('sound_enabled', !!this.user_settings.user_sound_enabled);
                }
            }

            this.tick();
        })();
    }

    _wait_for_bg_hello(timeout_ms = 30000) {
        if (this._bootstrap_hello_done) {
            return Promise.resolve();
        }
        return new Promise((resolve, reject) => {
            const waiter = () => {
                cleanup();
                resolve();
            };
            const timer = setTimeout(() => {
                cleanup();
                if (this._bootstrap_hello_done) {
                    resolve();
                } else {
                    reject(new Error(`BG_HELLO timeout after ${timeout_ms}ms`));
                }
            }, timeout_ms);
            const cleanup = () => {
                clearTimeout(timer);
                this._bootstrap_hello_waiters.delete(waiter);
            };
            this._bootstrap_hello_waiters.add(waiter);
        });
    }

    _notify_bootstrap_hello_received() {
        this._bootstrap_hello_done = true;
        for (const waiter of this._bootstrap_hello_waiters) {
            try {
                waiter();
            } catch (err) {
            }
        }
        this._bootstrap_hello_waiters.clear();
    }

    _is_dev_or_local_env() {
        const env = this.state_data?.env_value || null;
        return env === 'dev' || env === 'local';
    }

    async bootstrap_env_and_session_async(timeout_ms = 30000) {
        try {
            const env_resp = await this.send_port_request('GET_ENVIRONMENT', {}, timeout_ms);
            if (env_resp?.env) {
                this.state_data.env_value = env_resp.env;
                this.state_data.environment_ready = true;
                this.overlay_manager?.sync_sidecar_visibility?.();
                this.overlay_manager?.sync_streamer_overlay_visibility?.();
            } else {
            }
        } catch (err) {
        }

        try {
            const session_resp = await this.send_port_request('GET_SESSION_DATA', {}, timeout_ms);
            if (session_resp?.session_data) {
                this.set_session_from_response(session_resp.session_data);
            } else {
            }
        } catch (err) {
        }
    }

    set_session_from_response(sd) {
        const prev_allow_rankings = this.session_data?.allow_rankings;
        this.session_data = {
            user_uuid: sd.user_uuid,
            allow_rankings: sd.allow_rankings ?? null,
            reason: sd.reason ?? null,
            tier: normalize_tier(sd.tier)
        };
        if (prev_allow_rankings === true && this.session_data.allow_rankings !== true) {
            this.state_data.rankings_loading = false;
            if (this.overlay_manager?.model) {
                this.overlay_manager.model.set('rankings_loading', false);
            }
        }
        if (this.session_data.user_uuid) {
            this.state_data.session_ready = true;
        } else {
            this.state_data.session_ready = false;
        }
        this.state_data.session_access_level = this.get_session_access_level();
        // console.log("Fetched session_data from background:");
        // console.log(this.session_data);
        // console.log("Session ready: " + this.state_data.session_ready);
        
        // Update notification based on session data
        this.update_auth_notification();
    }

    get_session_access_level() {
        return session_access_level(this.session_data);
    }

    is_legup_lite_mode() {
        return is_legup_lite_mode(this.session_data, this.user_settings);
    }

    on_overlay_event(event) {
        if (!event || !event.type) return;
        if (!this.is_legup_lite_mode()) return;
        if (this.current_state !== STATE.EXTRACTION) return;

        const draft_result = this.state_data.last_extraction_result;
        if (!draft_result?.draft) return;

        if (event.type === 'ranking_set_changed') {
            this._custom_rankings_fetch_debug_sig = null;
            this._custom_rankings_picks_debug_sig = null;
            if (typeof _customRankDebugSig !== 'undefined') {
                _customRankDebugSig = '';
            }
            this._refresh_legup_local_rankings(false).catch((err) => {
                console.error('[FSM] LegUp ranking_set change refresh failed', err);
            });
            return;
        }

        if (event.type === 'format_type_changed') {
            this.state_data.legup_player_lists = null;
            this._refresh_legup_local_rankings(false).catch((err) => {
                console.error('[FSM] LegUp format_type change refresh failed', err);
            });
            return;
        }

        if (event.type === 'adp_override_changed') {
            if (!this._is_dev_or_local_env()) return;
            const resort = event.resort === true
                || resolveLegUpRankingSet(
                    this._get_dropdown_values().ranking_set || 'legup',
                    this._get_dropdown_values().format_type || 'standard',
                    this.overlay_manager?.model?.get('scoring') || null
                ) === 'adp';
            this._refresh_legup_local_rankings(resort).catch((err) => {
                console.error('[FSM] LegUp adp_override change refresh failed', err);
            });
        }
    }

    async _refresh_legup_local_rankings(resortForAdpOverride = false) {
        const draft_result = this.state_data.last_extraction_result;
        if (!draft_result?.draft) return;

        const site_name = this.state_data.current_draft_context?.site_name || draft_result.draft.site_name;
        const dropdownValues = this._get_dropdown_values();
        const draft_request = this._build_request_from_draft_result(draft_result, dropdownValues, site_name);
        if (!draft_request) return;

        draft_request.resort_for_adp_override = resortForAdpOverride === true;
        await this._handle_legup_local_rankings(draft_request);
    }

    async _get_legup_draft_selections(siteName) {
        const siteKey = siteOverlayKeyFromSiteName(siteName);
        try {
            const resp = await this.send_port_request('GET_SETTINGS', {
                scope: 'content_script',
                keys: ['overlay']
            });
            return resp?.settings?.overlay?.[siteKey]?.draftSelections || {};
        } catch (err) {
            return {};
        }
    }

    _compute_session_auth_notification() {
        return compute_session_auth_notification(this.session_data);
    }

    
    _resolve_overlay_notification() {
        const p = this.state_data.notification_sidecar_preview;
        if (p?.message) {
            return { layer: 'preview', message: p.message, type: p.type || 'auth_error' };
        }
        const dkProg =
            this.state_data.dk_exposure_progress_message != null
                ? String(this.state_data.dk_exposure_progress_message).trim()
                : '';
        if (dkProg) {
            return { layer: 'dk_exposure_progress', message: dkProg, type: 'info' };
        }
        const bg = this.state_data.notification_background;
        if (bg?.message) {
            return { layer: 'background', message: bg.message, type: bg.type || 'auth_error' };
        }
        const session = this._compute_session_auth_notification();
        const dismissed = this.state_data.session_auth_notification_dismissed_fingerprint;
        if (session.message && session.message !== dismissed) {
            return { layer: 'session_auth', message: session.message, type: session.type };
        }
        const wUrgent = this.state_data.warning_notification_urgent;
        if (wUrgent?.message) {
            const type = wUrgent.kind === 'page_refresh' ? 'page_refresh_hint' : 'warning';
            return { layer: 'warning_urgent', message: wUrgent.message, type };
        }
        const w = this.state_data.warning_notification;
        if (w?.message) {
            // User setting: allow suppressing non-fatal (non-urgent) warnings.
            // Urgent warnings are handled above and are never suppressed here.
            if (this.user_settings?.suppress_nonfatal_warning_notifications) {
                return { layer: 'none', message: '', type: 'auth_error' };
            }
            const type = w.kind === 'page_refresh' ? 'page_refresh_hint' : 'warning';
            return { layer: 'warning', message: w.message, type };
        }
        return { layer: 'none', message: '', type: 'auth_error' };
    }

    set_dk_exposure_progress_notification(message) {
        const trimmed = message != null ? String(message).trim() : '';
        if (!trimmed) {
            this.clear_dk_exposure_progress_notification();
            return;
        }
        this.state_data.dk_exposure_progress_message = trimmed;
        this.refresh_overlay_notification();
    }

    clear_dk_exposure_progress_notification() {
        if (!this.state_data.dk_exposure_progress_message) {
            return;
        }
        this.state_data.dk_exposure_progress_message = null;
        this.refresh_overlay_notification();
    }

    get_effective_notification() {
        const r = this._resolve_overlay_notification();
        if (!r?.message) return null;
        const closable = r.layer === 'warning' || r.layer === 'dk_exposure_progress';
        return { message: r.message, type: r.type, layer: r.layer, closable };
    }

    refresh_overlay_notification() {
        if (!this.overlay_manager?.is_initialized) return;
        const eff = this.get_effective_notification();
        if (!eff) {
            this.overlay_manager.display_notification('', 'auth_error', { closable: false, layer: 'none' });
            return;
        }
        this.overlay_manager.display_notification(eff.message, eff.type, { closable: eff.closable, layer: eff.layer });
    }

    apply_streamer_mode_data(streamer_mode_data) {
        const src = streamer_mode_data && typeof streamer_mode_data === 'object' ? streamer_mode_data : {};
        const rawWinning = src.currently_winning;
        const currently_winning = typeof rawWinning === 'string' ? rawWinning.trim() : '';
        const entry_fees_total_cents = Number.isFinite(+src.entry_fees_total_cents) ? +src.entry_fees_total_cents : null;
        this.state_data.streamer_mode_data = {
            currently_winning: currently_winning || null,
            entry_fees_total_cents: entry_fees_total_cents != null ? Math.max(0, Math.round(entry_fees_total_cents)) : null,
            updated_at_ms: Number.isFinite(+src.updated_at_ms) ? +src.updated_at_ms : null
        };
        this.overlay_manager?.update_streamer_overlay_content?.();
    }

    
    set_warning_notification(message, source = 'generic', options = null) {
        if (!message) {
            this.state_data.warning_notification = null;
        } else {
            const kind = options && options.kind === 'page_refresh' ? 'page_refresh' : 'standard';
            this.state_data.warning_notification = { message, source, kind };
        }
        this.refresh_overlay_notification();
    }

    clear_warning_notification(source = null) {
        const w = this.state_data.warning_notification;
        if (!w) return;
        if (source == null || w.source === source) {
            this.state_data.warning_notification = null;
            this.refresh_overlay_notification();
        }
    }

    
    set_urgent_warning_notification(message, source = 'generic', options = null) {
        if (!message) {
            this.state_data.warning_notification_urgent = null;
        } else {
            const kind = options && options.kind === 'page_refresh' ? 'page_refresh' : 'standard';
            this.state_data.warning_notification_urgent = { message, source, kind };
        }
        this.refresh_overlay_notification();
    }

    clear_urgent_warning_notification(source = null) {
        const w = this.state_data.warning_notification_urgent;
        if (!w) return;
        if (source == null || w.source === source) {
            this.state_data.warning_notification_urgent = null;
            this.refresh_overlay_notification();
        }
    }

    reset_all_overlay_notifications() {
        this.state_data.notification_sidecar_preview = null;
        this.state_data.notification_background = null;
        this.state_data.session_auth_notification_dismissed_fingerprint = null;
        this.state_data.warning_notification = null;
        this.state_data.warning_notification_urgent = null;
        this.state_data.dk_exposure_progress_message = null;
        this.refresh_overlay_notification();
    }

    set_sidecar_notification_preview(text, type = 'auth_error') {
        const trimmed = (text || '').trim();
        if (!trimmed) {
            this.reset_all_overlay_notifications();
            return;
        }
        this.state_data.notification_sidecar_preview = { message: trimmed, type: type || 'auth_error' };
        this.refresh_overlay_notification();
    }

    dismiss_notification_bubble() {
        const r = this._resolve_overlay_notification();
        if (r.layer === 'preview') {
            this.state_data.notification_sidecar_preview = null;
        } else if (r.layer === 'background') {
            this.state_data.notification_background = null;
        } else if (r.layer === 'session_auth') {
            this.state_data.session_auth_notification_dismissed_fingerprint = r.message;
        } else if (r.layer === 'warning_urgent') {
            this.state_data.warning_notification_urgent = null;
        } else if (r.layer === 'warning') {
            this.state_data.warning_notification = null;
        } else if (r.layer === 'dk_exposure_progress') {
            this.state_data.dk_exposure_progress_message = null;
        }
        this.refresh_overlay_notification();
    }

    update_auth_notification() {
        const bg = this.state_data.notification_background;
        if (bg?.type === 'auth_error_update' && bg?.message) {
            this.refresh_overlay_notification();
            return;
        }
        if (bg?.message && bg?.type !== 'auth_error_update') {
            this.state_data.notification_background = null;
        }
        this.refresh_overlay_notification();
    }

    _merge_background_auth_notification(msg) {
        const isUpdateNotification = msg?.type === 'auth_error_update';
        const sessionUnset = !this.session_data
            || (this.session_data.allow_rankings === null && this.session_data.allow_rankings === undefined);
        const trimmedMessage = typeof msg?.message === 'string' ? msg.message.trim() : '';

        if (isUpdateNotification) {
            this.state_data.notification_background = trimmedMessage
                ? { message: trimmedMessage, type: msg.type }
                : null;
        } else if (sessionUnset && trimmedMessage) {
            this.state_data.notification_background = { message: trimmedMessage, type: msg.type || 'auth_error' };
        } else if (!sessionUnset && this.state_data.notification_background?.type !== 'auth_error_update') {
            this.state_data.notification_background = null;
        } else if (!trimmedMessage) {
            this.state_data.notification_background = null;
        }

        if (this.overlay_manager?.is_initialized) {
            this.refresh_overlay_notification();
        }
    }

    _handle_background_auth_notification(msg) {
        if (msg?.session_data) {
            this.set_session_from_response(msg.session_data);
        } else {
            this.send_port_request('GET_SESSION_DATA', {}, 3000)
                .then((resp) => {
                    if (resp?.session_data) {
                        this.set_session_from_response(resp.session_data);
                    } else {
                        this._merge_background_auth_notification(msg);
                    }
                })
                .catch((err) => {
                    this._merge_background_auth_notification(msg);
                });
            return;
        }
        this._merge_background_auth_notification(msg);
    }



    
    _low_resources_should_send_rankings() {
        const tabVisible = typeof document.visibilityState === 'string' && document.visibilityState === 'visible';
        const userOnClock = !!this.overlay_manager?.model?.get?.('user_otc');
        return tabVisible || userOnClock;
    }

    /**
     * Reject rankings payloads for a different draft than the tab URL (or, if URL has no id, FSM context).
     * Fills the gap after navigation: context is cleared before extraction repopulates, but CHECK_CACHED
     * or poll completions for the previous draft can still arrive.
     */
    _cachedRankingsDraftMatchesActiveTab(messageDraftId) {
        if (messageDraftId == null || messageDraftId === '') {
            return true;
        }
        const m = String(messageDraftId);
        const href = typeof window !== 'undefined' ? window.location.href : '';
        const urlUd =
            typeof get_underdog_draft_id_from_url === 'function' ? get_underdog_draft_id_from_url(href) : null;
        const urlDk =
            typeof get_draftkings_draft_id_from_url === 'function' ? get_draftkings_draft_id_from_url(href) : null;
        const urlDraftId =
            urlUd != null && String(urlUd).length
                ? String(urlUd)
                : urlDk != null && String(urlDk).length
                  ? String(urlDk)
                  : null;

        if (urlDraftId) {
            return m === urlDraftId;
        }

        const liveRaw = this.state_data.current_draft_context?.draft_id;
        const liveId = liveRaw != null && liveRaw !== '' ? String(liveRaw) : null;
        if (liveId) {
            return m === liveId;
        }

        return true;
    }

    
    send_rankings_request(structured_data) {
        if (!structured_data || !this.bg_port) {
            return;
        }

        if (this.is_legup_lite_mode()) {
            return;
        }

        if (this.session_data?.allow_rankings !== true) {
            return;
        }

        // Block rankings requests while reset_draft_state is in progress
        if (this.reset_draft_state_in_progress) {
            // console.debug('[CS] Skipping rankings request: reset_draft_state in progress');
            return;
        }

        // Low resources mode (user setting): skip rankings when tab is in background and user is not on the clock
        if (this.user_settings.low_resources_mode && !this._low_resources_should_send_rankings()) {
            this.state_data.low_resources.rankings_deferred = true;
            if (this.overlay_manager?.update_top_bar_from_state) {
                this.overlay_manager.update_top_bar_from_state({});
            }
            return;
        }
        const was_deferred = this.state_data.low_resources.rankings_deferred;
        this.state_data.low_resources.rankings_deferred = false;
        if (was_deferred && this.overlay_manager?.update_top_bar_from_state) {
            this.overlay_manager.update_top_bar_from_state({});
        }

        const now = Date.now();

        const outgoing_request_identifier = structured_data.request_identifier;
        const last_sent = this.state_data.last_sent;
        const change_snapshot = build_rankings_change_snapshot(structured_data);
        const last_snapshot = last_sent ? build_rankings_change_snapshot(last_sent) : null;
        const draft_changed =
            !last_snapshot || !rankings_change_snapshots_equal(last_snapshot, change_snapshot);

        // Check if we have a pending request (timeout still active means request is in flight)
        const has_pending_request = this.state_data.pending_request_timeout !== null;
        
        const time_since_last_request = now - this.state_data.last_request_sent_time;
        
        // Empty picks container retry logic: only send if:
        // - Picks are empty AND
        // - rankings_loading is false (not currently loading) AND
        // - We're not already waiting for a response (no pending request) AND
        // - At least EMPTY_CONTAINER_RETRY_INTERVAL_MS since last request
        const picks_container_empty = this.overlay_manager?.picks_container && 
            (this.overlay_manager.picks_container.picks.length === 0);
        const should_force_for_empty = picks_container_empty && 
            !this.state_data.rankings_loading && 
            !has_pending_request && 
            time_since_last_request >= EMPTY_CONTAINER_RETRY_INTERVAL_MS;
        
        // Determine if we should send:
        // - Always send if draft snapshot changed (draft_id, num_picks, algo/format/ranking_set, picks[])
        // - Send if force_poll is set (user-initiated refresh, bypasses draft change and pending checks)
        // - Send if rankings_wanted doesn't match currently_showing_request_identifier AND rankings_loading is false
        // - Send if empty container conditions are met (throttled retry)
        // Goal: Maintain 1 draft request_identifier:1 request mapping (background handles polling)
        const rankings_wanted_identifier = this.state_data.rankings_needed?.request_identifier;
        const currently_showing_identifier = this.state_data.currently_showing_request_identifier;
        const identifiers_mismatch = rankings_wanted_identifier && 
            rankings_wanted_identifier !== currently_showing_identifier &&
            !this.state_data.rankings_loading;

        const bypass_same_request_check = identifiers_mismatch;
        const should_send = draft_changed || 
            (this.state_data.force_poll && !has_pending_request) ||
            bypass_same_request_check ||
            should_force_for_empty;
        
        // Clear force_poll if it was set but we can't send yet (pending request)
        // This ensures force_poll is only used for a single request attempt
        if (this.state_data.force_poll && !should_send) {
            this.state_data.force_poll = false;
        }
        
        const current_state = {
            request_identifier: outgoing_request_identifier,
            has_pending: has_pending_request,
            picks_empty: picks_container_empty
        };
        const state_changed = JSON.stringify(current_state) !== JSON.stringify(this.state_data.last_logged_state);
        
        if (should_send) {
            let reason = 'draft_changed';
            if (this.state_data.force_poll) {
                reason = 'force_poll';
            } else if (bypass_same_request_check) {
                reason = 'identifiers_mismatch';
            } else if (should_force_for_empty) {
                reason = 'empty_picks_with_loading_flag';
            }
            
            if (this._is_dev_or_local_env() && (state_changed || draft_changed)) {
                const logData = {
                    reason: reason,
                    request_identifier: outgoing_request_identifier,
                    draft_id: structured_data.draft?.draft_id,
                    picks_count: structured_data.draft?.picks?.length || 0
                };
            }
            
            if (this.state_data.pending_request_timeout) {
                clearTimeout(this.state_data.pending_request_timeout);
                this.state_data.pending_request_timeout = null;
            }
            
            // Only set loading flag if it's not already set to avoid restarting animation
            if (!this.state_data.rankings_loading) {
                if (this._is_dev_or_local_env()) {
                    const sendRankingsRequestLogData = {
                        request_identifier: outgoing_request_identifier,
                        draft_id: structured_data.draft?.draft_id,
                        stack: new Error().stack.split('\n').slice(1, 4).join('\n')
                    };
                }
                this.state_data.rankings_loading = true;
                if (this.overlay_manager?.model) {
                    // Model update will trigger rankings_loadingChanged subscription which updates UI
                    // console.log('[FSM] Updating model.rankings_loading = true');
                    this.overlay_manager.model.set('rankings_loading', true);
                }
            } else {
            }
            
            // Use cached rankings by default, but bypass cache when force_poll is set (user-initiated reload)
            // or when we must fetch after showing bootstrap / stale CHECK_CACHED results (see bypass_rankings_cache_once).
            const bypass_cache_for_this_send = this.state_data.bypass_rankings_cache_once;
            structured_data.use_cached_rankings =
                (this.state_data.force_poll || bypass_cache_for_this_send)
                    ? false
                    : this.user_settings.use_cached_rankings;

            let payload = { ...structured_data };
            if (this.state_data.page_context === 'draft_test') {
                const useProdUrlEl = document.getElementById('useProdUrlForRankings');
                const use_prod_url = !!(useProdUrlEl && useProdUrlEl.checked);
                payload = { ...payload, use_prod_url };
            }

            this.bg_port.postMessage({
                action: 'RANKINGS_REQUEST',
                data: payload
            });

            if (bypass_cache_for_this_send) {
                this.state_data.bypass_rankings_cache_once = false;
            }

            // Update overlay picked_ids so pick elements for already-picked players show at 50% opacity
            const draft = structured_data.draft;
            const draft_picks = draft?.picks || [];
            const site_name = (draft?.site_name || '').toLowerCase();
            const use_ud = site_name.includes('underdog');
            const picked_ids = draft_picks
                .map(p => (use_ud ? p.ud_id : p.dk_id))
                .filter(id => id != null && id !== '');
            if (this.overlay_manager?.model) {
                this.overlay_manager.model.set('picked_ids', picked_ids);
            }

            this.state_data.last_sent = structured_data;
                this.state_data.last_draft_send_time = now;
            this.state_data.last_request_sent_time = now;
            this.state_data.force_poll = false;

            this.state_data.pending_request_timeout = setTimeout(() => {
                if (this._is_dev_or_local_env()) {
                    const logData = {
                        request_identifier: outgoing_request_identifier,
                        timeout_ms: RANKINGS_REQUEST_TIMEOUT_MS,
                        tab_id: window.location.href
                    };
                }
                this.state_data.pending_request_timeout = null;
                if (this._is_dev_or_local_env()) {
                    const timeoutLogData = {
                        request_identifier: outgoing_request_identifier,
                        tab_id: window.location.href,
                        stack: new Error().stack.split('\n').slice(1, 4).join('\n')
                    };
                }
                this.state_data.rankings_loading = false;
                if (this.overlay_manager?.model) {
                    this.overlay_manager.model.set('rankings_loading', false);
                }
                this.overlay_manager?.refresh_loading_animation?.();

                if (this.bg_port && outgoing_request_identifier) {
                    this.bg_port.postMessage({
                        action: 'STOP_POLLING',
                        request_identifier: outgoing_request_identifier
                    });
                }

                // Soft notice + one fresh retry rather than blank notch forever.
                this.set_sidecar_notification_preview(
                    'Rankings timed out — retrying',
                    'rankings_error'
                );
                const last_sent_payload = this.state_data.last_sent;
                if (last_sent_payload && !this.state_data.rankings_timeout_retrying) {
                    this.state_data.rankings_timeout_retrying = true;
                    this.state_data.force_poll = true;
                    try {
                        this.send_rankings_request(last_sent_payload);
                    } catch (retryErr) {
                    } finally {
                        // Allow a later timeout to retry again after this attempt settles.
                        setTimeout(() => {
                            this.state_data.rankings_timeout_retrying = false;
                        }, RANKINGS_REQUEST_TIMEOUT_MS);
                    }
                }
                }, RANKINGS_REQUEST_TIMEOUT_MS);
            
            // Don't clear currently_showing_request_identifier or picks when draft changes
            // They will be updated when new picks arrive via CACHED_RANKINGS_FOUND
            // This ensures old picks remain visible until new picks replace them
            
            this.state_data.last_logged_state = current_state;
        } else {
            if (state_changed) {
                if (this._is_dev_or_local_env()) {
                    const logData = {
                        draft_unchanged: !draft_changed,
                        has_pending: has_pending_request,
                        time_since_last: time_since_last_request,
                        picks_empty: picks_container_empty
                    };
                }
                this.state_data.last_logged_state = current_state;
            }
        }
    }

    start() {
        this.set_tick_interval(TICK_INTERVALS[this.current_state]);
    }

    stop() {
        if (this.tick_timer) clearInterval(this.tick_timer);
        this.tick_timer = null;

        if (this._helloTimer) {
            clearTimeout(this._helloTimer);
            this._helloTimer = null;
        }

        if (this._reconnect_timer) {
            clearTimeout(this._reconnect_timer);
            this._reconnect_timer = null;
        }

        if (this._keepalive_timer) {
            clearInterval(this._keepalive_timer);
            this._keepalive_timer = null;
        }

        if (this._keepalive_watchdog_timer) {
            clearTimeout(this._keepalive_watchdog_timer);
            this._keepalive_watchdog_timer = null;
        }

        if (this.state_data?.pending_request_timeout) {
            clearTimeout(this.state_data.pending_request_timeout);
            this.state_data.pending_request_timeout = null;
        }

        // Reject and clear any pending port requests (and their timeouts)
        if (this.pending_port_requests && this.pending_port_requests.size) {
            for (const [request_id, ent] of this.pending_port_requests) {
                try {
                    if (ent && ent.timeout) clearTimeout(ent.timeout);
                } catch {}
                try {
                    ent?.reject?.(new Error('FSM stopped'));
                } catch {}
            }
            this.pending_port_requests.clear();
        }

        // Clean up any observers held by FSM state
        if (this.state_data?.queue_size_observer) {
            try { this.state_data.queue_size_observer.disconnect(); } catch {}
            this.state_data.queue_size_observer = null;
        }
        if (this.state_data?.queue_observer) {
            try { this.state_data.queue_observer.disconnect(); } catch {}
            this.state_data.queue_observer = null;
        }

        // Disconnect background port and prevent keepalive/reconnect loops
        if (this.bg_port) {
            try { this.bg_port.disconnect(); } catch {}
        }
        this.bg_port = null;
        this.bg_connected = false;
    }

    transition_to(new_state) {
        this.current_state = new_state;
        this.maybe_update_tick_interval();
        this.tick();
    }

    maybe_update_tick_interval() {
        const desired = TICK_INTERVALS[this.current_state];
        if (this.tick_interval !== desired) {
            this.set_tick_interval(desired);
        }
    }

    set_tick_interval(ms) {
        if (this.tick_timer) clearInterval(this.tick_timer);
        this.tick_interval = ms;
        this.tick_timer = setInterval(() => this.tick(), this.tick_interval);
    }

    tick() {
        this.maybe_update_tick_interval();
        try {
            switch (this.current_state) {
                case STATE.INIT:
                    this.handle_init();
                    break;
                case STATE.LEGUP_ACCOUNT_SYNC:
                    this.handle_legup_account_sync();
                    break;
                case STATE.INIT_OVERLAY:
                    this.handle_overlay_init();
                    break;
                case STATE.EXTRACTION:
                    this.handle_extraction();
                    break;
                case STATE.ERROR:
                    this.handle_error();
                    break;
            }
        } catch (error) {
            console.error('State machine error:', error);
            this.transition_to(STATE.ERROR);
        }
    }

    /**
     * Merge nested user_settings with legacy top-level keys (older BG_HELLO paths).
     * Prefer data.user_settings; fill from data.* only when missing in nested.
     */
    _normalizeUserSettingsFromContentScriptData(data) {
        if (!data || typeof data !== 'object') return {};
        const nested = data.user_settings && typeof data.user_settings === 'object'
            ? { ...data.user_settings }
            : {};
        const legacyTopLevelKeys = [
            'icon_size', 'use_image_icons', 'enable_mouse_over_text', 'user_sound_enabled',
            'use_cached_rankings', 'force_lite_mode', 'low_resources_mode', 'suppress_nonfatal_warning_notifications',
            'sidecar_enabled', 'streamer_overlay_enabled', 'ud_intercept_extraction_enabled', 'ghost_enable_button_container',
            'ghost_enable_player_card', 'ghost_enable_draft_board', 'ud_xhr_replay_disabled',
            'ud_debug_ignore_legacy_collision_rules'
        ];
        for (let i = 0; i < legacyTopLevelKeys.length; i++) {
            const k = legacyTopLevelKeys[i];
            if (data[k] !== undefined && nested[k] === undefined) {
                nested[k] = data[k];
            }
        }
        // Same as background hydrate: tag prefs may live on the top-level settings object.
        for (let ti = 0; ti < TAG_ICON_USER_SETTING_KEYS.length; ti++) {
            const k = TAG_ICON_USER_SETTING_KEYS[ti];
            if (data[k] !== undefined && nested[k] === undefined) {
                nested[k] = data[k];
            }
        }
        if (data.tag_icon_exposure_display !== undefined && nested.tag_icon_exposure_display === undefined) {
            nested.tag_icon_exposure_display = data.tag_icon_exposure_display;
        }
        if (data.ud_exposure_aggregate_slates !== undefined && nested.ud_exposure_aggregate_slates === undefined) {
            nested.ud_exposure_aggregate_slates = data.ud_exposure_aggregate_slates;
        }
        if (data.dk_exposure_aggregate_slates !== undefined && nested.dk_exposure_aggregate_slates === undefined) {
            nested.dk_exposure_aggregate_slates = data.dk_exposure_aggregate_slates;
        }
        if (data.exposure_aggregate_across_sites !== undefined && nested.exposure_aggregate_across_sites === undefined) {
            nested.exposure_aggregate_across_sites = data.exposure_aggregate_across_sites;
        }
        return nested;
    }

    /**
     * Apply a partial or full user_settings object: this.user_settings, tag_icon_settings, overlay model, UI hooks.
     * @returns {{ tag_icons_changed: boolean }}
     */
    _applyUserSettingsPatch(userSettings) {
        if (!userSettings || typeof userSettings !== 'object') {
            return { tag_icons_changed: false };
        }
        const prevTagSnapshot = JSON.stringify(this.tag_icon_settings || {});
        const next = { ...this.user_settings };
        if (userSettings.icon_size !== undefined) {
            next.icon_size = String(userSettings.icon_size);
        }
        if (userSettings.use_image_icons !== undefined) {
            next.use_image_icons = !!userSettings.use_image_icons;
        }
        if (userSettings.enable_mouse_over_text !== undefined) {
            next.enable_mouse_over_text = !!userSettings.enable_mouse_over_text;
        }
        if (userSettings.user_sound_enabled !== undefined) {
            next.user_sound_enabled = !!userSettings.user_sound_enabled;
        }
        if (userSettings.use_cached_rankings !== undefined) {
            next.use_cached_rankings = !!userSettings.use_cached_rankings;
        }
        if (userSettings.force_lite_mode !== undefined) {
            next.force_lite_mode = !!userSettings.force_lite_mode;
        }
        if (userSettings.low_resources_mode !== undefined) {
            next.low_resources_mode = !!userSettings.low_resources_mode;
        }
        if (userSettings.suppress_nonfatal_warning_notifications !== undefined) {
            next.suppress_nonfatal_warning_notifications = !!userSettings.suppress_nonfatal_warning_notifications;
        }
        if (userSettings.sidecar_enabled !== undefined) {
            next.sidecar_enabled = !!userSettings.sidecar_enabled;
        }
        if (userSettings.streamer_overlay_enabled !== undefined) {
            next.streamer_overlay_enabled = !!userSettings.streamer_overlay_enabled;
        }
        if (userSettings.ud_intercept_extraction_enabled !== undefined) {
            next.ud_intercept_extraction_enabled = !!userSettings.ud_intercept_extraction_enabled;
        }
        if (userSettings.ghost_enable_button_container !== undefined) {
            next.ghost_enable_button_container = !!userSettings.ghost_enable_button_container;
        }
        if (userSettings.ghost_enable_player_card !== undefined) {
            next.ghost_enable_player_card = !!userSettings.ghost_enable_player_card;
        }
        if (userSettings.ghost_enable_draft_board !== undefined) {
            next.ghost_enable_draft_board = !!userSettings.ghost_enable_draft_board;
        }
        if (userSettings.ud_xhr_replay_disabled !== undefined) {
            next.ud_xhr_replay_disabled = !!userSettings.ud_xhr_replay_disabled;
        }
        if (userSettings.ud_debug_ignore_legacy_collision_rules !== undefined) {
            next.ud_debug_ignore_legacy_collision_rules = !!userSettings.ud_debug_ignore_legacy_collision_rules;
        }
        const prevExposureAgg = this.user_settings.exposure_aggregate_across_sites === true;
        if (userSettings.exposure_aggregate_across_sites !== undefined) {
            next.exposure_aggregate_across_sites = !!userSettings.exposure_aggregate_across_sites;
        } else if (next.exposure_aggregate_across_sites === undefined) {
            next.exposure_aggregate_across_sites = false;
        }
        const prevUdExposureAggSlates = this.user_settings.ud_exposure_aggregate_slates === true;
        if (userSettings.ud_exposure_aggregate_slates !== undefined) {
            next.ud_exposure_aggregate_slates = !!userSettings.ud_exposure_aggregate_slates;
        } else if (next.ud_exposure_aggregate_slates === undefined) {
            next.ud_exposure_aggregate_slates = false;
        }
        const prevDkExposureAggSlates = this.user_settings.dk_exposure_aggregate_slates === true;
        if (userSettings.dk_exposure_aggregate_slates !== undefined) {
            next.dk_exposure_aggregate_slates = !!userSettings.dk_exposure_aggregate_slates;
        } else if (next.dk_exposure_aggregate_slates === undefined) {
            next.dk_exposure_aggregate_slates = false;
        }
        const prevTagIconCompact = this.user_settings.tag_icon_compact === true;
        if (userSettings.tag_icon_compact !== undefined) {
            next.tag_icon_compact = !!userSettings.tag_icon_compact;
        } else if (next.tag_icon_compact === undefined) {
            next.tag_icon_compact = false;
        }
        const prevExposureDisplay = this.user_settings.tag_icon_exposure_display;
        if (userSettings.tag_icon_exposure_display !== undefined) {
            const raw = String(userSettings.tag_icon_exposure_display);
            if (raw === 'fees_only' || raw === 'percent_only' || raw === 'default') {
                next.tag_icon_exposure_display = raw;
            } else {
                next.tag_icon_exposure_display = 'default';
            }
        }
        if (next.tag_icon_exposure_display === undefined) {
            next.tag_icon_exposure_display = 'default';
        }
        this.user_settings = next;

        const tagBase = { ...(this.tag_icon_settings || {}) };
        for (let ti = 0; ti < TAG_ICON_USER_SETTING_KEYS.length; ti++) {
            const k = TAG_ICON_USER_SETTING_KEYS[ti];
            if (userSettings[k] !== undefined) {
                tagBase[k] = !!userSettings[k];
            } else if (tagBase[k] === undefined) {
                tagBase[k] = !!TAG_ICON_DEFAULTS[k];
            }
        }
        this.tag_icon_settings = tagBase;
        const tag_icons_changed = JSON.stringify(this.tag_icon_settings) !== prevTagSnapshot;
        const exposure_display_changed = prevExposureDisplay !== next.tag_icon_exposure_display;
        const exposure_agg_changed = prevExposureAgg !== (next.exposure_aggregate_across_sites === true);
        const exposure_slate_agg_changed = prevUdExposureAggSlates !== (next.ud_exposure_aggregate_slates === true);
        const exposure_dk_slate_agg_changed = prevDkExposureAggSlates !== (next.dk_exposure_aggregate_slates === true);
        const tag_icon_compact_changed = prevTagIconCompact !== (next.tag_icon_compact === true);

        if (this.overlay_manager?.model && userSettings.user_sound_enabled !== undefined) {
            this.overlay_manager.model.set('sound_enabled', !!userSettings.user_sound_enabled);
        }
        this.overlay_manager?.refresh_sound_button_visual?.();
        this.overlay_manager?.refresh_loading_animation?.();
        this.overlay_manager?.sync_sidecar_visibility?.();
        this.overlay_manager?.sync_streamer_overlay_visibility?.();
        if (userSettings.streamer_overlay_enabled !== undefined) {
            this.overlay_manager?.refresh_displayed_picks_for_settings?.();
        }
        this.overlay_manager?.refresh_ud_xhr_replay_controls?.();
        if (userSettings.force_lite_mode !== undefined) {
            this.overlay_manager?.refresh_legup_button_icon?.();
        }
        if (userSettings.suppress_nonfatal_warning_notifications !== undefined) {
            this.refresh_overlay_notification();
        }
        if (tag_icons_changed || tag_icon_compact_changed || exposure_display_changed || exposure_agg_changed || exposure_slate_agg_changed || exposure_dk_slate_agg_changed) {
            this.overlay_manager?.refresh_displayed_picks_for_settings?.();
        }
        return { tag_icons_changed };
    }

    async load_settings_from_background(timeout_ms = 5000) {
        try {
            const response = await this.send_port_request('GET_SETTINGS', {
                scope: 'content_script',
                keys: CONTENT_SETTINGS_KEYS
            }, timeout_ms);
            const data = response?.settings || {};
            const userSettings = this._normalizeUserSettingsFromContentScriptData(data);
            this._applyUserSettingsPatch(userSettings);

            if (data?.static_settings?.season_stage !== undefined) {
                this.state_data.season_stage = data.static_settings.season_stage;
            }
            
            // Store static_settings for access by content scripts
            if (data?.static_settings) {
                this.state_data.static_settings = data.static_settings;
            }

            // Sync overlay dropdown settings to model if overlay manager exists
            if (this.overlay_manager?.model && data?.overlay) {
                this.overlay_manager.sync_overlay_settings_from_background().catch(err => {
                    console.error('[CS] Failed to sync overlay settings from load_settings:', err);
                });
            }

            return this.user_settings;
        } catch (err) {
            const is_timeout = err && String(err.message || '').includes('Request timeout');
            const log = is_timeout ? console.debug : console.error;
            log('[load_settings_from_background] failed', err);
            return this.user_settings;
        }
    }

    async handle_init() {
        // DOM detection is intentionally tolerant because these sites frequently change CSS modules.
        // UnderDog (app.underdogsports.com) currently exposes the deposit area via `data-testid="deposit-balance-link"`.
        const ud_deposit_button =
            document.querySelector('[data-testid="deposit-balance-link"]') ||
            document.querySelector('[data-testid="deposit-balance"]');

        const dk_dom_ready_element =
            typeof find_draft_kings_dom_ready_element === 'function'
                ? find_draft_kings_dom_ready_element()
                : document.querySelector('a[data-test-id="deposit-link"].draftkings');
        const logo_img       = document.querySelector('header.js-header img.c-logo__img[src="https://www.legendaryupside.com/content/images/2024/03/Leg-Up_Light-Mode-Logo_Darker-Gradient-1.png"]');
        const draft_test     = document.getElementById('draftTestPage');
        
        const onLegendaryUpsideHost = typeof is_legendary_upside_url === 'function'
            && is_legendary_upside_url(window.location.href);
        const initLogData = {
            ud_deposit_button: !!ud_deposit_button,
            dk_dom_ready_element: !!dk_dom_ready_element,
            logo_img: !!logo_img,
            legendary_upside_host: !!onLegendaryUpsideHost,
            draft_test: !!draft_test,
            dom_ready: this.state_data.dom_ready,
            page_context: this.state_data.page_context
        };
        
        // Prefer the legacy header logo (fast path). If the theme changed the image/DOM, still sync on www.legendaryupside.com.
        if (logo_img || onLegendaryUpsideHost) {
            this.state_data.page_context = 'legendary_upside';
            this.transition_to(STATE.LEGUP_ACCOUNT_SYNC);
            return;
        }

        if (!this.state_data.dom_ready && (ud_deposit_button || dk_dom_ready_element || draft_test)) {
            this.state_data.dom_ready = true;
            if (ud_deposit_button) {
                this.state_data.page_context = 'underdog';
                this.state_data.is_underdog_page = true;
            }
            else if (dk_dom_ready_element) {
                this.state_data.page_context = 'draftkings';
            }
            else if (draft_test) {
                this.state_data.page_context = 'draft_test';
            }
            else {
            }
        }
        if (['underdog', 'draftkings', 'draft_test'].includes(this.state_data.page_context)) {
            this.transition_to(STATE.INIT_OVERLAY);
            return;
        }
        // Otherwise (no matching DOM yet), we'll loop until DOM appears.
    }

    handle_legup_account_sync() {
        if (this.state_data.page_context !== 'legendary_upside') {
            return;
        }

        const now = Date.now();
        const interval = this.state_data.has_initialized_auth_loop ? this.LONG_AUTH_CHECK_INTERVAL : this.AUTH_CHECK_INTERVAL;
        if (now - this.state_data.last_auth_check < interval) return;
        this.state_data.last_auth_check = now;

        check_and_fetch_member_data(signedIn => {
            if (signedIn && !this.state_data.has_initialized_auth_loop) {
                this.state_data.has_initialized_auth_loop = true;
            } else if (!signedIn && !this.state_data.has_initialized_auth_loop) {
            } else {
            }
        });
    }

    handle_overlay_init() {
        // Ensure overlay_manager exists (should be created after settings load, but handle race condition)
        if (!this.overlay_manager) {
            this.overlay_manager = new Overlay_Manager(this);
        }
        
        if (!this.overlay_manager.is_initialized) {
            this.overlay_manager.initialize();
            this.overlay_manager.toggle_visibility(true);
            this.overlay_manager.sync_mini_mode_for_page();
            
            // Update notification based on current session data (if available)
            // This ensures notification is correct even if session was set before overlay init
            if (this.session_data && (this.session_data.user_uuid !== null || this.session_data.allow_rankings !== null)) {
                this.update_auth_notification();
            } else {
                this.refresh_overlay_notification();
            }
            
            this.send_port_request('GET_SESSION_DATA')
                .then((resp) => {
                    if (resp?.session_data) {
                        this.set_session_from_response(resp.session_data);
                        // update_auth_notification is called from set_session_from_response
                    }
                })
                .catch((err) => {
                });
        }
        if (!this.state_data.environment_ready) {
            this.send_port_request('GET_ENVIRONMENT')
                .then((resp) => {
                    if (resp?.env) {
                        this.state_data.env_value = resp.env;
                        this.state_data.environment_ready = true;
                    }
                })
                .catch((err) => {
                });
        }
        if (!this.state_data.session_ready) {
            this.send_port_request('GET_SESSION_DATA')
                .then((resp) => {
                    if (resp?.session_data) {
                        this.set_session_from_response(resp.session_data);
                        // update_auth_notification is called from set_session_from_response
                    }
                })
                .catch((err) => {
                });
        } else {
            // Session is already ready, but make sure notification is up to date
            // This handles the case where session was set before overlay was initialized
            this.update_auth_notification();
        }
        // Periodically poll for session data updates (e.g., when user signs in via another tab)
        const now = Date.now();
        const SESSION_POLL_INTERVAL = 2000; // Poll every 2 seconds for session updates
        if (now - this.state_data.last_session_poll >= SESSION_POLL_INTERVAL) {
            this.state_data.last_session_poll = now;
            this.send_port_request('GET_SESSION_DATA')
                .then((resp) => {
                    if (resp?.session_data) {
                        const old_allow_rankings = this.session_data?.allow_rankings;
                        const new_allow_rankings = resp.session_data.allow_rankings;
                        this.set_session_from_response(resp.session_data);
                        // If allow_rankings changed, update notification
                        if (old_allow_rankings !== new_allow_rankings) {
                            // update_auth_notification is called from set_session_from_response
                        }
                    }
                })
                .catch((err) => {
                    // Silently fail - session polling is best effort
                });
        }

        if (
            this.state_data.environment_ready &&
            this.state_data.session_ready &&
            this.get_session_access_level() !== 'none'
        ) {
            this.transition_to(STATE.EXTRACTION);
        }
    }

    _build_request_from_draft_result(draft_result, dropdownValues, site_name = null) {
        if (!draft_result || !draft_result.draft) {
            return null;
        }
        
        const draft = draft_result.draft;
        const advancement_structure = draft_result.advancement_structure || null;
        const tournament_info = draft_result.tournament_info || null;
        
        const algo_type = dropdownValues.algo_type || 'sim';
        const format_type = dropdownValues.format_type || 'standard';
        const ranking_set = dropdownValues.ranking_set || 'legup';
        
        // Calculate current_roster from draft and attach to draft
        const picks = draft.picks || [];
        const pick_slot = draft.pick_slot;
        const draft_size = draft.draft_size;
        const num_rounds = draft.num_rounds;
        const current_roster = generate_current_roster(picks, pick_slot, draft_size, num_rounds);
        const draft_with_roster = { ...draft, current_roster };

        // Build request object
        const request_data = {
            algo_type: algo_type,
            ranking_set: ranking_set,
            format_type: format_type,
            advancement_structure: advancement_structure,
            tournament_info: tournament_info,
            draft: draft_with_roster
        };

        const scoring = this._resolve_scoring_for_request(draft_result, site_name);
        if (scoring) {
            request_data.scoring = scoring;
        }
        
        // Generate request_identifier
        request_data.request_identifier = generate_request_identifier(request_data);
        
        // Set use_cached_rankings (will be overridden in send_rankings_request if force_poll is set)
        request_data.use_cached_rankings = this.user_settings.use_cached_rankings || false;
        
        // Set num_picks and rankings_needed for all sites (used to validate incoming ranking responses)
        const draft_id = draft.draft_id;
        const num_picks = picks.length;
        if (draft_id) {
            request_data.num_picks = num_picks;
            const rankings_needed = {
                draft_id: draft_id,
                num_picks: num_picks,
                request_identifier: request_data.request_identifier
            };
            // Legacy fields maintained for compatibility
            this.state_data.rankings_needed = rankings_needed;
            this.state_data.current_draft_context = {
                draft_id: draft_id,
                request_identifier: request_data.request_identifier,
                num_picks: num_picks,
                site_name: site_name,
                algo_type: algo_type,
                ranking_set: ranking_set,
                format_type: format_type,
                last_updated: Date.now()
            };

            if (this.overlay_manager) {
                this.overlay_manager.set_advancement_structure_on_model(advancement_structure);
                if (this.overlay_manager.update_top_bar_from_state) {
                    this.overlay_manager.update_top_bar_from_state({
                        request_identifier: request_data.request_identifier
                    });
                }
            }
        }
        
        return request_data;
    }

    _legup_schedule_calcs_enabled() {
        const staticSettings = this.state_data.static_settings;
        if (staticSettings && Object.prototype.hasOwnProperty.call(staticSettings, 'schedule_calcs_enabled')) {
            return !!staticSettings.schedule_calcs_enabled;
        }
        return true;
    }

    async _get_legup_background_datasets() {
        const TTL_MS = 5 * 60 * 1000;
        const now = Date.now();
        if (this._legup_datasets_cache && (now - this._legup_datasets_cache.fetched_at) < TTL_MS) {
            return this._legup_datasets_cache.data;
        }
        const keys = ['merged_ud_bbm', 'merged_dk_bbm', 'bbm_teams', 'team_override'];
        const responses = await Promise.all(
            keys.map((key) => this.send_port_request('GET_DATASET', { key }).catch(() => null))
        );
        const data = {};
        for (let i = 0; i < keys.length; i++) {
            const resp = responses[i];
            if (resp?.status === 'ok' && resp.dataset) {
                data[keys[i]] = resp.dataset;
            }
        }
        this._legup_datasets_cache = { data, fetched_at: now };
        return data;
    }

    async _build_legup_tagged_picks_from_request(draft_request) {
        if (!draft_request?.draft) return null;
        if (this.state_data.season_stage !== 'regular') {
            return null;
        }

        const draft = draft_request.draft;
        const datasets = await this._get_legup_background_datasets();
        const mergedKey = mergedDatasetKeyForSite(draft.site_name);
        const mergedDoc = datasets[mergedKey];
        if (!mergedDoc) {
            return null;
        }

        let customRankings = null;
        const formatType = draft_request.format_type || 'standard';
        const rankingSet = draft_request.ranking_set || 'legup';
        const resolvedRankingSet = resolveLegUpRankingSet(rankingSet, formatType, draft_request.scoring || null);
        if (resolvedRankingSet === 'custom') {
            try {
                const rankingsResp = await this.send_port_request('GET_USER_RANKINGS_DATASETS');
                const customKey = userRankingsDatasetKeyForSite(draft.site_name);
                const datasetKeys = rankingsResp?.datasets && typeof rankingsResp.datasets === 'object'
                    ? Object.keys(rankingsResp.datasets)
                    : [];
                const customDs = customKey && rankingsResp?.datasets ? rankingsResp.datasets[customKey] : null;
                customRankings = Array.isArray(customDs?.rankings) ? customDs.rankings : [];
                const first = customRankings[0] && typeof customRankings[0] === 'object'
                    ? customRankings[0]
                    : null;
                const fetchPayload = {
                    site_name: draft.site_name || null,
                    customKey,
                    datasetKeys,
                    rankingSet,
                    resolvedRankingSet,
                    rankingsLen: customRankings.length,
                    firstEntryKeys: first ? Object.keys(first).slice(0, 12) : [],
                    firstHasUdId: !!(first && (first.ud_id != null || first.udId != null)),
                    firstHasDkId: !!(first && (first.dk_id != null || first.dkId != null)),
                    firstHasId: !!(first && first.id != null),
                };
                const fetchSig = [
                    fetchPayload.customKey,
                    fetchPayload.rankingsLen,
                    fetchPayload.firstEntryKeys.join(','),
                    fetchPayload.firstHasUdId,
                    fetchPayload.firstHasId,
                ].join('|');
                if (this._custom_rankings_fetch_debug_sig !== fetchSig) {
                    this._custom_rankings_fetch_debug_sig = fetchSig;
                }
            } catch (err) {
                customRankings = [];
            }
        }

        const result = buildLegUpTaggedPicks({
            draft,
            rankingSet,
            formatType,
            scoring: draft_request.scoring || null,
            mergedDoc,
            bbmTeamsDoc: datasets.bbm_teams,
            teamOverrideDoc: datasets.team_override,
            scheduleCalcsEnabled: this._legup_schedule_calcs_enabled(),
            customRankings,
            draftSelections: await this._get_legup_draft_selections(draft.site_name),
            resortForAdpOverride: draft_request.resort_for_adp_override === true,
            adpOverrideEnabled: this._is_dev_or_local_env(),
            cachedState: this.state_data.legup_player_lists
        });

        if (result?.cachedState) {
            this.state_data.legup_player_lists = result.cachedState;
        }

        if (resolvedRankingSet === 'custom' && Array.isArray(result?.picks) && result.picks.length) {
            const top = result.picks.slice(0, 5).map((p) => ({
                name: p?.full_name || p?.fullName || p?.name || null,
                ud_id: p?.ud_id ?? p?.udId ?? null,
                dk_id: p?.dk_id ?? p?.dkID ?? null,
                user_rank: p?.user_rank ?? null,
            }));
            const topSig = top.map((p) => `${p.ud_id || p.dk_id}:${p.user_rank}`).join(',');
            if (this._custom_rankings_picks_debug_sig !== topSig) {
                this._custom_rankings_picks_debug_sig = topSig;
                if (this._is_dev_or_local_env()) {
                    const log_data = {
                        rankingSet,
                        resolvedRankingSet,
                        picksLen: result.picks.length,
                        top,
                    };
                }
            }
        }

        return result?.picks || null;
    }

    async _handle_legup_local_rankings(draft_request) {
        if (!draft_request?.draft) return;

        try {
            const picks = await this._build_legup_tagged_picks_from_request(draft_request);
            if (!Array.isArray(picks)) {
                return;
            }

            if (this.state_data.pending_request_timeout) {
                clearTimeout(this.state_data.pending_request_timeout);
                this.state_data.pending_request_timeout = null;
            }
            this.state_data.rankings_loading = false;
            if (this.overlay_manager?.model) {
                this.overlay_manager.model.set('rankings_loading', false);
            }
            this.overlay_manager?.refresh_loading_animation?.();

            const draft = draft_request.draft;
            const site_name = (draft.site_name || '').toLowerCase();
            const use_ud = site_name.includes('underdog');
            const draft_picks = draft.picks || [];
            const picked_ids = draft_picks
                .map((p) => (use_ud ? p.ud_id : p.dk_id))
                .filter((id) => id != null && id !== '');
            if (this.overlay_manager?.model) {
                this.overlay_manager.model.set('picked_ids', picked_ids);
            }

            const rankings_needed = {
                draft_id: draft.draft_id,
                num_picks: draft_request.num_picks ?? draft_picks.length,
                request_identifier: draft_request.request_identifier
            };

            const normalized_msg = {
                picks,
                advancement_structure: draft_request.advancement_structure || {},
                request_identifier: draft_request.request_identifier,
                algo_type: draft_request.algo_type,
                rankings_needed
            };

            this.last_recommended = normalized_msg;
            this.message_queue.push(normalized_msg);
            this.process_message_queue();
        } catch (err) {
            console.error('[FSM] LegUp local rankings failed', err);
        }
    }

    _get_dropdown_values() {
        const overlay_model = this.overlay_manager?.model;
        return {
            algo_type: overlay_model?.get?.('algo_type') || 'sim',
            ranking_set: overlay_model?.get?.('ranking_set') || 'legup',
            format_type: overlay_model?.get?.('format_type') || 'standard'
        };
    }

    _warnLegacyPlayerMapCollisionDiagnostics(datasets) {
        const pm = datasets && datasets.player_map_ud;
        if (!pm) {
            return;
        }
        const rawList = pm.legacy_lookup_raw_collisions;
        if (rawList && rawList.length) {
            const udLegacyCsRawSummary = { count: rawList.length, collisions: rawList };
        }
        const unhandledList = pm.legacy_lookup_unhandled_collisions;
        if (unhandledList && unhandledList.length) {
            const udLegacyCsUnhandledSummary = { count: unhandledList.length, collisions: unhandledList };
        }
    }

    _tournament_title_haystack(draft_result) {
        if (!draft_result) {
            return { haystack: '', title_parts: [], tournament_info: {} };
        }
        const tournament_info = draft_result.tournament_info || {};
        const title_parts = [];
        if (typeof tournament_info.title === 'string') {
            title_parts.push(tournament_info.title);
        }
        if (typeof tournament_info.contest_style_name === 'string') {
            title_parts.push(tournament_info.contest_style_name);
        }
        if (typeof tournament_info.description === 'string') {
            title_parts.push(tournament_info.description);
        }
        if (typeof tournament_info.contest_type === 'string') {
            title_parts.push(tournament_info.contest_type);
        }
        if (typeof draft_result.draft?.custom_title === 'string') {
            title_parts.push(draft_result.draft.custom_title);
        }
        return {
            haystack: title_parts.join(' ').toLowerCase(),
            title_parts,
            tournament_info
        };
    }

    _resolve_scoring_for_request(draft_result, site_name = null) {
        // Explicit scoring from test draft (or future extractors) wins.
        const explicit = draft_result && draft_result.scoring;
        if (explicit != null && String(explicit).trim() !== '') {
            return String(explicit).trim().toLowerCase();
        }
        return this._infer_scoring_from_draft(draft_result, site_name);
    }

    _infer_scoring_from_draft(draft_result, site_name = null) {
        // Scoring-variant Underdog slates (PPR, TEP) stay format_type=standard. Scoring is
        // resolved from the whitelisted slate key the tournament summary attached to
        // tournament_info (UD_SLATE_KEY_TO_SCORING); a whitelisted slate not in that map
        // uses the site default. The title haystack is only a fallback for drafts whose
        // slate key could not be resolved.
        const site = typeof site_name === 'string' ? site_name.toLowerCase() : '';
        if (site && site !== 'underdog' && site !== 'ud') {
            return null;
        }
        const slateKey = draft_result?.tournament_info?.slate_key;
        if (typeof slateKey === 'string' && slateKey) {
            return Object.prototype.hasOwnProperty.call(UD_SLATE_KEY_TO_SCORING, slateKey)
                ? UD_SLATE_KEY_TO_SCORING[slateKey]
                : null;
        }
        const { haystack } = this._tournament_title_haystack(draft_result);
        if (haystack.includes('ppr')) {
            return 'fppr';
        }
        return null;
    }

    _update_format_type_from_draft(draft_result, site_name) {
        // Test draft page: format_type is chosen manually in the bottom bar.
        if (site_name === 'draft_test' || (typeof is_test_draft_url === 'function' && is_test_draft_url(window.location.href))) {
            return;
        }
        const model = this.overlay_manager?.model;
        if (!model) return;
        const next = this._infer_format_type_from_draft(draft_result, site_name);
        if (next && model.get('format_type') !== next) {
            model.set('format_type', next);
            this.state_data.legup_player_lists = null;
        }
    }

    _update_scoring_from_draft(draft_result, site_name) {
        // Mirrors the scoring the rankings request will carry onto the overlay model so the
        // bottom bar can apply the ranking-set policy (e.g. hide Custom on PPR, ADP-only on TEP).
        // Runs on the test draft page too: its scoring select flows through draft_result.scoring.
        const model = this.overlay_manager?.model;
        if (!model) return;
        const next = this._resolve_scoring_for_request(draft_result, site_name) || null;
        if (model.get('scoring') !== next) {
            model.set('scoring', next);
            this.state_data.legup_player_lists = null;
        }
    }

    _infer_format_type_from_draft(draft_result, site_name) {
        const season_stage = this.state_data.season_stage;
        if (season_stage === 'playoffs') {
            return 'playoff';
        }

        const fallback = 'standard';
        if (!draft_result) {
            const dbg = { site_name: site_name || null, season_stage, reason: 'missing_draft_result' };
            // console.log('[FSM] format_type infer fallback=standard', dbg);
            return fallback;
        }

        const { haystack, title_parts, tournament_info } = this._tournament_title_haystack(draft_result);
        if (season_stage !== 'playoffs' && tournament_info.is_marathon === true) {
            return 'marathon';
        }

        if (!haystack) {
            const dbg = {
                site_name: site_name || null,
                season_stage,
                reason: 'empty_title_haystack',
                title_parts,
                tournament_info_keys: tournament_info && typeof tournament_info === 'object' ? Object.keys(tournament_info) : [],
                tournament_info_title: typeof tournament_info.title === 'string' ? tournament_info.title : null,
                tournament_info_contest_type: typeof tournament_info.contest_type === 'string' ? tournament_info.contest_type : null,
                draft_custom_title: typeof draft_result.draft?.custom_title === 'string' ? draft_result.draft.custom_title : null
            };
            // console.log('[FSM] format_type infer fallback=standard', dbg);
            return fallback;
        }

        if (haystack.includes('weekly winner')) return 'weekly_winners';
        if (haystack.includes('superflex') || haystack.includes('super flex') || haystack.includes('super-flex')) {
            return 'superflex';
        }
        if (haystack.includes('eliminator')) return 'eliminator';
        if (haystack.includes('marathon')) return 'marathon';
        if (haystack.includes('sprint')) return 'sprint';

        const dbg = {
            site_name: site_name || null,
            season_stage,
            reason: 'no_keyword_match',
            haystack,
            title_parts,
            tournament_info_title: typeof tournament_info.title === 'string' ? tournament_info.title : null,
            tournament_info_contest_type: typeof tournament_info.contest_type === 'string' ? tournament_info.contest_type : null,
            draft_custom_title: typeof draft_result.draft?.custom_title === 'string' ? draft_result.draft.custom_title : null
        };
        // console.log('[FSM] format_type infer fallback=standard', dbg);
        return fallback;
    }

    _schedule_extraction_if_bypass_pending() {
        if (!this.state_data.bypass_rankings_cache_once || this.current_state !== STATE.EXTRACTION) {
            return;
        }
        queueMicrotask(() => {
            if (!this.state_data.bypass_rankings_cache_once || this.current_state !== STATE.EXTRACTION) {
                return;
            }
            try {
                this.handle_extraction();
            } catch (err) {
                console.error('[FSM] extraction nudge after cache bypass failed', err);
            }
        });
    }

    _check_cached_rankings(rankings_needed = null, reason = 'tick', options = {}) {
        // force: event-driven pull (background says fresh results just landed) —
        // bypass the tick-skip/debounce throttles and the currently-showing guard,
        // which exist to keep the periodic loop cheap, not to gate a one-shot nudge.
        const force = options.force === true;

        if (this.is_legup_lite_mode()) {
            return;
        }

        // If the user manually reloaded rankings (RESET_DRAFT_STATE), do not fetch cached rankings while the
        // backend/background are clearing caches. This prevents a brief "re-populate from cache" flicker.
        if (this.reset_draft_state_in_progress) {
            return;
        }

        // Low resources mode (user setting): skip cache check when tab is in background and user not on clock
        if (this.user_settings.low_resources_mode && !this._low_resources_should_send_rankings()) {
            return;
        }

        const now = Date.now();
        const cache_state = this.state_data.cache_check_state || {};

        if (!force) {
            // Skip every other extraction tick to reduce cache spam (tick runs ~600ms)
            if (cache_state.skip_next_tick) {
                cache_state.skip_next_tick = false;
                return;
            }
            cache_state.skip_next_tick = true;

            const last_check = cache_state.last_cache_check_time || 0;
            // Debounce rapid checks
            if (now - last_check < 300) {
                return;
            }
        }

        // Build rankings_needed from current context if not provided
        if (!rankings_needed) {
            const ctx = this.state_data.current_draft_context;
            if (ctx?.draft_id) {
                rankings_needed = {
                    draft_id: ctx.draft_id,
                    num_picks: ctx.num_picks,
                    request_identifier: ctx.request_identifier
                };
            }
        }

        if (!rankings_needed || !rankings_needed.draft_id) {
            // Nothing to check
            return;
        }

        const currently_showing = this.state_data.currently_showing_request_identifier;
        const should_check = force ||
            !currently_showing ||
            rankings_needed.request_identifier !== currently_showing ||
            reason === 'context_change';

        if (!should_check) {
            return;
        }

        const overlay_model = this.overlay_manager?.model;
        const algo_type = overlay_model?.get?.('algo_type') || null;

        cache_state.last_cache_check_time = now;
        cache_state.last_requested_rankings_needed = rankings_needed;

        const checkCachedRankingsLogData = {
            rankings_needed: rankings_needed.request_identifier || 'most-recent',
            currently_showing: currently_showing,
            draft_id: rankings_needed.draft_id,
            num_picks: rankings_needed.num_picks,
            algo_type: algo_type,
            reason: reason
        };

        if (this.bg_port && this.bg_connected) {
            this.bg_port.postMessage({
                action: 'CHECK_CACHED_RANKINGS',
                data: {
                    rankings_needed: rankings_needed,
                    algo_type: algo_type
                }
            });
        } else {
        }
    }

    _clear_picks_for_navigation(draft_result) {
        const url = window.location.href;
        const urlUdDraftId =
            typeof get_underdog_draft_id_from_url === 'function'
                ? get_underdog_draft_id_from_url(url)
                : null;

        const current_ctx = this.state_data.current_draft_context;
        const currently_displayed = current_ctx?.draft_id ? current_ctx : null;

        // Extraction can return null/undefined this tick (XHR not intercepted yet, map miss, etc.)
        // while the tab is still on a draft URL. Do not wipe ud_intercepted_drafts or same-draft cache.
        if (!draft_result || !draft_result?.draft?.draft_id) {
            const stillSameUdDraft =
                urlUdDraftId &&
                currently_displayed &&
                currently_displayed.draft_id === urlUdDraftId;

            if (currently_displayed && !stillSameUdDraft) {
                this._clear_displayed_picks();
            }

            if (urlUdDraftId) {
                // Stale last_extraction from a prior draft before /v2/drafts XHR lands (applyUdXhrIntercept clears it too).
                const lastDraftId = this.state_data.last_extraction_result?.draft?.draft_id;
                if (lastDraftId && lastDraftId !== urlUdDraftId) {
                    this.state_data.last_extraction_result = null;
                    this.state_data.last_draft_status_span_text = null;
                } else if (!lastDraftId) {
                    this.state_data.last_draft_status_span_text = null;
                }
                return;
            }

            this.state_data.last_extraction_result = null;
            this.state_data.last_draft_status_span_text = null;
            this.state_data.ud_intercepted_drafts = {};
            this.state_data.ud_intercept_revision_by_draft = {};
            this._clear_otc_state();
            return;
        }

        const draft_id = draft_result.draft.draft_id;

        // Context may still show the previous draft_id on first tick after navigation; do not clear
        // ud_intercepted_drafts / last_extraction here — they were just filled for this draft_id and
        // the /v2/drafts XHR handler already busts cache when a new snapshot arrives.
        if (currently_displayed && currently_displayed.draft_id !== draft_id) {
            const draftChangedLogData = {
                old_draft_id: currently_displayed.draft_id,
                new_draft_id: draft_id
            };
            this._clear_displayed_picks();
            this.state_data.queue_size_changed = false;
        }
    }

    handle_extraction() {
        const url = window.location.href;

        if (!is_underdog_url(url) && this.state_data) {
            this.state_data.ud_fsm_extraction_draft_id = null;
            this.state_data.ud_underdog_extraction_skip_ticks_remaining = 0;
        }

        if (this.overlay_manager?.is_initialized) {
            this.overlay_manager.sync_mini_mode_for_page();
        }
        
        // If season_stage is "offseason", skip extraction
        if (this.state_data.season_stage === 'offseason') {
            return;
        }
        
        // Periodically poll for session data updates (e.g., when user signs out or session expires)
        // Use longer interval (1 minute) since we're already in extraction state
        const now = Date.now();
        const SESSION_POLL_INTERVAL = 60 * 1000; // Poll every 1 minute for session updates
        if (now - this.state_data.last_session_poll >= SESSION_POLL_INTERVAL) {
            this.state_data.last_session_poll = now;
            this.send_port_request('GET_SESSION_DATA')
                .then((resp) => {
                    if (resp?.session_data) {
                        const old_allow_rankings = this.session_data?.allow_rankings;
                        const new_allow_rankings = resp.session_data.allow_rankings;
                        this.set_session_from_response(resp.session_data);
                        // If allow_rankings changed, update notification
                        if (old_allow_rankings !== new_allow_rankings) {
                            // update_auth_notification is called from set_session_from_response
                        }
                    }
                })
                .catch((err) => {
                    // Silently fail - session polling is best effort
                });
        }
        
        const processExtractionResult = (draft_result, site_name) => {
            this._clear_picks_for_navigation(draft_result);
            if (!draft_result) return;
            this._update_format_type_from_draft(draft_result, site_name);
            this._update_scoring_from_draft(draft_result, site_name);
            const dropdownValues = this._get_dropdown_values();
            const prev_ctx = this.state_data.current_draft_context || {};
            const prev_request_id = prev_ctx.request_identifier || null;
            const prev_num_picks = prev_ctx.num_picks || 0;
            const draft_request = this._build_request_from_draft_result(draft_result, dropdownValues, site_name);
            if (draft_request) {
                const extractionSource = (typeof EXTRACTION_ERROR_WARNING_SOURCE !== 'undefined')
                    ? EXTRACTION_ERROR_WARNING_SOURCE
                    : 'extraction_error';
                this.clear_urgent_warning_notification(extractionSource);
                this.extraction_error_details = [];

                const context_changed = prev_request_id !== draft_request.request_identifier ||
                    prev_num_picks !== (draft_request.num_picks || 0);
                this._check_and_trigger_otc_notification(draft_request);
                if (this.is_legup_lite_mode()) {
                    this._handle_legup_local_rankings(draft_request).catch((err) => {
                        console.error('[FSM] LegUp local rankings handler failed', err);
                    });
                } else {
                    this.send_rankings_request(draft_request);
                    if (context_changed || !this.state_data.currently_showing_request_identifier) {
                        const rankings_needed = {
                            draft_id: draft_request.draft?.draft_id,
                            num_picks: draft_request.num_picks,
                            request_identifier: draft_request.request_identifier
                        };
                        this._check_cached_rankings(rankings_needed, 'context_change');
                    }
                }
            }
        };
        
        if (is_underdog_url(url)) {
            // Handle Bestball button for NFL section (runs on all Underdog pages, before extraction)
            handle_underdog_bestball_button();

            if (is_underdog_exposure_url(url)) {
                maybe_tick_exposure_mode(this, url);
                processExtractionResult(null, 'underdog');
            } else {
                const draftIdForTick =
                    typeof get_underdog_draft_id_from_url === 'function'
                        ? get_underdog_draft_id_from_url(url)
                        : null;
                const udActivePageUrl =
                    typeof is_active_url === 'function' && is_active_url(url);
                const udNonopTickAfterNavEnabled =
                    this.state_data?.static_settings?.ud_enable_nonop_tick_after_nav === true;
                const udScheduleNonopTickAfterNav =
                    udNonopTickAfterNavEnabled && udActivePageUrl;

                if (this.state_data.ud_underdog_extraction_skip_ticks_remaining > 0) {
                    this.state_data.ud_underdog_extraction_skip_ticks_remaining--;
                    observe_underdog_queue(this);
                    observe_underdog_queue_size_changes(this);
                    return;
                }

                const prevFsmDraftId = this.state_data.ud_fsm_extraction_draft_id;
                if (prevFsmDraftId != null && draftIdForTick != null && String(prevFsmDraftId) !== String(draftIdForTick)) {
                    this._hardResetUnderdogDraftViewState({
                        reason: 'underdog_draft_id_changed',
                        from: prevFsmDraftId,
                        to: draftIdForTick
                    });
                    this.state_data.ud_fsm_extraction_draft_id = draftIdForTick;
                    this.state_data.ud_underdog_extraction_skip_ticks_remaining =
                        udScheduleNonopTickAfterNav ? 1 : 0;
                    observe_underdog_queue(this);
                    observe_underdog_queue_size_changes(this);
                    return;
                }
                if (prevFsmDraftId != null && draftIdForTick == null) {
                    this._hardResetUnderdogDraftViewState({ reason: 'left_underdog_draft_url' });
                    this.state_data.ud_fsm_extraction_draft_id = null;
                    this.state_data.ud_underdog_extraction_skip_ticks_remaining =
                        udScheduleNonopTickAfterNav ? 1 : 0;
                    observe_underdog_queue(this);
                    observe_underdog_queue_size_changes(this);
                    return;
                }

                if (draftIdForTick != null) {
                    this.state_data.ud_fsm_extraction_draft_id = draftIdForTick;
                }

                if (typeof maybe_sync_ud_site_username === 'function') {
                    maybe_sync_ud_site_username(this);
                }

                const dispatchGen = this.state_data.ud_extraction_dispatch_generation || 0;
                extract_underdog_draft_data(this, url)
                    .then((draft_result) => {
                        if (dispatchGen !== (this.state_data.ud_extraction_dispatch_generation || 0)) {
                            return;
                        }
                        processExtractionResult(draft_result, 'underdog');
                    })
                    .catch((err) => {
                        console.error('Error extracting Underdog draft data:', err);
                        if (dispatchGen !== (this.state_data.ud_extraction_dispatch_generation || 0)) {
                            return;
                        }
                        this.report_extraction_error('extract_underdog', err);
                        processExtractionResult(null, 'underdog');
                    });
                observe_underdog_queue(this);
                observe_underdog_queue_size_changes(this);
            }
        } else if (is_draft_kings_url(url)) {
            if (typeof maybe_sync_dk_site_username === 'function') {
                maybe_sync_dk_site_username(this);
            }
            if (is_draft_kings_lineup_url(url)) {
                maybe_tick_exposure_mode(this, url);
                processExtractionResult(null, 'draftkings');
            } else {
                extract_draft_kings_draft_data(this)
                    .then(draft_result => {
                        processExtractionResult(draft_result, 'draftkings');
                    })
                    .catch(err => {
                        console.error('Error extracting DraftKings draft data:', err);
                        this.report_extraction_error('extract_draftkings', err);
                        processExtractionResult(null, 'draftkings');
                    });
                observe_draft_kings_queue(this);
            }
        } else if (is_test_draft_url(url)) {
            try {
                const draft_result = extract_test_draft_data(this);
                processExtractionResult(draft_result, 'draft_test');
            } catch (err) {
                console.error('Error extracting test draft data:', err);
                this.report_extraction_error('extract_draft_test', err);
                processExtractionResult(null, 'draft_test');
            }
        } else {
            // Not on any recognized draft page - clear picks if we have any displayed
            processExtractionResult(null, null);
        }
        
        // Periodic cache check using smart logic (debounced internally)
        this._check_cached_rankings(null, 'tick');
        
        // Queue functionality removed - playerQueue is legacy global variable
        // Queue star icons will be implemented in new overlay_picks_container.js when needed
    }

    
    _is_user_pick_in_snake_draft(pick_number, pick_slot, draft_size) {
        if (!pick_number || !pick_slot || !draft_size) {
            return false;
        }

        const round = Math.ceil(pick_number / draft_size);
        const position_in_round = ((pick_number - 1) % draft_size) + 1;

        // Snake draft: odd rounds go 1->N, even rounds go N->1
        let seat_for_this_pick;
        if (round % 2 === 1) {
            seat_for_this_pick = position_in_round;
        } else {
            seat_for_this_pick = draft_size - position_in_round + 1;
        }

        return seat_for_this_pick === pick_slot;
    }

    /**
     * Best-effort Underdog OTC when full extraction is skipped (unsupported contest).
     * Uses DOM onTheClock class for border; intercept pick count for sound dedup when available.
     */
    _check_underdog_otc_best_effort(draft_id) {
        if (!draft_id) {
            return;
        }

        const on_the_clock_element = document.querySelector(
            '[class*="styles__currentUser__"][class*="styles__onTheClock__"]'
        );
        const is_on_the_clock = !!on_the_clock_element;

        let current_pick_number = null;
        const wrap = this.state_data.ud_intercepted_drafts?.[String(draft_id)];
        const picks = wrap?.draft?.picks;
        if (Array.isArray(picks)) {
            current_pick_number = picks.length + 1;
        }

        const current_otc_flag = this.overlay_manager?.model?.get('user_otc') || false;

        if (is_on_the_clock) {
            if (!current_otc_flag) {
                this.overlay_manager?.model?.set('user_otc', true);
                if (this._is_dev_or_local_env()) {
                }
            }
        } else {
            if (current_otc_flag) {
                this.overlay_manager?.model?.set('user_otc', false);
            }
            return;
        }

        // Sound dedup key: prefer live pick count from intercept; otherwise edge-trigger only
        if (current_pick_number == null) {
            if (current_otc_flag) {
                return;
            }
            current_pick_number = `dom_otc_${Date.now()}`;
        }

        const last_otc_sound = this.state_data.last_otc_sound;
        const already_played =
            last_otc_sound &&
            last_otc_sound.draft_id === draft_id &&
            last_otc_sound.pick_number === current_pick_number;

        if (already_played) {
            return;
        }

        this.state_data.last_otc_sound = {
            draft_id: draft_id,
            pick_number: current_pick_number
        };

        if (this._is_dev_or_local_env()) {
        }

        if (this.overlay_manager?.trigger_otc_notification) {
            this.overlay_manager.trigger_otc_notification(draft_id, current_pick_number);
        }
    }

    
    _check_and_trigger_otc_notification(draft_request) {
        if (!draft_request || !draft_request.draft) {
            return;
        }

        const draft = draft_request.draft;
        const draft_id = draft.draft_id;
        const pick_slot = draft.pick_slot;
        const picks = draft.picks || [];
        const current_pick_number = picks.length + 1;
        const draft_size = draft.draft_size;

        // Prefer simple class-based check for Underdog (faster, works even for unsupported drafts)
        // Fall back to calculation if class check not available (e.g., span missing when UI elements open)
        let is_on_the_clock = false;
        if (draft.site_name === 'Underdog') {
            // Check for both currentUser and onTheClock classes together (matches legacy behavior)
            // This ensures we only match the user's own cell, not other users' cells
            const on_the_clock_element = document.querySelector('[class*="styles__currentUser__"][class*="styles__onTheClock__"]');
            if (on_the_clock_element) {
                is_on_the_clock = true;
            } else {
                // Class check not available (span missing), fall back to calculation
                is_on_the_clock = this._is_user_pick_in_snake_draft(current_pick_number, pick_slot, draft_size);
            }
        } else {
            // For non-Underdog sites, use calculation
            is_on_the_clock = this._is_user_pick_in_snake_draft(current_pick_number, pick_slot, draft_size);
        }
        
        const current_otc_flag = this.overlay_manager?.model?.get('user_otc') || false;
        
        if (is_on_the_clock) {
            if (!current_otc_flag) {
                // Flag transitioning from false to true - user just went on the clock
                this.overlay_manager?.model?.set('user_otc', true);
            } else {
                // console.log(`User still on the clock: pick_slot=${pick_slot}, current_pick=${current_pick_number}`);
            }
        } else {
            if (current_otc_flag) {
                // Flag transitioning from true to false - user is no longer on the clock
                this.overlay_manager?.model?.set('user_otc', false);
            } else {
                // console.log(`Not on the clock: pick_slot=${pick_slot}, current_pick=${current_pick_number}`);
            }
            return; // Don't play sound if not on the clock
        }

        // User is on the clock - check if we should play sound
        // Check last_otc_sound state to see if we've already played for this draft/pick combo
        const last_otc_sound = this.state_data.last_otc_sound;
        const already_played = last_otc_sound && 
                               last_otc_sound.draft_id === draft_id && 
                               last_otc_sound.pick_number === current_pick_number;

        if (already_played) {
            // console.log(`Already played sound for draft_id=${draft_id}, pick_number=${current_pick_number}`);
            return;
        }

        this.state_data.last_otc_sound = {
            draft_id: draft_id,
            pick_number: current_pick_number
        };

        // Trigger OTC notification (will play sound and show green border)

        if (this.overlay_manager?.trigger_otc_notification) {
            this.overlay_manager.trigger_otc_notification(draft_id, current_pick_number);
        } else {
        }
    }

    handle_error() {
        this.stop();
    }



    _is_in_lobby() {
        const url = window.location.href;
        
        // Check for Underdog lobby state
        if (is_underdog_draft_url(url)) {
            const desktop_section = document.querySelector('[class^="styles__draftDetailsSectionDesktop__"]');
            if (desktop_section) {
                const drafting_cells = desktop_section.querySelectorAll('[class*="styles__draftingCell__"]');
                if (drafting_cells.length > 0) {
                    // Check if draft has started (look for "fake" bars that appear when waiting)
                    const has_fake_bar = Array.from(drafting_cells).some(cell => 
                        cell.querySelector('[class*="styles__fakeBar__"]')
                    );
                    const draft_started = !has_fake_bar;
                    if (!draft_started) {
                        return true; // In lobby
                    }
                }
            }
        }
        
        // Check for DraftKings lobby / waiting-room state
        if (typeof is_draft_kings_waiting_room_url === 'function' && is_draft_kings_waiting_room_url(url)) {
            return true; // Tournament waiting room
        }
        if (is_draft_kings_draft_url(url)) {
            const enteredButtonContainer = document.querySelector('.ContestDetails_completed');
            if (enteredButtonContainer) {
                const enteredButton = enteredButtonContainer.querySelector('button.DKButtonLegacy_dk-btn-inactive[disabled]');
                if (enteredButton) {
                    const buttonText = enteredButton.textContent.trim();
                    if (buttonText.includes('Entered')) {
                        return true; // In lobby
                    }
                }
            }
        }
        
        return false; // Not in lobby
    }

    process_message_queue() {
        if (this.message_queue.length === 0) {
            return;
        }

        // Don't process messages if we're not on a draft page
        // This prevents picks from reappearing after clearing when navigating away
        const url = window.location.href;
        const is_on_draft_page = is_draft_url(url) || is_test_draft_url(url);
        
        if (!is_on_draft_page) {
            // Clear the queue since we're not on a draft page
            this.message_queue = [];
            // Force a fresh rankings request next time we detect a valid draft page
            // This avoids getting stuck with no rankings after navigating away and back
            this.state_data.force_poll = true;
            return;
        }

        // Don't process messages if we're in the lobby (draft hasn't started yet)
        // This prevents picks from flashing in the lobby before the draft starts
        // Check debug flag to skip lobby check
        const skip_lobby_check = this.state_data?.skip_lobby_check_debug || false;
        if (!skip_lobby_check && this._is_in_lobby()) {
            // Clear picks if they're displayed (safety check in case picks were displayed before entering lobby)
            if (this.state_data.currently_displayed) {
                this._clear_displayed_picks();
            }
            // Clear the queue since we're in the lobby
            this.message_queue = [];
            return;
        }

        const request = this.message_queue.shift();
        if (this.overlay_manager && this.overlay_manager.is_initialized && request.picks) {
            // Additional safety check: verify the request_identifier matches the currently displayed draft
            // Only check this if we have a currently_showing_request_identifier (meaning we've displayed picks before)
            const currently_showing = this.state_data.currently_showing_request_identifier;
            const request_id = request.request_identifier;
            const current_ctx = this.state_data.current_draft_context;
            const request_rankings_needed = request.rankings_needed || this.state_data.rankings_needed || null;
            const request_draft_id = request_rankings_needed?.draft_id || null;
            if (!this._cachedRankingsDraftMatchesActiveTab(request_draft_id)) {
                // console.log('[CS] Skipping message queue item - draft_id does not match tab URL / live context', {
                //     request_draft_id,
                //     href: typeof window !== 'undefined' ? window.location.href : null,
                //     live_draft_id: current_ctx?.draft_id ?? null,
                //     request_identifier: request.request_identifier
                // });
                return;
            }
            const request_num_picks = request_rankings_needed?.num_picks ?? null;
            const displayed = this.state_data.currently_displayed;
            const displayed_num_picks = displayed?.num_picks ?? null;
            const displayed_draft_id = displayed?.draft_id || current_ctx?.draft_id || null;
            const baseline_for_backwards = displayed_num_picks;
            const live_num_picks = current_ctx?.num_picks ?? null;

            // Never show cached picks for a different draft
            if (displayed_draft_id && request_draft_id && request_draft_id !== displayed_draft_id) {
                const crossDraftLog = {
                    request_draft_id: request_draft_id,
                    displayed_draft_id: displayed_draft_id,
                    request_identifier: request_id
                };
                return;
            }

            // Skip updates that would regress the UI to an older pick count (unless we're bootstrapping
            // after navigation and intentionally showing the best available cache before a forced fresh fetch).
            // Only compare to what was actually painted; live context must not define "backwards" when overlay is blank.
            const is_backwards = baseline_for_backwards !== null && request_num_picks !== null &&
                request_num_picks < baseline_for_backwards;
            if (is_backwards && !this.state_data.post_cache_fresh_fetch_needed) {
                const backwardsLog = {
                    request_num_picks: request_num_picks,
                    displayed_num_picks: baseline_for_backwards,
                    request_identifier: request_id
                };
                return;
            }

            // Allow request_identifier mismatches when stale cache is at/above what's on screen, or first paint
            // (nothing shown yet): same draft and cache num_picks at or below live — matches background stale picker.
            const allow_request_id_mismatch =
                (displayed_num_picks != null &&
                    request_num_picks != null &&
                    request_num_picks >= displayed_num_picks) ||
                (displayed_num_picks == null &&
                    currently_showing == null &&
                    request_draft_id &&
                    request_draft_id === current_ctx?.draft_id &&
                    request_num_picks != null &&
                    live_num_picks != null &&
                    Number.isFinite(request_num_picks) &&
                    Number.isFinite(live_num_picks) &&
                    request_num_picks <= live_num_picks);
            
            // If we have a currently_showing_request_identifier, only process messages that match it
            // This prevents displaying picks from a different draft unless the new message moves us forward
            const bootstrap_same_draft =
                this.state_data.post_cache_fresh_fetch_needed &&
                request_draft_id &&
                request_draft_id === current_ctx?.draft_id;

            if ((currently_showing && request_id && request_id !== currently_showing && !allow_request_id_mismatch) ||
                (!bootstrap_same_draft &&
                    current_ctx?.request_identifier &&
                    request_id &&
                    request_id !== current_ctx.request_identifier &&
                    !allow_request_id_mismatch)) {
                const skippingMessageLogData = {
                    message_id: request_id,
                    currently_showing: currently_showing,
                    current_ctx: current_ctx?.request_identifier || null,
                    request_num_picks: request_num_picks,
                    displayed_num_picks: displayed_num_picks
                };
                return;
            }

            // "Insufficient samples" error picks mean the sim endpoint is still warming up.
            // Instead of rendering the error, run the same flow as the reload button:
            // delete the stored error state from the DB, then re-request fresh rankings.
            if (this._maybe_auto_reload_for_insufficient_samples(request)) {
                return;
            }

            this.overlay_manager.update_recommended_picks(request.picks, request.request_identifier, request.advancement_structure);
            // Update currently_showing_request_identifier when picks are actually displayed
            // This ensures we track what's actually shown, not just what we received
            if (request.request_identifier) {
                this.state_data.currently_showing_request_identifier = request.request_identifier;
            }
            // Update currently_displayed metadata when picks are displayed
            // Use rankings_needed from message if available (for cached results)
            this._update_currently_displayed(request.request_identifier, request_rankings_needed);

            if (this.state_data.post_cache_fresh_fetch_needed) {
                this.state_data.post_cache_fresh_fetch_needed = false;
                this.state_data.bypass_rankings_cache_once = true;
            }
        } else {
            this.message_queue.unshift(request);
            setTimeout(() => this.process_message_queue(), 1000);
        }
    }

    
    _update_currently_displayed(request_identifier, rankings_needed_from_msg = null) {
        if (!request_identifier) {
            return;
        }

        // Prefer rankings_needed from message (for cached results), otherwise use state_data
        let rankings_needed = rankings_needed_from_msg || this.state_data.rankings_needed;
        const draft_id = rankings_needed?.draft_id || this.state_data.current_draft_context?.draft_id || null;
        const num_picks = rankings_needed?.num_picks ?? this.state_data.current_draft_context?.num_picks ?? null;

        this.state_data.currently_displayed = {
            request_identifier: request_identifier,
            draft_id: draft_id,
            num_picks: num_picks
        };

        // Do not overwrite current_draft_context here — it must stay aligned with the latest extraction /
        // _build_request_from_draft_result. Stale CHECK_CACHED payloads used to clobber live pick counts and
        // produced impossible top-bar deltas (e.g. negative "picks ago").

        if (this.overlay_manager?.update_top_bar_from_state) {
            this.overlay_manager.update_top_bar_from_state({
                request_identifier: request_identifier
            });
        }
    }

    _clear_otc_state() {
        if (this.overlay_manager?.model?.get('user_otc')) {
            this.overlay_manager.model.set('user_otc', false);
        }
    }

    _clear_displayed_picks() {
        this._clear_otc_state();

        // Clear picks from overlay
        if (this.overlay_manager?.picks_container) {
            this.overlay_manager.picks_container.clear();
        }
        
        // Clear picks and picked_ids from model
        if (this.overlay_manager?.model) {
            this.overlay_manager.model.set('picks', []);
            this.overlay_manager.model.set('picked_ids', []);
        }

        // Clear top bar text, unsupported-contest banner, and advancement (prevents bleed from prior draft)
        this.state_data.unsupported_contest = null;
        if (this.overlay_manager?.model) {
            this.overlay_manager.model.set('top_bar_message', { main_text: '', hover_text: '' });
        }
        this.overlay_manager?.clear_advancement_structure?.();

        // Clear queued players; reset queue snapshot so switching drafts with the same queued names
        // still runs update_stars_from_queue (JSON snapshot would otherwise match and skip).
        if (this.state_data.queue) {
            this.state_data.queue.players = [];
            this.state_data.queue.last_logged_queue_state = null;
        }

        // Update stars from queue (will hide all stars since queue is now empty)
        if (this.overlay_manager?.picks_container) {
            this.overlay_manager.picks_container.update_stars_from_queue([]);
        }

        // Clear currently_displayed metadata
        this.state_data.currently_displayed = null;
        this.state_data.currently_showing_request_identifier = null;
        this.state_data.rankings_needed = null;
        this.state_data.legup_player_lists = null;
        this.state_data.current_draft_context = {
            draft_id: null,
            request_identifier: null,
            num_picks: 0,
            site_name: null,
            algo_type: null,
            ranking_set: null,
            format_type: null,
            last_updated: Date.now()
        };

        // Clear message queue to prevent old messages from repopulating picks after navigation
        // This prevents flickering where picks reappear from queued messages
        this.message_queue = [];

        this.state_data.post_cache_fresh_fetch_needed = true;

    }

    _abortUnderdogRankingsInFlight() {
        if (this.state_data.pending_request_timeout) {
            clearTimeout(this.state_data.pending_request_timeout);
            this.state_data.pending_request_timeout = null;
        }
        const rid = this.state_data.last_sent?.request_identifier || null;
        if (this.bg_port && this.bg_connected && rid) {
            try {
                this.bg_port.postMessage({
                    action: 'STOP_POLLING',
                    request_identifier: rid
                });
            } catch (e) {
                // ignore
            }
        }
        this.state_data.last_sent = null;
        this.state_data.rankings_loading = false;
        if (this.overlay_manager?.model) {
            this.overlay_manager.model.set('rankings_loading', false);
        }
        this.overlay_manager?.refresh_loading_animation?.();
    }

    _resetUdActiveNavStateAfterDraftSwitch() {
        const sd = this.state_data;
        if (!sd) {
            return;
        }
        sd.ud_active_nav_track_id = null;
        sd.ud_active_nav_changed_at = null;
        sd.ud_active_nav_stable_ticks = 0;
        sd.ud_active_nav_pending_log_complete = false;
    }

    /**
     * Full reset when Underdog draft id changes or user leaves a draft URL: overlay, queues, in-flight rankings, extraction cache.
     */
    _hardResetUnderdogDraftViewState(reason) {
        this.state_data.ud_extraction_dispatch_generation =
            (this.state_data.ud_extraction_dispatch_generation || 0) + 1;
        this._clear_displayed_picks();
        this._abortUnderdogRankingsInFlight();
        this.state_data.last_extraction_result = null;
        this.state_data.last_draft_status_span_text = null;
        this._resetUdActiveNavStateAfterDraftSwitch();
    }

    is_background_runtime_alive() {
        try {
            return !!(typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id);
        } catch {
            return false;
        }
    }

    is_background_communication_broken_error(err) {
        if (this.background_communication_broken || !this.is_background_runtime_alive()) {
            return true;
        }
        const msg = (err && (err.message || String(err))) || '';
        if (/extension context invalidated/i.test(msg)) {
            return true;
        }
        try {
            const last = chrome.runtime?.lastError?.message;
            if (last && /extension context invalidated/i.test(last)) {
                return true;
            }
        } catch {
            return true;
        }
        return false;
    }

    _background_communication_error_detail(err) {
        if (err == null || err === '') return '';
        const raw = typeof err === 'string' ? err : (err.message || String(err));
        const trimmed = String(raw).trim().replace(/\s+/g, ' ');
        if (!trimmed) return '';
        return trimmed.length > 160 ? `${trimmed.slice(0, 157)}...` : trimmed;
    }

    _escape_notification_text(text) {
        return String(text)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
    }

    /**
     * Content↔background messaging is impossible until page refresh (usually dead chrome.runtime).
     * Shows a generic refresh hint and accumulates up to N unique error lines, then no-ops.
     */
    handle_background_communication_broken(reason, err = null) {
        const max_unique = (typeof BACKGROUND_COMMUNICATION_BROKEN_MAX_UNIQUE_ERRORS === 'number')
            ? BACKGROUND_COMMUNICATION_BROKEN_MAX_UNIQUE_ERRORS
            : 5;
        const details = this.background_communication_broken_errors || (this.background_communication_broken_errors = []);
        const detail = this._background_communication_error_detail(err);

        if (this.background_communication_broken) {
            if (details.length >= max_unique) {
                return;
            }
            if (!detail || details.includes(detail)) {
                return;
            }
            details.push(detail);
            console.error('[CS] Background communication broken — additional error', reason || '', detail);
            this._refresh_background_communication_broken_warning();
            return;
        }

        this.background_communication_broken = true;
        this.bg_connected = false;

        if (this._reconnect_timer) {
            clearTimeout(this._reconnect_timer);
            this._reconnect_timer = null;
        }
        if (this._keepalive_timer) {
            clearInterval(this._keepalive_timer);
            this._keepalive_timer = null;
        }
        this._clear_keepalive_watchdog();
        if (this._helloTimer) {
            clearTimeout(this._helloTimer);
            this._helloTimer = null;
        }

        if (this.bg_port) {
            try { this.bg_port.disconnect(); } catch {}
            this.bg_port = null;
        }

        for (const [, { reject, timeout }] of this.pending_port_requests) {
            clearTimeout(timeout);
            reject(new Error('Background communication broken'));
        }
        this.pending_port_requests.clear();

        if (detail) {
            details.push(detail);
        }
        console.error('[CS] Background communication broken — page refresh required', reason || '', detail || err || '');
        this._refresh_background_communication_broken_warning();
    }

    _refresh_background_communication_broken_warning() {
        let message = (typeof BACKGROUND_COMMUNICATION_BROKEN_WARNING_MESSAGE !== 'undefined')
            ? BACKGROUND_COMMUNICATION_BROKEN_WARNING_MESSAGE
            : 'Something went wrong. Please refresh this page.';
        const details = this.background_communication_broken_errors || [];
        if (details.length > 0) {
            message += '<br><br>' + details.map((d) => this._escape_notification_text(d)).join('<br>');
        }
        const source = (typeof BACKGROUND_COMMUNICATION_BROKEN_WARNING_SOURCE !== 'undefined')
            ? BACKGROUND_COMMUNICATION_BROKEN_WARNING_SOURCE
            : 'background_communication_broken';

        if (typeof this.set_urgent_warning_notification === 'function') {
            this.set_urgent_warning_notification(message, source, { kind: 'page_refresh' });
        }
    }

    report_extraction_error(reason, err = null) {
        const max_unique = (typeof EXTRACTION_ERROR_MAX_UNIQUE_ERRORS === 'number')
            ? EXTRACTION_ERROR_MAX_UNIQUE_ERRORS
            : 5;
        const details = this.extraction_error_details || (this.extraction_error_details = []);
        const detail = this._background_communication_error_detail(err);
        const hadDetails = details.length > 0;

        if (details.length >= max_unique) {
            return;
        }
        if (detail) {
            if (details.includes(detail)) {
                return;
            }
            details.push(detail);
        } else if (hadDetails) {
            return;
        }

        console.error('[CS] Extraction error — page refresh may help; contact support if persistent', reason || '', detail || err || '');
        this._refresh_extraction_error_warning();
    }

    _refresh_extraction_error_warning() {
        let message = (typeof EXTRACTION_ERROR_WARNING_MESSAGE !== 'undefined')
            ? EXTRACTION_ERROR_WARNING_MESSAGE
            : 'Something went wrong extracting draft data. Please refresh this page. If this keeps happening, contact support.';
        const details = this.extraction_error_details || [];
        if (details.length > 0) {
            message += '<br><br>' + details.map((d) => this._escape_notification_text(d)).join('<br>');
        }
        const source = (typeof EXTRACTION_ERROR_WARNING_SOURCE !== 'undefined')
            ? EXTRACTION_ERROR_WARNING_SOURCE
            : 'extraction_error';

        if (typeof this.set_urgent_warning_notification === 'function') {
            this.set_urgent_warning_notification(message, source, { kind: 'page_refresh' });
        }
    }

    send_port_request(action, data = {}, timeout_ms = 5000) {
        return new Promise((resolve, reject) => {
            if (this.background_communication_broken || !this.is_background_runtime_alive()) {
                this.handle_background_communication_broken('send_port_request');
                reject(new Error('Background communication broken'));
                return;
            }
            if (!this.bg_port || !this.bg_connected) {
                reject(new Error('Port not connected'));
                return;
            }
            
            const request_id = `req_${Date.now()}_${++this.port_request_counter}`;
            
            const timeout = setTimeout(() => {
                if (this.pending_port_requests.has(request_id)) {
                    this.pending_port_requests.delete(request_id);
                    reject(new Error(`Request timeout after ${timeout_ms}ms`));
                }
            }, timeout_ms);
            
            this.pending_port_requests.set(request_id, { resolve, reject, timeout });
            
            try {
                this.bg_port.postMessage({
                    action,
                    request_id,
                    ...data
                });
            } catch (err) {
                clearTimeout(timeout);
                this.pending_port_requests.delete(request_id);
                if (this.is_background_communication_broken_error(err)) {
                    this.handle_background_communication_broken('send_port_request:postMessage', err);
                }
                reject(err);
            }
        });
    }

    open_bg_port() {
        if (this.background_communication_broken) {
            return;
        }
        if (!this.is_background_runtime_alive()) {
            this.handle_background_communication_broken('open_bg_port:runtime-dead');
            return;
        }

        if (this.bg_port) {
            try { this.bg_port.disconnect(); } catch { }
            this.bg_port = null;
        }

        // Clear any existing keepalive timer
        if (this._keepalive_timer) {
            clearInterval(this._keepalive_timer);
            this._keepalive_timer = null;
        }

        let port;
        try {
            port = chrome.runtime.connect({ name: 'content' });
            if (chrome.runtime.lastError) {
                const errMsg = chrome.runtime.lastError.message;
                if (this.is_background_communication_broken_error({ message: errMsg })) {
                    this.handle_background_communication_broken('open_bg_port:lastError', errMsg);
                    return;
                }
                console.error('[CS] Failed to connect to background:', errMsg);
                this.bg_connected = false;
                this.schedule_port_reconnect();
                return;
            }
        } catch (err) {
            if (this.is_background_communication_broken_error(err)) {
                this.handle_background_communication_broken('open_bg_port:connect', err);
                return;
            }
            console.error('[CS] Error connecting to background:', err);
            this.bg_connected = false;
            this.schedule_port_reconnect();
            return;
        }
        
        this.bg_port = port;
        this.bg_connected = true;
        if (typeof flushPendingFantasySiteUsername === 'function') {
            flushPendingFantasySiteUsername(this);
        }
        // Orphan streamer panels (e.g. stale DOM after BG restart) reconcile before BG_HELLO races settings.
        this.overlay_manager?.sync_streamer_overlay_visibility?.();

        const timeSinceLastHello = this.debug.lastHelloAt ? Date.now() - this.debug.lastHelloAt : null;
        const wasReconnect = this.debug.rehydrateAttempts > 0;
        
        if (wasReconnect) {
            const logData = {
                rehydrateAttempts: this.debug.rehydrateAttempts,
                timeSinceLastHello: timeSinceLastHello ? Math.round(timeSinceLastHello / 1000) + 's' : 'never',
                timeSinceLastKeepaliveAck: this.debug.lastKeepaliveAck ? Math.round((Date.now() - this.debug.lastKeepaliveAck) / 1000) + 's' : 'never'
            };
        } else {
        }

        // --- NEW: watchdog to force a snapshot if hello is late ---
        this._helloSeen = false;
        if (this._helloTimer) clearTimeout(this._helloTimer);
        this._helloTimer = setTimeout(() => {
            if (!this._helloSeen) {
                try { 
                    port.postMessage({ action: 'CS_GET_STATE' }); 
                } catch (err) {
                    if (this.is_background_communication_broken_error(err)) {
                        this.handle_background_communication_broken('hello-watchdog', err);
                        return;
                    }
                    console.error('[CS] Failed to send CS_GET_STATE:', err);
                }
            }
        }, 600);
        
        try { 
            port.postMessage({ action: 'CS_HELLO' }); 
        } catch (err) {
            if (this.is_background_communication_broken_error(err)) {
                this.handle_background_communication_broken('CS_HELLO', err);
                return;
            }
            console.error('[CS] Failed to send CS_HELLO:', err);
        }

        // Start keepalive timer to prevent background script from being terminated
        this._start_keepalive();

        port.onDisconnect.addListener(() => {
            if (this.background_communication_broken) {
                return;
            }
            if (!this.is_background_runtime_alive()) {
                this.handle_background_communication_broken('port:onDisconnect');
                return;
            }

            const disconnectTime = Date.now();
            const timeSinceLastHello = this.debug.lastHelloAt ? disconnectTime - this.debug.lastHelloAt : null;
            const timeSinceLastKeepaliveAck = this.debug.lastKeepaliveAck ? disconnectTime - this.debug.lastKeepaliveAck : null;
            
            const logData = {
                rehydrateAttempts: this.debug.rehydrateAttempts + 1,
                timeSinceLastHello: timeSinceLastHello ? Math.round(timeSinceLastHello / 1000) + 's' : 'never',
                timeSinceLastKeepaliveAck: timeSinceLastKeepaliveAck ? Math.round(timeSinceLastKeepaliveAck / 1000) + 's' : 'never',
                pendingRequests: this.pending_port_requests.size,
                currentlyShowingRequestIdentifier: this.state_data.currently_showing_request_identifier
            };
            
            this.debug.rehydrateAttempts++;
            performance.mark("rehydrate:start");
            this.bg_connected = false;
            
            // Stop keepalive timer when port disconnects
            if (this._keepalive_timer) {
                clearInterval(this._keepalive_timer);
                this._keepalive_timer = null;
            }
            // Stop watchdog timer when port disconnects
            this._clear_keepalive_watchdog();
            
            // Reject all pending requests
            const pendingCount = this.pending_port_requests.size;
            if (pendingCount > 0) {
            }
            for (const [request_id, { reject, timeout }] of this.pending_port_requests) {
                clearTimeout(timeout);
                reject(new Error('Port disconnected - background script may have restarted'));
            }
            this.pending_port_requests.clear();
            
            this.schedule_port_reconnect();
        });

        port.onMessage.addListener((msg) => {
            if (chrome.runtime.lastError) {
                const errMsg = chrome.runtime.lastError.message;
                if (this.is_background_communication_broken_error({ message: errMsg })) {
                    this.handle_background_communication_broken('port:onMessage', errMsg);
                    return;
                }
                console.error('[CS] Port message error:', errMsg);
                return;
            }
            
            if (msg?.request_id && this.pending_port_requests.has(msg.request_id)) {
                const { resolve, reject, timeout } = this.pending_port_requests.get(msg.request_id);
                clearTimeout(timeout);
                this.pending_port_requests.delete(msg.request_id);
                
                if (msg.status === 'ok' || msg.status === 'success') {
                    resolve(msg);
                } else {
                    reject(new Error(msg.message || 'Request failed'));
                }
                return;
            }
            
            if (msg?.action === 'BG_HELLO') {
                const isNewBoot = this.debug.lastBootId && this.debug.lastBootId !== msg.boot_id;
                const wasReconnect = this.debug.rehydrateAttempts > 0;
                
                if (isNewBoot || wasReconnect) {
                    const logData = {
                        isNewBoot: isNewBoot,
                        wasReconnect: wasReconnect,
                        oldBootId: this.debug.lastBootId,
                        newBootId: msg.boot_id,
                        helloSeq: msg.hello_seq,
                        hasSession: !!msg.session_data,
                        env: msg.env
                    };
                } else {
                }
                
                this._helloSeen = true;
                if (this._helloTimer) {
                    clearTimeout(this._helloTimer);
                    this._helloTimer = null;
                }
                this._notify_bootstrap_hello_received();
                // Reset watchdog since we got a hello (background script is alive)
                this._reset_keepalive_watchdog();

                performance.mark("rehydrate:hello");
                const hadStart = performance.getEntriesByName("rehydrate:start").length > 0;
                if (hadStart) {
                    performance.measure("rehydrate", "rehydrate:start", "rehydrate:hello");
                    const m = performance.getEntriesByName("rehydrate").pop();
                    const reconnectInfo = isNewBoot ? " (BACKGROUND RESTARTED)" : (wasReconnect ? " (RECONNECTED)" : "");
                    performance.clearMarks("rehydrate:start");
                    performance.clearMarks("rehydrate:hello");
                    performance.clearMeasures("rehydrate");
                    
                    // Reset rehydrate counter after successful reconnection
                    this.debug.rehydrateAttempts = 0;

                    if (this.current_state === STATE.EXTRACTION) {
                        this.state_data.force_poll = true;
                        this.tick();
                    }
                } else {
                }

                this.debug.lastBootId = msg.boot_id;
                this.debug.lastHelloAt = Date.now();

                const data = msg.settings || {};
                const userSettings = this._normalizeUserSettingsFromContentScriptData(data);
                this._applyUserSettingsPatch(userSettings);

                // Extract season_stage from static_settings
                if (data?.static_settings?.season_stage !== undefined) {
                    this.state_data.season_stage = data.static_settings.season_stage;
                }
                
                // Store static_settings for access by content scripts
                if (data?.static_settings) {
                    this.state_data.static_settings = data.static_settings;
                }

                // Sync overlay dropdown settings to model
                if (this.overlay_manager?.model && data?.overlay) {
                    this.overlay_manager.sync_overlay_settings_from_background().catch(err => {
                        console.error('[CS] Failed to sync overlay settings from BG_HELLO:', err);
                    });
                }

                if (msg.datasets) {
                    this.datasets = msg.datasets;
                    this._warnLegacyPlayerMapCollisionDiagnostics(msg.datasets);
                    if (typeof tryFlushPendingUdOwnershipMerge === 'function') {
                        tryFlushPendingUdOwnershipMerge(this);
                    }
                    if (typeof tryFlushPendingDkLineupsExposureMerge === 'function') {
                        tryFlushPendingDkLineupsExposureMerge(this);
                    }
                } else {
                }

                const markerGen = msg.ud_tournament_marker_clear_gen;
                if (
                    typeof markerGen === 'number' &&
                    markerGen > (this.state_data.last_seen_ud_tournament_marker_clear_gen || 0)
                ) {
                    this.state_data.last_seen_ud_tournament_marker_clear_gen = markerGen;
                    this.state_data.tournament_summary_cache = {};
                }

                if (msg.env) {
                    this.state_data.env_value = msg.env;
                    this.state_data.environment_ready = true;
                    this.overlay_manager?.sync_sidecar_visibility?.();
                    this.overlay_manager?.sync_streamer_overlay_visibility?.();
                }
                if (msg.streamer_mode_data) {
                    this.apply_streamer_mode_data(msg.streamer_mode_data);
                }
                if (msg.session_data) {
                    this.set_session_from_response(msg.session_data);
                    // update_auth_notification is called from set_session_from_response
                }
            }
            if (msg?.action === 'UPDATE_NOTIFICATION') {
                this._handle_background_auth_notification(msg);
            }
            if (msg?.action === 'RANKINGS_REQUEST_FAILED') {
                const failedRid = msg.request_identifier || null;
                if (this._is_dev_or_local_env()) {
                    const log_data = {
                        request_identifier: failedRid,
                        reason: msg.reason || null,
                        message: msg.message || null
                    };
                }
                // A failure for a superseded request (e.g. an old pick's queued request
                // dropped after a newer pick's request went out) must not clear the
                // current request's watchdog/loading state or trigger a resubmit — the
                // newer request is still legitimately pending.
                const lastSentRid = this.state_data.last_sent?.request_identifier || null;
                if (failedRid && lastSentRid && failedRid !== lastSentRid) {
                    if (this._is_dev_or_local_env()) {
                        const superseded_log_data = {
                            failed: failedRid,
                            current: lastSentRid,
                            reason: msg.reason || null
                        };
                    }
                    return;
                }
                if (this.state_data.pending_request_timeout) {
                    clearTimeout(this.state_data.pending_request_timeout);
                    this.state_data.pending_request_timeout = null;
                }
                this.state_data.rankings_loading = false;
                if (this.overlay_manager?.model) {
                    this.overlay_manager.model.set('rankings_loading', false);
                }
                this.overlay_manager?.refresh_loading_animation?.();
                if (this.bg_port && failedRid) {
                    try {
                        this.bg_port.postMessage({
                            action: 'STOP_POLLING',
                            request_identifier: failedRid
                        });
                    } catch (stopErr) {
                    }
                }
                const notice = (msg.message || '').trim()
                    || 'Rankings request failed. Refresh your session and try again.';
                const noticeType = msg.type || 'rankings_error';
                if (noticeType === 'auth_error' || noticeType === 'auth_error_update') {
                    this._handle_background_auth_notification({
                        action: 'UPDATE_NOTIFICATION',
                        message: notice,
                        type: noticeType,
                        session_data: msg.session_data || null
                    });
                } else {
                    this.set_sidecar_notification_preview(notice, noticeType);
                }
                // Orphaned poll / soft failures: one fresh non-poll with full draft payload.
                if (msg.reason === 'poll_no_results_resubmit' && this.state_data.last_sent) {
                    this.state_data.force_poll = true;
                    try {
                        this.send_rankings_request(this.state_data.last_sent);
                    } catch (retryErr) {
                    }
                }
            }
            if (msg?.action === 'UPDATE_SETTINGS' && msg.settings) {
                const data = msg.settings;
                const userSettings = this._normalizeUserSettingsFromContentScriptData(data);
                this._applyUserSettingsPatch(userSettings);

                // Extract season_stage from static_settings
                const old_season_stage = this.state_data.season_stage;
                if (data?.static_settings?.season_stage !== undefined) {
                    this.state_data.season_stage = data.static_settings.season_stage;
                }
                
                // Store static_settings for access by content scripts
                if (data?.static_settings) {
                    this.state_data.static_settings = data.static_settings;
                }

                // If season_stage changed, destroy and rebuild overlay to update dropdowns
                if (old_season_stage !== undefined && old_season_stage !== this.state_data.season_stage && this.overlay_manager) {
                    const was_initialized = this.overlay_manager.is_initialized;
                    this.overlay_manager.destroy();
                    this.overlay_manager = new Overlay_Manager(this);
                    if (was_initialized && (this.current_state === STATE.INIT_OVERLAY || this.current_state === STATE.EXTRACTION)) {
                        this.overlay_manager.initialize();
                        this.overlay_manager.toggle_visibility(true);
                    }
                }

                // Sync overlay dropdown settings to model
                if (this.overlay_manager?.model && data?.overlay) {
                    this.overlay_manager.sync_overlay_settings_from_background().catch(err => {
                        console.error('[CS] Failed to sync overlay settings from UPDATE_SETTINGS:', err);
                    });
                }
            }
            if (msg?.action === 'UPDATE_STREAMER_MODE_DATA') {
                this.apply_streamer_mode_data(msg.streamer_mode_data || null);
            }
            if (msg?.action === 'UPDATE_DATASETS' && msg.datasets) {
                this.datasets = msg.datasets;
                this._warnLegacyPlayerMapCollisionDiagnostics(msg.datasets);
                if (typeof tryFlushPendingUdOwnershipMerge === 'function') {
                    tryFlushPendingUdOwnershipMerge(this);
                }
                if (typeof tryFlushPendingDkLineupsExposureMerge === 'function') {
                    tryFlushPendingDkLineupsExposureMerge(this);
                }
            }
            if (msg?.action === 'BG_PING') {
                this.debug.lastPingAt = Date.now();
                this._note_port_health_signal('BG_PING');
                if (msg.boot_id && this.debug.lastBootId && msg.boot_id !== this.debug.lastBootId) {
                    try {
                        this.bg_port?.postMessage({ action: 'CS_GET_STATE' });
                    } catch (err) {
                        this._force_port_reconnect('boot-id-mismatch');
                    }
                }
                if (!this._pingSeenOnce) {
                    this._pingSeenOnce = true;
                }
            }
            if (msg?.action === 'BG_KEEPALIVE_ACK') {
                // Background script is alive and responding to keepalive
                this._note_port_health_signal('BG_KEEPALIVE_ACK');
            }
            if (msg?.action === 'FORCE_REPOLL') {
                console.error('[CS] *** RECEIVED FORCE_REPOLL - Draft state was cleared, will re-poll fresh data ***', msg.draft_id, this.current_state);
                this.state_data.force_poll = true;
            }
            if (msg?.action === 'RANKINGS_RESULTS_READY') {
                // Background just cached fresh results for this tab. Pull them now
                // instead of waiting for the next extraction tick — display no longer
                // depends solely on the periodic CHECK_CACHED_RANKINGS loop.
                this._note_port_health_signal('RANKINGS_RESULTS_READY');
                if (!this.reset_draft_state_in_progress) {
                    try {
                        this._check_cached_rankings(null, 'results_ready', { force: true });
                    } catch (err) {
                    }
                }
            }
            if (msg?.action === 'REFRESH_GHOST_SESSION') {
                if (this.state_data.page_context === 'legendary_upside' && typeof check_and_fetch_member_data === 'function') {
                    check_and_fetch_member_data(() => {});
                }
            }
            if (msg?.action === 'CACHED_RANKINGS_FOUND' && msg.picks) {
                if (this.reset_draft_state_in_progress) {
                    const ignoreCachedDuringResetLogData = {
                        request_identifier: msg.request_identifier,
                        draft_id: msg.draft_id,
                        is_most_up_to_date: msg.is_most_up_to_date === true
                    };
                    return;
                }

                // Get algo_type from model (single source of truth)
                const selected_algo_type = this.overlay_manager?.model?.get?.('algo_type') || null;
                const message_algo_type = msg.algo_type || null;

                if (selected_algo_type && message_algo_type && selected_algo_type !== message_algo_type) {
                    return;
                }

                const cachedMessageDraftId = msg.draft_id || msg.rankings_needed?.draft_id || null;
                if (!this._cachedRankingsDraftMatchesActiveTab(cachedMessageDraftId)) {
                    // console.log('[CS] Ignoring cached rankings - draft_id does not match tab URL / live context', {
                    //     cachedMessageDraftId,
                    //     href: typeof window !== 'undefined' ? window.location.href : null,
                    //     live_draft_id: this.state_data.current_draft_context?.draft_id ?? null,
                    //     request_identifier: msg.request_identifier
                    // });
                    return;
                }

                // console.log('[CS] Received cached rankings:', message_algo_type || selected_algo_type || null, 'is_most_up_to_date:', msg.is_most_up_to_date);

                // Only clear loading flag if these are the most up-to-date picks
                // Otherwise keep loading flag set until we get the most recent picks
                if (msg.is_most_up_to_date) {
                    if (this.state_data.pending_request_timeout) {
                        clearTimeout(this.state_data.pending_request_timeout);
                        this.state_data.pending_request_timeout = null;
                    }

                    if (this._is_dev_or_local_env()) {
                        const cachedRankingsFoundLogData = {
                            request_identifier: msg.request_identifier,
                            current_fsm_value: this.state_data.rankings_loading,
                            current_model_value: this.overlay_manager?.model?.get('rankings_loading'),
                            stack: new Error().stack.split('\n').slice(1, 4).join('\n')
                        };
                    }
                    this.state_data.rankings_loading = false;
                    if (this.overlay_manager?.model) {
                        // console.log('[FSM] Updating model.rankings_loading = false (CACHED_RANKINGS_FOUND)');
                        this.overlay_manager.model.set('rankings_loading', false);
                    }
                    this.overlay_manager?.refresh_loading_animation?.();
                } else {
                    // Keep loading flag set - these aren't the most up-to-date picks
                    const notMostUpToDateLogData = {
                        request_identifier: msg.request_identifier,
                        current_fsm_value: this.state_data.rankings_loading,
                        current_model_value: this.overlay_manager?.model?.get('rankings_loading')
                    };
                    // console.log('[CS] Cached rankings are not most up-to-date, keeping loading flag set', notMostUpToDateLogData);
                    // Sync model to match FSM state to prevent animation restart on each tick
                    if (this.overlay_manager?.model) {
                        const current_model_value = this.overlay_manager.model.get('rankings_loading');
                        if (current_model_value !== true) {
                            if (this._is_dev_or_local_env()) {
                                const syncingModelLogData = {
                                    was: current_model_value,
                                    stack: new Error().stack.split('\n').slice(1, 4).join('\n')
                                };
                            }
                            this.overlay_manager.model.set('rankings_loading', true);
                        }
                    }
                }

                const effective_algo_type = message_algo_type || selected_algo_type || null;

                // Normalize rankings_needed so downstream logic can reason about draft_id/num_picks
                const normalized_rankings_needed = msg.rankings_needed ? { ...msg.rankings_needed } : {};
                if (msg.num_picks !== undefined) {
                    normalized_rankings_needed.num_picks = msg.num_picks;
                }
                if (msg.draft_id) {
                    normalized_rankings_needed.draft_id = msg.draft_id;
                }

                const normalized_msg = {
                    picks: msg.picks,
                    advancement_structure: msg.advancement_structure || {},
                    request_identifier: msg.request_identifier,
                    algo_type: effective_algo_type,
                    rankings_needed: Object.keys(normalized_rankings_needed).length ? normalized_rankings_needed : null
                };

                // Process the picks update
                this.last_recommended = normalized_msg;
                this.message_queue.push(normalized_msg);

                if (!msg.is_most_up_to_date) {
                    this.state_data.bypass_rankings_cache_once = true;
                }

                this.process_message_queue();
                this._schedule_extraction_if_bypass_pending();
            }
            if (msg?.action === 'CACHED_RANKINGS_MISSING') {
                if (this.reset_draft_state_in_progress) {
                    return;
                }
                // Cached rankings not available - keep loading flag set
                if (this.state_data.post_cache_fresh_fetch_needed) {
                    this.state_data.post_cache_fresh_fetch_needed = false;
                    this.state_data.bypass_rankings_cache_once = true;
                }
                this._schedule_extraction_if_bypass_pending();
            }
        });
    }

    async reset_draft_seed() {
        if (this.reset_seed_in_progress) {
            return;
        }

        const draftId = this._get_current_draft_id();
        const userUuid = this.session_data?.user_uuid || null;

        if (!draftId) {
            return;
        }

        if (!userUuid) {
            return;
        }

        this.reset_seed_in_progress = true;

        // Save request_identifier before clearing it, so we can use it for draft state reset
        let savedRequestIdentifier = this.state_data.currently_showing_request_identifier;
        if (!savedRequestIdentifier && this.state_data.last_sent?.request_identifier) {
            savedRequestIdentifier = this.state_data.last_sent.request_identifier;
        }
        if (!savedRequestIdentifier && this.state_data.last_sent && typeof generate_request_identifier === 'function') {
            savedRequestIdentifier = generate_request_identifier(this.state_data.last_sent);
        }

        if (this.state_data.pending_request_timeout) {
            clearTimeout(this.state_data.pending_request_timeout);
            this.state_data.pending_request_timeout = null;
        }

        // Clear picks and draft metadata
        this._clear_displayed_picks();

        if (this._is_dev_or_local_env()) {
            const resetDraftSeedLogData = {
                stack: new Error().stack.split('\n').slice(1, 4).join('\n')
            };
        }
        this.state_data.rankings_loading = true;
        // Set force_poll to true to bypass cache and trigger fresh rankings request
        this.state_data.force_poll = true;

        this.message_queue = [];
        this.last_recommended = null;

        if (this.overlay_manager?.model) {
            // console.log('[FSM] Updating model.rankings_loading = true (reset_draft_seed)');
            this.overlay_manager.model.set('rankings_loading', true);
        }

        // Don't call show_loading() directly - let model subscription handle it via rankings_loadingChanged event
        this.overlay_manager?.refresh_loading_animation?.();

        let response;
        try {
            response = await this.send_port_request('RESET_DRAFT_SEED', {
                draft_id: draftId,
                user_uuid: userUuid
            });
        } catch (error) {
            console.error('[CS] reset_draft_seed port request failed', error);
            response = { status: 'error', message: error?.message || 'Unexpected error' };
        }

        this.reset_seed_in_progress = false;

        if (response?.status !== 'ok') {
            if (this._is_dev_or_local_env()) {
                const resetDraftSeedErrorLogData = {
                    status: response?.status,
                    stack: new Error().stack.split('\n').slice(1, 4).join('\n')
                };
            }
            this.state_data.rankings_loading = false;
            if (this.overlay_manager?.model) {
                // console.log('[FSM] Updating model.rankings_loading = false (reset_draft_seed error)');
                this.overlay_manager.model.set('rankings_loading', false);
            }
            this.overlay_manager?.refresh_loading_animation?.();
            return;
        }


        // Reset draft state (same as reload button) if we have a request_identifier
        if (savedRequestIdentifier) {
            // Temporarily restore request_identifier so reset_draft_state can use it
            this.state_data.currently_showing_request_identifier = savedRequestIdentifier;
            try {
                await this.reset_draft_state();
            } catch (error) {
                console.error('[CS] reset_draft_state failed during reset_draft_seed', error);
            }
            // Clear it again after reset_draft_state
            this.state_data.currently_showing_request_identifier = null;
        }

        // Trigger rankings refresh (same as reload button)
        if (this.overlay_manager?.trigger_rankings_refresh) {
            this.overlay_manager.trigger_rankings_refresh();
        }
    }

    async reset_draft_state() {
        if (this.reset_draft_state_in_progress) {
            return;
        }

        const draftId = this._get_current_draft_id();
        const userUuid = this.session_data?.user_uuid || null;

        if (!draftId) {
            return;
        }

        if (!userUuid) {
            return;
        }

        let requestIdentifier = this.state_data.currently_showing_request_identifier;
        if (!requestIdentifier && this.state_data.last_sent?.request_identifier) {
            requestIdentifier = this.state_data.last_sent.request_identifier;
        }
        if (!requestIdentifier && this.state_data.last_sent && typeof generate_request_identifier === 'function') {
            requestIdentifier = generate_request_identifier(this.state_data.last_sent);
        }

        if (!requestIdentifier) {
            return;
        }

        this.reset_draft_state_in_progress = true;

        if (this.state_data.pending_request_timeout) {
            clearTimeout(this.state_data.pending_request_timeout);
            this.state_data.pending_request_timeout = null;
        }

        let response;
        try {
            response = await this.send_port_request('RESET_DRAFT_STATE', {
                draft_id: draftId,
                user_uuid: userUuid,
                request_identifier: requestIdentifier
            }, 20000);
        } catch (error) {
            console.error('[CS] reset_draft_state port request failed', error);
            response = { status: 'error', message: error?.message || 'Unexpected error' };
        }

        this.reset_draft_state_in_progress = false;

        if (response?.status !== 'ok') {
            if (this._is_dev_or_local_env()) {
                const resetDraftStateErrorLogData = {
                    status: response?.status,
                    stack: new Error().stack.split('\n').slice(1, 4).join('\n')
                };
            }
            this.state_data.rankings_loading = false;
            if (this.overlay_manager?.model) {
                // console.log('[FSM] Updating model.rankings_loading = false (reset_draft_state error)');
                this.overlay_manager.model.set('rankings_loading', false);
            }
            this.overlay_manager?.refresh_loading_animation?.();
            return;
        }


        // Only after the backend confirmed its caches were cleared (and background cleared local draft cache)
        // do we touch any content-script/overlay state. This avoids a brief flash of cached rankings during reset.
        this._clear_displayed_picks();

        if (this._is_dev_or_local_env()) {
            const resetDraftStateLogData = {
                stack: new Error().stack.split('\n').slice(1, 4).join('\n')
            };
        }
        this.state_data.rankings_loading = true;
        this.state_data.force_poll = true;
        if (this.overlay_manager?.model) {
            this.overlay_manager.model.set('rankings_loading', true);
        }
        this.overlay_manager?.refresh_loading_animation?.();

        // Trigger rankings refresh after reset to get fresh rankings (force_poll bypasses cache).
        this.overlay_manager?.trigger_rankings_refresh?.();
    }

    _is_insufficient_samples_error_pick(picks) {
        if (!Array.isArray(picks) || picks.length !== 1) {
            return false;
        }
        const pick = picks[0];
        return pick?.full_name === 'error_pick' &&
            typeof pick?.error_text === 'string' &&
            pick.error_text.toLowerCase().includes('insufficient samples');
    }

    // Returns true when the message was consumed (auto-reload triggered or already in
    // progress) and must not be rendered. Returns false to fall through and render.
    _maybe_auto_reload_for_insufficient_samples(request) {
        if (!this._is_insufficient_samples_error_pick(request?.picks)) {
            return false;
        }

        if (this.reset_draft_state_in_progress) {
            // A reload is already running; drop the error pick instead of rendering it.
            return true;
        }

        const count_key = request.request_identifier || 'unknown';
        const reload_count = this.error_pick_auto_reload_counts[count_key] || 0;
        if (reload_count >= this.MAX_ERROR_PICK_AUTO_RELOADS) {
            if (this._is_dev_or_local_env()) {
                const limit_log_data = {
                    request_identifier: count_key,
                    reload_count: reload_count
                };
            }
            return false;
        }
        this.error_pick_auto_reload_counts[count_key] = reload_count + 1;

        if (this._is_dev_or_local_env()) {
            const reload_log_data = {
                request_identifier: count_key,
                attempt: reload_count + 1,
                max_attempts: this.MAX_ERROR_PICK_AUTO_RELOADS
            };
        }
        this._auto_reload_for_error_pick(request.request_identifier || null);
        return true;
    }

    async _auto_reload_for_error_pick(request_identifier) {
        // Point reset_draft_state at the error state so it deletes the right
        // users/{uuid}/drafts/{draft_id}/states/{request_identifier} doc from the DB
        // (same pattern as reset_draft_seed).
        const saved_request_identifier = this.state_data.currently_showing_request_identifier;
        if (request_identifier) {
            this.state_data.currently_showing_request_identifier = request_identifier;
        }
        try {
            await this.reset_draft_state();
        } catch (error) {
            console.error('[CS] reset_draft_state failed during insufficient-samples auto-reload', error);
        } finally {
            // reset_draft_state clears the identifier on success; if it bailed early,
            // restore whatever was actually showing.
            if (request_identifier &&
                this.state_data.currently_showing_request_identifier === request_identifier) {
                this.state_data.currently_showing_request_identifier = saved_request_identifier;
            }
        }
    }

    _get_current_draft_id() {
        const lastSent = this.state_data.last_sent;
        if (lastSent?.draft?.draft_id) {
            return lastSent.draft.draft_id;
        }

        const url = window.location.href;
        if (typeof get_underdog_draft_id_from_url === 'function') {
            const ud = get_underdog_draft_id_from_url(url);
            if (ud) return ud;
        }
        if (typeof get_draftkings_draft_id_from_url === 'function') {
            const dk = get_draftkings_draft_id_from_url(url);
            if (dk) return dk;
        }

        const draftStateElement = document.getElementById('draftStateJsonMirror');
        if (draftStateElement) {
            try {
                const parsed = JSON.parse(draftStateElement.textContent || '{}');
                const draftId = parsed?.draft?.draft_id || null;
                if (draftId) {
                    return draftId;
                }
            } catch (error) {
            }
        }

        return null;
    }

    _note_port_health_signal(source) {
        this.debug.lastKeepaliveAck = Date.now();
        this._reset_keepalive_watchdog();
    }

    _bind_port_health_listeners() {
        if (this._port_health_listeners_bound) return;
        this._port_health_listeners_bound = true;

        const onWake = () => {
            if (!document.hidden) {
                this._check_port_health('visibility');
            }
        };
        document.addEventListener('visibilitychange', onWake);
        window.addEventListener('focus', onWake);
        window.addEventListener('pageshow', onWake);
    }

    _get_last_port_health_signal_at() {
        return Math.max(
            this.debug.lastKeepaliveAck || 0,
            this.debug.lastPingAt || 0,
            this.debug.lastHelloAt || 0
        );
    }

    _check_port_health(reason) {
        if (this.background_communication_broken || !this.is_background_runtime_alive()) {
            this.handle_background_communication_broken(`port-health:${reason}`);
            return;
        }
        if (!this.bg_port && !this.bg_connected) {
            this.open_bg_port();
            return;
        }

        const now = Date.now();
        const lastSignal = this._get_last_port_health_signal_at();
        const staleMs = lastSignal ? now - lastSignal : Infinity;

        if (this.bg_connected && staleMs > this.PORT_STALE_THRESHOLD_MS) {
            this._force_port_reconnect(`stale:${reason}`);
            return;
        }

        if (this.bg_port && this.bg_connected) {
            try {
                this.bg_port.postMessage({ action: 'CS_KEEPALIVE' });
                this._last_keepalive_sent = now;
                this._reset_keepalive_watchdog();
            } catch (err) {
                if (this.is_background_communication_broken_error(err)) {
                    this.handle_background_communication_broken('keepalive:health-check', err);
                    return;
                }
                this._force_port_reconnect(`keepalive-failed:${reason}`);
                return;
            }

            if (this.current_state === STATE.EXTRACTION) {
                this.tick();
            }
        }
    }

    _force_port_reconnect(reason) {
        if (this.background_communication_broken || !this.is_background_runtime_alive()) {
            this.handle_background_communication_broken(`force-reconnect:${reason}`);
            return;
        }
        this.bg_connected = false;

        if (this._reconnect_timer) {
            clearTimeout(this._reconnect_timer);
            this._reconnect_timer = null;
        }
        this._reconnect_delay = 500;

        if (this.bg_port) {
            try { this.bg_port.disconnect(); } catch {}
            this.bg_port = null;
        }

        this.open_bg_port();
    }

    _start_keepalive() {
        // Clear any existing keepalive timer
        if (this._keepalive_timer) {
            clearInterval(this._keepalive_timer);
            this._keepalive_timer = null;
        }
        this._clear_keepalive_watchdog();

        // Send periodic keepalive messages to prevent background script from being terminated
        this._keepalive_timer = setInterval(() => {
            if (this.bg_port && this.bg_connected) {
                try {
                    this.bg_port.postMessage({ action: 'CS_KEEPALIVE' });
                    this._last_keepalive_sent = Date.now();
                    // Start watchdog timer to detect if background script doesn't respond
                    this._reset_keepalive_watchdog();
                } catch (err) {
                    if (this.is_background_communication_broken_error(err)) {
                        this.handle_background_communication_broken('keepalive:interval', err);
                        return;
                    }
                    // If keepalive fails, the port is likely disconnected
                    // The onDisconnect handler will clean up and reconnect
                }
            }
        }, this.KEEPALIVE_INTERVAL_MS);
    }

    _reset_keepalive_watchdog() {
        // Clear existing watchdog timer
        this._clear_keepalive_watchdog();

        // Set new watchdog timer to detect if background script is dead
        this._keepalive_watchdog_timer = setTimeout(() => {
            if (!this.bg_port || !this.bg_connected) {
                // Port is not connected, don't check
                return;
            }

            const timeSinceLastAck = this.debug.lastKeepaliveAck ? Date.now() - this.debug.lastKeepaliveAck : Infinity;
            const timeSinceLastKeepalive = this._last_keepalive_sent ? Date.now() - this._last_keepalive_sent : Infinity;

            // If we sent a keepalive but haven't received an ack within the timeout, background script may be dead
            if (timeSinceLastKeepalive > 0 && timeSinceLastAck >= this.KEEPALIVE_WATCHDOG_TIMEOUT_MS) {
                this._wake_up_background_script();
            }
        }, this.KEEPALIVE_WATCHDOG_TIMEOUT_MS);
    }

    _clear_keepalive_watchdog() {
        if (this._keepalive_watchdog_timer) {
            clearTimeout(this._keepalive_watchdog_timer);
            this._keepalive_watchdog_timer = null;
        }
    }

    _wake_up_background_script() {
        if (this.background_communication_broken || !this.is_background_runtime_alive()) {
            this.handle_background_communication_broken('wake-up');
            return;
        }
        // sendMessage wakes MV3 service workers even when the port is a zombie connection
        try {
            chrome.runtime.sendMessage({ action: 'WAKE_UP' }, (response) => {
                if (chrome.runtime.lastError) {
                    const errMsg = chrome.runtime.lastError.message;
                    if (this.is_background_communication_broken_error({ message: errMsg })) {
                        this.handle_background_communication_broken('wake-up:sendMessage', errMsg);
                        return;
                    }
                } else if (response?.status === 'awake') {
                    this._check_port_health('wake-up-sendMessage');
                }
            });
        } catch (err) {
            if (this.is_background_communication_broken_error(err)) {
                this.handle_background_communication_broken('wake-up:sendMessage-throw', err);
                return;
            }
        }

        // Try to wake up the background script via port
        if (this.bg_port && this.bg_connected) {
            try {
                this.send_port_request('WAKE_UP')
                    .then(() => {
                    })
                    .catch((err) => {
                        // Force port disconnect to trigger reconnection
                        if (this.bg_port) {
                            try {
                                this.bg_port.disconnect();
                            } catch (disconnectErr) {
                                // Port may already be disconnected
                            }
                        }
                    });
            } catch (err) {
                // Force port disconnect to trigger reconnection
                if (this.bg_port) {
                    try {
                        this.bg_port.disconnect();
                    } catch (disconnectErr) {
                        // Port may already be disconnected
                    }
                }
            }
        } else {
            // Port not connected - try to reconnect
            if (this.bg_port) {
                try {
                    this.bg_port.disconnect();
                } catch (err) {
                    // Port may already be disconnected
                }
            }
            // Trigger port reconnection
            if (this.open_bg_port) {
                this.open_bg_port();
            }
        }
    }

    schedule_port_reconnect() {
        if (this.background_communication_broken || !this.is_background_runtime_alive()) {
            this.handle_background_communication_broken('schedule_port_reconnect');
            return;
        }
        if (this._reconnect_timer) {
            return;
        }
        let delay = this._reconnect_delay || 500;
        this._reconnect_timer = setTimeout(() => {
            this._reconnect_timer = null;
            this._reconnect_delay = Math.min((this._reconnect_delay || 500) * 2, 5000);
            try { 
                this.open_bg_port(); 
            } catch (e) {
                if (this.is_background_communication_broken_error(e)) {
                    this.handle_background_communication_broken('schedule_port_reconnect:open', e);
                    return;
                }
                console.error("[CS] Port reconnect attempt failed:", e);
                // Schedule another reconnect attempt
                this.schedule_port_reconnect();
            }
        }, delay);
    }

    reset_state() {
        this.state_data = {
            dom_ready: false,
            environment_ready: false,
            last_cached_rankings_request_time: 0,
        };
    }
}

async function get_environment_status() {
    const fsm = window.__LEGUP_FSM__;
    if (!fsm || !fsm.bg_port || !fsm.bg_connected) {
        throw new Error('FSM not available or port not connected');
    }
    try {
        const response = await fsm.send_port_request('GET_ENVIRONMENT');
        if (response && response.env) {
            return response.env;
        } else {
            throw new Error('Failed to get environment status');
        }
    } catch (err) {
        throw new Error('Failed to get environment status: ' + (err.message || err));
    }
}

function get_overlay_for_site(siteKey) {
    const fsm = window.__LEGUP_FSM__;
    if (!fsm || !fsm.bg_port || !fsm.bg_connected) {
        return Promise.resolve({});
    }
    return fsm.send_port_request('GET_SETTINGS', {
        scope: 'content_script',
        keys: ['overlay']
    }).then((resp) => {
        const overlay = resp?.settings?.overlay || {};
        return overlay[siteKey] || {};
    }).catch((err) => {
        console.error('[get_overlay_for_site] failed', err);
        if (fsm.is_background_communication_broken_error?.(err)) {
            fsm.handle_background_communication_broken?.('get_overlay_for_site', err);
            return {};
        }
        return {};
    });
}

function set_overlay_for_site(siteKey, patchForSite) {
    const fsm = window.__LEGUP_FSM__;
    if (!fsm || !fsm.bg_port || !fsm.bg_connected) {
        return Promise.resolve(null);
    }
    return fsm.send_port_request('SET_SETTINGS', {
        scope: 'content_script',
        settings: { overlay: { [siteKey]: patchForSite } }
    }).then((resp) => resp?.settings || null).catch((err) => {
        console.error('[set_overlay_for_site] failed', err);
        if (fsm.is_background_communication_broken_error?.(err)) {
            fsm.handle_background_communication_broken?.('set_overlay_for_site', err);
            return null;
        }
        return null;
    });
}

function generate_request_identifier(request_data) {
    const draft_id = request_data.draft?.draft_id || 'unknown';
    const picks_count = request_data.draft?.picks?.length ?? 0;
    let algo_type = request_data.algo_type || 'sim';
    const format_type = request_data.format_type || 'regular';
    const ranking_set = request_data.ranking_set || 'legup';

    if (algo_type.toLowerCase().includes('sim')) {
        algo_type = 'sim';
    }

    let identifier = `${draft_id}-${picks_count}-${algo_type}`;

    if (format_type !== 'regular') {
        identifier += `-${format_type}`;
    }

    if (ranking_set !== 'legup') {
        identifier += `-${ranking_set}`;
    }

    const scoring = request_data.scoring != null ? String(request_data.scoring).trim().toLowerCase() : '';
    if (scoring) {
        identifier += `-${scoring}`;
    }

    return identifier;
}

/**
 * Dict aligned with generate_request_identifier inputs, plus full picks[].
 * Used client-side to detect draft changes; server still uses request_identifier string.
 */
function build_rankings_change_snapshot(request_data) {
    if (!request_data) {
        return null;
    }
    const draft = request_data.draft || {};
    const picks = Array.isArray(draft.picks) ? draft.picks : [];
    let algo_type = request_data.algo_type || 'sim';
    const format_type = request_data.format_type || 'regular';
    const ranking_set = request_data.ranking_set || 'legup';

    if (algo_type.toLowerCase().includes('sim')) {
        algo_type = 'sim';
    }

    let picks_clone;
    try {
        picks_clone = JSON.parse(JSON.stringify(picks));
    } catch (_e) {
        picks_clone = picks.map((p) => (p && typeof p === 'object' ? { ...p } : p));
    }

    return {
        draft_id: draft.draft_id != null && draft.draft_id !== '' ? draft.draft_id : null,
        num_picks: picks.length,
        algo_type,
        format_type,
        ranking_set,
        scoring: request_data.scoring != null ? String(request_data.scoring).trim().toLowerCase() : null,
        picks: picks_clone
    };
}

function rankings_change_snapshots_equal(a, b) {
    if (!a || !b) {
        return a === b;
    }
    if (
        a.draft_id !== b.draft_id ||
        a.num_picks !== b.num_picks ||
        a.algo_type !== b.algo_type ||
        a.format_type !== b.format_type ||
        a.ranking_set !== b.ranking_set ||
        a.scoring !== b.scoring
    ) {
        return false;
    }
    return JSON.stringify(a.picks) === JSON.stringify(b.picks);
}

function generate_current_roster(picks, pick_slot, draft_size, num_rounds) {
    if (!pick_slot || !Array.isArray(picks) || picks.length === 0) {
        return [];
    }
    
    const seat_pattern = `seat ${pick_slot}`;
    
    return picks.filter((pick, index) => {
        // Handle verbose format: has drafted_by field
        if (pick.drafted_by) {
            return pick.drafted_by === seat_pattern;
        }
        
        // Handle minimal format: compute seat from pick index
        // Picks are in order, so index represents the pick number (0-indexed)
        if (draft_size && num_rounds) {
            const pick_number = index + 1;
            const round = Math.ceil(pick_number / draft_size);
            const position_in_round = ((pick_number - 1) % draft_size) + 1;
            
        // Snake draft: odd rounds go 1->N, even rounds go N->1
        let seat;
        if (round % 2 === 1) {
            seat = position_in_round;
        } else {
            seat = draft_size - position_in_round + 1;
            }
            
            return seat === pick_slot;
        }
        
        return false;
    });
}

function normalize_player_name(name) {
    const removableSuffixes = ["Jr.", "Sr."];
    const retainableSuffixes = ["II", "III", "IV"];
    const specialCases = ["St."];
    const keepSuffixPlayers = ["Brian Thomas Jr.", "B. Thomas Jr.", "Travis Etienne Jr.", "T. Etienne Jr.", "Michael Pittman Jr.", "M. Pittman Jr.", "Brian Robinson Jr.", "B. Robinson Jr.", "Marvin Mims Jr.", "M. Mims Jr.", "DJ Chark Jr.", "D. Chark Jr.", "Odell Beckham Jr.", "O. Beckham Jr.", "Louis Rees-Zammit Jr.", "L. Rees-Zammit Jr.", "Donald Parham Jr.", "D. Parham Jr."]; // List of exceptions to keep the "Jr." suffix

    let nameParts = name.trim().split(' ');
    let suffix = '';

    if (keepSuffixPlayers.includes(name)) {
        // Return the initialized format with the "Jr." suffix intact, without further parsing
        return nameParts.map((part, index) => {
            if (index === 0) {
                return part.charAt(0) + '.'; // Initial for first name
            } else {
                return part; // Full middle and last name
            }
        }).join(' ');
    }

    // Check if the last part is a suffix that should be removed or retained
    if (retainableSuffixes.includes(nameParts[nameParts.length - 1])) {
        suffix = nameParts.pop(); // Retain the suffix
    } else if (removableSuffixes.includes(nameParts[nameParts.length - 1])) {
        nameParts.pop();
    }

    if (nameParts.length === 0) return "Error: Invalid name format";

    // Check for special cases where certain parts should be treated as part of the last name
    let lastNameIndex = nameParts.length - 1;
    for (let i = lastNameIndex - 1; i >= 0; i--) {
        if (specialCases.includes(nameParts[i])) {
            lastNameIndex = i;
        }
    }

    const firstName = nameParts.slice(0, lastNameIndex).map(part => part.charAt(0) + '.').join(' ');
    const lastName = nameParts.slice(lastNameIndex).join(' ');

    return `${firstName} ${lastName}${suffix ? ' ' + suffix : ''}`.trim();
}

function normalizeNameForFuzzyMatch(name) {
    if (!name) return '';
    const normalized = String(name)
        .replace(/[\u2019’]/g, "'")
        // Keep apostrophe so "O'Brien" stays one token; period becomes space so "O. Gadsden" splits
        .replace(/[^a-zA-Z0-9\s']/g, ' ')
        .replace(/\s+/g, ' ')
        .trim()
        .toLowerCase();
    if (!normalized) return '';
    const tokens = normalized.split(' ');
    while (tokens.length > 1 && fuzzyNameSuffixes.has(tokens[tokens.length - 1])) {
        tokens.pop();
    }
    return tokens.join(' ');
}

function getLastNameTokens(tokens) {
    if (tokens.length <= 1) return tokens;
    if (tokens.length === 2 && fuzzyLastNamePrefixes.has(tokens[0])) {
        // Single-letter first token is a first initial (e.g. "O. Gadsden"), not a last-name prefix
        if (tokens[0].length === 1) {
            return [tokens[1]];
        }
        return tokens;
    }
    const lastTokens = [tokens[tokens.length - 1]];
    for (let i = tokens.length - 2; i >= 1; i--) {
        if (fuzzyLastNamePrefixes.has(tokens[i])) {
            lastTokens.unshift(tokens[i]);
        } else {
            break;
        }
    }
    return lastTokens;
}

function getFuzzyNameMatchData(name) {
    const normalized = normalizeNameForFuzzyMatch(name);
    if (!normalized) return null;
    const tokens = normalized.split(' ');
    const lastNameTokens = getLastNameTokens(tokens);
    const firstNameTokens = tokens.slice(0, tokens.length - lastNameTokens.length);
    const firstName = firstNameTokens.join(' ');
    const lastName = lastNameTokens.join(' ');
    const firstInitial = firstName ? firstName.charAt(0) : '';
    return {
        normalized,
        tokens,
        firstName,
        lastName,
        firstInitial,
        firstNameTokens,
        lastNameTokens
    };
}

function levenshteinDistance(a, b) {
    if (a === b) return 0;
    if (!a) return b.length;
    if (!b) return a.length;
    const matrix = Array.from({ length: a.length + 1 }, () => new Array(b.length + 1));
    for (let i = 0; i <= a.length; i++) matrix[i][0] = i;
    for (let j = 0; j <= b.length; j++) matrix[0][j] = j;
    for (let i = 1; i <= a.length; i++) {
        for (let j = 1; j <= b.length; j++) {
            const cost = a[i - 1] === b[j - 1] ? 0 : 1;
            matrix[i][j] = Math.min(
                matrix[i - 1][j] + 1,
                matrix[i][j - 1] + 1,
                matrix[i - 1][j - 1] + cost
            );
        }
    }
    return matrix[a.length][b.length];
}

function getNormalizedNameSimilarity(a, b) {
    if (!a && !b) return 1;
    const maxLen = Math.max(a.length, b.length);
    if (maxLen === 0) return 1;
    const distance = levenshteinDistance(a, b);
    return (maxLen - distance) / maxLen;
}

function isDeterministicNameMatchData(a, b) {
    if (!a || !b) return false;
    if (a.normalized === b.normalized) return true;
    if (a.lastName && b.lastName && a.lastName === b.lastName) {
        if (a.firstName && b.firstName) {
            if (a.firstName === b.firstName) return true;
            if (a.firstName.startsWith(b.firstName) || b.firstName.startsWith(a.firstName)) return true;
        }
        if (a.firstInitial && b.firstInitial && a.firstInitial === b.firstInitial) return true;
    }
    return false;
}

function isPlayerNameMatchData(a, b, options = {}) {
    if (!a || !b) return false;
    if (isDeterministicNameMatchData(a, b)) return true;
    const allowFuzzy = options.allowFuzzy !== false;
    if (!allowFuzzy) return false;
    if (!a.lastName || !b.lastName || a.lastName !== b.lastName) return false;
    if (!a.firstInitial || !b.firstInitial || a.firstInitial !== b.firstInitial) return false;
    return getNormalizedNameSimilarity(a.normalized, b.normalized) >= 0.9;
}


function boot() {
    try {
        if (window.__LEGUP_FSM__) {
            try { window.__LEGUP_FSM__.stop?.(); } catch (e) { }
            try { window.__LEGUP_FSM__ = null; } catch (e) { }
        }
        const fsm = new Content_Script_FSM();
        window.__LEGUP_FSM__ = fsm;
        fsm.start();
    } catch (e) {
        console.error('[CS] boot failed', e);
        console.error('[CS] boot error stack:', e.stack);
    }
}


if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot, { once: true });
} else {
    boot();
}
