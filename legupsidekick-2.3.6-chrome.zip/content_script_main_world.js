(function () {
    if (window.__legupPageWorldNetworkHooked) {
        return;
    }
    window.__legupPageWorldNetworkHooked = true;

    const hostname = typeof window.location !== 'undefined' ? window.location.hostname : '';

    const toAbsoluteUrl = (url) => {
        if (!url || typeof url !== 'string') {
            return '';
        }
        try {
            if (url.indexOf('http://') === 0 || url.indexOf('https://') === 0) {
                return url;
            }
            return new URL(url, window.location.origin).href;
        } catch (e) {
            return url;
        }
    };

    /** ─── DraftKings: POST …/lineups/v3/users/{uuid}/playerexposure (fetch and/or XHR) ─── */
    const isDraftKingsSurfaceHostname = function (h) {
        return (
            h === 'www.draftkings.com' ||
            h === 'draftkings.com' ||
            (typeof h === 'string' && /\.draftkings\.com$/i.test(h))
        );
    };

    if (isDraftKingsSurfaceHostname(hostname)) {
        const LEGUP_DK_DEBUG = false;
        const DK_PLAYER_EXPOSURE_EVENT = '__legup_dk_player_exposure_json';
        const DK_LINEUPS_EVENT = '__legup_dk_lineups_json';

        const logDk = function () {
            if (!LEGUP_DK_DEBUG || typeof console === 'undefined') return;
            const con = console;
            if (!con || !con.log) return;
            con.log.apply(con, arguments);
        };

        logDk(
            '[LegUp][MAIN] content_script_page_world_intercept_hook: DraftKings, patching XHR + fetch (frame=',
            window === window.top ? 'top' : 'child',
            ')'
        );

        const isDkPlayerExposureUrl = (abs) => {
            if (!abs || typeof abs !== 'string') {
                return false;
            }
            let u;
            try {
                u = new URL(abs);
            } catch (e) {
                return false;
            }
            if (u.hostname !== 'api.draftkings.com') {
                return false;
            }
            return /\/lineups\/v3\/users\/[^/]+\/playerexposure\b/i.test(u.pathname);
        };

        // DraftKings: lineups list (used to infer total entry count for exposure).
        // Example pattern: GET/POST https://api.draftkings.com/lineups/v3/users/{uuid}/lineups
        const isDkLineupsUrl = (abs) => {
            if (!abs || typeof abs !== 'string') {
                return false;
            }
            let u;
            try {
                u = new URL(abs);
            } catch (e) {
                return false;
            }
            if (u.hostname !== 'api.draftkings.com') {
                return false;
            }
            return /\/lineups\/v\d+\/users\/[^/]+\/lineups\b/i.test(u.pathname);
        };

        // Isolated overlay/FSM runs in the top frame only (default all_frames=false on the main bundle).
        // Exposure fetch/XHR often runs from a same-origin child iframe: patch every frame (manifest
        // all_frames) but always dispatch on top so content_script_draft_kings.js receives the event.
        const dispatchDkPlayerExposureJson = (detail) => {
            try {
                const ev = new CustomEvent(DK_PLAYER_EXPOSURE_EVENT, { detail });
                let targetWin = window;
                try {
                    if (window.top && window.top !== window) {
                        targetWin = window.top;
                    }
                } catch (eTop) {
                    targetWin = window;
                }
                targetWin.dispatchEvent(ev);
            } catch (e) {
                // ignore
            }
        };

        const dispatchDkLineupsJson = (detail) => {
            try {
                const ev = new CustomEvent(DK_LINEUPS_EVENT, { detail });
                let targetWin = window;
                try {
                    if (window.top && window.top !== window) {
                        targetWin = window.top;
                    }
                } catch (eTop) {
                    targetWin = window;
                }
                targetWin.dispatchEvent(ev);
            } catch (e) {
                // ignore
            }
        };

        const tryDispatchDkPlayerExposureFromText = (bodyText, sourceLabel) => {
            if (!bodyText || typeof bodyText !== 'string') {
                return;
            }
            const trimmed = bodyText.trim();
            if (trimmed.charAt(0) !== '{' && trimmed.charAt(0) !== '[') {
                return;
            }
            try {
                const json = JSON.parse(trimmed);
                const rows = json && json.playerExposure;
                if (!Array.isArray(rows)) {
                    return;
                }
                logDk('[LegUp][MAIN] intercepted DK playerExposure JSON via', sourceLabel, rows.length);
                dispatchDkPlayerExposureJson(json);
            } catch (e) {
                logDk('[LegUp][MAIN] DK playerExposure parse failed (' + sourceLabel + '):', e && e.message);
            }
        };

        const extractDkLineupEntryContestKey = (ent) => {
            if (!ent || typeof ent !== 'object') return '';
            const ck = ent.contestKey != null ? String(ent.contestKey).trim() : '';
            if (ck) return ck;
            const mega = ent.megaContestId != null ? String(ent.megaContestId).trim() : '';
            return mega || '';
        };

        const extractDkLineupEntryKey = (ent) => {
            if (!ent || typeof ent !== 'object') return '';
            const raw =
                ent.entryKey != null
                    ? ent.entryKey
                    : ent.EntryKey != null
                      ? ent.EntryKey
                      : ent.entry_key != null
                        ? ent.entry_key
                        : ent.userContestId != null
                          ? ent.userContestId
                          : ent.userEntryId != null
                            ? ent.userEntryId
                            : ent.entryId != null
                              ? ent.entryId
                              : null;
            return raw != null ? String(raw).trim() : '';
        };

        const extractDkLineupCreateDate = (lineup) => {
            if (!lineup || typeof lineup !== 'object') return '';
            const raw =
                lineup.CreateDate != null
                    ? lineup.CreateDate
                    : lineup.createDate != null
                      ? lineup.createDate
                      : lineup.create_date != null
                        ? lineup.create_date
                        : null;
            return raw != null ? String(raw).trim() : '';
        };

        const sanitizeDkLineupPlayerForWire = (dp) => {
            if (!dp || typeof dp !== 'object') return null;
            const rawDkId =
                dp.playerDkId != null ? dp.playerDkId : dp.playerdkid != null ? dp.playerdkid : null;
            if (rawDkId == null || rawDkId === '') return null;
            const playerDkId = String(rawDkId).trim();
            if (!playerDkId) return null;

            const player = { player_dk_id: playerDkId };

            const displayName = dp.displayName != null ? String(dp.displayName).trim() : '';
            if (displayName) player.display_name = displayName;

            const draftableIdRaw = dp.draftableId != null ? Number(dp.draftableId) : NaN;
            if (Number.isFinite(draftableIdRaw)) player.draftable_id = Math.round(draftableIdRaw);

            const firstName = dp.firstName != null ? String(dp.firstName).trim() : '';
            if (firstName) player.first_name = firstName;

            const lastName = dp.lastName != null ? String(dp.lastName).trim() : '';
            if (lastName) player.last_name = lastName;

            const playerIdRaw = dp.playerId != null ? Number(dp.playerId) : NaN;
            if (Number.isFinite(playerIdRaw)) player.player_id = Math.round(playerIdRaw);

            const positionName = dp.positionName != null ? String(dp.positionName).trim() : '';
            if (positionName) player.position_name = positionName;

            return player;
        };

        const sanitizeDkLineupForWire = (lineup, draftGroupId) => {
            if (!lineup || typeof lineup !== 'object') return null;
            const drafted = Array.isArray(lineup.draftedPlayers) ? lineup.draftedPlayers : [];
            const draftedPlayers = [];
            for (let di = 0; di < drafted.length; di++) {
                const player = sanitizeDkLineupPlayerForWire(drafted[di]);
                if (player) draftedPlayers.push(player);
            }
            if (!draftedPlayers.length) return null;

            const ceRaw = lineup.contestEntries != null ? Number(lineup.contestEntries) : NaN;
            const contestEntries = Number.isFinite(ceRaw) && ceRaw > 0 ? Math.round(ceRaw) : 1;

            const entriesArr = Array.isArray(lineup.entries) ? lineup.entries : [];
            const entries = [];
            for (let ei = 0; ei < entriesArr.length; ei++) {
                const ent = entriesArr[ei];
                if (!ent || typeof ent !== 'object') continue;
                const contestKey = extractDkLineupEntryContestKey(ent);
                if (!contestKey) continue;
                const entry = { contest_key: contestKey };
                const entryKey = extractDkLineupEntryKey(ent);
                if (entryKey) entry.entry_key = entryKey;
                const mega =
                    ent.megaContestId != null
                        ? String(ent.megaContestId).trim()
                        : ent.mega_contest_id != null
                          ? String(ent.mega_contest_id).trim()
                          : '';
                if (mega) entry.mega_contest_id = mega;
                entries.push(entry);
            }

            const out = {
                draft_group_id: String(draftGroupId),
                contest_entries: contestEntries,
                drafted_players: draftedPlayers,
                entries: entries
            };

            // Prefer DK's lineup id; fall back to the first entry_key so unified
            // cache keys stay unique when the same contest is mass-entered.
            const lineupIdRaw =
                lineup.id != null
                    ? lineup.id
                    : lineup.lineupId != null
                      ? lineup.lineupId
                      : lineup.lineup_id != null
                        ? lineup.lineup_id
                        : null;
            if (lineupIdRaw != null && String(lineupIdRaw).trim()) {
                out.lineup_id = String(lineupIdRaw).trim();
            } else {
                for (let ei = 0; ei < entries.length; ei++) {
                    const ek = entries[ei] && entries[ei].entry_key;
                    if (ek != null && String(ek).trim()) {
                        out.lineup_id = String(ek).trim();
                        break;
                    }
                }
            }

            const createDate = extractDkLineupCreateDate(lineup);
            if (createDate) out.create_date = createDate;

            const sport = lineup.sport != null ? String(lineup.sport).trim() : '';
            if (sport) out.sport = sport;

            const gameTypeName =
                lineup.gameTypeName != null
                    ? String(lineup.gameTypeName).trim()
                    : lineup.game_type_name != null
                      ? String(lineup.game_type_name).trim()
                      : '';
            if (gameTypeName) out.game_type_name = gameTypeName;

            const contestStartDate =
                lineup.contestStartDate != null
                    ? String(lineup.contestStartDate).trim()
                    : lineup.draftGroupStartTime != null
                      ? String(lineup.draftGroupStartTime).trim()
                      : '';
            if (contestStartDate) out.contest_start_date = contestStartDate;

            const contestStartSuffix =
                lineup.contestStartTimeSuffix != null
                    ? String(lineup.contestStartTimeSuffix).trim()
                    : lineup.startTimeSuffix != null
                      ? String(lineup.startTimeSuffix).trim()
                      : '';
            if (contestStartSuffix) out.contest_start_suffix = contestStartSuffix;

            return out;
        };

        const tryDispatchDkLineupsFromText = (bodyText, sourceLabel, requestUrl) => {
            if (!bodyText || typeof bodyText !== 'string') {
                return;
            }
            const trimmed = bodyText.trim();
            if (trimmed.charAt(0) !== '{' && trimmed.charAt(0) !== '[') {
                return;
            }
            try {
                const json = JSON.parse(trimmed);
                let lineups = null;
                if (Array.isArray(json)) {
                    lineups = json;
                } else if (json && typeof json === 'object') {
                    if (Array.isArray(json.lineups)) {
                        lineups = json.lineups;
                    } else if (Array.isArray(json.lineupIds)) {
                        lineups = json.lineupIds;
                    } else if (Array.isArray(json.items)) {
                        lineups = json.items;
                    }
                }
                if (!Array.isArray(lineups)) {
                    return;
                }
                const slates = {};
                const raw_lineups_by_draft_group = {};
                for (let i = 0; i < lineups.length; i++) {
                    const l = lineups[i];
                    if (!l || typeof l !== 'object') continue;
                    const dgRaw = l.draftGroupId != null ? l.draftGroupId : l.DraftGroupId;
                    if (dgRaw == null || dgRaw === '') continue;
                    const dgKey = String(dgRaw).trim();
                    if (!dgKey) continue;
                    if (!window.__legupDkRawLineupSampleLogged) {
                        window.__legupDkRawLineupSampleLogged = true;
                        try {
                        } catch (eSampleLog) {
                        }
                    }
                    if (!slates[dgKey]) {
                        slates[dgKey] = {
                            total_entries: 0,
                            pick_count_by_player_dk_id: {},
                            entry_fees_by_player_dk_id: {},
                            label_seed: null
                        };
                    }
                    const bucket = slates[dgKey];
                    const ceRaw = l.contestEntries != null ? Number(l.contestEntries) : NaN;
                    const contestEntries = Number.isFinite(ceRaw) && ceRaw > 0 ? Math.round(ceRaw) : 1;
                    const sanitizedLineup = sanitizeDkLineupForWire(l, dgKey);
                    if (sanitizedLineup) {
                        if (!raw_lineups_by_draft_group[dgKey]) {
                            raw_lineups_by_draft_group[dgKey] = [];
                        }
                        raw_lineups_by_draft_group[dgKey].push(sanitizedLineup);
                    }
                    bucket.total_entries += contestEntries;
                    const drafted = Array.isArray(l.draftedPlayers) ? l.draftedPlayers : [];
                    for (let di = 0; di < drafted.length; di++) {
                        const dp = drafted[di];
                        if (!dp || typeof dp !== 'object') continue;
                        const raw = dp.playerDkId != null ? dp.playerDkId : dp.playerdkid != null ? dp.playerdkid : null;
                        if (raw == null || raw === '') continue;
                        const pdk = String(raw).trim();
                        if (!pdk) continue;
                        bucket.pick_count_by_player_dk_id[pdk] =
                            (bucket.pick_count_by_player_dk_id[pdk] || 0) + contestEntries;
                    }
                    if (!bucket.label_seed) {
                        const gt =
                            l.gameTypeName != null
                                ? String(l.gameTypeName).trim()
                                : l.game_type_name != null
                                  ? String(l.game_type_name).trim()
                                  : '';
                        const suf =
                            l.contestStartTimeSuffix != null
                                ? String(l.contestStartTimeSuffix).trim()
                                : l.startTimeSuffix != null
                                  ? String(l.startTimeSuffix).trim()
                                  : '';
                        const sd =
                            l.contestStartDate != null
                                ? String(l.contestStartDate).trim()
                                : l.draftGroupStartTime != null
                                  ? String(l.draftGroupStartTime).trim()
                                  : '';
                        const sp = l.sport != null ? String(l.sport).trim() : '';
                        if (gt || suf || sd || sp) {
                            bucket.label_seed = {
                                sport: sp || null,
                                suffix: suf || null,
                                start_date: sd || null,
                                game_type_name: gt || null
                            };
                        }
                    }
                }
                const slateKeys = Object.keys(slates);
                if (!slateKeys.length) {
                    return;
                }

                // Identity-key coverage for diagnosing homepage undercount vs toast N/M.
                try {
                    let sanitizedCount = 0;
                    let missingLineupId = 0;
                    let missingEntryKey = 0;
                    let missingContestKey = 0;
                    const lineupIds = {};
                    const entryKeys = {};
                    const contestKeys = {};
                    const missingSamples = [];
                    const dgKeys = Object.keys(raw_lineups_by_draft_group);
                    for (let di = 0; di < dgKeys.length; di++) {
                        const arr = raw_lineups_by_draft_group[dgKeys[di]];
                        if (!Array.isArray(arr)) continue;
                        for (let li = 0; li < arr.length; li++) {
                            const lu = arr[li];
                            if (!lu || typeof lu !== 'object') continue;
                            sanitizedCount++;
                            const lid = lu.lineup_id != null ? String(lu.lineup_id).trim() : '';
                            if (lid) lineupIds[lid] = true;
                            else missingLineupId++;
                            const entries = Array.isArray(lu.entries) ? lu.entries : [];
                            let hasEk = false;
                            let hasCk = false;
                            const first = entries[0] && typeof entries[0] === 'object' ? entries[0] : {};
                            for (let ei = 0; ei < entries.length; ei++) {
                                const ent = entries[ei];
                                if (!ent || typeof ent !== 'object') continue;
                                const ek = ent.entry_key != null ? String(ent.entry_key).trim() : '';
                                const ck = ent.contest_key != null ? String(ent.contest_key).trim() : '';
                                if (ek) {
                                    hasEk = true;
                                    entryKeys[ek] = true;
                                }
                                if (ck) {
                                    hasCk = true;
                                    contestKeys[ck] = true;
                                }
                            }
                            if (!hasEk) missingEntryKey++;
                            if (!hasCk) missingContestKey++;
                            if (missingSamples.length < 5 && (!lid || !hasEk || !hasCk)) {
                                missingSamples.push({
                                    draft_group_id: dgKeys[di],
                                    lineup_id: lid || null,
                                    entry_key:
                                        first.entry_key != null ? String(first.entry_key) : null,
                                    contest_key:
                                        first.contest_key != null ? String(first.contest_key) : null,
                                    entry_count: entries.length,
                                    top_keys: Object.keys(lu).slice(0, 16)
                                });
                            }
                        }
                    }
                    const uniqueLineupIds = Object.keys(lineupIds).length;
                    const uniqueEntryKeys = Object.keys(entryKeys).length;
                    const uniqueContestKeys = Object.keys(contestKeys).length;
                    const log_data = {
                        source: sourceLabel,
                        api_lineups: lineups.length,
                        sanitized_lineups: sanitizedCount,
                        unique_lineup_ids: uniqueLineupIds,
                        unique_entry_keys: uniqueEntryKeys,
                        unique_contest_keys: uniqueContestKeys,
                        missing_lineup_id: missingLineupId,
                        missing_entry_key: missingEntryKey,
                        missing_contest_key: missingContestKey,
                        would_collapse_on_contest_key:
                            sanitizedCount > 0 &&
                            uniqueContestKeys > 0 &&
                            uniqueContestKeys < sanitizedCount,
                        would_collapse_on_entry_key:
                            sanitizedCount > 0 &&
                            uniqueEntryKeys > 0 &&
                            uniqueEntryKeys < sanitizedCount,
                        missing_samples: missingSamples
                    };
                } catch (eIdentityLog) {}

                const detail = {
                    lineups_count: lineups.length,
                    slates: slates,
                    raw_lineups_by_draft_group: raw_lineups_by_draft_group,
                    __legup_dk_lineups_request_url: requestUrl && typeof requestUrl === 'string' ? requestUrl : null
                };
                logDk('[LegUp][MAIN] intercepted DK lineups JSON via', sourceLabel, {
                    lineups: lineups.length,
                    slate_count: slateKeys.length
                });
                dispatchDkLineupsJson(detail);
            } catch (e) {
                logDk('[LegUp][MAIN] DK lineups parse failed (' + sourceLabel + '):', e && e.message);
            }
        };

        const origDkXhrOpen = XMLHttpRequest.prototype.open;
        XMLHttpRequest.prototype.open = function (method, url) {
            this.__legupDkUrl = url;
            this.__legupDkMethod = typeof method === 'string' ? method.toUpperCase() : '';
            return origDkXhrOpen.apply(this, arguments);
        };

        const origDkXhrSend = XMLHttpRequest.prototype.send;
        XMLHttpRequest.prototype.send = function () {
            const xhr = this;
            const url = xhr.__legupDkUrl;
            const abs = toAbsoluteUrl(url || '');
            xhr.addEventListener('load', function () {
                if (xhr.status < 200 || xhr.status >= 300) {
                    return;
                }
                if (isDkPlayerExposureUrl(abs)) {
                    tryDispatchDkPlayerExposureFromText(xhr.responseText, 'XHR-dk-playerexposure');
                } else if (isDkLineupsUrl(abs)) {
                    tryDispatchDkLineupsFromText(xhr.responseText, 'XHR-dk-lineups', abs);
                }
            });
            return origDkXhrSend.apply(this, arguments);
        };

        const origFetch = window.fetch;
        if (typeof origFetch === 'function') {
            window.fetch = function (input, init) {
                const p = origFetch.apply(window, arguments);
                let url = '';
                if (typeof input === 'string') {
                    url = input;
                } else if (input && typeof input === 'object' && typeof input.url === 'string') {
                    url = input.url;
                }
                const abs = toAbsoluteUrl(url);
                const isEx = isDkPlayerExposureUrl(abs);
                const isLineups = isDkLineupsUrl(abs);
                if (!isEx && !isLineups) {
                    return p;
                }
                return p.then(function (response) {
                    if (!response || typeof response.clone !== 'function') {
                        return response;
                    }
                    if (response.status < 200 || response.status >= 300) {
                        return response;
                    }
                    const clone = response.clone();
                    clone
                        .text()
                        .then(function (text) {
                            if (isEx) {
                                tryDispatchDkPlayerExposureFromText(text, 'fetch-dk-playerexposure');
                            } else if (isLineups) {
                                tryDispatchDkLineupsFromText(text, 'fetch-dk-lineups', abs);
                            }
                        })
                        .catch(function () {});
                    return response;
                });
            };
        }

        return;
    }

    /** ─── Underdog: draft snapshot, ownership, Pusher ─── */
    const isUdAppHostname = function (h) {
        return h === 'app.underdogsports.com' || h === 'app.underdogfantasy.com';
    };
    if (!isUdAppHostname(hostname)) {
        return;
    }

    const LEGUP_UD_DEBUG =
        (function () {
            try {
                return window && window.localStorage && window.localStorage.getItem('LEGUP_UD_DEBUG') === '1';
            } catch (e) {
                return false;
            }
        })();

    const EVENT_NAME = '__legup_ud_draft_v2_json';
    const OWNERSHIP_EVENT_NAME = '__legup_ud_ownership_json';
    const CAPTURE_EVENT = '__legup_ud_draft_xhr_capture';
    const REPLAY_EVENT = '__legup_ud_replay_draft_xhr';
    const WS_EVENT_NAME = '__legup_ud_ws_message';

    const log = function () {
        if (!LEGUP_UD_DEBUG || typeof console === 'undefined') return;
        const con = console;
        if (!con || !con.log) return;
        con.log.apply(con, arguments);
    };

    log('[LegUp][MAIN] content_script_page_world_intercept_hook: Underdog, patching XHR + WebSocket');

    const dispatchDraftJson = (detail) => {
        try {
            window.dispatchEvent(new CustomEvent(EVENT_NAME, { detail }));
        } catch (e) {
            // ignore
        }
    };

    const UD_API_HOST = 'api.underdogfantasy.com';

    const urlHasUdApiOrAppHost = function (abs) {
        if (!abs || typeof abs !== 'string') {
            return false;
        }
        return (
            abs.indexOf('api.underdogfantasy.com') !== -1 ||
            abs.indexOf('app.underdogsports.com') !== -1 ||
            abs.indexOf('app.underdogfantasy.com') !== -1
        );
    };

    const isDraftV2Url = (url) => {
        const abs = toAbsoluteUrl(url);
        if (!abs) {
            return false;
        }
        return urlHasUdApiOrAppHost(abs) && abs.indexOf('/v2/drafts/') !== -1;
    };

    // Exposure tool: GET .../ownership?product=fantasy&product_experience_id=...
    const isUdOwnershipGetUrl = (url) => {
        const abs = toAbsoluteUrl(url);
        if (!abs) {
            return false;
        }
        if (!urlHasUdApiOrAppHost(abs)) {
            return false;
        }
        let u;
        try {
            u = new URL(abs);
        } catch (e) {
            return false;
        }
        return /\/ownership\b/i.test(u.pathname);
    };

    const extractDraftIdFromV2Url = (abs) => {
        const m = typeof abs === 'string' ? abs.match(/\/v2\/drafts\/([a-f0-9-]{36})/i) : null;
        return m ? m[1] : null;
    };

    // App-relative draft URLs resolve against the SPA origin; storage/replay canonicalizes to api.underdogfantasy.com.
    const canonicalUdDraftSnapshotUrl = (abs) => {
        if (!abs || typeof abs !== 'string') {
            return abs;
        }
        let u;
        try {
            u = new URL(abs);
        } catch (e) {
            return abs;
        }
        if (u.hostname !== UD_API_HOST && !isUdAppHostname(u.hostname)) {
            return abs;
        }
        if (!/^\/v2\/drafts\/[a-f0-9-]{36}\/?$/i.test(u.pathname)) {
            return abs;
        }
        const path = u.pathname.replace(/\/$/, '') || u.pathname;
        return 'https://' + UD_API_HOST + path + u.search;
    };

    // Only the main /v2/drafts/{uuid} snapshot GET (expected query) is stored for replay.
    const isUdDraftSnapshotGetForStorage = (abs) => {
        if (!abs || typeof abs !== 'string') {
            return false;
        }
        let u;
        try {
            u = new URL(abs);
        } catch (e) {
            return false;
        }
        if (u.hostname !== UD_API_HOST && !isUdAppHostname(u.hostname)) {
            return false;
        }
        if (!/^\/v2\/drafts\/[a-f0-9-]{36}\/?$/i.test(u.pathname)) {
            return false;
        }
        const product = u.searchParams.get('product');
        const product_experience_id = u.searchParams.get('product_experience_id');
        const state_config_id = u.searchParams.get('state_config_id');
        return Boolean(product && product_experience_id && state_config_id);
    };

    const tryDispatchJsonFromText = (bodyText, sourceLabel) => {
        if (!bodyText || typeof bodyText !== 'string') {
            return;
        }
        const trimmed = bodyText.trim();
        if (trimmed.charAt(0) !== '{' && trimmed.charAt(0) !== '[') {
            return;
        }
        try {
            const json = JSON.parse(trimmed);
            log('[LegUp][MAIN] intercepted draft JSON via', sourceLabel);
            dispatchDraftJson(json);
        } catch (e) {
            log('[LegUp][MAIN] parse failed (' + sourceLabel + '):', e && e.message);
        }
    };

    const dispatchOwnershipJson = (detail) => {
        try {
            window.dispatchEvent(new CustomEvent(OWNERSHIP_EVENT_NAME, { detail }));
        } catch (e) {
            // ignore
        }
    };

    const tryDispatchOwnershipJsonFromText = (bodyText, sourceLabel, requestUrl) => {
        if (!bodyText || typeof bodyText !== 'string') {
            return;
        }
        const trimmed = bodyText.trim();
        if (trimmed.charAt(0) !== '{' && trimmed.charAt(0) !== '[') {
            return;
        }
        try {
            const json = JSON.parse(trimmed);
            log('[LegUp][MAIN] intercepted ownership JSON via', sourceLabel);
            const own = json && json.ownership;
            if (own && typeof own === 'object') {
                const apps = own.appearances;
                const n = Array.isArray(apps) ? apps.length : 0;
                log('[LegUp][MAIN] ownership raw summary', {
                    draft_count: own.draft_count,
                    updated_at: own.updated_at,
                    appearance_count: n
                });
                if (n > 0 && apps[0] && typeof apps[0] === 'object') {
                    log('[LegUp][MAIN] ownership raw first row', apps[0]);
                }
            } else {
                log('[LegUp][MAIN] ownership response missing ownership root', json && typeof json === 'object' ? Object.keys(json) : json);
            }
            const absReq = requestUrl && typeof requestUrl === 'string' ? toAbsoluteUrl(requestUrl) : '';
            const detail =
                json && typeof json === 'object' && json !== null && !Array.isArray(json)
                    ? Object.assign({}, json, absReq ? { __legup_ownership_request_url: absReq } : {})
                    : json;
            dispatchOwnershipJson(detail);
        } catch (e) {
            log('[LegUp][MAIN] ownership parse failed (' + sourceLabel + '):', e && e.message);
        }
    };

    const origXhrOpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function (method, url) {
        this.__legupUdUrl = url;
        this.__legupUdMethod = typeof method === 'string' ? method.toUpperCase() : '';
        this.__legupUdHeaders = {};
        return origXhrOpen.apply(this, arguments);
    };

    const origSetRequestHeader = XMLHttpRequest.prototype.setRequestHeader;
    XMLHttpRequest.prototype.setRequestHeader = function (name, value) {
        if (!this.__legupUdHeaders) {
            this.__legupUdHeaders = {};
        }
        if (name && typeof name === 'string') {
            this.__legupUdHeaders[name.toLowerCase()] = String(value);
        }
        return origSetRequestHeader.apply(this, arguments);
    };

    const origXhrSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.send = function () {
        const xhr = this;
        const url = xhr.__legupUdUrl;
        const abs = toAbsoluteUrl(url || '');
        if (LEGUP_UD_DEBUG && abs && abs.indexOf('api.underdogfantasy.com') !== -1) {
            log('[LegUp][MAIN] XHR', abs);
        }

        const method = xhr.__legupUdMethod || '';
        if (!xhr.__legupUdSkipCapture && method === 'GET' && isUdDraftSnapshotGetForStorage(abs)) {
            const absUrl = canonicalUdDraftSnapshotUrl(abs);
            const draft_id = extractDraftIdFromV2Url(absUrl);
            if (draft_id) {
                const headers = xhr.__legupUdHeaders ? Object.assign({}, xhr.__legupUdHeaders) : {};
                try {
                    window.dispatchEvent(
                        new CustomEvent(CAPTURE_EVENT, {
                            detail: { draft_id: draft_id, url: absUrl, headers: headers }
                        })
                    );
                } catch (e) {
                    // ignore
                }
            }
        }

        xhr.addEventListener('load', function () {
            const method = xhr.__legupUdMethod || '';
            if (method === 'GET' && isUdOwnershipGetUrl(url)) {
                if (xhr.status >= 200 && xhr.status < 300) {
                    tryDispatchOwnershipJsonFromText(xhr.responseText, 'XHR-ownership', abs);
                }
                return;
            }
            if (!isDraftV2Url(url)) {
                return;
            }
            const sourceLabel = xhr.__legupUdSource === 'replay' ? 'XHR-replay' : 'XHR';
            if (xhr.__legupUdSource === 'replay' && LEGUP_UD_DEBUG) {
                const len = xhr.responseText && xhr.responseText.length ? xhr.responseText.length : 0;
                log('[LegUp][MAIN] XHR-replay load status=', xhr.status, 'responseLength=', len);
            }
            tryDispatchJsonFromText(xhr.responseText, sourceLabel);
        });
        xhr.addEventListener('error', function () {
            if (!isDraftV2Url(url) || xhr.__legupUdSource !== 'replay') {
                return;
            }
            log('[LegUp][MAIN] XHR-replay network error', abs);
        });
        return origXhrSend.apply(this, arguments);
    };

    // Do not replay headers that (a) trigger CORS preflights the API does not allow (e.g. Cache-Control),
    // (b) are forbidden on XHR, or (c) duplicate what the browser sends (Sec-*, Origin).
    const REPLAY_SKIP_REQUEST_HEADERS = [
        'if-none-match',
        'if-modified-since',
        'cache-control',
        'pragma',
        'accept-encoding',
        'host',
        'content-length',
        'connection',
        'origin',
        'referer',
        'cookie',
        'dnt',
        'sec-fetch-site',
        'sec-fetch-mode',
        'sec-fetch-dest',
        'sec-fetch-user',
        'sec-ch-ua',
        'sec-ch-ua-mobile',
        'sec-ch-ua-platform'
    ];

    window.addEventListener(REPLAY_EVENT, function (ev) {
        const d = (ev && ev.detail) || {};
        const rawUrl = d.url;
        const headers = d.headers || {};
        if (!rawUrl || typeof rawUrl !== 'string') {
            log('[LegUp][MAIN] XHR-replay: missing url');
            return;
        }
        const replayUrl = canonicalUdDraftSnapshotUrl(rawUrl);
        log('[LegUp][MAIN] XHR-replay: issuing GET', replayUrl);
        const xhr = new XMLHttpRequest();
        xhr.__legupUdSkipCapture = true;
        xhr.__legupUdSource = 'replay';
        xhr.open('GET', replayUrl, true);
        for (const k in headers) {
            if (!Object.prototype.hasOwnProperty.call(headers, k)) {
                continue;
            }
            const lower = String(k).toLowerCase();
            if (REPLAY_SKIP_REQUEST_HEADERS.indexOf(lower) !== -1) {
                continue;
            }
            if (lower.indexOf('sec-') === 0) {
                continue;
            }
            try {
                xhr.setRequestHeader(k, headers[k]);
            } catch (e) {
                log('[LegUp][MAIN] XHR-replay: setRequestHeader failed', k, e && e.message);
            }
        }
        xhr.send();
    });

    const dispatchWsMessage = (detail) => {
        try {
            window.dispatchEvent(new CustomEvent(WS_EVENT_NAME, { detail }));
        } catch (e) {
            // ignore
        }
    };

    const isPusherWsUrl = (url) => {
        return typeof url === 'string' && url.indexOf('pusher.com') !== -1;
    };

    const parsePusherFrame = (rawData) => {
        let parsed = null;
        let pusherEvent = null;
        let pusherData = null;
        if (typeof rawData !== 'string' || !rawData.length) {
            return { parsed, pusherEvent, pusherData };
        }
        try {
            parsed = JSON.parse(rawData);
        } catch (e) {
            return { parsed, pusherEvent, pusherData };
        }
        if (parsed && typeof parsed.event === 'string') {
            pusherEvent = parsed.event;
        }
        if (parsed && typeof parsed.data === 'string') {
            try {
                pusherData = JSON.parse(parsed.data);
            } catch (e2) {
                pusherData = parsed.data;
            }
        } else if (parsed && parsed.data !== undefined && parsed.data !== null) {
            pusherData = parsed.data;
        }
        return { parsed, pusherEvent, pusherData };
    };

    const getUdDraftIdFromUrl = () => {
        try {
            const href = window && window.location && typeof window.location.href === 'string' ? window.location.href : '';
            if (!href) return null;
            // Prefer explicit /active/{uuid} route; fallback to first uuid in the path.
            let m = href.match(/\/active\/([a-f0-9-]{36})/i);
            if (m && m[1]) return m[1];
            m = href.match(/\/drafts\/([a-f0-9-]{36})/i);
            if (m && m[1]) return m[1];
            m = href.match(/([a-f0-9-]{36})/i);
            return m && m[1] ? m[1] : null;
        } catch (e) {
            return null;
        }
    };

    const extractDraftIdFromPusherData = (d) => {
        if (!d || typeof d !== 'object') {
            return null;
        }
        if (d.draft && typeof d.draft === 'object' && d.draft.id != null) {
            return String(d.draft.id);
        }
        if (d.id != null) {
            return String(d.id);
        }
        if (d.draft_id != null) {
            return String(d.draft_id);
        }
        return null;
    };

    const NativeWebSocket = window.WebSocket;
    window.WebSocket = function (url, protocols) {
        const wsUrl = typeof url === 'string' ? url : '';
        const ws =
            protocols !== undefined
                ? new NativeWebSocket(url, protocols)
                : new NativeWebSocket(url);
        if (isPusherWsUrl(wsUrl) && LEGUP_UD_DEBUG) {
            log('[LegUp][MAIN] WebSocket open (Pusher):', wsUrl);
        }
        ws.addEventListener('message', function (ev) {
            if (!isPusherWsUrl(wsUrl)) {
                return;
            }
            const rawData = ev.data;
            if (typeof rawData !== 'string') {
                return;
            }
        const { parsed, pusherEvent, pusherData } = parsePusherFrame(rawData);
        // In production we only care about a couple Pusher events. Avoid dispatching (and allocating)
        // a large detail object for every frame; fast drafts can receive hundreds of messages.
        let shouldDispatch = LEGUP_UD_DEBUG || pusherEvent === 'pick_made' || pusherEvent === 'status_change';
        if (!LEGUP_UD_DEBUG && shouldDispatch && pusherEvent === 'status_change') {
            const urlDraftId = getUdDraftIdFromUrl();
            const msgDraftId = extractDraftIdFromPusherData(pusherData);
            if (urlDraftId && msgDraftId && String(urlDraftId) !== String(msgDraftId)) {
                shouldDispatch = false;
            }
        }
        if (!shouldDispatch) {
            return;
        }
        const detail = {
            url: wsUrl,
            pusherEvent: pusherEvent,
            pusherData: pusherData
        };
        if (LEGUP_UD_DEBUG) {
            detail.rawData = rawData;
            detail.parsed = parsed;
        }
        dispatchWsMessage(detail);
        if (LEGUP_UD_DEBUG && pusherEvent) {
            log('[LegUp][MAIN] Pusher message:', pusherEvent, pusherData);
        }
        });
        return ws;
    };
    window.WebSocket.prototype = NativeWebSocket.prototype;
    try {
        Object.assign(window.WebSocket, NativeWebSocket);
    } catch (e) {
        // ignore
    }
})();

