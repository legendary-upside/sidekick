const MAX_RANKINGS_ROWS = 500;

function parseCsvLine(line) {
    const out = [];
    let i = 0;
    while (i < line.length) {
        if (line[i] === '"') {
            i += 1;
            let field = '';
            while (i < line.length) {
                if (line[i] === '"') {
                    i += 1;
                    if (line[i] === '"') {
                        field += '"';
                        i += 1;
                    } else {
                        break;
                    }
                } else {
                    field += line[i];
                    i += 1;
                }
            }
            out.push(field.trim());
        } else {
            const comma = line.indexOf(',', i);
            if (comma === -1) {
                out.push(line.slice(i).trim());
                break;
            }
            out.push(line.slice(i, comma).trim());
            i = comma + 1;
        }
    }
    return out;
}

function isIdHeaderCell(cell) {
    return typeof cell === 'string' && cell.trim().toLowerCase() === 'id';
}

function parseCsvToRankings(csvText) {
    if (typeof csvText !== 'string') {
        return { error: 'Could not read the file contents. Please re-export the CSV and try again.', rankings: [] };
    }
    const lines = csvText.split(/\n/).map((ln) => ln.replace(/\r$/, '')).filter((ln) => ln.length > 0);
    if (lines.length === 0) {
        return { error: 'The CSV file is empty. It must have a header row with an "id" column followed by one id per row.', rankings: [] };
    }
    const rows = lines.map((ln) => parseCsvLine(ln));
    const header = rows[0];
    let idIndex = -1;
    for (let j = 0; j < header.length; j++) {
        if (isIdHeaderCell(header[j])) {
            idIndex = j;
            break;
        }
    }
    if (idIndex === -1) {
        const found = header.map((c) => String(c).trim()).filter((c) => c.length > 0);
        const foundText = found.length ? found.map((c) => `"${c}"`).join(', ') : '(no columns found)';
        return {
            error: `Could not find an "id" column in the CSV header row. Found column(s): ${foundText}. Rename the id column to exactly "id" (use the site's slate ids) and try again.`,
            rankings: []
        };
    }
    if (rows.length < 2) {
        return { error: 'The CSV has a header row but no data rows. Add one slate id per row below the header.', rankings: [] };
    }
    const rankings = [];
    for (let i = 1; i < rows.length && rankings.length < MAX_RANKINGS_ROWS; i++) {
        const row = rows[i];
        const val = row[idIndex] !== undefined ? String(row[idIndex]).trim() : '';
        if (!val) continue;
        rankings.push({ id: val });
    }
    if (rankings.length === 0) {
        return { error: 'The CSV has an "id" header but every data row is missing an id value in that column.', rankings: [] };
    }
    return { error: null, rankings };
}

const EXPOSURE_PAGE_HELP_URL = {
    underdog: 'https://app.underdogsports.com/completed/all',
    draftkings: 'https://www.draftkings.com/lineup'
};

document.addEventListener('DOMContentLoaded', () => {
    let port = null;
    let keepaliveTimer = null;
    let keepaliveWatchdogTimer = null;
    let reconnectTimer = null;
    let pushMessageListener = null;
    let lastHealthAck = 0;
    let lastKnownBootId = null;

    const UPLOAD_REQUEST_TIMEOUT_MS = 60000;
    const DEFAULT_REQUEST_TIMEOUT_MS = 5000;
    const KEEPALIVE_INTERVAL_MS = 30000;
    const KEEPALIVE_WATCHDOG_MS = 60000;
    const PORT_STALE_MS = 90000;

    const sendPortRequest = (action, data = {}, options = {}) => {
        const activePort = port;
        if (!activePort) {
            return Promise.reject(new Error('Port not connected'));
        }
        const timeoutMs = options.timeout != null ? options.timeout : DEFAULT_REQUEST_TIMEOUT_MS;
        return new Promise((resolve, reject) => {
            const request_id = `req_${Date.now()}_${Math.random()}`;
            const timeout = setTimeout(() => {
                reject(new Error('Request timeout'));
            }, timeoutMs);

            const messageHandler = (msg) => {
                if (msg?.request_id === request_id) {
                    clearTimeout(timeout);
                    activePort.onMessage.removeListener(messageHandler);
                    if (msg.status === 'ok' || msg.status === 'success') {
                        resolve(msg);
                    } else {
                        const err = new Error(msg.message || 'Request failed');
                        if (msg.uploaded) {
                            err.uploaded = true;
                        }
                        if (msg.datasets) {
                            err.datasets = msg.datasets;
                        }
                        reject(err);
                    }
                }
            };

            activePort.onMessage.addListener(messageHandler);
            try {
                activePort.postMessage({ action, request_id, ...data });
            } catch (err) {
                clearTimeout(timeout);
                activePort.onMessage.removeListener(messageHandler);
                reject(err);
            }
        });
    };

    const getRankingLabel = (entry) => {
        if (entry === null || entry === undefined) return '';
        if (typeof entry === 'string' || typeof entry === 'number') return String(entry);
        if (typeof entry === 'object') {
            const fullName = entry.fullName || entry.full_name || entry.name || entry.player_name || entry.display_name || '';
            const pos = entry.pos || entry.position || '';
            const team = entry.team || entry.team_abbr || entry.teamAbbr || '';
            const parts = [];
            if (fullName) parts.push(String(fullName));
            if (pos) parts.push(String(pos));
            if (team) parts.push(String(team));
            if (parts.length > 0) {
                return parts.join(' · ');
            }
            const fallback = entry.id || entry.uuid || '';
            if (fallback) return String(fallback);
            try {
                return JSON.stringify(entry);
            } catch (err) {
                return String(entry);
            }
        }
        return String(entry);
    };

    let _udSlateWhitelistUuidToLabel = null; // uuid -> label (whitelist-derived via shorthand keys)
    let _udSlateWhitelistLoaded = false;
    let _udSlateFriendlyLabels = null; // uuid -> label (from static_settings.underdog_slate_friendly_labels)
    let _udSlateFriendlyLabelsLoaded = false;
    let _udExposureIncludedSlates = null;
    let _udExposureAggregateSlates = false;
    let _udActiveSlateTab = null; // slateId string or '__aggregated__'
    let _dkExposureIncludedSlates = null;
    let _dkActiveSlateTab = null; // draftGroupId string or '__aggregated__'
    let _dkSlateFriendlyLabels = null; // draftGroupId -> friendly label (from static_settings.draftkings_slate_friendly_labels)
    let _dkSlateFriendlyLabelsLoaded = false;

    // Exposure table sort state per site. Column is one of: 'name' | 'fees' | 'pct' | 'entries'.
    let _udExposureSort = { column: 'name', direction: 'asc' };
    let _dkExposureSort = { column: 'name', direction: 'asc' };

    const buildUnderdogWhitelistUuidToLabel = (staticSettings) => {
        const w = staticSettings?.underdog_slate_whitelist;
        if (!w || typeof w !== 'object' || Array.isArray(w)) {
            return {};
        }
        const FRIENDLY_UNDERDOG_SLAKE_LABELS = {
            ud_bbm: 'Regular Bestball',
            ud_sf: 'Superflex',
            ud_ww: 'Weekly Winners',
            ud_spr: 'Sprint',
            ud_mar: 'Marathon',
            ud_eli: 'Eliminator',
            ud_ppr: 'PPR',
            ud_tep: 'TEP'
        };
        const out = {};
        for (const [label, uuid] of Object.entries(w)) {
            if (!label || typeof uuid !== 'string' || !uuid.trim()) continue;
            const raw = String(label).trim();
            const nicer =
                Object.prototype.hasOwnProperty.call(FRIENDLY_UNDERDOG_SLAKE_LABELS, raw)
                    ? FRIENDLY_UNDERDOG_SLAKE_LABELS[raw]
                    : raw;
            out[String(uuid).trim()] = nicer;
        }
        return out;
    };

    const loadUnderdogSlateWhitelist = () => {
        if (_udSlateWhitelistLoaded) {
            return Promise.resolve(_udSlateWhitelistUuidToLabel || {});
        }
        _udSlateWhitelistLoaded = true;
        return sendPortRequest('GET_SETTINGS', { scope: 'content_script', keys: 'static_settings' })
            .then((response) => {
                const staticSettings = response?.settings?.static_settings || {};
                _udSlateWhitelistUuidToLabel = buildUnderdogWhitelistUuidToLabel(staticSettings);
                return _udSlateWhitelistUuidToLabel;
            })
            .catch((err) => {
                console.error('[settings] Failed to load static_settings for slate whitelist', err);
                _udSlateWhitelistUuidToLabel = {};
                return _udSlateWhitelistUuidToLabel;
            });
    };

    // UD friendly labels: { "<slate_uuid>": "<label>" } from static_settings.underdog_slate_friendly_labels.
    // Takes precedence over the whitelist-derived label so legacy/retired slate UUIDs can be labeled
    // without being part of the active whitelist.
    const buildUnderdogFriendlyLabelsMap = (staticSettings) => {
        const w = staticSettings?.underdog_slate_friendly_labels;
        if (!w || typeof w !== 'object' || Array.isArray(w)) {
            return {};
        }
        const out = {};
        for (const [uuid, label] of Object.entries(w)) {
            if (uuid == null || label == null) continue;
            const idStr = String(uuid).trim();
            const labelStr = String(label).trim();
            if (!idStr || !labelStr) continue;
            out[idStr] = labelStr;
        }
        return out;
    };

    const loadUnderdogSlateFriendlyLabels = () => {
        if (_udSlateFriendlyLabelsLoaded) {
            return Promise.resolve(_udSlateFriendlyLabels || {});
        }
        _udSlateFriendlyLabelsLoaded = true;
        return sendPortRequest('GET_SETTINGS', { scope: 'content_script', keys: 'static_settings' })
            .then((response) => {
                const staticSettings = response?.settings?.static_settings || {};
                _udSlateFriendlyLabels = buildUnderdogFriendlyLabelsMap(staticSettings);
                return _udSlateFriendlyLabels;
            })
            .catch((err) => {
                console.error('[settings] Failed to load static_settings for UD slate friendly labels', err);
                _udSlateFriendlyLabels = {};
                return _udSlateFriendlyLabels;
            });
    };

    // Single resolver for UD slate display: friendly-labels dict > whitelist-derived label > Unknown Slate.
    const resolveUdSlateTabLabel = (slateId) => {
        const idStr = slateId == null ? '' : String(slateId).trim();
        if (!idStr || idStr === 'legacy') return 'Legacy / unknown slate';
        const friendly =
            _udSlateFriendlyLabels && _udSlateFriendlyLabels[idStr]
                ? String(_udSlateFriendlyLabels[idStr]).trim()
                : '';
        if (friendly) return friendly;
        const fromWhitelist =
            _udSlateWhitelistUuidToLabel && _udSlateWhitelistUuidToLabel[idStr]
                ? String(_udSlateWhitelistUuidToLabel[idStr]).trim()
                : '';
        if (fromWhitelist) return fromWhitelist;
        return `Unknown Slate (${idStr.slice(0, 8)}…)`;
    };

    // DraftKings: friendly slate labels live in remote `static_settings.draftkings_slate_friendly_labels`
    // shaped { "<draftGroupId>": "<label>" }. Decoupled from `draftkings_slate_whitelist` so legacy
    // draft groups can be labeled without being part of the active whitelist.
    const buildDraftKingsFriendlyLabelsMap = (staticSettings) => {
        const w = staticSettings?.draftkings_slate_friendly_labels;
        if (!w || typeof w !== 'object' || Array.isArray(w)) {
            return {};
        }
        const out = {};
        for (const [slateId, label] of Object.entries(w)) {
            if (slateId == null || label == null) continue;
            const idStr = String(slateId).trim();
            const labelStr = String(label).trim();
            if (!idStr || !labelStr) continue;
            out[idStr] = labelStr;
        }
        return out;
    };

    const loadDraftKingsSlateFriendlyLabels = () => {
        if (_dkSlateFriendlyLabelsLoaded) {
            return Promise.resolve(_dkSlateFriendlyLabels || {});
        }
        _dkSlateFriendlyLabelsLoaded = true;
        return sendPortRequest('GET_SETTINGS', { scope: 'content_script', keys: 'static_settings' })
            .then((response) => {
                const staticSettings = response?.settings?.static_settings || {};
                _dkSlateFriendlyLabels = buildDraftKingsFriendlyLabelsMap(staticSettings);
                return _dkSlateFriendlyLabels;
            })
            .catch((err) => {
                console.error('[settings] Failed to load static_settings for DK slate friendly labels', err);
                _dkSlateFriendlyLabels = {};
                return _dkSlateFriendlyLabels;
            });
    };

    const resolveDkSlateTabLabel = (slateId, slateEnt) => {
        const idStr = slateId == null ? '' : String(slateId).trim();
        const friendly =
            _dkSlateFriendlyLabels && idStr && _dkSlateFriendlyLabels[idStr]
                ? String(_dkSlateFriendlyLabels[idStr]).trim()
                : '';
        if (friendly) return friendly;
        if (slateEnt && slateEnt.label != null && String(slateEnt.label).trim()) {
            return String(slateEnt.label).trim();
        }
        return idStr ? 'Draft Group ' + idStr : 'Unknown Draft Group';
    };

    const mergeUdExposureByIdForDisplay = (buckets) => {
        const out = {};
        if (!Array.isArray(buckets) || buckets.length === 0) return out;
        for (let bi = 0; bi < buckets.length; bi++) {
            const byId = buckets[bi] && typeof buckets[bi] === 'object' ? buckets[bi] : null;
            if (!byId || typeof byId !== 'object') continue;
            for (const [id, row] of Object.entries(byId)) {
                if (!id) continue;
                const r = row && typeof row === 'object' ? row : null;
                if (!r) continue;
                const prev = out[id] && typeof out[id] === 'object' ? out[id] : {};
                const next = { ...prev };
                // Aggregate fees across slates.
                const pf = Number(prev.ud_entry_fees);
                const nf = Number(r.ud_entry_fees);
                if (Number.isFinite(nf)) {
                    next.ud_entry_fees = (Number.isFinite(pf) ? pf : 0) + nf;
                }
                // Aggregate pick_count across slates (enables accurate percent synthesis).
                const ppc = Number(prev.ud_pick_count);
                const npc = Number(r.ud_pick_count);
                if (Number.isFinite(npc)) {
                    next.ud_pick_count = (Number.isFinite(ppc) ? ppc : 0) + npc;
                }
                if (!next.full_name && r.full_name) next.full_name = r.full_name;
                if (!next.position && r.position) next.position = r.position;
                if (!next.team && r.team) next.team = r.team;
                out[id] = next;
            }
        }
        return out;
    };

    const renderExposureSitePane = (site, storage) => {
        const metaId = site === 'underdog' ? 'ud_exposure_meta' : 'dk_exposure_meta';
        const listId = site === 'underdog' ? 'ud_exposure_list' : 'dk_exposure_list';
        const metaEl = document.getElementById(metaId);
        const listEl = document.getElementById(listId);
        if (!metaEl || !listEl) return;
        let byId = storage && typeof storage.by_id === 'object' ? storage.by_id : {};
        let tsKey = site === 'underdog' ? 'ud_last_updated_ms' : 'dk_last_updated_ms';
        let ts = storage && storage[tsKey];

        // Underdog: tab bar (per-slate + aggregated) + aggregate toggle checklist.
        if (site === 'underdog') {
            const tabsEl = document.getElementById('ud_exposure_tabs');
            const slateBox = document.getElementById('ud_exposure_slates');
            const udBySlate =
                storage && storage.ud_by_slate && typeof storage.ud_by_slate === 'object' ? storage.ud_by_slate : {};
            const sortedSlateIds = Object.keys(udBySlate)
                .slice()
                .sort((a, b) => (Number(udBySlate[b]?.ud_last_updated_ms) || 0) - (Number(udBySlate[a]?.ud_last_updated_ms) || 0));

            // Default active tab to most recent slate, or aggregated if no slates
            if (!_udActiveSlateTab || (_udActiveSlateTab !== '__aggregated__' && !udBySlate[_udActiveSlateTab])) {
                _udActiveSlateTab = sortedSlateIds.length > 0 ? sortedSlateIds[0] : '__aggregated__';
            }

            // Build tab bar
            if (tabsEl) {
                tabsEl.replaceChildren();
                if (sortedSlateIds.length > 0) {
                    tabsEl.hidden = false;
                    sortedSlateIds.forEach((slateId) => {
                        const label = resolveUdSlateTabLabel(slateId);
                        const btn = document.createElement('button');
                        btn.type = 'button';
                        btn.className = 'exposure-tab' + (slateId === _udActiveSlateTab ? ' active' : '');
                        btn.textContent = label;
                        btn.addEventListener('click', () => {
                            _udActiveSlateTab = slateId;
                            renderExposureSitePane('underdog', storage);
                        });
                        tabsEl.appendChild(btn);
                    });
                    const aggBtn = document.createElement('button');
                    aggBtn.type = 'button';
                    aggBtn.className = 'exposure-tab' + (_udActiveSlateTab === '__aggregated__' ? ' active' : '');
                    aggBtn.textContent = 'Aggregated';
                    aggBtn.addEventListener('click', () => {
                        _udActiveSlateTab = '__aggregated__';
                        renderExposureSitePane('underdog', storage);
                    });
                    tabsEl.appendChild(aggBtn);
                } else {
                    tabsEl.hidden = true;
                }
            }

            // Override byId and ts based on active tab
            if (_udActiveSlateTab !== '__aggregated__' && udBySlate[_udActiveSlateTab]) {
                const slateData = udBySlate[_udActiveSlateTab];
                byId = slateData.by_id && typeof slateData.by_id === 'object' ? slateData.by_id : {};
                ts = slateData.ud_last_updated_ms != null ? slateData.ud_last_updated_ms : ts;
            }

            // Per-slate checklist (enabled only when aggregation mode is not default)
            if (slateBox) {
                const included = _udExposureIncludedSlates && typeof _udExposureIncludedSlates === 'object' ? _udExposureIncludedSlates : {};
                slateBox.replaceChildren();
                slateBox.hidden = sortedSlateIds.length === 0;

                if (sortedSlateIds.length > 0) {
                    const slateLabel = document.createElement('span');
                    slateLabel.className = 'exposure-slate-checklist-label';
                    slateLabel.textContent = 'Slates to use for aggregated:';
                    slateBox.appendChild(slateLabel);
                }

                sortedSlateIds.forEach((slateId) => {
                    const label = resolveUdSlateTabLabel(slateId);
                    const row = document.createElement('label');
                    row.className = 'checkbox-row';
                    const cb = document.createElement('input');
                    cb.type = 'checkbox';
                    cb.className = 'ud-slate-include-cb';
                    cb.checked = Object.prototype.hasOwnProperty.call(included, slateId) ? !!included[slateId] : true;
                    cb.addEventListener('change', () => {
                        const next = { ...included, [slateId]: !!cb.checked };
                        sendPortRequest('SET_SETTINGS', {
                            scope: 'content_script',
                            settings: { ud_exposure_included_slates: next, tag_icon_exposure: true }
                        }).catch((err) => console.error('[settings] Failed to update ud exposure slate include map', err));
                    });
                    const span = document.createElement('span');
                    span.textContent = label;
                    row.appendChild(cb);
                    row.appendChild(span);
                    slateBox.appendChild(row);
                });
            }
        }

        if (site === 'draftkings') {
            const tabsEl = document.getElementById('dk_exposure_tabs');
            const slateBox = document.getElementById('dk_exposure_slates');
            const dkBySlate =
                storage && storage.dk_by_slate && typeof storage.dk_by_slate === 'object' ? storage.dk_by_slate : {};
            const sortedSlateIds = Object.keys(dkBySlate)
                .slice()
                .sort((a, b) => (Number(dkBySlate[b]?.dk_last_updated_ms) || 0) - (Number(dkBySlate[a]?.dk_last_updated_ms) || 0));

            if (!_dkActiveSlateTab || (_dkActiveSlateTab !== '__aggregated__' && !dkBySlate[_dkActiveSlateTab])) {
                _dkActiveSlateTab = sortedSlateIds.length > 0 ? sortedSlateIds[0] : '__aggregated__';
            }

            if (tabsEl) {
                tabsEl.replaceChildren();
                if (sortedSlateIds.length > 0) {
                    tabsEl.hidden = false;
                    sortedSlateIds.forEach((slateId) => {
                        const slateEnt = dkBySlate[slateId];
                        const tabLabel = resolveDkSlateTabLabel(slateId, slateEnt);
                        const btn = document.createElement('button');
                        btn.type = 'button';
                        btn.className = 'exposure-tab' + (slateId === _dkActiveSlateTab ? ' active' : '');
                        btn.textContent = tabLabel;
                        btn.addEventListener('click', () => {
                            _dkActiveSlateTab = slateId;
                            renderExposureSitePane('draftkings', storage);
                        });
                        tabsEl.appendChild(btn);
                    });
                    const aggBtn = document.createElement('button');
                    aggBtn.type = 'button';
                    aggBtn.className = 'exposure-tab' + (_dkActiveSlateTab === '__aggregated__' ? ' active' : '');
                    aggBtn.textContent = 'Aggregated';
                    aggBtn.addEventListener('click', () => {
                        _dkActiveSlateTab = '__aggregated__';
                        renderExposureSitePane('draftkings', storage);
                    });
                    tabsEl.appendChild(aggBtn);
                } else {
                    tabsEl.hidden = true;
                }
            }

            if (_dkActiveSlateTab !== '__aggregated__' && dkBySlate[_dkActiveSlateTab]) {
                const slateData = dkBySlate[_dkActiveSlateTab];
                byId = slateData.by_id && typeof slateData.by_id === 'object' ? slateData.by_id : {};
                ts = slateData.dk_last_updated_ms != null ? slateData.dk_last_updated_ms : ts;
            }

            if (slateBox) {
                const included =
                    _dkExposureIncludedSlates && typeof _dkExposureIncludedSlates === 'object'
                        ? _dkExposureIncludedSlates
                        : {};
                slateBox.replaceChildren();
                slateBox.hidden = sortedSlateIds.length === 0;

                if (sortedSlateIds.length > 0) {
                    const slateLabel = document.createElement('span');
                    slateLabel.className = 'exposure-slate-checklist-label';
                    slateLabel.textContent = 'Slates to use for aggregated:';
                    slateBox.appendChild(slateLabel);
                }

                sortedSlateIds.forEach((slateId) => {
                    const slateEnt = dkBySlate[slateId];
                    const tabLabel = resolveDkSlateTabLabel(slateId, slateEnt);
                    const row = document.createElement('label');
                    row.className = 'checkbox-row';
                    const cb = document.createElement('input');
                    cb.type = 'checkbox';
                    cb.className = 'dk-slate-include-cb';
                    cb.checked = Object.prototype.hasOwnProperty.call(included, slateId) ? !!included[slateId] : true;
                    cb.addEventListener('change', () => {
                        const next = { ...included, [slateId]: !!cb.checked };
                        sendPortRequest('SET_SETTINGS', {
                            scope: 'content_script',
                            settings: { dk_exposure_included_slates: next, tag_icon_exposure: true }
                        }).catch((err) => console.error('[settings] Failed to update dk exposure slate include map', err));
                    });
                    const span = document.createElement('span');
                    span.textContent = tabLabel;
                    row.appendChild(cb);
                    row.appendChild(span);
                    slateBox.appendChild(row);
                });
            }
        }

        metaEl.replaceChildren();
        const helpP = document.createElement('p');
        helpP.className = 'rankings-hint exposure-meta-help';
        helpP.appendChild(document.createTextNode('To update exposure data, navigate to the '));
        const exposureLink = document.createElement('a');
        exposureLink.href = EXPOSURE_PAGE_HELP_URL[site] || '#';
        exposureLink.target = '_blank';
        exposureLink.rel = 'noopener noreferrer';
        exposureLink.textContent = 'exposure page';
        helpP.appendChild(exposureLink);
        helpP.appendChild(document.createTextNode(' and view your exposures.'));
        metaEl.appendChild(helpP);
        const updatedLine = document.createElement('div');
        updatedLine.className = 'exposure-meta-updated';
        if (ts == null || !Number.isFinite(Number(ts))) {
            updatedLine.textContent = 'Last updated: never';
        } else {
            updatedLine.textContent = 'Last updated: ' + new Date(Number(ts)).toLocaleString();
        }
        metaEl.appendChild(updatedLine);
        listEl.replaceChildren();
        const feesKey = site === 'underdog' ? 'ud_entry_fees' : 'dk_entry_fees';
        const pickKey = site === 'underdog' ? 'ud_pick_count' : site === 'draftkings' ? 'dk_pick_count' : null;
        let udDenom = site === 'underdog' ? Number(storage?.ud_draft_count) : NaN;
        if (site === 'underdog' && _udActiveSlateTab !== '__aggregated__') {
            const slateData = storage?.ud_by_slate?.[_udActiveSlateTab];
            if (slateData) udDenom = Number(slateData.draft_count);
        }
        let dkDenom = site === 'draftkings' ? Number(storage?.dk_total_entries) : NaN;
        if (site === 'draftkings' && _dkActiveSlateTab && _dkActiveSlateTab !== '__aggregated__') {
            const dkSlate = storage?.dk_by_slate?.[_dkActiveSlateTab];
            if (dkSlate && dkSlate.total_entries != null) dkDenom = Number(dkSlate.total_entries);
        }
        const exposureLabelFromRow = (row, fallbackId) => {
            if (!row || typeof row !== 'object') {
                return fallbackId;
            }
            const name = row.full_name != null ? String(row.full_name).trim() : '';
            const pos = row.position != null ? String(row.position).trim() : '';
            const team = row.team != null ? String(row.team).trim() : '';
            const parts = [];
            if (name) parts.push(name);
            if (pos) parts.push(pos);
            if (team) parts.push(team);
            return parts.length ? parts.join(' · ') : fallbackId;
        };
        const normalizeNameForSort = (name) => {
            const s = name == null ? '' : String(name).trim();
            return s;
        };
        const firstNameSortKey = (name) => {
            const s = normalizeNameForSort(name);
            if (!s) return '';
            const token = s.split(/\s+/).filter(Boolean)[0] || '';
            return token.toLocaleLowerCase();
        };
        const fullNameSortKey = (name) => normalizeNameForSort(name).toLocaleLowerCase();

        const allKeys = Object.keys(byId).sort();
        const matchingKeys = allKeys.filter((id) => {
            const row = byId[id];
            if (!row || typeof row !== 'object') {
                return false;
            }
            const nf = Number(row[feesKey]);
            const pc = pickKey ? Number(row[pickKey]) : NaN;
            if (site === 'underdog') {
                return Number.isFinite(nf) && Number.isFinite(pc) && Number.isFinite(udDenom) && udDenom > 0;
            }
            return Number.isFinite(pc) && Number.isFinite(dkDenom) && dkDenom > 0;
        });

        if (matchingKeys.length === 0) {
            const empty = document.createElement('div');
            empty.className = 'exposure-table-empty';
            empty.textContent =
                site === 'underdog'
                    ? 'No Underdog exposure data stored yet.'
                    : 'No DraftKings exposure data stored yet.';
            listEl.appendChild(empty);
            return;
        }

        // Build row records for sorting/display. NaN/missing numeric values are kept null
        // so they can be sorted last regardless of direction.
        const rowRecords = matchingKeys.map((id) => {
            const row = byId[id];
            const nf = Number(row && typeof row === 'object' ? row[feesKey] : NaN);
            const pc = pickKey ? Number(row && typeof row === 'object' ? row[pickKey] : NaN) : NaN;
            const denom = site === 'underdog' ? udDenom : dkDenom;
            let pctValue = null;
            let entries = null;
            if (Number.isFinite(pc) && Number.isFinite(denom) && denom > 0) {
                pctValue = (pc / denom) * 100;
                entries = pc;
            }
            return {
                id,
                player: exposureLabelFromRow(row, id),
                firstNameKey: firstNameSortKey(row?.full_name),
                fullNameKey: fullNameSortKey(row?.full_name),
                fees: Number.isFinite(nf) ? nf : null,
                pct: pctValue,
                entries,
                denom: Number.isFinite(denom) ? denom : null
            };
        });

        const sortState = site === 'underdog' ? _udExposureSort : _dkExposureSort;
        const cmpNumeric = (a, b, dir) => {
            const aMissing = a == null || !Number.isFinite(a);
            const bMissing = b == null || !Number.isFinite(b);
            if (aMissing && bMissing) return 0;
            if (aMissing) return 1;
            if (bMissing) return -1;
            return dir === 'asc' ? a - b : b - a;
        };
        const cmpName = (ra, rb, dir) => {
            const firstCmp = ra.firstNameKey.localeCompare(rb.firstNameKey);
            if (firstCmp !== 0) return dir === 'asc' ? firstCmp : -firstCmp;
            const fullCmp = ra.fullNameKey.localeCompare(rb.fullNameKey);
            if (fullCmp !== 0) return dir === 'asc' ? fullCmp : -fullCmp;
            return String(ra.id).localeCompare(String(rb.id));
        };
        const tieBreakName = (ra, rb) => cmpName(ra, rb, 'asc');
        rowRecords.sort((ra, rb) => {
            let primary = 0;
            switch (sortState.column) {
                case 'fees':
                    primary = cmpNumeric(ra.fees, rb.fees, sortState.direction);
                    break;
                case 'pct':
                    primary = cmpNumeric(ra.pct, rb.pct, sortState.direction);
                    break;
                case 'entries':
                    primary = cmpNumeric(ra.entries, rb.entries, sortState.direction);
                    break;
                case 'name':
                default:
                    primary = cmpName(ra, rb, sortState.direction);
                    break;
            }
            if (primary !== 0) return primary;
            return tieBreakName(ra, rb);
        });

        // Default sort direction picked when a column header is first clicked.
        // Numeric columns default to descending so the user sees the highest values first.
        const defaultDirectionFor = (col) => (col === 'name' ? 'asc' : 'desc');
        const setSortColumn = (col) => {
            const current = site === 'underdog' ? _udExposureSort : _dkExposureSort;
            let next;
            if (current.column === col) {
                next = { column: col, direction: current.direction === 'asc' ? 'desc' : 'asc' };
            } else {
                next = { column: col, direction: defaultDirectionFor(col) };
            }
            if (site === 'underdog') {
                _udExposureSort = next;
            } else {
                _dkExposureSort = next;
            }
            renderExposureSitePane(site, storage);
        };

        const table = document.createElement('table');
        table.className = 'exposure-table';

        const colgroup = document.createElement('colgroup');
        ['exposure-col-player', 'exposure-col-fees', 'exposure-col-pct', 'exposure-col-entries'].forEach((cls) => {
            const col = document.createElement('col');
            col.className = cls;
            colgroup.appendChild(col);
        });
        table.appendChild(colgroup);

        const thead = document.createElement('thead');
        const headerRow = document.createElement('tr');
        const columns = [
            { key: 'name', label: 'Player', align: 'left' },
            { key: 'fees', label: '$', align: 'right' },
            { key: 'pct', label: '%', align: 'right' },
            { key: 'entries', label: 'Entries', align: 'right' }
        ];
        columns.forEach((c) => {
            const th = document.createElement('th');
            th.className = 'exposure-th sortable';
            if (c.align === 'right') th.classList.add('numeric');
            if (sortState.column === c.key) th.classList.add('active');
            th.setAttribute('role', 'button');
            th.setAttribute('tabindex', '0');
            const labelSpan = document.createElement('span');
            labelSpan.className = 'exposure-th-label';
            labelSpan.textContent = c.label;
            const arrow = document.createElement('span');
            arrow.className = 'exposure-sort-arrow';
            if (sortState.column === c.key) {
                arrow.textContent = sortState.direction === 'asc' ? '▲' : '▼';
            } else {
                arrow.textContent = '';
            }
            th.appendChild(labelSpan);
            th.appendChild(arrow);
            th.addEventListener('click', () => setSortColumn(c.key));
            th.addEventListener('keydown', (ev) => {
                if (ev.key === 'Enter' || ev.key === ' ') {
                    ev.preventDefault();
                    setSortColumn(c.key);
                }
            });
            headerRow.appendChild(th);
        });
        thead.appendChild(headerRow);
        table.appendChild(thead);

        const tbody = document.createElement('tbody');
        rowRecords.forEach((rec) => {
            const tr = document.createElement('tr');

            const tdPlayer = document.createElement('td');
            tdPlayer.className = 'exposure-td-player';
            tdPlayer.textContent = rec.player;
            tr.appendChild(tdPlayer);

            const tdFees = document.createElement('td');
            tdFees.className = 'exposure-td-numeric';
            tdFees.textContent = rec.fees == null ? '—' : '$' + Math.round(rec.fees);
            tr.appendChild(tdFees);

            const tdPct = document.createElement('td');
            tdPct.className = 'exposure-td-numeric';
            tdPct.textContent = rec.pct == null ? '—' : Math.round(rec.pct) + '%';
            tr.appendChild(tdPct);

            const tdEntries = document.createElement('td');
            tdEntries.className = 'exposure-td-numeric exposure-td-entries';
            if (rec.entries == null) {
                tdEntries.textContent = '—';
            } else {
                const num = document.createElement('span');
                num.className = 'exposure-entries-num';
                num.textContent = String(Math.round(rec.entries));
                tdEntries.appendChild(num);
                if (Number.isFinite(rec.denom) && rec.denom > 0) {
                    const denom = document.createElement('span');
                    denom.className = 'exposure-entries-denom';
                    denom.textContent = '/' + Math.round(rec.denom);
                    tdEntries.appendChild(denom);
                }
            }
            tr.appendChild(tdEntries);

            tbody.appendChild(tr);
        });
        table.appendChild(tbody);

        listEl.appendChild(table);
    };

    const loadExposurePanes = () => {
        return Promise.all([
            loadUnderdogSlateWhitelist(),
            loadUnderdogSlateFriendlyLabels(),
            loadDraftKingsSlateFriendlyLabels(),
            sendPortRequest('GET_SETTINGS', { scope: 'content_script', keys: 'user_settings' }).catch(() => ({ settings: { user_settings: {} } })),
            sendPortRequest('GET_EXPOSURE_STORAGE')
        ])
            .then(([uuidToLabel, udFriendly, dkIdToLabel, settingsRes, response]) => {
                _udSlateWhitelistUuidToLabel = uuidToLabel || {};
                _udSlateFriendlyLabels = udFriendly || {};
                _dkSlateFriendlyLabels = dkIdToLabel || {};
                _udExposureIncludedSlates = settingsRes?.settings?.user_settings?.ud_exposure_included_slates || {};
                _dkExposureIncludedSlates = settingsRes?.settings?.user_settings?.dk_exposure_included_slates || {};
                _udExposureAggregateSlates = !!settingsRes?.settings?.user_settings?.ud_exposure_aggregate_slates;
                const storage = response?.exposure_storage || {};
                renderExposureSitePane('underdog', storage);
                renderExposureSitePane('draftkings', storage);
                return response;
            })
            .catch((err) => {
                console.error('[settings] Failed to load exposure storage', err);
                return null;
            });
    };

    const RANKINGS_SET_IDS = ['ud_bbm', 'dk_bbm'];
    const rankingsState = {
        entries: { ud_bbm: [], dk_bbm: [] },
        dirty: { ud_bbm: false, dk_bbm: false },
        dragSetName: null,
        dragFromIndex: null
    };

    const rankingSlateIdForUpload = (entry, setName) => {
        if (entry === null || entry === undefined) return '';
        if (typeof entry === 'string' || typeof entry === 'number') return String(entry).trim();
        if (typeof entry !== 'object') return '';
        const candidates = [];
        if (setName === 'dk_bbm') {
            candidates.push(entry.dk_id, entry.dkID, entry.dkId, entry.slateId, entry.slate_id);
        } else {
            candidates.push(entry.slateId, entry.slate_id, entry.ud_id, entry.udId);
        }
        candidates.push(entry.id, entry.Id, entry.ID, entry.uuid);
        for (let i = 0; i < candidates.length; i++) {
            if (candidates[i] != null && String(candidates[i]).trim()) {
                return String(candidates[i]).trim();
            }
        }
        return '';
    };

    const normalizeRankingsEntries = (dataset, setName) => {
        if (!dataset || typeof dataset !== 'object') return [];
        const rankings = dataset.rankings || dataset.players || dataset.items;
        let entries = [];
        if (Array.isArray(rankings)) {
            entries = rankings;
        } else if (rankings && typeof rankings === 'object') {
            entries = Object.values(rankings);
        }
        return entries
            .map((entry) => {
                if (typeof entry === 'string' || typeof entry === 'number') {
                    return { id: String(entry) };
                }
                return entry && typeof entry === 'object' ? entry : null;
            })
            .filter((entry) => entry && rankingSlateIdForUpload(entry, setName));
    };

    const rankingsPayloadFromEntries = (entries, setName) => {
        const out = [];
        for (let i = 0; i < entries.length && out.length < MAX_RANKINGS_ROWS; i++) {
            const id = rankingSlateIdForUpload(entries[i], setName);
            if (!id) continue;
            out.push({ id });
        }
        return out;
    };

    const setRankingsStatus = (setName, text) => {
        const el = document.getElementById(`${setName}_status`);
        if (el) el.textContent = text || '';
    };

    const updateRankingsSaveButton = (setName) => {
        const btn = document.getElementById(`${setName}_save_btn`);
        if (!btn) return;
        const dirty = !!rankingsState.dirty[setName];
        const hasRows = (rankingsState.entries[setName] || []).length > 0;
        btn.disabled = !dirty || !hasRows;
    };

    const updateRankingsCardMeta = (setName) => {
        const el = document.getElementById(`${setName}_card_meta`);
        if (!el) return;
        const count = (rankingsState.entries[setName] || []).length;
        const dirty = !!rankingsState.dirty[setName];
        if (!count) {
            el.textContent = 'No rankings';
            return;
        }
        el.textContent = dirty ? `${count} · unsaved order` : `${count} players`;
    };

    const markRankingsDirty = (setName, dirty) => {
        rankingsState.dirty[setName] = !!dirty;
        updateRankingsSaveButton(setName);
        updateRankingsCardMeta(setName);
    };

    const renderRankingsList = (setName) => {
        const listEl = document.getElementById(`${setName}_list`);
        if (!listEl) return;
        listEl.innerHTML = '';
        const entries = rankingsState.entries[setName] || [];
        if (!entries.length) {
            const li = document.createElement('li');
            li.className = 'empty-rankings';
            li.textContent = 'You do not have any custom rankings for this site.';
            listEl.appendChild(li);
            updateRankingsSaveButton(setName);
            updateRankingsCardMeta(setName);
            return;
        }
        entries.forEach((entry, idx) => {
            const label = getRankingLabel(entry);
            if (!label) return;
            const li = document.createElement('li');
            li.draggable = true;
            li.dataset.index = String(idx);
            li.dataset.setName = setName;

            const handle = document.createElement('span');
            handle.className = 'rank-handle';
            handle.setAttribute('aria-hidden', 'true');
            handle.textContent = '⋮⋮';

            const num = document.createElement('span');
            num.className = 'rank-num';
            num.textContent = `${idx + 1}.`;

            const labelEl = document.createElement('span');
            labelEl.className = 'rank-label';
            labelEl.textContent = label;

            li.appendChild(handle);
            li.appendChild(num);
            li.appendChild(labelEl);
            listEl.appendChild(li);
        });
        updateRankingsSaveButton(setName);
        updateRankingsCardMeta(setName);
    };

    const applyRankingsDataset = (setName, dataset) => {
        rankingsState.entries[setName] = normalizeRankingsEntries(dataset, setName);
        markRankingsDirty(setName, false);
        renderRankingsList(setName);
    };

    const applyRankingsDatasets = (datasets, options = {}) => {
        const onlySet = options.onlySetName || null;
        const src = datasets && typeof datasets === 'object' ? datasets : {};
        RANKINGS_SET_IDS.forEach((setName) => {
            if (onlySet && setName !== onlySet) return;
            applyRankingsDataset(setName, src[setName] || null);
        });
    };

    const reorderRankingsEntries = (setName, fromIndex, toIndex) => {
        const entries = rankingsState.entries[setName] || [];
        if (
            fromIndex === toIndex ||
            fromIndex < 0 ||
            toIndex < 0 ||
            fromIndex >= entries.length ||
            toIndex >= entries.length
        ) {
            return;
        }
        const next = entries.slice();
        const moved = next.splice(fromIndex, 1)[0];
        next.splice(toIndex, 0, moved);
        rankingsState.entries[setName] = next;
        markRankingsDirty(setName, true);
        renderRankingsList(setName);
    };

    const bindRankingsListDrag = (listEl) => {
        if (!listEl || listEl.dataset.dragBound === '1') return;
        listEl.dataset.dragBound = '1';

        listEl.addEventListener('dragstart', (event) => {
            const li = event.target.closest('li');
            if (!li || !listEl.contains(li) || li.classList.contains('empty-rankings')) return;
            const setName = li.dataset.setName;
            const fromIndex = Number(li.dataset.index);
            if (!setName || !Number.isFinite(fromIndex)) return;
            rankingsState.dragSetName = setName;
            rankingsState.dragFromIndex = fromIndex;
            li.classList.add('dragging');
            if (event.dataTransfer) {
                event.dataTransfer.effectAllowed = 'move';
                event.dataTransfer.setData('text/plain', String(fromIndex));
            }
        });

        listEl.addEventListener('dragend', (event) => {
            const li = event.target.closest('li');
            if (li) li.classList.remove('dragging');
            listEl.querySelectorAll('.drag-over').forEach((el) => el.classList.remove('drag-over'));
            rankingsState.dragSetName = null;
            rankingsState.dragFromIndex = null;
        });

        listEl.addEventListener('dragover', (event) => {
            const li = event.target.closest('li');
            if (!li || !listEl.contains(li) || li.classList.contains('empty-rankings')) return;
            event.preventDefault();
            listEl.querySelectorAll('.drag-over').forEach((el) => {
                if (el !== li) el.classList.remove('drag-over');
            });
            li.classList.add('drag-over');
            if (event.dataTransfer) event.dataTransfer.dropEffect = 'move';
        });

        listEl.addEventListener('dragleave', (event) => {
            const li = event.target.closest('li');
            if (!li || !listEl.contains(li)) return;
            if (event.relatedTarget && li.contains(event.relatedTarget)) return;
            li.classList.remove('drag-over');
        });

        listEl.addEventListener('drop', (event) => {
            event.preventDefault();
            const li = event.target.closest('li');
            if (!li || !listEl.contains(li) || li.classList.contains('empty-rankings')) return;
            li.classList.remove('drag-over');
            const setName = li.dataset.setName || rankingsState.dragSetName;
            const toIndex = Number(li.dataset.index);
            const fromIndex = rankingsState.dragFromIndex;
            if (!setName || !Number.isFinite(fromIndex) || !Number.isFinite(toIndex)) return;
            reorderRankingsEntries(setName, fromIndex, toIndex);
        });
    };

    const setSiteCardExpanded = (stackEl, cardName) => {
        if (!stackEl || (cardName !== 'rankings' && cardName !== 'exposure')) return;
        stackEl.dataset.expanded = cardName;
        stackEl.querySelectorAll('.site-card').forEach((card) => {
            const name = card.getAttribute('data-card');
            const expanded = name === cardName;
            card.setAttribute('data-state', expanded ? 'expanded' : 'collapsed');
            const toggle = card.querySelector('.site-card-toggle');
            if (toggle) toggle.setAttribute('aria-expanded', expanded ? 'true' : 'false');
        });
    };

    const wireSiteCardToggles = () => {
        document.querySelectorAll('.site-card-stack').forEach((stackEl) => {
            setSiteCardExpanded(stackEl, stackEl.dataset.expanded || 'exposure');
            stackEl.querySelectorAll('.site-card-toggle').forEach((btn) => {
                btn.addEventListener('click', () => {
                    const cardName = btn.getAttribute('data-expand');
                    if (!cardName || stackEl.dataset.expanded === cardName) return;
                    setSiteCardExpanded(stackEl, cardName);
                });
            });
        });
    };

    const soundEnabledCheckbox = document.getElementById('soundEnabledCheckbox');
    const resetDefaultsButton = document.getElementById('resetDefaultsButton');
    const tagIconQuarterbackCheckbox = document.getElementById('tagIconQuarterbackCheckbox');
    const tagIconTeammateCheckbox = document.getElementById('tagIconTeammateCheckbox');
    const tagIconExposureCheckbox = document.getElementById('tagIconExposureCheckbox');
    const tagIconWeek17Checkbox = document.getElementById('tagIconWeek17Checkbox');
    const tagIconByeOverlapCheckbox = document.getElementById('tagIconByeOverlapCheckbox');
    const tagIconR1ActiveCheckbox = document.getElementById('tagIconR1ActiveCheckbox');
    const tagIconConfChampOppCheckbox = document.getElementById('tagIconConfChampOppCheckbox');
    const tagIconCombinationUniquenessCheckbox = document.getElementById('tagIconCombinationUniquenessCheckbox');
    const tagIconDraftAvailabilityCheckbox = document.getElementById('tagIconDraftAvailabilityCheckbox');
    const tagIconCompactCheckbox = document.getElementById('tagIconCompactCheckbox');
    const tagIconHideInactiveCheckbox = document.getElementById('tagIconHideInactiveCheckbox');
    const tagIconExposureDisplayFieldset = document.getElementById('tagIconExposureDisplayFieldset');
    const EXPOSURE_DISPLAY_MODES = ['default', 'fees_only', 'percent_only'];
    const EXPOSURE_AGGREGATION_MODES = ['default', 'aggregate_within_site', 'aggregate_ud_dk'];
    const normalizeExposureDisplayMode = (v) => {
        const s = v == null ? 'default' : String(v);
        return EXPOSURE_DISPLAY_MODES.indexOf(s) !== -1 ? s : 'default';
    };
    const resolveExposureAggregationMode = (userSettings) => {
        const udAgg = !!userSettings.ud_exposure_aggregate_slates;
        const dkAgg = !!userSettings.dk_exposure_aggregate_slates;
        const cross = !!userSettings.exposure_aggregate_across_sites;
        if (cross) return 'aggregate_ud_dk';
        if (udAgg || dkAgg) return 'aggregate_within_site';
        return 'default';
    };
    const exposureAggregationModeToSettings = (mode) => {
        // 'aggregate_within_site' aggregates across all slates for whichever site the user is on.
        // We flip both per-site flags so the overlay/exposure pipeline aggregates on either site,
        // but leave exposure_aggregate_across_sites off so UD and DK totals stay separate.
        if (mode === 'aggregate_within_site') {
            return {
                ud_exposure_aggregate_slates: true,
                dk_exposure_aggregate_slates: true,
                exposure_aggregate_across_sites: false
            };
        }
        if (mode === 'aggregate_ud_dk') {
            return {
                ud_exposure_aggregate_slates: true,
                dk_exposure_aggregate_slates: true,
                exposure_aggregate_across_sites: true
            };
        }
        return {
            ud_exposure_aggregate_slates: false,
            dk_exposure_aggregate_slates: false,
            exposure_aggregate_across_sites: false
        };
    };
    const syncExposureDisplayFieldset = (userSettings = {}) => {
        if (!tagIconExposureDisplayFieldset) return;
        const expEnabled =
            userSettings.tag_icon_exposure === undefined ? false : !!userSettings.tag_icon_exposure;
        tagIconExposureDisplayFieldset.disabled = !expEnabled;
        const mode = normalizeExposureDisplayMode(userSettings.tag_icon_exposure_display);
        tagIconExposureDisplayFieldset.querySelectorAll('input[name="tagIconExposureDisplay"]').forEach((r) => {
            r.checked = r.value === mode;
        });
        const aggMode = resolveExposureAggregationMode(userSettings);
        tagIconExposureDisplayFieldset.querySelectorAll('input[name="exposureAggregationMode"]').forEach((r) => {
            r.checked = r.value === aggMode;
        });
    };
    const lowResourcesModeCheckbox = document.getElementById('lowResourcesModeCheckbox');
    const suppressNonfatalWarningNotificationsCheckbox = document.getElementById('suppressNonfatalWarningNotificationsCheckbox');
    const updateSoundPreference = (userSettings = {}) => {
        if (!soundEnabledCheckbox) return;
        soundEnabledCheckbox.checked = !!userSettings.user_sound_enabled;
    };
    const updateLowResourcesPreference = (userSettings = {}) => {
        if (!lowResourcesModeCheckbox) return;
        lowResourcesModeCheckbox.checked = !!userSettings.low_resources_mode;
    };
    const updateSuppressNonfatalWarningPreference = (userSettings = {}) => {
        if (!suppressNonfatalWarningNotificationsCheckbox) return;
        suppressNonfatalWarningNotificationsCheckbox.checked = !!userSettings.suppress_nonfatal_warning_notifications;
    };

    const loadSoundPreference = () => {
        if (!soundEnabledCheckbox) return;
        sendPortRequest('GET_SETTINGS', { scope: 'content_script', keys: 'user_settings' })
            .then((response) => {
                const user_settings = response?.settings?.user_settings || {};
                updateSoundPreference(user_settings);
            })
            .catch((err) => {
                console.error('[settings] Failed to load sound preference', err);
                soundEnabledCheckbox.checked = false;
            });
    };

    const persistSoundPreference = (checked) => {
        return sendPortRequest('SET_SETTINGS', {
            scope: 'content_script',
            settings: { user_sound_enabled: !!checked }
        });
    };

    if (soundEnabledCheckbox) {
        soundEnabledCheckbox.addEventListener('change', () => {
            const checked = !!soundEnabledCheckbox.checked;
            soundEnabledCheckbox.disabled = true;
            persistSoundPreference(checked)
                .catch((err) => {
                    console.error('[settings] Failed to update sound preference', err);
                    soundEnabledCheckbox.checked = !checked;
                })
                .finally(() => {
                    soundEnabledCheckbox.disabled = false;
                });
        });
    }

    const loadLowResourcesPreference = () => {
        if (!lowResourcesModeCheckbox) return;
        sendPortRequest('GET_SETTINGS', { scope: 'content_script', keys: 'user_settings' })
            .then((response) => {
                const user_settings = response?.settings?.user_settings || {};
                updateLowResourcesPreference(user_settings);
            })
            .catch((err) => {
                console.error('[settings] Failed to load low resources mode preference', err);
                lowResourcesModeCheckbox.checked = false;
            });
    };
    const persistLowResourcesPreference = (checked) => {
        return sendPortRequest('SET_SETTINGS', {
            scope: 'content_script',
            settings: { low_resources_mode: !!checked }
        });
    };
    if (lowResourcesModeCheckbox) {
        lowResourcesModeCheckbox.addEventListener('change', () => {
            const checked = !!lowResourcesModeCheckbox.checked;
            lowResourcesModeCheckbox.disabled = true;
            persistLowResourcesPreference(checked)
                .catch((err) => {
                    console.error('[settings] Failed to update low resources mode preference', err);
                    lowResourcesModeCheckbox.checked = !checked;
                })
                .finally(() => {
                    lowResourcesModeCheckbox.disabled = false;
                });
        });
    }

    const loadSuppressNonfatalWarningPreference = () => {
        if (!suppressNonfatalWarningNotificationsCheckbox) return;
        sendPortRequest('GET_SETTINGS', { scope: 'content_script', keys: 'user_settings' })
            .then((response) => {
                const user_settings = response?.settings?.user_settings || {};
                updateSuppressNonfatalWarningPreference(user_settings);
            })
            .catch((err) => {
                console.error('[settings] Failed to load suppress warnings preference', err);
                suppressNonfatalWarningNotificationsCheckbox.checked = false;
            });
    };
    const persistSuppressNonfatalWarningPreference = (checked) => {
        return sendPortRequest('SET_SETTINGS', {
            scope: 'content_script',
            settings: { suppress_nonfatal_warning_notifications: !!checked }
        });
    };
    if (suppressNonfatalWarningNotificationsCheckbox) {
        suppressNonfatalWarningNotificationsCheckbox.addEventListener('change', () => {
            const checked = !!suppressNonfatalWarningNotificationsCheckbox.checked;
            suppressNonfatalWarningNotificationsCheckbox.disabled = true;
            persistSuppressNonfatalWarningPreference(checked)
                .catch((err) => {
                    console.error('[settings] Failed to update suppress warnings preference', err);
                    suppressNonfatalWarningNotificationsCheckbox.checked = !checked;
                })
                .finally(() => {
                    suppressNonfatalWarningNotificationsCheckbox.disabled = false;
                });
        });
    }

    const tagIconSettings = [
        { key: 'tag_icon_compact', checkbox: tagIconCompactCheckbox, defaultValue: false },
        { key: 'tag_icon_quarterback', checkbox: tagIconQuarterbackCheckbox, defaultValue: true },
        { key: 'tag_icon_teammate', checkbox: tagIconTeammateCheckbox, defaultValue: true },
        { key: 'tag_icon_exposure', checkbox: tagIconExposureCheckbox, defaultValue: false },
        { key: 'tag_icon_week_17', checkbox: tagIconWeek17Checkbox, defaultValue: true },
        { key: 'tag_icon_bye_overlap', checkbox: tagIconByeOverlapCheckbox, defaultValue: true },
        { key: 'tag_icon_r1_active', checkbox: tagIconR1ActiveCheckbox, defaultValue: true },
        { key: 'tag_icon_conf_champ_opp', checkbox: tagIconConfChampOppCheckbox, defaultValue: true },
        { key: 'tag_icon_combination_uniqueness', checkbox: tagIconCombinationUniquenessCheckbox, defaultValue: false },
        { key: 'tag_icon_draft_availability', checkbox: tagIconDraftAvailabilityCheckbox, defaultValue: true },
        { key: 'tag_icon_hide_inactive', checkbox: tagIconHideInactiveCheckbox, defaultValue: false }
    ];

    const updateTagIconPreferences = (userSettings = {}) => {
        tagIconSettings.forEach(({ key, checkbox, defaultValue }) => {
            if (!checkbox) return;
            const value = userSettings[key];
            checkbox.checked = value === undefined ? !!defaultValue : !!value;
        });
        syncExposureDisplayFieldset(userSettings);
    };

    const loadTagIconPreferences = () => {
        const hasAnyCheckbox = tagIconSettings.some(({ checkbox }) => checkbox);
        if (!hasAnyCheckbox) return;
        sendPortRequest('GET_SETTINGS', { scope: 'content_script', keys: 'user_settings' })
            .then((response) => {
                const user_settings = response?.settings?.user_settings || {};
                updateTagIconPreferences(user_settings);
            })
            .catch((err) => {
                console.error('[settings] Failed to load tag icon preferences', err);
            });
    };

    const persistTagIconPreference = (key, checked) => {
        return sendPortRequest('SET_SETTINGS', {
            scope: 'content_script',
            settings: { [key]: !!checked }
        });
    };

    tagIconSettings.forEach(({ key, checkbox, defaultValue }) => {
        if (!checkbox) return;
        checkbox.checked = !!defaultValue;
        checkbox.addEventListener('change', () => {
            const checked = !!checkbox.checked;
            checkbox.disabled = true;
            persistTagIconPreference(key, checked)
                .catch((err) => {
                    console.error('[settings] Failed to update tag icon preference', err);
                    checkbox.checked = !checked;
                })
                .finally(() => {
                    checkbox.disabled = false;
                    if (key === 'tag_icon_exposure') {
                        syncExposureDisplayFieldset({
                            tag_icon_exposure: tagIconExposureCheckbox ? !!tagIconExposureCheckbox.checked : false,
                            tag_icon_exposure_display: normalizeExposureDisplayMode(
                                document.querySelector('input[name="tagIconExposureDisplay"]:checked')?.value
                            )
                        });
                    }
                });
        });
    });

    if (tagIconExposureDisplayFieldset) {
        tagIconExposureDisplayFieldset.addEventListener('change', (ev) => {
            const t = ev.target;
            if (!t) return;
            if (t.type === 'radio' && t.name === 'tagIconExposureDisplay') {
                if (!tagIconExposureCheckbox || !tagIconExposureCheckbox.checked) return;
                const value = normalizeExposureDisplayMode(t.value);
                tagIconExposureDisplayFieldset.disabled = true;
                sendPortRequest('SET_SETTINGS', {
                    scope: 'content_script',
                    settings: { tag_icon_exposure_display: value }
                })
                    .then((msg) => {
                        const us = msg?.settings?.user_settings || {};
                        syncExposureDisplayFieldset(us);
                    })
                    .catch((err) => {
                        console.error('[settings] Failed to update exposure display preference', err);
                        loadTagIconPreferences();
                    })
                    .finally(() => {
                        if (tagIconExposureDisplayFieldset && tagIconExposureCheckbox) {
                            const currentAggMode = document.querySelector('input[name="exposureAggregationMode"]:checked')?.value || 'default';
                            syncExposureDisplayFieldset({
                                tag_icon_exposure: !!tagIconExposureCheckbox.checked,
                                tag_icon_exposure_display: normalizeExposureDisplayMode(
                                    document.querySelector('input[name="tagIconExposureDisplay"]:checked')?.value
                                ),
                                ...exposureAggregationModeToSettings(currentAggMode)
                            });
                        }
                    });
                return;
            }
            if (t.type === 'radio' && t.name === 'exposureAggregationMode') {
                if (!tagIconExposureCheckbox || !tagIconExposureCheckbox.checked) return;
                const aggMode = EXPOSURE_AGGREGATION_MODES.includes(t.value) ? t.value : 'default';
                tagIconExposureDisplayFieldset.disabled = true;
                sendPortRequest('SET_SETTINGS', {
                    scope: 'content_script',
                    settings: exposureAggregationModeToSettings(aggMode)
                })
                    .then((msg) => {
                        const us = msg?.settings?.user_settings || {};
                        _udExposureAggregateSlates = !!us.ud_exposure_aggregate_slates;
                        syncExposureDisplayFieldset(us);
                        loadExposurePanes();
                    })
                    .catch((err) => {
                        console.error('[settings] Failed to update exposure aggregation mode', err);
                        loadTagIconPreferences();
                    })
                    .finally(() => {
                        if (tagIconExposureDisplayFieldset) tagIconExposureDisplayFieldset.disabled = false;
                    });
            }
        });
    }

    // Ghost overlay preference handlers (moved from popup)
    const ghostEnableButtonContainerCheckbox = document.getElementById('ghostEnableButtonContainerCheckbox');
    const ghostEnablePlayerCardCheckbox = document.getElementById('ghostEnablePlayerCardCheckbox');
    const ghostEnableDraftBoardCheckbox = document.getElementById('ghostEnableDraftBoardCheckbox');

    const updateGhostPreferences = (userSettings = {}) => {
        if (!ghostEnableButtonContainerCheckbox || !ghostEnablePlayerCardCheckbox || !ghostEnableDraftBoardCheckbox) return;
        ghostEnableButtonContainerCheckbox.checked = userSettings.ghost_enable_button_container !== false;
        ghostEnablePlayerCardCheckbox.checked = userSettings.ghost_enable_player_card === true;
        ghostEnableDraftBoardCheckbox.checked = userSettings.ghost_enable_draft_board === true;
    };

    const loadGhostPreferences = () => {
        if (!ghostEnableButtonContainerCheckbox || !ghostEnablePlayerCardCheckbox || !ghostEnableDraftBoardCheckbox) return;
        sendPortRequest('GET_SETTINGS', { scope: 'content_script', keys: 'user_settings' })
            .then((response) => {
                const user_settings = response?.settings?.user_settings || {};
                updateGhostPreferences(user_settings);
            })
            .catch((err) => {
                console.error('[settings] Failed to load ghost preferences', err);
                updateGhostPreferences({});
            });
    };

    const persistGhostPreference = (key, checked) => {
        return sendPortRequest('SET_SETTINGS', {
            scope: 'content_script',
            settings: { [key]: !!checked }
        });
    };

    if (ghostEnableButtonContainerCheckbox) {
        ghostEnableButtonContainerCheckbox.addEventListener('change', () => {
            const checked = !!ghostEnableButtonContainerCheckbox.checked;
            ghostEnableButtonContainerCheckbox.disabled = true;
            persistGhostPreference('ghost_enable_button_container', checked)
                .catch((err) => {
                    console.error('[settings] Failed to update ghost button container preference', err);
                    ghostEnableButtonContainerCheckbox.checked = !checked;
                })
                .finally(() => {
                    ghostEnableButtonContainerCheckbox.disabled = false;
                });
        });
    }

    if (ghostEnablePlayerCardCheckbox) {
        ghostEnablePlayerCardCheckbox.addEventListener('change', () => {
            const checked = !!ghostEnablePlayerCardCheckbox.checked;
            ghostEnablePlayerCardCheckbox.disabled = true;
            persistGhostPreference('ghost_enable_player_card', checked)
                .catch((err) => {
                    console.error('[settings] Failed to update ghost player card preference', err);
                    ghostEnablePlayerCardCheckbox.checked = !checked;
                })
                .finally(() => {
                    ghostEnablePlayerCardCheckbox.disabled = false;
                });
        });
    }

    if (ghostEnableDraftBoardCheckbox) {
        ghostEnableDraftBoardCheckbox.addEventListener('change', () => {
            const checked = !!ghostEnableDraftBoardCheckbox.checked;
            ghostEnableDraftBoardCheckbox.disabled = true;
            persistGhostPreference('ghost_enable_draft_board', checked)
                .catch((err) => {
                    console.error('[settings] Failed to update ghost draft board preference', err);
                    ghostEnableDraftBoardCheckbox.checked = !checked;
                })
                .finally(() => {
                    ghostEnableDraftBoardCheckbox.disabled = false;
                });
        });
    }

    const syncAllPreferencesFromUserSettings = (user_settings = {}) => {
        updateSoundPreference(user_settings);
        updateLowResourcesPreference(user_settings);
        updateSuppressNonfatalWarningPreference(user_settings);
        updateTagIconPreferences(user_settings);
        updateGhostPreferences(user_settings);
    };

    const SETTINGS_EXPORT_FORMAT = 'legup_sidekick_settings';
    const SETTINGS_EXPORT_VERSION = 1;

    const toastStatusOnButton = (btn, text, type, options = {}) => {
        if (!btn) return;
        const resetAfterMs = options.resetAfterMs != null ? Number(options.resetAfterMs) : 2200;
        if (!btn.dataset.defaultText) {
            btn.dataset.defaultText = btn.textContent || '';
        }
        if (btn.dataset.toastTimer) {
            clearTimeout(Number(btn.dataset.toastTimer));
            btn.dataset.toastTimer = '';
        }
        btn.textContent = text || btn.dataset.defaultText || '';
        btn.classList.remove('success', 'error', 'pending');
        if (type === 'success' || type === 'error' || type === 'pending') {
            btn.classList.add(type);
        }
        if (resetAfterMs > 0) {
            const timer = setTimeout(() => {
                btn.textContent = btn.dataset.defaultText || '';
                btn.classList.remove('success', 'error', 'pending');
                btn.dataset.toastTimer = '';
            }, resetAfterMs);
            btn.dataset.toastTimer = String(timer);
        }
    };

    const parseSettingsImportFile = (text) => {
        let data;
        try {
            data = JSON.parse(text);
        } catch (e) {
            return { error: 'Invalid JSON.' };
        }
        if (!data || typeof data !== 'object' || Array.isArray(data)) {
            return { error: 'Settings file must be a JSON object.' };
        }
        const us = data.user_settings;
        if (!us || typeof us !== 'object' || Array.isArray(us)) {
            return { error: 'Missing or invalid "user_settings" object.' };
        }
        return { user_settings: us };
    };

    const exportSettingsButton = document.getElementById('exportSettingsButton');
    if (exportSettingsButton) {
        exportSettingsButton.addEventListener('click', () => {
            exportSettingsButton.disabled = true;
            toastStatusOnButton(exportSettingsButton, 'Exporting…', 'pending', { resetAfterMs: 0 });
            sendPortRequest('GET_SETTINGS', { scope: 'content_script' })
                .then((response) => {
                    const user_settings = response?.settings?.user_settings || {};
                    const payload = {
                        format: SETTINGS_EXPORT_FORMAT,
                        version: SETTINGS_EXPORT_VERSION,
                        exported_at: new Date().toISOString(),
                        user_settings
                    };
                    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    const d = new Date();
                    const pad = (n) => String(n).padStart(2, '0');
                    const fname = `sidekick-settings-${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}.json`;
                    a.href = url;
                    a.download = fname;
                    a.rel = 'noopener';
                    document.body.appendChild(a);
                    a.click();
                    a.remove();
                    URL.revokeObjectURL(url);
                    toastStatusOnButton(exportSettingsButton, 'Exported', 'success');
                })
                .catch((err) => {
                    console.error('[settings] Failed to export settings', err);
                    toastStatusOnButton(exportSettingsButton, 'Export failed', 'error');
                })
                .finally(() => {
                    exportSettingsButton.disabled = false;
                });
        });
    }

    const importSettingsFileInput = document.getElementById('importSettingsFileInput');
    const importSettingsButton = document.getElementById('importSettingsButton');
    if (importSettingsButton && importSettingsFileInput) {
        importSettingsButton.addEventListener('click', () => {
            importSettingsFileInput.click();
        });
        importSettingsFileInput.addEventListener('change', () => {
            const file = importSettingsFileInput.files && importSettingsFileInput.files[0];
            if (!file) {
                return;
            }
            const reader = new FileReader();
            reader.onload = () => {
                const text = typeof reader.result === 'string' ? reader.result : '';
                const parsed = parseSettingsImportFile(text);
                if (parsed.error) {
                    toastStatusOnButton(importSettingsButton, 'Import failed', 'error');
                    importSettingsFileInput.value = '';
                    return;
                }
                importSettingsButton.disabled = true;
                toastStatusOnButton(importSettingsButton, 'Importing…', 'pending', { resetAfterMs: 0 });
                sendPortRequest('SET_SETTINGS', {
                    scope: 'content_script',
                    settings: { user_settings: parsed.user_settings }
                })
                    .then((response) => {
                        const user_settings = response?.settings?.user_settings || {};
                        syncAllPreferencesFromUserSettings(user_settings);
                        toastStatusOnButton(importSettingsButton, 'Imported', 'success');
                    })
                    .catch((err) => {
                        console.error('[settings] Failed to import settings', err);
                        toastStatusOnButton(importSettingsButton, 'Import failed', 'error');
                    })
                    .finally(() => {
                        importSettingsButton.disabled = false;
                        importSettingsFileInput.value = '';
                    });
            };
            reader.onerror = () => {
                toastStatusOnButton(importSettingsButton, 'Read failed', 'error');
                importSettingsFileInput.value = '';
            };
            reader.readAsText(file);
        });
    }

    if (resetDefaultsButton) {
        resetDefaultsButton.addEventListener('click', () => {
            resetDefaultsButton.disabled = true;
            showImportExportMessage('', '');
            sendPortRequest('RESET_SETTINGS_DEFAULTS')
                .then((response) => {
                    const user_settings = response?.settings?.user_settings || {};
                    syncAllPreferencesFromUserSettings(user_settings);
                })
                .catch((err) => {
                    console.error('[settings] Failed to reset defaults', err);
                })
                .finally(() => {
                    resetDefaultsButton.disabled = false;
                });
        });
    }

    const stopPortKeepalive = () => {
        if (keepaliveTimer) {
            clearInterval(keepaliveTimer);
            keepaliveTimer = null;
        }
        if (keepaliveWatchdogTimer) {
            clearTimeout(keepaliveWatchdogTimer);
            keepaliveWatchdogTimer = null;
        }
    };

    const resetPortKeepaliveWatchdog = () => {
        if (keepaliveWatchdogTimer) {
            clearTimeout(keepaliveWatchdogTimer);
            keepaliveWatchdogTimer = null;
        }
        keepaliveWatchdogTimer = setTimeout(() => {
            if (!port) return;
            const staleMs = lastHealthAck ? Date.now() - lastHealthAck : Infinity;
            if (staleMs >= KEEPALIVE_WATCHDOG_MS) {
                reconnectSettingsPort('watchdog');
            }
        }, KEEPALIVE_WATCHDOG_MS);
    };

    const startPortKeepalive = () => {
        stopPortKeepalive();
        keepaliveTimer = setInterval(() => {
            if (!port) return;
            try {
                port.postMessage({ action: 'SETTINGS_KEEPALIVE' });
                resetPortKeepaliveWatchdog();
            } catch (err) {
                reconnectSettingsPort('keepalive-failed');
            }
        }, KEEPALIVE_INTERVAL_MS);
        resetPortKeepaliveWatchdog();
    };

    const checkPortHealth = (reason) => {
        if (!port) {
            reconnectSettingsPort(reason || 'health-check');
            return;
        }

        const staleMs = lastHealthAck ? Date.now() - lastHealthAck : Infinity;
        if (staleMs > PORT_STALE_MS) {
            reconnectSettingsPort(`stale:${reason}`);
            return;
        }

        try {
            port.postMessage({ action: 'SETTINGS_KEEPALIVE' });
            resetPortKeepaliveWatchdog();
        } catch (err) {
            reconnectSettingsPort(`health-check-failed:${reason}`);
        }
    };

    const scheduleSettingsPortReconnect = (delayMs = 500) => {
        if (reconnectTimer) return;
        reconnectTimer = setTimeout(() => {
            reconnectTimer = null;
            connectSettingsPort();
        }, delayMs);
    };

    const reconnectSettingsPort = (reason) => {
        stopPortKeepalive();
        if (port) {
            if (pushMessageListener) {
                try { port.onMessage.removeListener(pushMessageListener); } catch {}
            }
            try { port.disconnect(); } catch {}
            port = null;
        }
        scheduleSettingsPortReconnect(500);
    };

    const refreshSettingsAfterReconnect = () => {
        sendPortRequest('GET_SETTINGS', { scope: 'content_script', keys: 'user_settings' })
            .then((response) => {
                const user_settings = response?.settings?.user_settings || {};
                syncAllPreferencesFromUserSettings(user_settings);
            })
            .catch((err) => {
                console.error('[settings] Failed to load user preferences after connect', err);
            });
        loadExposurePanes();
        sendPortRequest('GET_USER_RANKINGS_DATASETS', { refresh: true })
            .then((rankingsRes) => {
                if (rankingsRes && rankingsRes.datasets) {
                    applyRankingsDatasets(rankingsRes.datasets || {});
                }
            })
            .catch((err) => {
                console.error('[settings] Failed to reload rankings datasets after reconnect', err);
            });
    };

    const handlePortPushMessage = (request) => {
        if (request?.action === 'BG_KEEPALIVE_ACK' || request?.action === 'BG_PING') {
            lastHealthAck = Date.now();
            if (request?.action === 'BG_PING' && request.boot_id) {
                if (lastKnownBootId && request.boot_id !== lastKnownBootId) {
                    reconnectSettingsPort('boot-id-mismatch');
                    return;
                }
                lastKnownBootId = request.boot_id;
            }
            resetPortKeepaliveWatchdog();
            return;
        }

        if (request?.action === 'UPDATE_SETTINGS') {
            const userSettings = request?.settings?.user_settings || {};
            syncAllPreferencesFromUserSettings(userSettings);
            _udExposureIncludedSlates = userSettings.ud_exposure_included_slates || _udExposureIncludedSlates || {};
            _dkExposureIncludedSlates = userSettings.dk_exposure_included_slates || _dkExposureIncludedSlates || {};
            if (Object.prototype.hasOwnProperty.call(userSettings, 'ud_exposure_aggregate_slates')) {
                _udExposureAggregateSlates = !!userSettings.ud_exposure_aggregate_slates;
            }
            loadExposurePanes();
        }
        if (request?.action === 'UPDATE_EXPOSURE') {
            loadExposurePanes();
        }
    };

    const connectSettingsPort = () => {
        if (reconnectTimer) {
            clearTimeout(reconnectTimer);
            reconnectTimer = null;
        }

        if (port) {
            if (pushMessageListener) {
                try { port.onMessage.removeListener(pushMessageListener); } catch {}
            }
            try { port.disconnect(); } catch {}
            port = null;
        }
        stopPortKeepalive();

        try {
            port = chrome.runtime.connect({ name: 'settings_page' });
            if (chrome.runtime.lastError) {
                console.error('[settings] Failed to connect port:', chrome.runtime.lastError.message);
                port = null;
                scheduleSettingsPortReconnect(1000);
                return;
            }
        } catch (err) {
            console.error('[settings] Error connecting port:', err);
            port = null;
            scheduleSettingsPortReconnect(1000);
            return;
        }

        pushMessageListener = handlePortPushMessage;
        port.onMessage.addListener(pushMessageListener);
        port.onDisconnect.addListener(() => {
            port = null;
            stopPortKeepalive();
            scheduleSettingsPortReconnect(500);
        });

        lastHealthAck = Date.now();
        startPortKeepalive();
        refreshSettingsAfterReconnect();
    };

    const toastUploadStatusOnButton = (btn, text, type, options = {}) => {
        if (!btn) return;
        const resetAfterMs = options.resetAfterMs != null ? Number(options.resetAfterMs) : 2200;
        if (!btn.dataset.defaultText) {
            btn.dataset.defaultText = btn.textContent || 'Upload CSV';
        }
        if (btn.dataset.toastTimer) {
            clearTimeout(Number(btn.dataset.toastTimer));
            btn.dataset.toastTimer = '';
        }
        btn.textContent = text || btn.dataset.defaultText;
        btn.classList.remove('success', 'error', 'pending');
        if (type === 'success' || type === 'error' || type === 'pending') {
            btn.classList.add(type);
        }
        if (resetAfterMs > 0) {
            const timer = setTimeout(() => {
                btn.textContent = btn.dataset.defaultText || 'Upload CSV';
                btn.classList.remove('success', 'error', 'pending');
                btn.dataset.toastTimer = '';
            }, resetAfterMs);
            btn.dataset.toastTimer = String(timer);
        }
    };

    const showUploadErrorAlert = (message) => {
        const text = message ? String(message) : 'Upload failed.';
        window.alert(`Rankings upload failed:\n\n${text}`);
    };

    const uploadRankingsPayload = (setName, rankings) => {
        return sendPortRequest(
            'UPLOAD_CUSTOM_RANKINGS',
            { set_name: setName, rankings },
            { timeout: UPLOAD_REQUEST_TIMEOUT_MS }
        ).then((response) => {
            const datasets = response?.datasets || {};
            if (datasets[setName]) {
                applyRankingsDataset(setName, datasets[setName]);
            } else {
                applyRankingsDatasets(datasets, { onlySetName: setName });
            }
            return response;
        });
    };

    const doUploadRankings = (setName) => {
        const fileInput = document.getElementById(`${setName}_file`);
        const uploadBtn = document.getElementById(`${setName}_upload_btn`);
        if (!fileInput || !uploadBtn) return;
        const file = fileInput.files && fileInput.files[0];
        if (!file) return;

        toastUploadStatusOnButton(uploadBtn, 'Uploading…', 'pending', { resetAfterMs: 0 });
        uploadBtn.disabled = true;
        const reader = new FileReader();
        reader.onload = () => {
            const csvText = typeof reader.result === 'string' ? reader.result : '';
            const parsed = parseCsvToRankings(csvText);
            if (parsed.error) {
                toastUploadStatusOnButton(uploadBtn, 'Upload failed', 'error');
                showUploadErrorAlert(parsed.error);
                uploadBtn.disabled = false;
                fileInput.value = '';
                return;
            }
            if (parsed.rankings.length === 0) {
                toastUploadStatusOnButton(uploadBtn, 'No rows found', 'error');
                showUploadErrorAlert('No id values were found in the CSV. Add one slate id per row below the "id" header.');
                uploadBtn.disabled = false;
                fileInput.value = '';
                return;
            }
            uploadRankingsPayload(setName, parsed.rankings)
                .then(() => {
                    toastUploadStatusOnButton(uploadBtn, 'Saved', 'success');
                    setRankingsStatus(setName, `Uploaded ${parsed.rankings.length} rows.`);
                })
                .catch((err) => {
                    let msg = err && err.message ? String(err.message) : 'Upload failed';
                    msg = msg.replace(/<[^>]+>/g, ' ').trim();
                    if (err?.datasets && err.datasets[setName]) {
                        applyRankingsDataset(setName, err.datasets[setName]);
                    }
                    toastUploadStatusOnButton(
                        uploadBtn,
                        err?.uploaded ? 'Uploaded; refresh failed' : 'Upload failed',
                        'error'
                    );
                    setRankingsStatus(setName, msg || 'Upload failed.');
                    showUploadErrorAlert(msg || 'Upload failed.');
                })
                .finally(() => {
                    uploadBtn.disabled = false;
                    fileInput.value = '';
                });
        };
        reader.onerror = () => {
            toastUploadStatusOnButton(uploadBtn, 'Read failed', 'error');
            showUploadErrorAlert('Could not read the selected file. Please try selecting the CSV again.');
            uploadBtn.disabled = false;
            fileInput.value = '';
        };
        reader.readAsText(file);
    };

    const saveRankingsOrder = (setName) => {
        const saveBtn = document.getElementById(`${setName}_save_btn`);
        const payload = rankingsPayloadFromEntries(rankingsState.entries[setName] || [], setName);
        if (!payload.length) {
            setRankingsStatus(setName, 'Nothing to save.');
            return;
        }
        if (saveBtn) {
            toastUploadStatusOnButton(saveBtn, 'Saving…', 'pending', { resetAfterMs: 0 });
            saveBtn.disabled = true;
        }
        setRankingsStatus(setName, 'Saving…');
        uploadRankingsPayload(setName, payload)
            .then(() => {
                if (saveBtn) toastUploadStatusOnButton(saveBtn, 'Saved', 'success');
                setRankingsStatus(setName, 'Saved.');
            })
            .catch((err) => {
                let msg = err && err.message ? String(err.message) : 'Save failed';
                msg = msg.replace(/<[^>]+>/g, ' ').trim();
                if (saveBtn) {
                    toastUploadStatusOnButton(saveBtn, 'Save failed', 'error');
                }
                setRankingsStatus(setName, msg || 'Save failed.');
                showUploadErrorAlert(msg || 'Save failed.');
                updateRankingsSaveButton(setName);
            });
    };

    const wireCustomRankingsControls = () => {
        RANKINGS_SET_IDS.forEach((setName) => {
            const listEl = document.getElementById(`${setName}_list`);
            const fileInput = document.getElementById(`${setName}_file`);
            const uploadBtn = document.getElementById(`${setName}_upload_btn`);
            const saveBtn = document.getElementById(`${setName}_save_btn`);
            bindRankingsListDrag(listEl);
            if (uploadBtn && fileInput) {
                uploadBtn.addEventListener('click', () => fileInput.click());
                fileInput.addEventListener('change', () => doUploadRankings(setName));
            }
            if (saveBtn) {
                if (!saveBtn.dataset.defaultText) {
                    saveBtn.dataset.defaultText = saveBtn.textContent || 'Save order';
                }
                saveBtn.addEventListener('click', () => saveRankingsOrder(setName));
            }
            updateRankingsSaveButton(setName);
            updateRankingsCardMeta(setName);
        });
    };

    wireSiteCardToggles();
    wireCustomRankingsControls();

    document.addEventListener('visibilitychange', () => {
        if (!document.hidden) {
            checkPortHealth('visibility');
        }
    });
    window.addEventListener('focus', () => checkPortHealth('focus'));
    window.addEventListener('pageshow', () => checkPortHealth('pageshow'));

    connectSettingsPort();
});
